using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;

namespace EMTWebApp.AuthenticationandAuthorization.Views
{
    public class DefaultViewPresenter : Presenter<IDefaultView>
    {
        private IAuthenticationandAuthorizationController _controller;

        public DefaultViewPresenter([CreateNew] IAuthenticationandAuthorizationController controller)
        {
            this._controller = controller;
        }
    }
}
