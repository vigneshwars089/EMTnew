﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using System.Collections;

namespace EMTWebApp.AuthenticationandAuthorization.Views
{
    public class LoginPresenter : Presenter<ILoginView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        private AuthenticationandAuthorizationController _controller;
        public LoginPresenter([CreateNew] AuthenticationandAuthorizationController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        // TODO: Handle other view events and set state in the view

        public int Test(int a)
        {
            return _controller.Test(a);
        }
        public int ValidateLogin(string LoginId, string encryptPassword)
        {
            return _controller.ValidateLogin(LoginId, encryptPassword);
        }
        public int ValidateADLogin(string LoginId)
        {
            return _controller.ValidateADLogin(LoginId);
        }
        public int ValidateLogin(string LoginId)
        {
            return _controller.ValidateLogin(LoginId);
        }
        public IDataReader UserDetails(string loginId)
        {
            return _controller.UserDetails(loginId);
        }

        public int InsertSubscription(Hashtable hsparams) 
        {
            return _controller.InsertSubscription(hsparams);

        }
    }
}




