using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;

namespace EMTWebApp.AuthenticationandAuthorization
{
    public interface IAuthenticationandAuthorizationController
    {
        
    }
}
