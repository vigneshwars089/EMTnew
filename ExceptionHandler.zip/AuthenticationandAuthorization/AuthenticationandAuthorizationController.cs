using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using EMTWebApp.DataService.AuthenticationandAuthorization;
using System.Collections;

namespace EMTWebApp.AuthenticationandAuthorization
{
    public class AuthenticationandAuthorizationController : IAuthenticationandAuthorizationController
    {
        IAuthenticationandAuthorizationDataService _AuthenticationandAuthorizationDataService = new AuthenticationandAuthorizationDataService();
        
        //public AuthenticationandAuthorizationController()
        //{
            
        //}

        public int Test(int a)
        {
            return _AuthenticationandAuthorizationDataService.Test(a);
        }

        public int ValidateLogin(string LoginId, string encryptPassword)
        {
            return _AuthenticationandAuthorizationDataService.ValidateLogin(LoginId, encryptPassword);
        }
        public int ValidateADLogin(string LoginId)
        {
            return _AuthenticationandAuthorizationDataService.ValidateADLogin(LoginId);
        }
        public int ValidateLogin(string LoginId)
        {
            return _AuthenticationandAuthorizationDataService.ValidateLogin(LoginId);
        }
        public IDataReader UserDetails(string loginId)
        {
            return _AuthenticationandAuthorizationDataService.UserDetails(loginId);
        }
        public DataSet DisplayRole(String UserId)
        {
            return _AuthenticationandAuthorizationDataService.DisplayRole(UserId);
        }
        public int ValidateTL(string UserId)
        {
            return _AuthenticationandAuthorizationDataService.ValidateTL(UserId);
        }

        public int InsertSubscription(Hashtable hsparams)
        {
            return _AuthenticationandAuthorizationDataService.InsertSubscription(hsparams);

        }
    }
}
