using System;

namespace EMTWebApp.Configuration
{
    public interface IConfigurationController
    {
    }
}
