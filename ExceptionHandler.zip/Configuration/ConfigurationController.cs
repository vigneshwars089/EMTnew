using System;
using System.Data;
using System.Data.SqlClient;
using EMTWebApp.DataService.Configuration;
using System.Collections;


namespace EMTWebApp.Configuration
{
    public class ConfigurationController : IConfigurationController
    {
        IConfigurationDataService _ConfigurationDataService = new ConfigurationDataService();
        public ConfigurationController()
        {

        }

        public int ConfigureCountry(string CountryName, int Active, string LoginId)
        {
            return _ConfigurationDataService.ConfigureCountry(CountryName, Active, LoginId);
        }

        public DataSet GridCountryDetBind()
        {
            return _ConfigurationDataService.GridCountryDetBind();
        }

        public int UpdateCountry(string CountryId, string CountryName, int Active, string LoginId)
        {
            return _ConfigurationDataService.UpdateCountry(CountryId, CountryName, Active, LoginId);
        }

        public int MailBoxCreation(string EmailBox, string EmailAddrs, string EmailAddrsOpt, string MailFoldPath, string Domain, string UserId, string encryptConfirmPassword, string CountryName, string SubProcessId, string SLA, int Active, int QcReq,int IsApprovalRequired, int MailTrigger, string LoginId, string EMailid, int ReplyNotReq, int IsVocSurvey,int IsSkillBasedAllocation, int IsLocked, string TimeZone, string OffSet, bool isTimezone)
        {
            return _ConfigurationDataService.MailBoxCreation(EmailBox, EmailAddrs, EmailAddrsOpt, MailFoldPath, Domain, UserId, encryptConfirmPassword, CountryName, SubProcessId, SLA, Active, QcReq,IsApprovalRequired, MailTrigger, LoginId, EMailid, ReplyNotReq, IsVocSurvey,IsSkillBasedAllocation, IsLocked, TimeZone, OffSet,isTimezone);
        }

        public DataSet BindCountry()
        {
            return _ConfigurationDataService.BindCountry();
        }

        public DataSet BindSubProcessNames()
        {
            return _ConfigurationDataService.BindSubProcessNames();
        }

        public DataSet BindEmailBoxMailId()
        {
            return _ConfigurationDataService.BindEmailBoxMailId();
        }

        public DataSet GridMailBoxDetBind()
        {
            return _ConfigurationDataService.GridMailBoxDetBind();
        }

        public DataSet bindActiveUsers()
        {
            return _ConfigurationDataService.bindActiveUsers();
        }

        public int UpdateMailBoxDet(string MailBoxId, string EmailBox, string EmailAddrs, string EmailAddrsOpt, string MailFoldPath, string Domain, string UserId, string encryptConfirmPassword, string CountryName, string SubProcessId, string SLA, int Active, int QcReq,int IsApprovalRequired, int MailTrigger, string LoginId, string EMailid, int ReplyNotReq, int IsVocSurvey,int IsSkillBasedAllocation, int IsLocked, string TimeZone, string OffSet, bool isTimezone)
        {
            //Pranay 2nd January 2017---added parameter TimeZone 
            return _ConfigurationDataService.UpdateMailBoxDet(MailBoxId, EmailBox, EmailAddrs, EmailAddrsOpt, MailFoldPath, Domain, UserId, encryptConfirmPassword, CountryName, SubProcessId, SLA, Active, QcReq,IsApprovalRequired, MailTrigger, LoginId, EMailid, ReplyNotReq,IsVocSurvey,IsSkillBasedAllocation, IsLocked, TimeZone, OffSet, isTimezone);
        }

        public int ConfigureSubProcessNames(int CountryId, string SubProcessName, string ProcessOwnerId, int Active, string LoginId)
        {
            return _ConfigurationDataService.ConfigureSubProcessNames(CountryId, SubProcessName, ProcessOwnerId, Active, LoginId);
        }

        public DataSet GridSubProcessGroupsBind()
        {
            return _ConfigurationDataService.GridSubProcessGroupsBind();
        }

        public int UpdateSubProcessNames(int CountryId, string SubProcessId, string SubProcessName, string ProcessOwnerId, int Active, string LoginId, string PreSubProcessname)
        {
            return _ConfigurationDataService.UpdateSubProcessNames(CountryId, SubProcessId, SubProcessName, ProcessOwnerId, Active, LoginId, PreSubProcessname);
        }

        public int ConfigureHolidays(string Holiday, DateTime HolidayDate, int Active, string LoginId)
        {
            return _ConfigurationDataService.ConfigureHolidays(Holiday, HolidayDate, Active, LoginId);
        }

        public DataSet GridBindHolidayDet()
        {
            return _ConfigurationDataService.GridBindHolidayDet();
        }

        public int UpdateHoliday(string HolidayId, string Holiday, DateTime HolidayDate, int Active, string LoginId)
        {
            return _ConfigurationDataService.UpdateHoliday(HolidayId, Holiday, HolidayDate, Active, LoginId);
        }

        public DataSet GetSubProcessByCountryId(Hashtable htUserData)
        {
            return this._ConfigurationDataService.GetSubProcessByCountryId(htUserData);
        }

        public DataSet BindCountryForSubProcess()
        {
            return _ConfigurationDataService.BindCountryForSubProcess();
        }
    }
}
