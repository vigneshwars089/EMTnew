using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;

namespace EMTWebApp.Configuration.Views
{
    public class DefaultViewPresenter : Presenter<IDefaultView>
    {
        private IConfigurationController _controller;

        public DefaultViewPresenter([CreateNew] IConfigurationController controller)
        {
            this._controller = controller;
        }
    }
}
