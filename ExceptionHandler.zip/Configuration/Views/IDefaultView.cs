using System;
using System.Collections.Generic;
using System.Text;

namespace EMTWebApp.Configuration.Views
{
    public interface IDefaultView
    {
    }
}
