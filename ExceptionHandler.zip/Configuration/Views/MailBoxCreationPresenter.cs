﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using System.Data;
using System.Data.SqlClient;
using System.Collections;

namespace EMTWebApp.Configuration.Views
{
    public class MailBoxCreationPresenter : Presenter<IMailBoxCreationView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        private ConfigurationController _controller;
        public MailBoxCreationPresenter([CreateNew] ConfigurationController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        // TODO: Handle other view events and set state in the view
        
        public int MailBoxCreation(string EmailBox, string EmailAddrs, string EmailAddrsOpt, string MailFoldPath, string Domain, string UserId, string encryptConfirmPassword, string CountryName, string SubProcessId, string SLA, int Active, int QcReq,int IsApprovalRequired, int MailTrigger, string LoginId, string EMailid, int ReplyNotReq,int IsVocSurvey ,int IsSkillBasedAllocation, int IsLocked, string TimeZone, string OffSet,bool isTimezone)
        {
            return _controller.MailBoxCreation(EmailBox, EmailAddrs, EmailAddrsOpt, MailFoldPath, Domain, UserId, encryptConfirmPassword, CountryName, SubProcessId, SLA, Active, QcReq,IsApprovalRequired, MailTrigger, LoginId, EMailid, ReplyNotReq, IsVocSurvey,IsSkillBasedAllocation, IsLocked, TimeZone, OffSet, isTimezone);
        }

        public DataSet bindActiveUsers()
        {
            return _controller.bindActiveUsers();
        }

        public DataSet BindCountry()
        {
            return _controller.BindCountry();
        }

        public DataSet BindSubProcessNames()
        {
            return _controller.BindSubProcessNames();
        }

        public DataSet BindEmailBoxMailId()
        {
            return _controller.BindEmailBoxMailId();
        }

        public DataSet GridMailBoxDetBind()
        {
            return _controller.GridMailBoxDetBind();
        }

        //public int UpdateMailBoxDet(int MailBoxId, string EmailBox, string EmailAddrs, string MailFoldPath, string Domain, string UserId, string encryptConfirmPassword, string CountryName, int Active, int QcReq, int MailTrigger, string LoginId)
        //{
        //    return _controller.UpdateMailBoxDet(MailBoxId, EmailBox, EmailAddrs, MailFoldPath, Domain, UserId, encryptConfirmPassword, CountryName, Active, QcReq, MailTrigger, LoginId);
        //}
        public int UpdateMailBoxDet(string MailBoxId, string EmailBox, string EmailAddrs, string EmailAddrsOpt, string MailFoldPath, string Domain, string UserId, string encryptConfirmPassword, string CountryName, string SubProcessId, string SLA, int Active, int QcReq,int IsApprovalRequired, int MailTrigger, string LoginId, string EMailid, int ReplyNotReq, int IsVocSurvey,int IsSkillBasedAllocation, int IsLocked, string TimeZone, string OffSet, bool isTimezone)
        {
            //Pranay 2nd January 2017---added parameter TimeZone 
            return _controller.UpdateMailBoxDet(MailBoxId, EmailBox, EmailAddrs,EmailAddrsOpt, MailFoldPath, Domain, UserId, encryptConfirmPassword, CountryName, SubProcessId, SLA, Active, QcReq,IsApprovalRequired, MailTrigger, LoginId, EMailid, ReplyNotReq,IsVocSurvey,IsSkillBasedAllocation, IsLocked,TimeZone,OffSet, isTimezone);
        }

        public void GetSubProcessByCountryId(string userId, int roleId, int countryId)
        {
            Hashtable htCountryandUserData = new Hashtable();
            htCountryandUserData.Add("@USERID", userId);
            htCountryandUserData.Add("@ROLEID", roleId);
            htCountryandUserData.Add("@COUNTRYID", countryId);
            View.BindSubProcessByCountryId = this._controller.GetSubProcessByCountryId(htCountryandUserData);
            
        }



    }
}




