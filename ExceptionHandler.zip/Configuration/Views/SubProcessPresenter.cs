﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;

namespace EMTWebApp.Configuration.Views
{
    public class SubProcessPresenter : Presenter<ISubProcessView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        private ConfigurationController _controller;
        public SubProcessPresenter([CreateNew] ConfigurationController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        public int ConfigureSubProcessNames(int CountryId, string SubProcessName, string ProcessOwnerId, int Active, string LoginId)
        {
            return _controller.ConfigureSubProcessNames(CountryId, SubProcessName, ProcessOwnerId, Active, LoginId);
        }

        public DataSet GridSubProcessGroupsBind()
        {
            return _controller.GridSubProcessGroupsBind();
        }

        public int UpdateSubProcessNames(int CountryId,string SubProcessId, string SubProcessName, string ProcessOwnerId, int Active, string LoginId,string PreSubProcessname)
        {
            return _controller.UpdateSubProcessNames(CountryId, SubProcessId, SubProcessName, ProcessOwnerId, Active, LoginId, PreSubProcessname);
        }
        
        public DataSet BindCountry()
        {
            return _controller.BindCountry();
        }

        public DataSet BindCountryForSubProcess()
        {
            return _controller.BindCountryForSubProcess();
        }
    }
}




