﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;

namespace EMTWebApp.Configuration.Views
{
    public class HolidayPresenter : Presenter<IHolidayView>
    {


        private ConfigurationController _controller;
        public HolidayPresenter([CreateNew] ConfigurationController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        public int ConfigureHolidays(string Holiday, DateTime HolidayDate, int Active, string LoginId)
        {
            return _controller.ConfigureHolidays(Holiday, HolidayDate, Active, LoginId);
        }

        public DataSet GridBindHolidayDet()
        {
            return _controller.GridBindHolidayDet();
        }

        public int UpdateHoliday(string HolidayId, string Holiday, DateTime HolidayDate, int Active, string LoginId)
        {
            return _controller.UpdateHoliday(HolidayId, Holiday, HolidayDate, Active, LoginId);
        }
    }
}




