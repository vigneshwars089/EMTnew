﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.ComponentModel;
using Microsoft.Exchange.WebServices.Data;
using System.Collections;
using System.Reflection;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Data.Common;
using DigiOPS.TechFoundation.Security;
using System.Data.SqlClient;
using EMTWebApp.DataHelper;
using EMTWebApp.ExceptionHandler;
using System.Configuration;
using System.Security.Cryptography;


namespace EMTWebApp.Constants
{
    public static class HelperMethods
    {    
       public static string ReturnExtension(string fileName)
        {
            string fileExtension = (fileName.Substring((fileName.LastIndexOf(".") + 1), (fileName.Length - (fileName.LastIndexOf(".") + 1)))).ToLower();
            switch (fileExtension)
            {
                case "htm":
                case "html":
                case "log":
                    return "text/HTML";
                case "txt":
                    return "text/plain";

                case "xls":
                    return "application/vnd.ms-excel";
                case "pptx":
                case "csv":
                case "xlsx":
                    return "application/octet-stream";
                case "doc":
                    return "application/vnd.ms-word";
                case "docx":
                    return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                case "ppt":
                    return "application/mspowerpoint";
                case "tiff":
                case "tif":
                    return "tif";
                case "gif":
                    return "image/gif";
                case "jpg":
                case "jpeg":
                    return "image/jpeg";
                case "png":
                    return "image/png";
                case "bmp":
                    return "image/bmp";
                case "rtf":
                    return "application/rtf";
                case "aspx":
                    return "text/aspx";
                case "pdf":
                case "fdf":
                    return "pdf";
                case "mdi":
                    return "mdi";
                default:
                    return "application/octet-stream";
            }
        }
        public static bool ValidateAttachmentsSize(int ContentLength)
        {
            bool ReturnVal = true;
            if (ContentLength > 10485760) // Chk attachment size not exceed 10 MB
            {
                ReturnVal = false;
            }
            return ReturnVal;
        }
        public static string Concatenate(string str, string insertstr)
        {
            string retst = string.Empty;
            if (str.Contains("<body"))
            {
                int ln = str.Length;
                int pos = str.LastIndexOf("<body ");
                if (pos == -1)
                {
                    pos = str.LastIndexOf("<body");
                }
                int strlen = 0;

                if (ln > 0)
                {
                    for (int i = pos; i < ln; i++)
                    {
                        strlen = strlen + 1;
                        if (str[i] == '>')
                            break;
                    }
                    retst = str.Substring(0, pos + strlen) + insertstr + str.Substring(pos + strlen);

                }
            }
            else
            {
                retst = insertstr + str;
            }

            return retst;
        }
        public static byte[] GetBytes(string str)
        {
            return Encoding.ASCII.GetBytes(str);
            //byte[] bytes = new byte[str.Length * sizeof(char)];
            //System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            //return bytes;
        }
        public static DataTable ToDataTable<T>(this List<T> iList)
        {
            DataTable dataTable = new DataTable();
            PropertyDescriptorCollection propertyDescriptorCollection =
                TypeDescriptor.GetProperties(typeof(T));
            for (int i = 0; i < propertyDescriptorCollection.Count; i++)
            {
                PropertyDescriptor propertyDescriptor = propertyDescriptorCollection[i];
                Type type = propertyDescriptor.PropertyType;

                if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
                    type = Nullable.GetUnderlyingType(type);


                dataTable.Columns.Add(propertyDescriptor.Name, type);
            }
            object[] values = new object[propertyDescriptorCollection.Count];
            foreach (T iListItem in iList)
            {
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = propertyDescriptorCollection[i].GetValue(iListItem);
                }
                dataTable.Rows.Add(values);
            }
            return dataTable;
        }

        public static string EncryptCredentials(string loginvalue)
        {
            string resultValue = "";
            CryptInfo cryptInfo = new CryptInfo();
            SecurityFactory securityFactory = new SecurityFactory();
            string cipher = ConfigurationManager.AppSettings["ENCRYPTIONKEY"].ToString();
            cryptInfo.CryptKey = cipher;
            cryptInfo.ValueToCrypt = loginvalue;
            resultValue = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
            return resultValue;
        }


        public static string DecryptCredentials(string loginvalue)
        {
            string resultValue = "";
            CryptInfo cryptInfo = new CryptInfo();
            SecurityFactory securityFactory = new SecurityFactory();
            string cipher = ConfigurationManager.AppSettings["ENCRYPTIONKEY"].ToString();
            cryptInfo.CryptKey = cipher;
            cryptInfo.ValueToCrypt = loginvalue;
            resultValue = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
            return resultValue;
        }

        /// <summary>
        /// Method to encrypt string
        /// </summary>        
        ///<returns>string</returns>
        ///
        public static string EncryptString(string encryptionvalue)
        {
            string resultValue = "";
            CryptInfo cryptInfo = new CryptInfo();
            SecurityFactory securityFactory = new SecurityFactory();
            string encryptionmode = ConfigurationManager.AppSettings["ENCRYPT/DECRYPT"].ToString();
            string cipher = ConfigurationManager.AppSettings["ENCRYPTIONKEY"].ToString();
            if (encryptionmode == "ON")
            {
                cryptInfo.CryptKey = cipher;
                cryptInfo.ValueToCrypt = encryptionvalue;
                resultValue = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);                
            }
            else
            {
                resultValue = encryptionvalue;
            }
            return resultValue;
        }

        public static string GenerateSecureRandom()
        {
            int length = 10;
            string charSet = "1234567890";
            var charArray = charSet.ToArray();
            var bytes = new byte[length * 8];
            new RNGCryptoServiceProvider().GetBytes(bytes);
            var result = new char[length];
            for (int i = 0; i < length; i++)
            {
                ulong value = BitConverter.ToUInt64(bytes, i * 8);
                result[i] = charArray[value % (uint)charArray.Length];
            }
            return new string(result);
        }
        /// <summary>
        /// Method to decrypt string
        /// </summary>        
        ///<returns>string</returns>
        ///
        public static string DecryptString(string decryptionvalue)
        {
            string resultValue = "";
            CryptInfo cryptInfo = new CryptInfo();
            SecurityFactory securityFactory = new SecurityFactory();
            string encryptionmode = ConfigurationManager.AppSettings["ENCRYPT/DECRYPT"].ToString();
            string cipher = ConfigurationManager.AppSettings["ENCRYPTIONKEY"].ToString();
            if (encryptionmode == "ON")
            {
                cryptInfo.CryptKey = cipher;
                cryptInfo.ValueToCrypt = decryptionvalue;
                resultValue = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
            }
            else
            {
                resultValue = decryptionvalue;
            }
            return resultValue;
        }


        /// <summary>
        /// Method to encrypt Attachments
        /// </summary>        
        ///<returns>byte</returns>
        ///
        public static byte[] EncryptAttachments(byte[] encryptionvalue)
        {
            byte[] resultValue;
            CryptInfo cryptInfo = new CryptInfo();
            SecurityFactory securityFactory = new SecurityFactory();
            string encryptionmode = ConfigurationManager.AppSettings["ENCRYPT/DECRYPT"].ToString();
            string cipher = ConfigurationManager.AppSettings["ENCRYPTIONKEY"].ToString();
            if (encryptionmode == "ON")
            {
                cryptInfo.CryptKey = cipher;
                string actualFileContent = Convert.ToBase64String(encryptionvalue);
                cryptInfo.ValueToCrypt = actualFileContent;                                              
                actualFileContent = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
                resultValue = Convert.FromBase64String(actualFileContent);
            }
            else
            {
                resultValue = encryptionvalue;
            }
            return resultValue;
        }


        /// <summary>
        /// Method to decrypt Attachments
        /// </summary>        
        ///<returns>byte</returns>
        ///
        public static byte[] DecryptAttachments(byte[] encryptionvalue)
        {
            byte[] resultValue;
            CryptInfo cryptInfo = new CryptInfo();
            SecurityFactory securityFactory = new SecurityFactory();
            string encryptionmode = ConfigurationManager.AppSettings["ENCRYPT/DECRYPT"].ToString();
            string cipher = ConfigurationManager.AppSettings["ENCRYPTIONKEY"].ToString();
            if (encryptionmode == "ON")
            {
                cryptInfo.CryptKey = cipher;
                string actualFileContent = Convert.ToBase64String(encryptionvalue);
                cryptInfo.ValueToCrypt = actualFileContent;
                actualFileContent = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
                resultValue = Convert.FromBase64String(actualFileContent);
            }
            else
            {
                resultValue = encryptionvalue;
            }
            return resultValue;
        }
        

        /// <summary>
        /// Method to send an email
        /// </summary>
        /// <param name="CaseId">EMail will be send corresponding to this id</param>
        ///<returns>boolean</returns>
        ///
        public static IList SendMail(string MailBoxEmailId, string LoginEmailId, string Password, string ServiceURL,
            string EMailTo, string EMailCc, string EMailBcc, string Subject, string Body, IList fileCollection, long CaseId, int EMailType, int isHighimportance, string plainbody, out bool isSuccess, List<string> EmbedImgs, string SubjectwithoutCaseID, int MaxNo)
        {
            string cipher = ConfigurationManager.AppSettings["ENCRYPTIONKEY"].ToString();
            UserMailLog uml = new UserMailLog();
            UserErrorLog uel = new UserErrorLog();
            bool isVIP = false;
            IList FollowAttachment = null;
            CryptInfo cryptInfo = new CryptInfo();
            SecurityFactory securityFactory = new SecurityFactory();
            string encryptedValue;
            try
            {
                //Create an object to ExchangeService
                ExchangeService objService;

                if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2013_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2007_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2010")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2010_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010_SP1);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2010_SP2")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010_SP2);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2013")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013);
                }
                else
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                }
                //Create an object to EMailBox which we need to send emails
                Mailbox objCommonMailBox = new Mailbox(MailBoxEmailId);
                //Create an object to Drafte folder
                FolderId objDraftsFolder = new FolderId(WellKnownFolderName.Drafts, objCommonMailBox);
                //Create an object to Sentitems folder
                FolderId objSentItemsFolder = new FolderId(WellKnownFolderName.SentItems, objCommonMailBox);

                objService.Credentials = new WebCredentials(LoginEmailId, Password,"CTS");  //Assign Credentials

                objService.Url = new Uri(ServiceURL); //Assign Service URL
                objService.UseDefaultCredentials = false;
                //create an object for EmailMessage with Exchangeservice object
                EmailMessage objMessage = new EmailMessage(objService);

                DataTable dtVIP = GetVIPUsers();

                objMessage.From = MailBoxEmailId;
                //Add the recipients in the TO list
                if (EMailTo != string.Empty)
                {
                    string[] names = EMailTo.Split(';');
                    int length = names.Length;
                    string DuplicateNames = string.Empty;
                    for (int len = 0; len < length; len++)
                    {
                        if (names[len] != string.Empty)
                        {
                            names[len] = names[len].Replace(';', ' ').Trim();




                            List<string> lstUserList = new List<string>();
                            if (isVIP == false)
                            {
                                lstUserList = dtVIP.AsEnumerable().Where(r => names[len].ToLower().Equals(r.Field<string>("EmailAddress").ToLower()))
                        .Select(r => r.Field<string>("EmailAddress")).ToList();
                                if (lstUserList.Count > 0)
                                {
                                    if (!String.IsNullOrEmpty(lstUserList[0].ToString()))
                                    {
                                        isVIP = true;
                                    }
                                }
                            }


                            if (len == 0)
                            {
                                objMessage.ToRecipients.Add(names[len].Trim());
                                DuplicateNames = names[len].Trim();
                            }
                            else if (!DuplicateNames.Contains(names[len]))
                            {
                                objMessage.ToRecipients.Add(names[len].Trim());
                                DuplicateNames += "; " + names[len].Trim();
                            }
                        }
                    }
                }
                //Add the recipients in the CC list
                if (EMailCc != string.Empty)
                {
                    string[] names = EMailCc.Split(';');
                    int length = names.Length;
                    string DuplicateNames = string.Empty;
                    for (int len = 0; len < length; len++)
                    {
                        if (names[len] != string.Empty)
                        {

                            names[len] = names[len].Replace(';', ' ').Trim();

                            List<string> lstUserList = new List<string>();

                            if (isVIP == false)
                            {
                                lstUserList = dtVIP.AsEnumerable().Where(r => names[len].Equals(r.Field<string>("EmailAddress")))
                        .Select(r => r.Field<string>("EmailAddress")).ToList();
                                if (lstUserList.Count > 0)
                                {
                                    if (!String.IsNullOrEmpty(lstUserList[0].ToString()))
                                    {
                                        isVIP = true;
                                    }
                                }
                            }


                            if (len == 0)
                            {
                                objMessage.CcRecipients.Add(names[len].Trim());
                                DuplicateNames = names[len].Trim();
                            }
                            else if (!DuplicateNames.Contains(names[len]))
                            {
                                objMessage.CcRecipients.Add(names[len].Trim());
                                DuplicateNames += "; " + names[len].Trim();
                            }
                        }
                    }
                }


                //Add the recipents in Bcc list
                if (EMailBcc != string.Empty)
                {
                    string[] names = EMailBcc.Split(';');
                    int length = names.Length;
                    string DuplicateNames = string.Empty;
                    for (int len = 0; len < length; len++)
                    {
                        if (names[len] != string.Empty)
                        {
                            //names[len] = names[len].Replace(';', ' ').Trim();
                            //objMessage.CcRecipients.Add(names[len]);

                            names[len] = names[len].Replace(';', ' ').Trim();

                            if (len == 0)
                            {
                                objMessage.BccRecipients.Add(names[len].Trim());
                                DuplicateNames = names[len].Trim();
                            }
                            else if (!DuplicateNames.Contains(names[len]))
                            {
                                objMessage.BccRecipients.Add(names[len].Trim());
                                DuplicateNames += "; " + names[len].Trim();
                            }
                        }
                    }
                }

                //if (isHighimportance == 1)

                if (isHighimportance == 1 || isVIP)

                {
                    objMessage.Importance = Importance.High;
                }
                else
                {
                    objMessage.Importance = Importance.Normal;
                }
                //Inline Attachments
                if (EmbedImgs.Count > 0)
                {
                  
                    for (int i = 0; i < EmbedImgs.Count; i++)
                    {
                        byte[] imgbyte = Convert.FromBase64String(EmbedImgs[i].Replace(" ", "+").ToString());
                        string Name = "";
                        if (MaxNo > 99)
                            Name = "image" + MaxNo + ".png";
                        else if (MaxNo >= 10 && MaxNo <= 99)
                            Name = "image0" + MaxNo + ".png";
                        else
                            Name = "image00" + MaxNo + ".png";
                        FileAttachment attachment = objMessage.Attachments.AddFileAttachment(Name, imgbyte);
                       
                        attachment.IsInline = true;
                        attachment.ContentType = "PNG";
                        attachment.ContentId = Name;
                       
                        MaxNo = MaxNo + 1;
                    }
                }

                objMessage.Subject = Subject;
                objMessage.Body = Body; //EMail Body
                objMessage.Body.BodyType = BodyType.HTML;

                long totSize = 0;

                //Add Attachments to the EMail
                if (fileCollection != null)
                {
                    foreach (Attachment at in fileCollection)
                    {
                        if (at.FileName.Contains("cid:image") && at.FileName.Contains(".png"))
                        {
                            FileAttachment attachment = objMessage.Attachments.AddFileAttachment(at.FileName, at.FileContent);
                            //if (!ExVersion2007orNot) 
                            attachment.IsInline = true;

                            attachment.ContentType = "PNG";
                            attachment.ContentId = at.FileName.Replace("cid:", "");
                        }
                        else
                            objMessage.Attachments.AddFileAttachment(at.FileName, at.FileContent);
                    }
                }

                objMessage.Save(objDraftsFolder); //Save the message in drafts folder - to fix the attachment opening issue
                objMessage.SendAndSaveCopy(objSentItemsFolder); // Save the messgae in sentitems folder and send
                isSuccess = true;
                if (isSuccess)
                {
                    uml.HandleMailLog("Mail sent success! Sub: " + Subject + ". Mailbox: " + MailBoxEmailId);
                    FollowAttachment = CreateHTMLFile(MailBoxEmailId, EMailTo, EMailCc, Subject, Body, CaseId, objMessage);
                }
            }
            catch (Exception ex)
            {
                if (ex.Message == Constant.Unauthorized)
                {
                    LockEmail((int)Constant.EmailBoxType.LoginEmail, LoginEmailId);
                    uel.HandleError(ex, "", "Mail sent failure! Sub: " + Subject + ". Mailbox: " + MailBoxEmailId + " Locked.");
                }
                else if (ex.Message == Constant.NotFoundinStore)
                {
                    LockEmail((int)Constant.EmailBoxType.EmailBox, MailBoxEmailId);
                    uel.HandleError(ex, "", "Mail sent failure! Sub: " + Subject + ". Mailbox: " + MailBoxEmailId + " Locked.");
                }
                else if (ex.Message == "The message exceeds the maximum supported size.")
                {
                    throw ex;
                }
                else
                {
                    uel.HandleError(ex, "", "Mail sent failure! Sub: " + Subject + ". Mailbox: " + MailBoxEmailId + " Locked.");
                }
                isSuccess = false;
            }

            //Pranay 24 January 2017 changing DateTime.Now to DateTime.UtcNow  
            //ENCRYPTION
            //cryptInfo.CryptKey = cipherpassword;
            //cryptInfo.ValueToCrypt = Subject;
            //encryptedValue = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
            string EncryptedSubject = EncryptString(Subject);
            //cryptInfo.ValueToCrypt = Body;
            //encryptedValue = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
            string EncryptedBody = EncryptString(Body);
            //cryptInfo.ValueToCrypt = plainbody;
            //encryptedValue = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
            string Encryptedplainbody = EncryptString(plainbody);
            InsertEMailDetails(CaseId, EMailTo, EMailCc, EMailBcc, EncryptedSubject, EncryptedBody, EMailType, DateTime.UtcNow, isSuccess, Encryptedplainbody, isHighimportance, isVIP);
            return FollowAttachment;
        }

        public static bool ForgotPasswordSendMail(string MailBoxEmailId, string LoginEmailId, string MailBoxPassword, string ServiceURL,
           string To, string Subject, string Body)
        {
            bool IsSucceed = false;
            UserMailLog uml = new UserMailLog();
            UserErrorLog uel = new UserErrorLog();
            try
            {
                //Create an object to ExchangeService

                ExchangeService objService;

                if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2013_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2007_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2010")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2010_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010_SP1);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2010_SP2")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010_SP2);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2013")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013);
                }
                else
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                }


                //Create an object to EMailBox which we need to send emails
                Mailbox objCommonMailBox = new Mailbox(LoginEmailId);
                objService.Credentials = new WebCredentials(MailBoxEmailId, MailBoxPassword);  //Assign Credentials

                if (MailBoxEmailId.ToLower().Contains("@cognizant.com"))
                {
                    objService.Url = new Uri("https://mail.cognizant.com/ews/Exchange.asmx"); //Assign Service URL
                    objService = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                }
                else
                {
                    objService.Url = new Uri(ServiceURL); //Assign Service URL
                }

                objService.UseDefaultCredentials = false;
                //create an object for EmailMessage with Exchangeservice object
                EmailMessage objMessage = new EmailMessage(objService);
                objMessage.From = LoginEmailId;
                //Add the recipients in the TO list
                if (To != string.Empty)
                {
                    string[] names = To.Split(';');
                    int length = names.Length;
                    string DuplicateNames = string.Empty;
                    for (int len = 0; len < length; len++)
                    {
                        if (names[len] != string.Empty)
                        {
                            names[len] = names[len].Replace(';', ' ').Trim();
                            if (len == 0)
                            {
                                objMessage.ToRecipients.Add(names[len].Trim());
                                DuplicateNames = names[len].Trim();
                            }
                            else if (!DuplicateNames.Contains(names[len]))
                            {
                                objMessage.ToRecipients.Add(names[len].Trim());
                                DuplicateNames += "; " + names[len].Trim();
                            }
                        }
                    }
                }
                objMessage.Subject = Subject;
                objMessage.Body = Body; //EMail Body
                objMessage.Send();
                IsSucceed = true;
                if (IsSucceed)
                {
                    uml.HandleMailLog("Forgot password mail sent success! Sub: " + Subject + ". To: " + To + " Mailbox: " + LoginEmailId);
                }
            }
            catch (Exception ex)
            {
                if (ex.Message == Constant.Unauthorized)
                {
                    LockEmail((int)Constant.EmailBoxType.LoginEmail, MailBoxEmailId);
                }
                else if (ex.Message == Constant.NotFoundinStore)
                {
                    LockEmail((int)Constant.EmailBoxType.EmailBox, LoginEmailId);
                }

                IsSucceed = false;
                uel.HandleError(ex, "", "Forgot password mail sent failed! Sub: " + Subject + ". To: " + To + " Mailbox: " + LoginEmailId + " Locked.");
            }
            return IsSucceed;
        }
        public static bool TokenSendMail(string MailBoxEmailId, string LoginEmailId, string MailBoxPassword, string ServiceURL,
          string To, string Subject, string Body)
        {
            bool IsSucceed = false;
            UserMailLog uml = new UserMailLog();
            UserErrorLog uel = new UserErrorLog();
            try
            {
                //Create an object to ExchangeService

                ExchangeService objService;

                if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2013_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2007_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2010")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2010_SP1")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010_SP1);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2010_SP2")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2010_SP2);
                }
                else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2013")
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013);
                }
                else
                {
                    objService = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                }


                //Create an object to EMailBox which we need to send emails
                Mailbox objCommonMailBox = new Mailbox(LoginEmailId);
                objService.Credentials = new WebCredentials(MailBoxEmailId, MailBoxPassword);  //Assign Credentials

                if (MailBoxEmailId.ToLower().Contains("@cognizant.com"))
                {
                    objService.Url = new Uri("https://mail.cognizant.com/ews/Exchange.asmx"); //Assign Service URL
                    objService = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                }
                else
                {
                    objService.Url = new Uri(ServiceURL); //Assign Service URL
                }

                objService.UseDefaultCredentials = false;
                //create an object for EmailMessage with Exchangeservice object
                EmailMessage objMessage = new EmailMessage(objService);
                objMessage.From = LoginEmailId;
                //Add the recipients in the TO list
                if (To != string.Empty)
                {
                    string[] names = To.Split(';');
                    int length = names.Length;
                    string DuplicateNames = string.Empty;
                    for (int len = 0; len < length; len++)
                    {
                        if (names[len] != string.Empty)
                        {
                            names[len] = names[len].Replace(';', ' ').Trim();
                            if (len == 0)
                            {
                                objMessage.ToRecipients.Add(names[len].Trim());
                                DuplicateNames = names[len].Trim();
                            }
                            else if (!DuplicateNames.Contains(names[len]))
                            {
                                objMessage.ToRecipients.Add(names[len].Trim());
                                DuplicateNames += "; " + names[len].Trim();
                            }
                        }
                    }
                }
                objMessage.Subject = Subject;
                objMessage.Body = Body; //EMail Body
                objMessage.Send();
                IsSucceed = true;
                if (IsSucceed)
                {
                    uml.HandleMailLog("Token mail sent success! Sub: " + Subject + ". To: " + To + " Mailbox: " + LoginEmailId);
                }
            }
            catch (Exception ex)
            {
                if (ex.Message == Constant.Unauthorized)
                {
                    LockEmail((int)Constant.EmailBoxType.LoginEmail, MailBoxEmailId);
                }
                else if (ex.Message == Constant.NotFoundinStore)
                {
                    LockEmail((int)Constant.EmailBoxType.EmailBox, LoginEmailId);
                }

                IsSucceed = false;
                uel.HandleError(ex, "", "Token mail sent failed! Sub: " + Subject + ". To: " + To + " Mailbox: " + LoginEmailId + " Locked.");
            }
            return IsSucceed;
        }

        private static void LockEmail(int EmailBoxType, string EmailId)
        {
            try
            {
                DBHelper objDBHelper = new DBHelper();
                using (DbConnection connection = objDBHelper.Db.CreateConnection())
                {
                    connection.Open();
                    DbCommand attachcommand = objDBHelper.Db.GetStoredProcCommand("USP_LockEmail");
                    attachcommand.Parameters.Add(new SqlParameter("EmailBoxType", EmailBoxType));
                    attachcommand.Parameters.Add(new SqlParameter("EmailId", EmailId));
                    objDBHelper.Db.ExecuteNonQuery(attachcommand);
                }
            }
            catch (SqlException ex)
            {
                ExceptionHelper.HandleException(ex);
            }
        }
        /// <summary>
        /// Create a HTML content and upload it into database
        /// </summary>
        /// <param name="EMailFrom"></param>
        /// <param name="EMailTo"></param>
        /// <param name="EMailCC"></param>
        /// <param name="Subject"></param>
        /// <param name="BodyText"></param>
        /// <param name="CaseId"></param>
        ///<returns>void</returns>
        private static List<EMTWebApp.Constants.Conversation> CreateHTMLFile(string EMailFrom, string EMailTo, string EMailCC, string Subject, string BodyText, long CaseId, EmailMessage msg)
        {
            string cipher = ConfigurationManager.AppSettings["ENCRYPTIONKEY"].ToString();
            List<EMTWebApp.Constants.Conversation> htmlFileCollection = new List<EMTWebApp.Constants.Conversation>();
            EMTWebApp.Constants.Conversation conver = new EMTWebApp.Constants.Conversation();
            //Create a Email sender and receiver info with datetime
            StringBuilder EMailTransactionDetails = new StringBuilder();
            EMailTransactionDetails.Append("<div style='border: none; border-top: solid #B5C4DF 1.0pt; padding: 3.0pt 0in 0in 0in'><p class='MsoNormal'><b><span style='font-size: 10.0pt; font-family: Tahoma,sans-serif'>");
            EMailTransactionDetails.Append("From: ");
            EMailTransactionDetails.Append("</span></b><span style='font-size: 10.0pt; font-family: Tahoma,sans-serif'>");
            EMailTransactionDetails.Append(EMailFrom + "<br/>");
            EMailTransactionDetails.Append("<b>Sent: </b>" + DateTime.Now.ToLongDateString() + " " + DateTime.Now.ToShortTimeString() + "<br/>");

            EMailTransactionDetails.Append("<b>To: </b>" + GetNamesWithoutDuplicates(EMailTo) + "<br/>");
            if (EMailCC.Length > 0)
            {
                EMailTransactionDetails.Append("<b>Cc: </b>" + GetNamesWithoutDuplicates(EMailCC) + "<br/>");
            }

            EMailTransactionDetails.Append("<b>Subject: </b>" + Subject);
            bool Priority = (msg.Importance.ToString() == "Low" || msg.Importance.ToString() == "Normal" ? false : true);
            if (Priority)
                EMailTransactionDetails.Append("<br/><b>Importance: </b>" + msg.Importance.ToString());
            EMailTransactionDetails.Append("</span>");
            EMailTransactionDetails.Append("</p></div><br/>");

            if (BodyText != null)
            {
                //Append body text and mail transaction details
                //if (BodyText.Contains("<html"))
                //{
                //    BodyText = HelperMethods.Concatenate(BodyText.ToString(), EMailTransactionDetails.ToString());
                //}
                //else
                //{
                BodyText = EMailTransactionDetails.ToString() + BodyText.ToString();
                //BodyText = BodyText.Replace("\r\n", "<br/>");
                //BodyText = BodyText.Replace("\n", "<br/>");
                //BodyText = BodyText.Replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
                //}
            }
            else
            {
                BodyText = "";
            }
            //ENCRYPTION
            //CryptInfo cryptInfo = new CryptInfo();
            //SecurityFactory securityFactory = new SecurityFactory();
            //cryptInfo.CryptKey = cipherpassword;
            //cryptInfo.ValueToCrypt = BodyText;
            //string encryptedValue = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
            string encryptedValue = EncryptString(BodyText);
            conver.Content = HelperMethods.GetBytes(encryptedValue); //convert string to byte array
            conver.FileType = ".html";
            htmlFileCollection.Add(conver);
            return htmlFileCollection;
        }

        /// <summary>
        /// Create a HTML content and upload it into database
        /// </summary>
        /// <param name="EMailFrom"></param>
        /// <param name="EMailTo"></param>
        /// <param name="EMailCC"></param>
        /// <param name="Subject"></param>
        /// <param name="BodyText"></param>
        /// <param name="CaseId"></param>
        ///<returns>void</returns>
        public static List<EMTWebApp.Constants.Attachment> CreateHTMLFileGMB(string EMailFrom, string EMailTo, string EMailCC, string Subject, string BodyText, long CaseId, string msgImportance)
        {
            List<EMTWebApp.Constants.Attachment> htmlFileCollection = new List<EMTWebApp.Constants.Attachment>();
            EMTWebApp.Constants.Attachment attach = new EMTWebApp.Constants.Attachment();
            //Create a Email sender and receiver info with datetime
            StringBuilder EMailTransactionDetails = new StringBuilder();
            EMailTransactionDetails.Append("<div style='border: none; border-top: solid #B5C4DF 1.0pt; padding: 3.0pt 0in 0in 0in'><p class='MsoNormal'><b><span style='font-size: 10.0pt; font-family: Tahoma,sans-serif'>");
            EMailTransactionDetails.Append("From: ");
            EMailTransactionDetails.Append("</span></b><span style='font-size: 10.0pt; font-family: Tahoma,sans-serif'>");
            EMailTransactionDetails.Append(EMailFrom + "<br/>");
            EMailTransactionDetails.Append("<b>Sent: </b>" + DateTime.Now.ToLongDateString() + " " + DateTime.Now.ToShortTimeString() + "<br/>");
            EMailTransactionDetails.Append("<b>To: </b>" + GetNamesWithoutDuplicates(EMailTo) + "<br/>");
            if (EMailCC.Length > 0)
            {
                EMailTransactionDetails.Append("<b>Cc: </b>" + GetNamesWithoutDuplicates(EMailCC) + "<br/>");
            }
            EMailTransactionDetails.Append("<b>Subject: </b>" + Subject);
            bool Priority = (msgImportance == "Low" || msgImportance == "Normal" ? false : true);
            if (Priority)
                EMailTransactionDetails.Append("<br/><b>Importance: </b>" + msgImportance);
            EMailTransactionDetails.Append("</span>");
            EMailTransactionDetails.Append("</p></div><br/>");

            if (BodyText != null)
            {
                BodyText = EMailTransactionDetails.ToString() + BodyText.ToString();
            }
            else
            {
                BodyText = "";
            }
            attach.FileContent = HelperMethods.GetBytes(BodyText); //convert string to byte array
            attach.FileType = ".html";
            htmlFileCollection.Add(attach);
            return htmlFileCollection;
        }


        public static string GetNamesWithoutDuplicates(string MailIds)
        {
            string MailIdsWithoutDuplicates = string.Empty;

            //Add the recipients in the CC list
            if (MailIds != null && MailIds != string.Empty)
            {
                string[] names = MailIds.Split(';');
                int length = names.Length;


                for (int len = 0; len < length; len++)
                {
                    if (names[len] != string.Empty)
                    {
                        if (len == 0)
                        {
                            MailIdsWithoutDuplicates = names[len].Trim();
                        }
                        else if (!MailIdsWithoutDuplicates.Contains(names[len].Trim()))
                        {
                            MailIdsWithoutDuplicates += "; " + names[len].Trim();
                        }
                    }
                }
            }
            return MailIdsWithoutDuplicates;
        }

        public static DataTable GetVIPUsers()
        {
            DataTable dsStatus = new DataTable();
            SqlConnection myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnStr"].ToString());
            myConnection.Open();
            SqlCommand myCommand1 = new SqlCommand("USP_VIP_User", myConnection);
            //myCommand1.Parameters.Add(ExchangeConstants.SP_PARAMETER_CASEID, SqlDbType.VarChar, 10).Value = caseID;
            myCommand1.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter daStatus = new SqlDataAdapter(myCommand1);
            daStatus.Fill(dsStatus);
            myConnection.Close();

            //if (dsStatus.Rows.Count > 0)
            //{
            //    currentStatus = Convert.ToInt32(dsStatus.Tables[0].Rows[0]["CurrentStatus"]);
            //}

            return dsStatus;
        }

        //update emailsent table
        private static void InsertEMailDetails(long CaseId, string EMailTo, string EMailCc, string EMailBcc, string Subject, string EMailBody, int EMailTypeId, DateTime EMailSentDate, bool SentStatus, string plainbody, int ishighimp, bool isVIP)
        {
            try
            {
                DBHelper objDBHelper = new DBHelper();
                using (DbConnection connection = objDBHelper.Db.CreateConnection())
                {
                    connection.Open();
                    DbCommand attachcommand = objDBHelper.Db.GetStoredProcCommand("USP_Insert_EMailDetails_old");
                    attachcommand.Parameters.Add(new SqlParameter("CaseId", CaseId));
                    attachcommand.Parameters.Add(new SqlParameter("EMailTo", EMailTo));
                    attachcommand.Parameters.Add(new SqlParameter("EMailCc", EMailCc));
                    attachcommand.Parameters.Add(new SqlParameter("EMailBcc", EMailBcc));
                    attachcommand.Parameters.Add(new SqlParameter("Subject", Subject));
                    attachcommand.Parameters.Add(new SqlParameter("EMailBody", EMailBody));
                    attachcommand.Parameters.Add(new SqlParameter("EMailTypeId", EMailTypeId));
                    attachcommand.Parameters.Add(new SqlParameter("EMailSentDate", EMailSentDate));
                    attachcommand.Parameters.Add(new SqlParameter("SentStatus", SentStatus));
                    attachcommand.Parameters.Add(new SqlParameter("plainbody", plainbody));
                    attachcommand.Parameters.Add(new SqlParameter("ishighimp", ishighimp));
                    attachcommand.Parameters.Add(new SqlParameter("IsVip",isVIP));
                    objDBHelper.Db.ExecuteNonQuery(attachcommand);
                }
            }
            catch (SqlException ex)
            {
                ExceptionHelper.HandleException(ex);
            }
        }
        public static List<T> ToList<T>(this DataTable table) where T : new()
        {
            IList<PropertyInfo> properties = typeof(T).GetProperties().ToList();
            List<T> result = new List<T>();

            foreach (var row in table.Rows)
            {
                var item = CreateItemFromRow<T>((DataRow)row, properties);
                result.Add(item);
            }

            return result;
        }

        private static T CreateItemFromRow<T>(DataRow row, IList<PropertyInfo> properties) where T : new()
        {
            T item = new T();
            foreach (var property in properties)
            {
                if (property.PropertyType == typeof(System.DayOfWeek))
                {
                    DayOfWeek day = (DayOfWeek)Enum.Parse(typeof(DayOfWeek), row[property.Name].ToString());
                    property.SetValue(item, day, null);
                }
                else
                {
                    property.SetValue(item, row[property.Name], null);
                }
            }
            return item;
        }
        /// <summary>
        /// Method to Encrpt a string
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>        
        public static string EncryptValue(string value)
        {
            byte[] b = System.Text.ASCIIEncoding.ASCII.GetBytes(value);
            string encrypted = Convert.ToBase64String(b);
            return encrypted;
        }
        /// <summary>
        /// Method to Decrypt a string
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string DecryptValue(string value)
        {
            byte[] b = Convert.FromBase64String(value.ToString());
            string decryptedvalue = System.Text.ASCIIEncoding.ASCII.GetString(b);
            return decryptedvalue;
        }


        public static int GetMaxNoScreenshotCaseId(long CaseId, int AttachmentType)
        {
            int result = 0;
            DBHelper objDBHelper = new DBHelper();
            using (DbConnection connection = objDBHelper.Db.CreateConnection())
            {
                connection.Open();
                try
                {
                    using (DbTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            DbCommand attachcommand = objDBHelper.Db.GetStoredProcCommand("USP_GetNextScreenshotNumber");
                            attachcommand.Parameters.Add(new SqlParameter("CaseId", CaseId));
                            attachcommand.Parameters.Add(new SqlParameter("AttachmentType", AttachmentType));
                            result = Convert.ToInt32(objDBHelper.Db.ExecuteScalar(attachcommand, transaction));
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            ExceptionHelper.HandleException(ex);
                            throw ex;
                        }
                    }
                }
                finally
                {
                    connection.Close();
                }
            }
            return result;
        }


        public static bool ValidateMailAttachmentsSize(int ContentLength)
        {
            bool ReturnVal = true;
            if (ContentLength > 20971520) // Chk total attachments size not exceed 20 MB
            {
                ReturnVal = false;
            }
            return ReturnVal;
        }


        public static bool fnCheckOtherFileExtension(string strFileName)
        {
            bool retVal = false;
            try
            {
                string strOtherExtnName = System.Configuration.ConfigurationManager.AppSettings["AttachType"].Trim().ToLower();

                if (strOtherExtnName != "")
                {
                    string fileExtensionAttach = (strFileName.Substring((strFileName.LastIndexOf(".") + 1), (strFileName.Length - (strFileName.LastIndexOf(".") + 1)))).ToLower();

                    string[] strSplitval = strOtherExtnName.Split(new Char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                    for (int intSplitVal = 0; intSplitVal < strSplitval.Length; intSplitVal++)
                    {
                        if (fileExtensionAttach.Trim().ToLower() == strSplitval[intSplitVal].ToLower().Trim())
                        {
                            retVal = false;
                            break;
                        }
                        else
                        {
                            retVal = true;
                        }
                    }
                }
                else
                {
                    retVal = true;
                }
            }
            catch (Exception ex)
            {
                ExceptionHelper.HandleException(ex);
                throw ex;
            }
            return retVal;
        }

        //Pranay 7th Feb 2017 -- method for restricting particular tags and scripts
        public static string StripHtml(string source)
        {
            string[] removeElements = new string[] { "script", "javascript", "text", "language", "function", "input", "output", "button", "img", "noscript" };
            string _newString = source;
            foreach (string removeElement in removeElements)
            {
                while (_newString.ToLower().Contains("&lt;" + removeElement.ToLower()))
                {
                    if (removeElement == "input" || removeElement == "img")
                    {
                        _newString = _newString.Substring(0, _newString.ToLower().IndexOf("&lt;" + removeElement.ToLower())) + _newString.Substring(_newString.ToLower().IndexOf("&gt;") + removeElement.Length + 6);
                    }
                    else
                    {
                        _newString = _newString.Substring(0, _newString.ToLower().IndexOf("&lt;" + removeElement.ToLower())) + _newString.Substring(_newString.ToLower().IndexOf("&lt;/" + removeElement.ToLower() + "&gt;") + removeElement.Length + 9);
                    }
                }
            }

            string[] removeFurtherElements = new string[] { "div", "style", "button", "span", "script", "input" };
            foreach (string removeElement in removeFurtherElements)
            {
                while (_newString.ToLower().Contains("<" + removeElement.ToLower()))
                {
                    if (removeElement == "input" || removeElement == "img")
                    {
                        _newString = _newString.Substring(0, _newString.ToLower().IndexOf("<" + removeElement.ToLower())) + _newString.Substring(_newString.ToLower().IndexOf(">") + 1);
                    }
                    else if (removeElement == "span")
                    {
                        _newString = _newString.Substring(0, _newString.ToLower().IndexOf("<" + removeElement.ToLower())) + _newString.Substring(_newString.ToLower().LastIndexOf("</" + removeElement.ToLower() + ">") + removeElement.Length + 3);
                    }
                    else
                    {
                        _newString = _newString.Substring(0, _newString.ToLower().IndexOf("<" + removeElement.ToLower())) + _newString.Substring(_newString.ToLower().IndexOf("</" + removeElement.ToLower() + ">") + removeElement.Length + 3);
                    }
                }
            }
            return _newString;
        }


    }

}
