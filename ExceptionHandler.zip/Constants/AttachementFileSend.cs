﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EMTWebApp.Constants
{
    public class AttachementFileSend
    {


        private string filenamesend;
        public string FileName
        {
            set
            {
                filenamesend = value;
            }
            get
            {
                return filenamesend;
            }
        }



        private Byte[] filecontentsend;
        public Byte[] FileContent
        {
            set
            {
                filecontentsend = value;
            }
            get
            {
                return filecontentsend;
            }
        }
      
    }
}
