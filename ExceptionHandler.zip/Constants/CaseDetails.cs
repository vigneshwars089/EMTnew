﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EMTWebApp.Constants
{
    public class CaseDetails
    {
        private long caseid;
        public long CaseId
        {
            set
            {
                caseid = value;
            }
            get
            {
                return caseid;
            }
        }

        private int statusid;
        public int StatusId
        {
            set
            {
                statusid = value;
            }
            get
            {
                return statusid;
            }
        }
        private DateTime starttime;
        public DateTime StartTime
        {
            set
            {
                starttime = value;
            }
            get
            {
                return starttime;
            }
        }

        private int emailboxid;
        public int EMailBoxId
        {
            set
            {
                emailboxid = value;
            }
            get
            {
                return emailboxid;
            }
        }
        private string mailboxemailid;
        public string MailBoxEMailId
        {
            set
            {
                mailboxemailid = value;
            }
            get
            {
                return mailboxemailid;
            }
        }
        private bool isemailtriggerrequired;
        public bool isEMailTriggerRequired
        {
            set
            {
                isemailtriggerrequired = value;
            }
            get
            {
                return isemailtriggerrequired;
            }
        }
        private bool isqcrequired;
        public bool isQCRequired
        {
            set
            {
                isqcrequired = value;
            }
            get
            {
                return isqcrequired;
            }
        }

        private string caseassignedto;
        public string CaseAssignedTo
        {
            set
            {
                caseassignedto = value;
            }
            get
            {
                return caseassignedto;
            }
        }

        private string qcassignedto;
        public string QCAssignedTo
        {
            set
            {
                qcassignedto = value;
            }
            get
            {
                return qcassignedto;
            }
        }
    }
}
