﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EMTWebApp.Constants
{
    public static class Constant
    {
        public const string Test = "test";

        public enum AttachmentType
        {
            FileSent=1,
            FileReceived=2
        }
        public enum EMailType
        {
            Clarification = 1,
            Completed = 2,
            Clarification_ManualCaseCreation = 3,
            Followup = 4
        }

        public enum UserRole
        {
            SuperAdmin = 1,
            Admin = 2,
            TeamLead = 3,
            Processor = 4,
            ClientUser=5
        }

        public enum Status
        {
            Open = 1,
            Assigned = 2,
            ClarificationNeeded = 3,
            ClarificationProvided = 4,
            PushforQC = 5,
            Ignored = 6,
            QCAccepted = 7,
            QCRejected = 8,
            QCActionTaken = 9,
            Completed = 10,
            Reassigned = 11,
            QCReassigned = 12,
            OnHold =13
        }

        public enum EmailBoxType
        {
            LoginEmail=1,
            EmailBox=2
        }
        
        public const string WorkQueuePage = "WorkQueue";
        public const string QCWorkQueuePage = "QCWorkQueue";
        public const string SearchPage = "Search";
        public const string Processing = "ProcessingNewUI";
        public const string FileSent = "File Sent";
        public const string FileReceived = "File Received";
        public const string Unauthorized = "The request failed. The remote server returned an error: (401) Unauthorized.";
        public const string NotFoundinStore = "The specified folder could not be found in the store.";

        public const string TextBox = "1";
        public const string DropDownList = "2";
        public const string CheckBox = "3";
        public const string TextArea = "4";

        public const int ChkItmCnt = 7;
        public const int RadItmCnt = 2;
       
    }
}
