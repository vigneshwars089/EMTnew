﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMTWebApp.Constants
{
    public class Reminderdetails
    {
        private int fromstatusid;
        public int FromStatusID
        {
            set
            {
                fromstatusid = value;
            }
            get
            {
                return fromstatusid;
            }
        }

        private int tostatusid;
        public int ToStatusID
        {
            set
            {
                tostatusid = value;
            }
            get
            {
                return tostatusid;
            }
        }

        private int nooftimes;
        public int NoOfTimes
        {
            set
            {
                nooftimes = value;
            }
            get
            {
                return nooftimes;
            }
        }

        private int frequency;
        public int Frequency
        {
            set
            {
                frequency = value;
            }
            get
            {
                return frequency;
            }
        }

        private bool isescalated;
        public bool IsEscalated
        {
            set
            {
                isescalated = value;
            }
            get
            {
                return isescalated;
            }
        }

        private string escalatedmailid;
        public string EscalatedMailID
        {
            set
            {
                escalatedmailid = value;
            }
            get
            {
                return escalatedmailid;
            }
        }

        private bool isactive;
        public bool IsActive
        {
            set
            {
                isactive = value;
            }
            get
            {
                return isactive;
            }
        }
    }
}
