﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using NodaTime;
using NodaTime.Text;
using System.Globalization;
using System.Xml;
using System.Web;
using NodaTime.TimeZones;
using System.Collections;

namespace EMTWebApp.Constants
{
    
    class DateTimePatterns
    {
        public const string longDateTimePattern = "dd/MM/yyyy HH:mm:ss";
        public const string shortDatePattern = "dd/MM/yyyy";
        public const string twelveHourPattern = "dd/MM/yyyy hh:mm:ss tt";

        // Nodatime does not work with leading Zero. Hence removing leading zero format for Parsing

        public const string nodaDateTimePattern = "d/M/yyyy H:m:s";
        public const string nodaLongDateTimePattern = "d/M/yyyy H:m:s";
        public const string nodaDatePattern = "d/M/yyyy";
        public const string nodaTwelveHourPattern = "d/M/yyyy h:m:s tt";

    }
    public static class TransformDateTime
    {

        public static Hashtable ht = new Hashtable();

        static TransformDateTime()
        {
            ht.Add("Aleutian Standard Time", "America/Adak");
            ht.Add("Marquesas Standard Time", "Pacific/Marquesas");
            ht.Add("UTC-09", "Etc/GMT+9");
            ht.Add("Pacific Standard Time (Mexico)", "America/Tijuana");
            ht.Add("UTC-08", "Etc/GMT+8");
            ht.Add("Easter Island Standard Time", "Pacific/Easter");
            ht.Add("Haiti Standard Time", "America/Port-au-Prince");
            ht.Add("Cuba Standard Time", "America/Havana");
            ht.Add("Turks And Caicos Standard Time", "America/Grand_Turk");
            ht.Add("Tocantins Standard Time", "America/Araguaina");
            ht.Add("Saint Pierre Standard Time", "America/Miquelon");
            ht.Add("West Bank Standard Time", "Asia/Hebron");
            ht.Add("Astrakhan Standard Time", "Europe/Astrakhan");
            ht.Add("Altai Standard Time", "Asia/Barnaul");
            ht.Add("W. Mongolia Standard Time", "Asia/Hovd");
            ht.Add("Tomsk Standard Time", "Asia/Tomsk");
            ht.Add("Aus Central W. Standard Time", "Australia/Eucla");
            ht.Add("Transbaikal Standard Time", "Asia/Chita");
            ht.Add("Lord Howe Standard Time", "Australia/Lord_Howe");
            ht.Add("Bougainville Standard Time", "Pacific/Bougainville");
            ht.Add("Norfolk Standard Time", "Pacific/Norfolk");
              ht.Add("Sakhalin Standard Time", "Asia/Sakhalin");
              ht.Add("Kamchatka Standard Time", "Asia/Kamchatka");
        }


        

        /// <summary>
        /// Method to convert mentioned time to a specific time zone.
        /// </summary>
        /// <param name="dateTimeString">datetime to be converted</param>
        /// <param name="isUtcTime"> is the datetime inout in utc?</param>
        /// <param name="clientTimeZoneID">destination time zone to which the datetime has to be converted to</param>
        /// <param name="isDate">is the output expected in date format?</param>
        /// <returns></returns>
        public static string GetZonedDateTimeToDisplay(string dateTimeString, bool isUtcTime, string clientTimeZoneID, bool isDate)
        {

            string zonedDateTimeStr = string.Empty;
            string dateTimePattern = DateTimePatterns.nodaDateTimePattern;
            string outPutPattern = DateTimePatterns.longDateTimePattern;
            string configuredTimeZoneID = string.Empty;
            try
            {
                dateTimeString = dateTimeString.Replace("-", "/");
                string timeZoneID = ConfigurationManager.AppSettings["ServerTimeZoneFormat"].ToString();
                if (!String.IsNullOrEmpty(timeZoneID))
                {
                    configuredTimeZoneID = timeZoneID;
                }
                TzdbDateTimeZoneSource source = new TzdbDateTimeZoneSource("NodaTime.TimeZones.Tzdb");
                string NodaClientTimeZoneId = source.MapTimeZoneId(TimeZoneInfo.FindSystemTimeZoneById(clientTimeZoneID));
                if (NodaClientTimeZoneId == null)
                {
                    NodaClientTimeZoneId = ht[clientTimeZoneID].ToString();
                }
                string NodaConfiguredTimeZoneId = source.MapTimeZoneId(TimeZoneInfo.FindSystemTimeZoneById(configuredTimeZoneID));
                if (NodaConfiguredTimeZoneId == null)
                {
                    NodaConfiguredTimeZoneId = ht[configuredTimeZoneID].ToString();
                }
                DateTimeZone configuredTimeZone = DateTimeZoneProviders.Tzdb[NodaConfiguredTimeZoneId];// that of server?? eg IST
                DateTimeZone clientTimeZone = DateTimeZoneProviders.Tzdb[NodaClientTimeZoneId];//Eastern Standard Time??
                if (isDate)
                {
                    outPutPattern = DateTimePatterns.shortDatePattern;
                }
                if (!isUtcTime)
                {
                    if (dateTimeString.IndexOf("AM") > 0 || dateTimeString.IndexOf("PM") > 0)
                    {
                        dateTimePattern = DateTimePatterns.nodaTwelveHourPattern;
                    }
                    else
                    {
                        dateTimePattern = DateTimePatterns.nodaDateTimePattern;
                        if (dateTimeString.IndexOf(":") < 0)
                        {
                            dateTimePattern = DateTimePatterns.nodaDatePattern;
                        }
                        else if (dateTimeString.IndexOf("/") == 4)
                        {
                            dateTimePattern = DateTimePatterns.nodaLongDateTimePattern;
                        }
                    }

                    LocalDateTimePattern pattern = LocalDateTimePattern.CreateWithInvariantCulture(dateTimePattern);

                    ParseResult<LocalDateTime> parseResult = pattern.Parse(dateTimeString);
                    if (!parseResult.Success)
                    {
                        throw new Exception("NodaTime Parse failed  - " + parseResult.Value.ToString());
                    }
                    else
                    {
                        LocalDateTime localDateTime = parseResult.Value;
                        ZonedDateTime clientDateTime = localDateTime.InZoneLeniently(configuredTimeZone);
                        LocalDateTime zonedDateTimeOutput = clientDateTime.ToInstant().InZone(clientTimeZone).LocalDateTime;
                        zonedDateTimeStr = zonedDateTimeOutput.ToString(outPutPattern, CultureInfo.InvariantCulture);
                    }
                }
                else
                {
                    DateTime utcDateTime = DateTime.SpecifyKind(DateTime.ParseExact(dateTimeString, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture), DateTimeKind.Utc);
                    Instant inst = Instant.FromDateTimeUtc(utcDateTime);
                    ZonedDateTime zonedDt = new ZonedDateTime(inst, clientTimeZone);

                    zonedDateTimeStr = zonedDt.LocalDateTime.ToString(outPutPattern, CultureInfo.InvariantCulture);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return zonedDateTimeStr;
        }

        //public static string CurrentTimeToZonedTime(string serverTimeZoneID)
        //{
        //    string zonedDateTimeStr = string.Empty;
        //    string dateTimePattern = string.Empty;
        //    string outPutPattern = "dd-MM-yyyy HH:mm:ss";
        //    var serverTimeZone = DateTimeZoneProviders.Tzdb[serverTimeZoneID];
        //    try
        //    {
        //        DateTime utcDateTime = DateTime.UtcNow;
        //        var inst = Instant.FromDateTimeUtc(utcDateTime);
        //        var zonedDt = new ZonedDateTime(inst, serverTimeZone);

        //        zonedDateTimeStr = zonedDt.LocalDateTime.ToString(outPutPattern, CultureInfo.InvariantCulture);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return zonedDateTimeStr;
        //}

        /// <summary>
        /// Method to convert the date and time from a specific timezone to UTC
        /// </summary>
        /// <param name="dateTimeString">String representing the date and time to be converted to utc</param>
        /// <param name="timeZoneID">timezone from which the mentioned date has to be converted to utc</param>
        /// <returns></returns>
        public static string GetUtcTimeFromZonedTime(string dateTimeString, string timeZoneID)
        {
            string utcTime = string.Empty;
            string dateTimePattern = string.Empty;

            dateTimeString = dateTimeString.Replace("-", "/");
            try
            {
                if (dateTimeString.IndexOf("1900") > 0)
                {
                    utcTime = dateTimeString;
                }
                else
                {
                    if (dateTimeString.IndexOf(":") > 0)
                    {
                        dateTimePattern = DateTimePatterns.nodaDateTimePattern;
                        if (dateTimeString.IndexOf("AM") > 0 || dateTimeString.IndexOf("PM") > 0)
                        {
                            dateTimePattern = DateTimePatterns.nodaTwelveHourPattern;
                        }
                        else if (dateTimeString.IndexOf("/") == 4)
                        {
                            dateTimePattern = DateTimePatterns.nodaLongDateTimePattern;
                        }
                    }
                    else
                    {
                        dateTimePattern = DateTimePatterns.nodaDatePattern;
                    }
                    LocalDateTimePattern pattern = LocalDateTimePattern.CreateWithInvariantCulture(dateTimePattern);
                    ParseResult<LocalDateTime> parseResult = pattern.Parse(dateTimeString);
                    if (!parseResult.Success)
                    {
                        throw new Exception("NodaTime Parse failed  - " + parseResult.Value.ToString());
                    }
                    else
                    {
                        LocalDateTime localDateTime = parseResult.Value;

                        TzdbDateTimeZoneSource source = new TzdbDateTimeZoneSource("NodaTime.TimeZones.Tzdb");
                        string NodatimeZoneID = source.MapTimeZoneId(TimeZoneInfo.FindSystemTimeZoneById(timeZoneID));
                        DateTimeZone timeZone = DateTimeZoneProviders.Tzdb[NodatimeZoneID];
                        ZonedDateTime zonedDateTime = localDateTime.InZoneLeniently(timeZone);
                        utcTime = zonedDateTime.ToDateTimeUtc().ToString(dateTimePattern, CultureInfo.InvariantCulture);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return utcTime;
        }


    }
}
