﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Exchange.WebServices.Data;
using System.IO;
using EMTWebApp.UserManagement.Common;

  public class BuildInLineAttachments
    {
        private const string CidPattern = "cid:";
        UserSession UserData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        private static HashSet<int> BuildCidIndex(string html)
        {
            UserSession UserData = new UserSession();
            UserErrorLog errorlog = new UserErrorLog();
            var index = new HashSet<int>();
            try
            {
               
                var pos = html.IndexOf(CidPattern, 0);
                while (pos > 0)
                {
                    var start = pos + CidPattern.Length;
                    index.Add(start);
                    pos = html.IndexOf(CidPattern, start);
                }
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | BuildInLineAttachments.cs | HashSet()");
            }
            return index;
        }

        private static void AdjustIndex(HashSet<int> index, int oldPos, int byHowMuch)
        {
            UserSession UserData = new UserSession();
            UserErrorLog errorlog = new UserErrorLog();
            try
            {
                var oldIndex = new List<int>(index);
                index.Clear();
                foreach (var pos in oldIndex)
                {
                    if (pos < oldPos)
                        index.Add(pos);
                    else
                        index.Add(pos + byHowMuch);
                }
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | BuildInLineAttachments.cs | AdjustIndex()");
            }
        }

        private static bool ReplaceCid(HashSet<int> index, ref string html, string cid, string path)
        {
            UserSession UserData = new UserSession();
            UserErrorLog errorlog = new UserErrorLog();
            try
            {
                var posToRemove = -1;
                foreach (var pos in index)
                {
                    if (pos + cid.Length < html.Length && html.Substring(pos, cid.Length) == cid)
                    {
                        var sb = new StringBuilder();
                        sb.Append(html.Substring(0, pos - CidPattern.Length));
                        sb.Append(path);
                        sb.Append(html.Substring(pos + cid.Length));
                        html = sb.ToString();

                        posToRemove = pos;
                        break;
                    }
                }

                if (posToRemove < 0)
                    return false;

                index.Remove(posToRemove);
                AdjustIndex(index, posToRemove, path.Length - (CidPattern.Length + cid.Length));
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | BuildInLineAttachments.cs | ReplaceCid()");
            }

            return true;
        }

        public string BuildInlineAttachments(string sHTMLContent, Item EmailItem)
        {
            FileAttachment[] attachments = null;
            HashSet<int> index = BuildCidIndex(sHTMLContent);
            try
            {
                if (index.Count > 0 && EmailItem.Attachments.Count > 0)
                {
                    var basePath = Directory.GetCurrentDirectory();

                    attachments = new FileAttachment[EmailItem.Attachments.Count];
                    for (var i = 0; i < EmailItem.Attachments.Count; ++i)
                    {
                        var type = EmailItem.Attachments[i].ContentType.ToLower();
                        if (!type.StartsWith("image/")) continue;
                        type = type.Replace("image/", "");

                        var attachment = (FileAttachment)EmailItem.Attachments[i];
                        var cid = attachment.ContentId;
                        var filename = cid + "." + type;
                        var path = Path.Combine(basePath, filename);
                        if (ReplaceCid(index, ref sHTMLContent, cid, path))
                        {
                            // only load images when they have been found          
                            attachment.Load(path);
                            attachments[i] = attachment;
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | BuildInLineAttachments.cs | BuildInlineAttachments()");
            }
            return sHTMLContent;
        }

    }
