﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Xml.Linq;
using System.IO;
using System.Text;

    /// <summary>
    /// Summary description for UserErrorLog
    /// </summary>
public  class UserErrorLog
{
    public void HandleError(Exception ex, string UserId,string otherDesc )
    {
        try
        {
            string ErrorLogPath = ConfigurationSettings.AppSettings["ErrorLogPath"];
            string FileName = string.Format("{0}ErrorLog_{1}.txt", ErrorLogPath, System.DateTime.Now.Date.ToString("MM-dd-yyyy"));
            System.IO.StreamWriter errlog = new System.IO.StreamWriter(FileName, true);
            errlog.AutoFlush = true;
            errlog.WriteLine("++++++++++++++++++++++++++++++++++++ Error Date and Time - " + System.DateTime.Now + "   +++++++++++++++++++++++++++++++++++++++");
            errlog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
            errlog.WriteLine("Source              :	" + otherDesc);
            errlog.WriteLine("UserId              :	" + UserId);
            errlog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
            errlog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
            errlog.WriteLine("Error Source        :	" + ex.Source);
            errlog.WriteLine("Target Site         :	" + ex.TargetSite);
            errlog.WriteLine("System Message      :	" + ex.Message);
            errlog.WriteLine("Stack Trace         :	" + ex.StackTrace);
            errlog.WriteLine("GetType             :	" + ex.GetType().Name);
            errlog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
            Exception objExec = ex.InnerException;
            string sInnerTab = "";
            while (objExec != null)
            {
                sInnerTab += "        ";
                errlog.WriteLine("");
                errlog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
                errlog.WriteLine(sInnerTab + "Inner Exception:");
                errlog.WriteLine(sInnerTab + "Error Source        :	" + objExec.Source);
                errlog.WriteLine(sInnerTab + "Target Site         :	" + objExec.TargetSite);
                errlog.WriteLine(sInnerTab + "System Message      :	" + objExec.Message);
                errlog.WriteLine(sInnerTab + "Stack Trace         :	" + objExec.StackTrace);
                errlog.WriteLine(sInnerTab + "GetType             :	" + objExec.GetType().Name);
                errlog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
                objExec = objExec.InnerException;
            }

            errlog.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++ End of Error Message  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            errlog.WriteLine("");
            errlog.WriteLine("");

            errlog.Close();
        }
        catch (Exception exp)
        {

        }
    }
}

    /// <summary>
    /// Summary description for MailLog
    /// </summary>
public class UserMailLog
{
    public void HandleMailLog(string messgae)
    {
        try
        {
            string ErrorLogPath = ConfigurationSettings.AppSettings["MailLogPath"];
            string FileName = string.Format("{0}MailLog_{1}.txt", ErrorLogPath, System.DateTime.Now.Date.ToString("MM-dd-yyyy"));
            System.IO.StreamWriter maillog = new System.IO.StreamWriter(FileName, true);
            maillog.AutoFlush = true;
            maillog.WriteLine("++++++++++++++++++++++++++++++++++++ Remainder Mail Date and Time - " + System.DateTime.Now + "   +++++++++++++++++++++++++++++++++++++++");
            maillog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
            maillog.WriteLine(messgae);
            maillog.WriteLine("---------------------------------------------------------------------------------------------------------------------------");
            maillog.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++ End of Remainder Mail Message  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            maillog.WriteLine("");
            maillog.WriteLine("");
            maillog.Close();
        }
        catch (Exception exp)
        {

        }
    }
}

public class LoggError
{
    /// <summary>
    /// Writes error occured in log file,if log file does not exist,it creates the file first.
    /// </summary>
    /// <param name="exception">Exception</param>
    public static void Write(Exception exception)
    {
        string logFile = String.Empty;
        StreamWriter logWriter;
        try
        {
            logFile = (ConfigurationSettings.AppSettings["ErrorLog"].ToString());
            if (File.Exists(logFile))
                logWriter = File.AppendText(logFile);
            else
                logWriter = File.CreateText(logFile);
            logWriter.WriteLine("=>" + DateTime.Now + " " + " An Error occured : " +
                exception.StackTrace + " Message : " + exception.Message + "\n\n");
            logWriter.Close();
            throw exception;
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            throw exception;
        }
    }
}



