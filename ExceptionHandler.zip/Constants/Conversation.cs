﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace EMTWebApp.Constants
{
    public class Conversation
    {
        private int conversationid;
        private string subject;
        private string conversationdate;
        private string createddate;
        private string emailfrom;
        private string emailto;
        private string emailcc;
        private string emailbcc;
        private string filetype;
        private string filename;
        private string attachmenttype;

       public string AttachmentType
        {
            set
            {
                attachmenttype = value;
            }
            get
            {
                return attachmenttype;
            }
        }

        public string FileType
        {
            set
            {
                filetype = value;
            }
            get
            {
                return filetype;
            }
        }


        public string FileName
        {
            set
            {
                filename = value;
            }
            get
            {
                return filename;
            }
        }


        private Byte[] content;
        public Byte[] Content
        {
            set
            {
                content = value;
            }
            get
            {
                return content;
            }
        }

        public string EmailFrom
        {
            set
            {
                emailfrom = value;
            }
            get
            {
                return emailfrom;
            }
        }

        public string EmailTo
        {
            set
            {
                emailto = value;
            }
            get
            {
                return emailto;
            }
        }

        public string EmailCc
        {
            set
            {
                emailcc = value;
            }
            get
            {
                return emailcc;
            }
        }

        public string EmailBcc
        {
            set
            {
                emailbcc = value;
            }
            get
            {
                return emailbcc;
            }
        }

        public string CreatedDate
        {
            set
            {
                createddate = value;
            }
            get
            {
                return createddate;
            }
        }

        public string ConversationDate
        {
            set
            {
                conversationdate = value;
            }
            get
            {
                return conversationdate;
            }
        }


        public int ConversationId
        {
            set
            {
                conversationid = value;
            }
            get
            {
                return conversationid;
            }
        }

        public string Subject
        {
            set
            {
                subject = value;
            }
            get
            {
                return subject;
            }
        }

    }
}
