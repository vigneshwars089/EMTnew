﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EMTWebApp.Constants
{
    public class Attachment
    {
        private int attachmentid;
        public int AttachmentId
        {
            set
            {
                attachmentid = value;
            }
            get
            {
                return attachmentid;
            }
        }

        private string filename;
        public string FileName
        {
            set
            {
                filename = value;
            }
            get
            {
                return filename;
            }
        }

        private string filetype;
        public string FileType
        {
            set
            {
                filetype = value;
            }
            get
            {
                return filetype;
            }
        }

        private Byte[] filecontent;
        public Byte[] FileContent
        {
            set
            {
                filecontent = value;
            }
            get
            {
                return filecontent;
            }
        }
        private string attachmenttype;
        public string AttachmentType
        {
            set
            {
                attachmenttype = value;
            }
            get
            {
                return attachmenttype;
            }
        }
        private int attachmenttypeid;
        public int AttachmentTypeId
        {
            set
            {
                attachmenttypeid = value;
            }
            get
            {
                return attachmenttypeid;
            }
        }

        private string createddate;
        public string CreatedDate
        {
            set
            {
                createddate = value;
            }
            get
            {
                return createddate;
            }
        }
        private string contentID;
        public string ContentID
        {
            set
            {
                contentID = value;
            }
            get
            {
                return contentID;
            }
        }
    }
}
