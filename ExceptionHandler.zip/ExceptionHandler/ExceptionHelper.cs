﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

namespace EMTWebApp.ExceptionHandler
{
    public class ExceptionHelper
    {
        public static void HandleException(Exception exception)
        {
            Exception ex;
            ExceptionPolicy.HandleException(exception, "Log Only Policy", out ex);
            //ExecuteNonQuery("PROC_INSERT_ERRORLOG_TEST", exception.ToString());
        }
    }
}
