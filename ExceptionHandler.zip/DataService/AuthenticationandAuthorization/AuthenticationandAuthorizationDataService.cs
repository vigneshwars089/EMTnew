﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using EMTWebApp.DataHelper;
using EMTWebApp.ExceptionHandler;
using System.Collections;
using System.IO;
using System.Web.UI;
using EMTWebApp.UserManagement.Common;
namespace EMTWebApp.DataService.AuthenticationandAuthorization
{
    public class AuthenticationandAuthorizationDataService : DBHelper, IAuthenticationandAuthorizationDataService
    {
        UserSession UserData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        public int Test(int a)
        {
            try
            {
                Hashtable hs = new Hashtable();
                this.ExecuteNonQuery("test", hs);
               
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | AuthenticationandAuthorizationDataService | Test()");
                //Response.Redirect("~/Errors/Error.aspx", false);
            }
            return a;
        }
        public int ValidateLogin(string LoginId)
        {
            Hashtable hs = new Hashtable();
            
            try
            {                            
                hs.Add("@UserID", LoginId);
              
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | AuthenticationandAuthorizationDataService | ValidateLogin()");
            }
            return  Convert.ToInt32(this.SelectSingleValue("USP_VALIDATEUSERID", hs));
        }
        public int ValidateLogin(string LoginId, string encryptPassword)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserID", LoginId);
                hs.Add("@Password", encryptPassword);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | AuthenticationandAuthorizationDataService | ValidateLogin()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_USERLOGIN1", hs));
        }
        public int ValidateADLogin(string LoginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserID", LoginId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | AuthenticationandAuthorizationDataService | ValidateADLogin()");
            }
            return Convert.ToInt32(this.SelectSingleValue("AD_USP_USERLOGIN1", hs));
        }

        public IDataReader UserDetails(string loginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserID", loginId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | AuthenticationandAuthorizationDataService | UserDetails()");
            }
            return this.SelectDataReader("USP_USERSESSION", hs);
        }
        public DataSet DisplayRole(string UserId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserID", UserId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | AuthenticationandAuthorizationDataService | DisplayRole()");
            }
            return this.SelectDataSet("USP_SELECT_USERROLES", hs);
        }

        public int ValidateTL(string UserId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserID", UserId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | AuthenticationandAuthorizationDataService | ValidateTL()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_VALIDATE_TL_LOGIN", hs));
        }

        public int InsertSubscription(Hashtable hsparams)
        {
            return Convert.ToInt32(this.SelectSingleValue("InsertSubscriberContact", hsparams));
        }
    }
}
