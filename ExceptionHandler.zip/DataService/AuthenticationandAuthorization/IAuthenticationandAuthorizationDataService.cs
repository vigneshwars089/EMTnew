﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace EMTWebApp.DataService.AuthenticationandAuthorization
{
    public interface IAuthenticationandAuthorizationDataService
    {
           
        int Test(int a);
        int ValidateLogin(string LoginId, string Password);
        int ValidateADLogin(string LoginId);
        IDataReader UserDetails(string loginId);
        DataSet DisplayRole(String UserId);
        int ValidateLogin(string LoginId);
        int ValidateTL(string UserId);
        int InsertSubscription(Hashtable hsparams);
    }
}
