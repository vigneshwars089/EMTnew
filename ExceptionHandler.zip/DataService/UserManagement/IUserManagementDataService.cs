﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Collections;

namespace EMTWebApp.DataService.UserManagement
{
    public interface IUserManagementDataService
    {
        int AddUser(string UserID, string FirstName, string LastName, string EmailID, string Password, int Active, string LoginId, string TimeZone, string OffSet,string SkillSet,string SkillDescription, bool isTimezone);
        int UpdateUser(string UserID, string FirstName, string LastName, string EmailID, string Password, int Active, string LoginId, string TimeZone, string OffSet,string SkillSet, string SkillDescription,bool isTimezone);
        int ValidatePassword(string UserID, string encryptOldPassword);
        int ChangePassword(string txtLoginID, string encryptOldPassword, string encryptConfirmPassword);
        int ValidateLogin(string LoginId);
        DataSet ForgotPassword(string loginId);
        DataSet GridBind();
        DataSet GetSkillSet();
        DataSet GetUsercount();
        DataSet BindRole();
        DataSet BindActiveUsers();
        DataSet BindCountryChekBoxList();
        int MapUserRole(string UserId, int RoleId, string LoginId, string strCountryIdsToMap);
        DataSet BindCountry();
        DataSet GridUserRoleMapBind();
        DataSet UserWiseRoleMapGridBind(string UserId);
        int UpdateRoleMap(string UserRoleMapId, string UserId, int RoleId, string LoginId, string CountryIdsToMap);
        int DeleteRoleMap(string hddnRMapId);
        DataSet BindActiveMailBox(int CountryId, string LoggedInUserId, int LoggedInUserRoleId);
        int MapUserMailBox(string UserId, int MailBoxId, string LoginId);
        int ConfigureRemaindertoMailbox(Hashtable hs);
        //Pranay 16 August 2016-- adding method for Acknowledgement
        int ConfigureAcknowledgetoMailbox(Hashtable hs);
        int ConfigureCategorytoMailbox(Hashtable hs);
        DataSet GridMailBoxMapBind(Hashtable hs);
        DataSet GridMailBoxRemainderBind(Hashtable hs);
        ////Pranay 16 August 2016--Adding method for binding acknowlegded mailbox in gridview
        DataSet GridMailBoxAcknowledgeBind(Hashtable hs);
        DataSet GridMailBoxcategoryBind(Hashtable hs);
        DataSet getfromStatus(Hashtable hs);
        DataSet UserWiseMailBoxMapGridBind(string UserId, string ddlCountryId);
        int UpdateUserMailBoxMap(string UserMailBoxMapId, string UserId, int MailBoxId, string LoginId);
        int UpdateConfigureRemaindertoMailbox(Hashtable hs);
        //Pranay 16 August 2016--Adding method for updating acknowledged mailbox
        int UpdateConfigureAcknowledgetoMailbox(Hashtable hs);
        int UpdateConfigurecategorytoMailbox(Hashtable hs);
        int DeleteMailBoxMap(string hddnMBMapId, string UserId);
        int InsertMailLoginDetails(string MailId, string encryptConfirmPassword, int Locked, int Active);
        DataSet GridEmailBoxLoginDetailsBind();
        int UpdateMailBoxLoginDetails(string EmailBoxLoginDetailID, string MailId, string EncryptConfirmPassword, int Locked, int Active);
        DataSet GetSignature(string userid);
        int ConfigureSignature(string Signature, string LoginId);
        int UpdateSignature(string SignId, string Signature, string LoginId);
        DataSet GetCountryByUserIdForDashboard(Hashtable hsparams);

        //Pranay 20 October 2016--Adding method for  configuring reference
        int ConfigureReferencetoMailbox(Hashtable hs);

        //Pranay 21 October 2016--update method for referenceUpdate(Folder Structure(Patheon CR))
        int UpdateConfigureReferencetoMailbox(Hashtable hs);

        //Pranay 21 October 2016 -- method for binding GridView
        DataSet GridMailBoxReferenceBind(Hashtable hs);

        int ConfigureEscalationMatrix(Hashtable htUserData);
        int UpdateConfigureEscalationMatrix(Hashtable htUserData);
        DataSet GridEscalationMatrixBind(Hashtable hs);
        int DeleteEscalationMatrixMap(string hddnMBMapId, string UserId);
        DataSet BindFieldType();
        DataSet GetFieldDataandValidationType(Int32 FieldTypeID); DataSet Getfieldname(Int32 intFieldMasterID); DataSet BindFieldName(Int32 intFieldMasterID);
        DataSet GetDefaultListValues(Int32 intFieldTypeId, Int32 DynamicDropdownId);
        DataSet USP_GetConfigureFieldsValidationType_Result(Int32 fldDataTypeID);
        DataSet GetDatetimeFormat(Int32 ValidationTypeID);
        DataSet GridMailBoxFieldBind(Hashtable hs);
        int UpdateConfigureFieldstoMailbox(Hashtable hs);
        int ConfigureFieldtoMailbox(Hashtable hs);
        int ConfigureOptiontoField(Hashtable hs); 
        int UpdateOptionstoFields(Hashtable hs);
        DataSet GetOptionvalue(Int32 FieldmasterID);
    }
}
