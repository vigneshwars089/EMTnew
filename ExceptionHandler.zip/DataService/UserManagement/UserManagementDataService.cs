﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using EMTWebApp.DataHelper;
using EMTWebApp.ExceptionHandler;
using System.Collections;
using EMTWebApp.UserManagement.Common;


namespace EMTWebApp.DataService.UserManagement
{
    public class UserManagementDataService : DBHelper, IUserManagementDataService
    {
       
        UserSession UserData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        public int AddUser(string UserID, string FirstName, string LastName, string EmailID, string Password, int Active, string LoginId, string TimeZone, string OffSet,string SkillSet,string SkillDescription, bool isTimezone)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@USERID", UserID);
                hs.Add("@FIRSTNAME", FirstName);
                hs.Add("@LASTNAME", LastName);
                hs.Add("@EMAIL", EmailID);
                hs.Add("@Password", Password);
                hs.Add("@ISACTIVE", Active);
                hs.Add("@LoggedinUserId", LoginId);
                hs.Add("@SkillId", SkillSet);
                hs.Add("@SkillDescription", SkillDescription);
                if (isTimezone)
                {
                    hs.Add("@TIMEZONE", TimeZone);
                    hs.Add("@OFFSET", OffSet);
                }
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService.cs | AddUser()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_CREATE_USERS", hs));
        }

        public DataSet GridBind()
        {
            return this.SelectDataSet("USP_GET_USER_DETAILS");
        }

        public DataSet GetSkillSet()
        {
            return this.SelectDataSet("USP_GetSkillSet");
        }

        public DataSet GetUsercount()
        {
          return this.SelectDataSet("USP_TotalNoUsersCount");
        }


        public int UpdateUser(string UserID, string FirstName, string LastName, string EmailID, string Password, int Active, string LoginId, string TimeZone, string OffSet,string SkillSet,string SkillDescription, bool isTimezone)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@USERID", UserID);
                hs.Add("@FIRSTNAME", FirstName);
                hs.Add("@LASTNAME", LastName);
                hs.Add("@EMAIL", EmailID);
                hs.Add("@Password", Password);
                hs.Add("@ISACTIVE", Active);
                hs.Add("@LoggedinUserId", LoginId);
                hs.Add("@SkillId", SkillSet);
                hs.Add("@SkillDescription", SkillDescription);
                if (isTimezone)
                {
                    hs.Add("@TIMEZONE", TimeZone);
                    hs.Add("@OFFSET", OffSet);
                }
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UpdateUser()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_UPDATE_USERS", hs));
        }

        public int ValidatePassword(string txtLoginID, string encryptOldPassword)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@UserId", txtLoginID);
            hs.Add("@OldPassword", encryptOldPassword);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | ValidatePassword()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_VALIDATEPASSWORD", hs));
        }

        public int ChangePassword(string txtLoginID, string encryptOldPassword, string encryptConfirmPassword)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@UserId", txtLoginID);
            hs.Add("@OldPassword", encryptOldPassword);
            hs.Add("@NewPassword", encryptConfirmPassword);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | ChangePassword()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_CHANGEPASSWORD1", hs));
        }

        public int ValidateLogin(string LoginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@UserID", LoginId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | ValidateLogin()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_VALIDATEUSERID", hs));
        }

        public DataSet ForgotPassword(string loginId)
        {
            Hashtable hs = new Hashtable();
            hs.Add("@UserID", loginId);
            return this.SelectDataSet("USP_ForgotPassword", hs);
        }

        public DataSet GetSignature(string userid)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@Userid", userid);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | GetSignature()");
            }
            return this.SelectDataSet("USP_GET_SIGNATURE", hs);
        }

        public int ConfigureSignature(string Signature, string LoginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@Signature", Signature);
            hs.Add("@UserID", LoginId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | ConfigureSignature()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_Signature_CONFIGURATION", hs));
        }

        public int UpdateSignature(string SignId, string Signature, string LoginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@SignId", SignId);
            hs.Add("@Signature", Signature);
            hs.Add("@UserID", LoginId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UpdateSignature()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_UPDATE_Signature", hs));
        }

        public DataSet BindRole()
        {
            Hashtable hs = new Hashtable();
            return this.SelectDataSet("USP_BIND_ROLES", hs);
        }

        public DataSet BindActiveUsers()
        {
            Hashtable hs = new Hashtable();
            return this.SelectDataSet("USP_BIND_ACTIVE_USERS", hs);
        }

        public DataSet BindCountryChekBoxList()
        {
            Hashtable hs = new Hashtable();
            return this.SelectDataSet("USP_GET_COUNTRY_NAMES", hs);
        }

        public int MapUserRole(string UserId, int RoleId, string LoginId, string strCountryIdsToMap)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@UserID", UserId);
            hs.Add("@RoleId", RoleId);
            hs.Add("@LoggedinUserId", LoginId);
            hs.Add("@CountryIdsToMap", strCountryIdsToMap);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | MapUserRole()");
           
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_USER_ROLEMAP", hs));
        }

        public DataSet BindCountry()
        {
            return this.SelectDataSet("USP_GET_COUNTRY_NAMES");
        }

        public DataSet GridUserRoleMapBind()
        {
            Hashtable hs = new Hashtable();
            return this.SelectDataSet("USP_SELECT_ROLEMAPPED_USERS", hs);
        }

        public DataSet UserWiseRoleMapGridBind(string UserId)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@UserId", UserId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UserWiseRoleMapGridBind()");
            }
            return this.SelectDataSet("USP_SELECT_ROLEMAPPED_USERS_BY_USERID", hs);
        }
        public int UpdateRoleMap(string UserRoleMapId, string UserId, int RoleId, string LoginId, string CountryIdsToMap)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@UserRoleMappingId", UserRoleMapId);
            //hs.Add("@UserID", UserId);
            //hs.Add("@RoleId", RoleId);
            hs.Add("@CountryIdsToMap", CountryIdsToMap);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UpdateRoleMap()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_UPDATE_ROLEMAPPED_USERS", hs));
        }

        public int DeleteRoleMap(string hddnRMapId)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@UserRoleMappingId", hddnRMapId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | DeleteRoleMap()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_DELETE_ROLEMAPPED_USERS", hs));
        }

        public DataSet BindActiveMailBox(int CountryId, string LoggedInUserId, int LoggedInUserRoleId)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@COUNTRYID", CountryId);
            hs.Add("@LoggedInUserId", LoggedInUserId);
            hs.Add("@LoggedInUserRoleId", LoggedInUserRoleId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | BindActiveMailBox()");
            }
            return this.SelectDataSet("USP_BIND_COUNTRY_BASED_EMAILBOX", hs);
        }

        public int MapUserMailBox(string UserId, int MailBoxId, string LoginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@UserID", UserId);
            hs.Add("@MailBoxId", MailBoxId);
            hs.Add("@LoggedinUserId", LoginId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | MapUserMailBox()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_USER_MAILBOXMAP", hs));
        }

        public int ConfigureRemaindertoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_REMAINDER_MAILBOXADD_dynamicstatus", hs));
        }
        public int ConfigureCategorytoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_CATEGORY_MAILBOXADD", hs));
        }

        public DataSet GridMailBoxMapBind(Hashtable hs)
        {            
            return this.SelectDataSet("USP_SELECT_MAILBOXMAPPED_USERS", hs);
        }
        public DataSet GridMailBoxRemainderBind(Hashtable hs)
        {

            return this.SelectDataSet("USP_SELECT_MAILBOXMAPPED_REMAINDER_Dynamic", hs);
        }

        public DataSet getfromStatus(Hashtable hs)
        {
            return this.SelectDataSet("USP_SELECT_FROMSTATUS",hs);
        }

        public DataSet GridMailBoxcategoryBind(Hashtable hs)
        {

            return this.SelectDataSet("USP_SELECT_MAILBOXMAPPED_CATEGORY", hs);
        }

        public DataSet UserWiseMailBoxMapGridBind(string UserId, string ddlCountryId)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@UserId", UserId);
            hs.Add("@CountryId", ddlCountryId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UserWiseMailBoxMapGridBind()");
            }
            return this.SelectDataSet("USP_SELECT_MAILBOXMAPPED_USERS_BY_USERWISE", hs);
        }

        public int UpdateUserMailBoxMap(string UserMailBoxMapId, string UserId, int MailBoxId, string LoginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@UsermailBoxMappingId", UserMailBoxMapId);
            hs.Add("@UserID", UserId);
            hs.Add("@MailBoxId", MailBoxId);
            hs.Add("@LoggedinUserId", LoginId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UpdateUserMailBoxMap()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_UPDATE_MAILBOXMAPPED_USERS", hs));
        }

        public int UpdateConfigureRemaindertoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_UPDATE_REMAINDERMAILBOXMAPPED_dynamicstatus", hs));
        }

        public int UpdateConfigurecategorytoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_UPDATE_CATEGORYMAILBOXMAPPED", hs));
        }
       

        public int DeleteMailBoxMap(string hddnMBMapId, string UserId)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@UsermailBoxMappingId", hddnMBMapId);
            hs.Add("@USERID", UserId);            
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | DeleteMailBoxMap()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_DELETE_MAILBOXMAPPED_USERS", hs));
        }

        public int InsertMailLoginDetails(string MailId, string encryptConfirmPassword, int Locked, int Active)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@EMAILID", MailId);
            hs.Add("@PASSWORD", encryptConfirmPassword);
            hs.Add("@ISLOCKED", Locked);
            hs.Add("@ISACTIVE", Active);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | InsertMailLoginDetails()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_EMAILBOXLOGINDETAILS_CONFIGURATION", hs));
        }

        public DataSet GridEmailBoxLoginDetailsBind()
        {
            return this.SelectDataSet("USP_GET_EMAILBOXLOGINDETAILS_DETAILS");
        }

        public int UpdateMailBoxLoginDetails(string EmailBoxLoginDetailID, string MailId, string EncryptConfirmPassword, int Locked, int Active)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@EmailBoxLoginDetailId", EmailBoxLoginDetailID);
            hs.Add("@PASSWORD", EncryptConfirmPassword);
            hs.Add("@EMAILID", MailId);
            hs.Add("@ISLOCKED", Locked);
            hs.Add("@ISACTIVE", Active);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UpdateMailBoxLoginDetails()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_UPDATE_EMAILBOXLOGINDETAIL", hs));
        }
        public DataSet GetCountryByUserIdForDashboard(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetCountryByUserId_For_Dashboard", hs);
        }

        public int ConfigureEscalationMatrix(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_EscalationMatrix_ADD", hs));
        }
        public int UpdateConfigureEscalationMatrix(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_EscalationMatrix_UPDATE", hs));
        }
        public DataSet GridEscalationMatrixBind(Hashtable hs)
        {

            return this.SelectDataSet("USP_EscaltionMatrix_SELECT", hs);
        }

        public int DeleteEscalationMatrixMap(string hddnMBMapId, string UserId)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@EscalationMasterId", hddnMBMapId);
            // hs.Add("@USERID", UserId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | DeleteEscalationMatrixMap()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_EscalationMatrix_DELETE", hs));
        }

        public int UpdateConfigureFieldstoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_UpdateConfigureFields", hs));
        }

        public DataSet GridMailBoxFieldBind(Hashtable hs)
        {

            return this.SelectDataSet("USP_SELECT_MAILBOXMAPPED_FIELDS", hs);
        }

        public DataSet BindFieldType()
        {
            return this.SelectDataSet("USP_GET_FIELDTYPE");
        }
        public DataSet GetFieldDataandValidationType(Int32 FieldTypeID)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@FieldTypeID", FieldTypeID);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | GetFieldDataandValidationType()");
            }
            return this.SelectDataSet("USP_GETFIELDDATAANDVALIDATIONTYPE", hs);
        }

        public DataSet Getfieldname(Int32 intFieldMasterID)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@intFieldMasterID", intFieldMasterID);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | Getfieldname()");
            }
            return this.SelectDataSet("USP_Getfieldname", hs);
        }

        public DataSet BindFieldName(Int32 intFieldMasterID)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@intFieldMasterID", intFieldMasterID);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | BindFieldName()");
            }
            return this.SelectDataSet("USP_BindFieldName", hs);
        }

        public DataSet GetDefaultListValues(Int32 intFieldTypeId, Int32 DynamicDropdownId)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@FieldMasterID", intFieldTypeId);
            hs.Add("@DynamicDropdownId", DynamicDropdownId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | GetDefaultListValues()");
            }
            return this.SelectDataSet("USP_GetDefaultListValues", hs);
        }

        public DataSet USP_GetConfigureFieldsValidationType_Result(Int32 fldDataTypeID)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@FieldDataTypeID", fldDataTypeID);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | USP_GetConfigureFieldsValidationType_Result()");
            }
            return this.SelectDataSet("USP_GETCONFIGUREFIELDSVALIDATIONTYPE", hs);
        }

        public DataSet GetDatetimeFormat(Int32 ValidationTypeID)
        {
            Hashtable hs = new Hashtable();
            try
            {
            hs.Add("@ValidationTypeID", ValidationTypeID);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | GetDatetimeFormat()");
            }
            return this.SelectDataSet("USP_GETDATTIMEFORMAT", hs);
        }

        public int ConfigureFieldtoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_InsertConfigureFields", hs));
        }

        public int ConfigureOptiontoField(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_ConfigureOptiontoField", hs));
        }

        public int UpdateOptionstoFields(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_UpdateOption", hs));
        }

        public DataSet GetOptionvalue(Int32 FieldmasterID)
        {
            Hashtable hs = new Hashtable();
            try
            {

            hs.Add("@FieldmasterID", FieldmasterID);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | GetOptionvalue()");
            }
            return this.SelectDataSet("USP_GetOptionvalue", hs);
        }
        //Pranay 11 August 2016 ---Adding method for adding acknowledgeMail Template
        public int ConfigureAcknowledgetoMailbox(Hashtable htUserData)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_Acknowledge_MAILBOXADD", htUserData));
        }

        //Pranay 16 August 2016--Adding method for binding acknowlegded mailbox in gridview
        public DataSet GridMailBoxAcknowledgeBind(Hashtable hs)
        {

            return this.SelectDataSet("USP_SELECT_MAILBOXMAPPED_ACKNOWLEDGE", hs);
        }

        //Pranay 16 August 2016--Adding method for updating acknowlegded mailbox
        public int UpdateConfigureAcknowledgetoMailbox(Hashtable htUserData)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_UPDATE_ACKNOWLEDGEMAILBOXMAPPED", htUserData));
        }


        //Pranay 20 October 2016 -- Method for adding Reference for future user
        public int ConfigureReferencetoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_REFERENCE_MAILBOXADD", hs));
        }

        //Pranay 21 October 2016--update method for referenceUpdate(Folder Structure(Patheon CR))
        public int UpdateConfigureReferencetoMailbox(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_UPDATE_REFERENCEMAILBOXMAPPED", hs));
        }

        //Pranay 21 October 2016--update method for referenceUpdate(Folder Structure(Patheon CR))
        public DataSet GridMailBoxReferenceBind(Hashtable hs)
        {

            return this.SelectDataSet("USP_SELECT_MAILBOXMAPPED_REFERENCE", hs);
        }
    }
}
