using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.CompositeWeb;
using Microsoft.Practices.CompositeWeb.Interfaces;
using Microsoft.Practices.CompositeWeb.Services;
using Microsoft.Practices.CompositeWeb.Configuration;
//using Microsoft.Practices.CompositeWeb.EnterpriseLibrary.Services;
using Microsoft.Practices.EnterpriseLibrary.PolicyInjection;
using EMTWebApp.DataService.AuthenticationandAuthorization;
using EMTWebApp.UserManagement.Common;

namespace EMTWebApp.DataService
{
    public class DataServiceModuleInitializer : ModuleInitializer
    {
        UserSession UserData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        public override void Load(CompositionContainer container)
        {
            try
            {
                base.Load(container);

                AddGlobalServices(container.Services);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | DataServiceModuleInitializer.cs | GetOptionvalue()");
            }
        }

        protected virtual void AddGlobalServices(IServiceCollection globalServices)
        {

        }
        public override void Configure(IServiceCollection services, System.Configuration.Configuration moduleConfiguration)
        {
        }
    }
}
