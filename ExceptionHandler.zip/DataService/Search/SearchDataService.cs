﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EMTWebApp.DataHelper;
using System.Data;
using System.Collections;
using EMTWebApp.UserManagement.Common;

namespace EMTWebApp.DataService.Search
{
    public class SearchDataService : DBHelper, ISearchDataService
    {
        UserSession UserData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        public DataSet GetCountryByUserId(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetCountryByUserId", ht);
        }
        public DataSet GetCountryByUserIdForDashboard(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetCountryByUserId_For_Dashboard", ht);
        }
        public DataSet GetMailboxByCountryId(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetEmailBoxByCountryId", ht);
        }
        public DataSet GetMailboxByCountryIdandUserId(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetEmailBoxByCountryId_And_UserID", ht);
        }
        public DataSet GetSearchCaseList(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetSearchCaseList_Pagination", ht);
        }
        public DataSet GetSearchExportList(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetSearchCaseList", ht);
        }
        public DataSet GetAllStatus(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetAllStatus", ht);
        }
        public DataSet GetUserIdsByCountryEmailboxRole(Hashtable ht)
        {
            return this.SelectDataSet("usp_GetUserIdsByCountryEmailboxRole", ht);
        }
        public DataSet GetSkillSet()
        {
            return this.SelectDataSet("USP_GetSkillSet");
        }
        public int UpdateOnReassign(Hashtable ht)
        {
            return this.ExecuteNonQuery("USP_UpdateOnReassign", ht);
        }
        public int UpdateCaseFromClarifNeededToClarifReceived(Hashtable ht)
        {
            return this.ExecuteNonQuery("USP_UpdateCaseFromClarifNeededToClarifReceived", ht);
        }
        public DataSet IsSkillBasedAllocation(Hashtable ht)
        {
            
                return this.SelectDataSet("USP_IsSkillBasedAllocation", ht);
           
        }
        

        //Pranay -3 October 2016
        /// <summary>
        /// Function for Inserting values to StoredProcedure for Reopen Cases
        /// </summary>
        /// <param name="ht"></param>
        /// <returns></returns>
        public int InsertMailForReopenCases(Hashtable ht)
        {

            return Convert.ToInt32(this.SelectSingleValue("USP_Insert_MailCaseDetailsForReopenCases", ht));
        }

        //Pranay   -- 3 October 2016
        /// <summary>
        /// Function for Inserting Attachments of Previous caseid to Reopened Cases
        /// </summary>
        /// <param name="ht"></param>
        /// <returns></returns>

        public int InsertAttachmentForReopenCases(Hashtable htcaseid)
        {
            return this.InsertData("USP_Insert_Mail_Attachment_For_Reopen_Cases", htcaseid);
        }

        public DataSet LoadCaseDetails(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetCaseDetailsForProcessing", hs);
        }

        ////Pranay 24 October 2016 Function to Bind the Flag Criteria based on Mailbox selected
        public DataSet GetFlagCriteriaByEmailboxSelected(Hashtable ht)
        { 
          return this.SelectDataSet("USP_GetFlagCriteriaByEmailBoxSelected", ht);
        }


        ////Pranay -24 October 2016
        ///// <summary>
        ///// Function for Inserting values to StoredProcedure for Reopen Cases
        ///// </summary>
        ///// <param name="ht"></param>
        ///// <returns></returns>
        //public int InsertDetailsForFlaggedCases(Hashtable ht)
        //{

        //    return Convert.ToInt32(this.ExecuteNonQuery("USP_InsertDetailsForFlaggedCases", ht));
        //}

        //Pranay -26 October 2016
        /// <summary>
        /// Function for Inserting values to StoredProcedure for Reopen Cases
        /// </summary>
        /// <param name="ht"></param>
        /// <returns></returns>
        public int UpdateDetailsForUnFlaggedCases(Hashtable ht)
        {

            return Convert.ToInt32(this.ExecuteNonQuery("USP_UpdateDetailsForUnFlaggedCases", ht));
        }
    }
}
