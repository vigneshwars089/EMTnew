﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Collections;

namespace EMTWebApp.DataService.Configuration
{
    public interface IConfigurationDataService
    {
        int ConfigureCountry(string CountryName, int Active, string LoginId);
        DataSet GridCountryDetBind();
        int UpdateCountry(string CountryId, string CountryName, int Active, string LoginId);
        //Pranay 2nd January 2017---added parameter TimeZone 
        int MailBoxCreation(string EmailBox, string EmailAddrs, string EmailAddrsOpt, string MailFoldPath, string Domain, string UserId, string encryptConfirmPassword, string CountryName, string SubProcessId, string SLA, int Active, int QcReq,int IsApprovalRequired, int MailTrigger, string LoginId, string EMailid, int ReplyNotReq, int IsVocSurvey,int IsSkillBasedAllocation, int IsLocked, string TimeZone, string Offset, bool isTimezone);
        DataSet BindCountry();
        DataSet BindCountryForSubProcess();
        DataSet GridMailBoxDetBind();
        DataSet bindActiveUsers();
        DataSet BindEmailBoxMailId();
        //Pranay 2nd January 2017---added parameter TimeZone 
        int UpdateMailBoxDet(string MailBoxId, string EmailBox, string EmailAddrs, string EmailAddrsOpt, string MailFoldPath, string Domain, string UserId, string encryptConfirmPassword, string CountryName, string SubProcessId, string SLA, int Active, int QcReq,int IsApprovalRequired, int MailTrigger, string LoginId, string EMailid, int ReplyNotReq, int IsVocSurvey,int IsSkillBasedAllocation, int IsLocked, string TimeZone, string OffSet, bool isTimezone);
        int ConfigureSubProcessNames(int CountryId, string SubProcessName, string ProcessOwnerId, int Active, string LoginId);
        DataSet GridSubProcessGroupsBind();
        int UpdateSubProcessNames(int CountryId, string SubProcessId, string SubProcessName, string ProcessOwnerId, int Active, string LoginId, string PreSubProcessname);
        DataSet BindSubProcessNames();
        int ConfigureHolidays(string Holiday, DateTime HolidayDate, int Active, string LoginId);
        DataSet GridBindHolidayDet();
        int UpdateHoliday(string HolidayId, string Holiday, DateTime HolidayDate, int Active, string LoginId);


        DataSet GetSubProcessByCountryId(Hashtable htUserData);
    }
}
