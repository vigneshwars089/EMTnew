﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EMTWebApp.DataHelper;
using System.Data;
using System.Collections;
using EMTWebApp.UserManagement.Common;
using System.Web.UI;

namespace EMTWebApp.DataService.Configuration
{
    public class ConfigurationDataService : DBHelper, IConfigurationDataService
    {
        UserSession UserData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        public int ConfigureCountry(string CountryName, int Active, string LoginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@COUNTRYNAME", CountryName);
                hs.Add("@ISACTIVE", Active);
                hs.Add("@CREATEDBY", LoginId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | ConfigurationDataService | ConfigureCountry()");
                
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_COUNTRY_CONFIGURATION", hs));
        }

        public DataSet GridCountryDetBind()
        {
            return this.SelectDataSet("USP_GET_COUNTRY_DETAILS");
        }

        public int UpdateCountry(string CountryId, string CountryName, int Active, string LoginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@CountryId", CountryId);
                hs.Add("@COUNTRYNAME", CountryName);
                hs.Add("@ISACTIVE", Active);
                hs.Add("@CREATEDBY", LoginId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | ConfigurationDataService | UpdateCountry()");
                
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_UPDATE_COUNTRY", hs));
        }

        public int MailBoxCreation(string EmailBox, string EmailAddrs, string EmailAddrsOpt, string MailFoldPath, string Domain, string UserId, string encryptConfirmPassword, string CountryName, string SubProcessId, string SLA, int Active, int QcReq,int IsApprovalRequired, int MailTrigger, string LoginId, string EMailid, int ReplyNotReq, int IsVocSurvey,int IsSkillBasedAllocation, int IsLocked, string TimeZone, string OffSet, bool isTimezone)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@EMailBoxName", EmailBox);
                hs.Add("@EMailBoxADDRESS", EmailAddrs);
                hs.Add("@EMailBoxADDRESSOpt", EmailAddrsOpt);
                hs.Add("@EMAILFOLDERPATH", MailFoldPath);
                hs.Add("@DOMAIN", Domain);
                hs.Add("@UserId", UserId);
                hs.Add("@PASSWORD", encryptConfirmPassword);
                hs.Add("@COUNTRYNAME", CountryName);
                hs.Add("@SUBPROCESSGROUPID", SubProcessId);
                hs.Add("@TATHRS", SLA);
                hs.Add("@ISACTIVE", Active);
                hs.Add("@ISQCREQUIRED", QcReq);
                hs.Add("@IsApprovalRequired", IsApprovalRequired);
                hs.Add("@TriggerMAil", MailTrigger);
                hs.Add("@CREATEDBYID", LoginId);
                hs.Add("@EMAILID", EMailid);
                hs.Add("@ISREPLYNOTREQUIRED", ReplyNotReq);
                hs.Add("@ISLOCKED", IsLocked);
                hs.Add("@IsVocSurvey", IsVocSurvey);
                hs.Add("@IsSkillBasedAllocation", IsSkillBasedAllocation);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | ConfigurationDataService | MailBoxCreation()");
            }
            if (isTimezone)
            {
                //Pranay 2nd January 2017---added parameter TimeZone 
                hs.Add("@TIMEZONE", TimeZone);
                hs.Add("@OFFSET", OffSet);
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_MAILBOX_CONFIGURATION", hs));
        }

        public DataSet BindCountry()
        {
            return this.SelectDataSet("USP_GET_COUNTRY_NAMES");
        }

        public DataSet BindSubProcessNames()
        {
            return this.SelectDataSet("USP_BIND_SUBPROCESSNAMES");
        }

        public DataSet BindEmailBoxMailId()
        {
            return this.SelectDataSet("USP_BIND_EMAILBOX_LOGINMAILID");
        }

        public DataSet GridMailBoxDetBind()
        {
            return this.SelectDataSet("USP_GET_MailBox_Details");
        }

        public DataSet bindActiveUsers()
        {
            return this.SelectDataSet("USP_BIND_ACTIVE_USERS");
        }

        public int UpdateMailBoxDet(string MailBoxId, string EmailBox, string EmailAddrs, string EmailAddrsOpt, string MailFoldPath, string Domain, string UserId, string encryptConfirmPassword, string CountryName, string SubProcessId, string SLA, int Active, int QcReq,int IsApprovalRequired, int MailTrigger, string LoginId, string EMailid, int ReplyNotReq, int IsVocSurvey,int IsSkillBasedAllocation, int IsLocked, string TimeZone, string OffSet, bool isTimezone)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@EMailBoxId", MailBoxId);
                hs.Add("@EMailBoxName", EmailBox);
                hs.Add("@EMailBoxADDRESS", EmailAddrs);
                hs.Add("@EMailBoxADDRESSOPT", EmailAddrsOpt);
                hs.Add("@EMAILFOLDERPATH", MailFoldPath);
                hs.Add("@DOMAIN", Domain);
                hs.Add("@UserId", UserId);
                hs.Add("@PASSWORD", encryptConfirmPassword);
                hs.Add("@COUNTRYNAME", CountryName);
                hs.Add("@SUBPROCESSGROUPID", SubProcessId);
                hs.Add("@TATHRS", SLA);
                hs.Add("@ISACTIVE", Active);
                hs.Add("@ISQCREQUIRED", QcReq);
                hs.Add("@IsApprovalRequired", IsApprovalRequired);
                hs.Add("@TriggerMAil", MailTrigger);
                hs.Add("@ISREPLYNOTREQUIRED", ReplyNotReq);
                hs.Add("@CREATEDBYID", LoginId);
                hs.Add("@EMAILID", EMailid);
                hs.Add("@ISLOCKED", IsLocked);
                hs.Add("@IsVocSurvey", IsVocSurvey);
                hs.Add("@IsSkillBasedAllocation", IsSkillBasedAllocation);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | ConfigurationDataService | UpdateMailBoxDet()");
            }
            if (isTimezone)
            {
                //Pranay 2nd January 2017---added parameter TimeZone 
                hs.Add("@TIMEZONE", TimeZone);
                hs.Add("@OFFSET", OffSet);
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_UPDATE_MAILBOX", hs));
        }

        public int ConfigureSubProcessNames(int CountryId, string SubProcessName, string ProcessOwnerId, int Active, string LoginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@SubProcessName", SubProcessName);
                hs.Add("@ProcessOwnerId", ProcessOwnerId);
                hs.Add("@ISACTIVE", Active);
                hs.Add("@CREATEDBY", LoginId);
                hs.Add("@CountryId", CountryId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | ConfigurationDataService | ConfigureSubProcessNames()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_SUBPROCESSGROUPS_CONFIGURATION", hs));
        }

        public DataSet GridSubProcessGroupsBind()
        {
            return this.SelectDataSet("USP_GET_SUBPROCESSGROUPS_DETAILS");
        }

        public int UpdateSubProcessNames(int CountryId, string SubProcessId, string SubProcessName, string ProcessOwnerId, int Active, string LoginId, string PreSubProcessname)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@SubProcessGroupID", SubProcessId);
                hs.Add("@SubProcessName", SubProcessName);
                hs.Add("@ProcessOwnerId", ProcessOwnerId);
                hs.Add("@ISACTIVE", Active);
                hs.Add("@CREATEDBY", LoginId);
                hs.Add("@CountryId", CountryId);
                hs.Add("@PreSubProcessname", PreSubProcessname);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | ConfigurationDataService | UpdateSubProcessNames()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_UPDATE_SUBPROCESSGROUPS", hs));
        }

        public int ConfigureHolidays(string Holiday, DateTime HolidayDate, int Active, string LoginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@HolidayDesc", Holiday);
                hs.Add("@HolidayDATE ", HolidayDate);
                hs.Add("@ISACTIVE", Active);
                hs.Add("@LOGGEDINUSERID", LoginId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | ConfigurationDataService | ConfigureHolidays()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_INSERT_HOLIDAY_DETAILS", hs));
        }

        public DataSet GridBindHolidayDet()
        {
            return this.SelectDataSet("USP_GET_HOLIDAY_DETAILS");
        }

        public int UpdateHoliday(string HolidayId, string Holiday, DateTime HolidayDate, int Active, string LoginId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@HOLIDAYID", HolidayId);
                hs.Add("@HolidayDesc", Holiday);
                hs.Add("@HolidayDATE ", HolidayDate);
                hs.Add("@ISACTIVE", Active);
                hs.Add("@LOGGEDINUSERID", LoginId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | ConfigurationDataService | UpdateHoliday()");
            }
            return Convert.ToInt32(this.SelectSingleValue("USP_UPDATE_HOLIDAYDETAILS", hs));
        }

        public DataSet GetSubProcessByCountryId(Hashtable htUserData)
        {
            return this.SelectDataSet("USP_GetSubProcessByCountryID", htUserData);
        }


        public DataSet BindCountryForSubProcess()
        {
            return this.SelectDataSet("USP_GET_COUNTRY_SUBPROCESS_NAMES");
        }
    }
}
