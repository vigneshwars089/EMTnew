﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;

namespace EMTWebApp.DataService.Common
{
    public interface ICommonDataService
    {
        DataSet LoadCaseDetails(Hashtable hs);
        DataSet GetQcReAssignWorkQueueDetails(Hashtable hsparams);
        int UpdateDirectReAssign(Hashtable hsparams);
        DataSet GetQcWorkQueueDetails(Hashtable hsparams);
        DataSet GetAttachmentDetails(Hashtable hs);
        DataSet LoadAttachmentList(Hashtable hs);
        void UploadAttachment(long CaseId, IList AttachmentList, string UserId);
        DataSet GetStatusList();
        DataSet GetProcessorsForQC(Hashtable hsparams);
        DataSet GetEmailBox(Hashtable hsparams);
        DataSet GetCountry(Hashtable hsparams);
        DataSet GetCountryByUserId(Hashtable hsparams);
        DataSet GetEmailBoxDetails(Hashtable hs);
        int UpdateCaseDetails(Hashtable hs);
        DataSet GetEMailBoxByUserId(Hashtable htUserData);
        long CreateManualCase(Hashtable hs,IList fileCollection);
        //DataSet GetUserIdsByEMailboxId(Hashtable hsparams);
        DataSet GetClarificationResetReason();
        DataSet Getcategory(Hashtable hs);

        DataSet BindComments(Hashtable hsparams);
        DataSet BindAuditLog(Hashtable hsparams);
    }
}
