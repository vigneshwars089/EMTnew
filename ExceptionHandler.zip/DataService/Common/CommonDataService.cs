﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EMTWebApp.DataHelper;
using System.Data.Common;
using EMTWebApp.ExceptionHandler;
using EMTWebApp.Constants;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using EMTWebApp.UserManagement.Common;

namespace EMTWebApp.DataService.Common
{
    public class CommonDataService : DBHelper, ICommonDataService
    {
        UserErrorLog errorlog = new UserErrorLog();
        UserSession UserData = new UserSession();
        public void test()
        {
            //this.ExecuteNonQuery();
        }

        public DataSet BindComments(Hashtable hsparams)
        {
            return this.SelectDataSet("USP_GetComments", hsparams);
        }

        public DataSet BindAuditLog(Hashtable hsparams)
        {
            return this.SelectDataSet("USP_GetCaseAuditLog", hsparams);
        }

        public DataSet GetUserIdsByCountryEmailboxRole(Hashtable ht)
        {
            return this.SelectDataSet("usp_GetUserIdsByCountryEmailboxRole", ht);
        }

        public DataSet GetCategoryNames()
        {
            return this.SelectDataSet("USP_GetClassificationNamesList");
        }
        public int UpdateOnReassign(Hashtable ht)
        {            
            return this.ExecuteNonQuery("USP_UpdateOnReassign", ht);
        }

        public DataSet GetStatusTransition(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetStatusTransitionBySubProcessIdAndRoleId", ht);
        }

        public int UpdateOnRemappingOfCategory(Hashtable ht)
        {
            return this.ExecuteNonQuery("USP_UpdateOnRemapOfCategory",ht);
        }
        public DataSet LoadCaseDetails(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetCaseDetailsForProcessing", hs);
        }
        //Case travsersal
        public DataSet GetChildCaseDetails(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetGMBChildCaseDetails", hs);
        }

        //Case traversal
        public DataSet GetParentCaseDetails(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetGMBParentCaseDetails", hs);
        }
        public int UpdateForwardToGMB(Hashtable hs)
        {
            return this.UpdateData("USP_UpdateForwardToGMB", hs);
        }

        public DataSet LoadEMailBoxDetails(Hashtable hs)
        {
            return this.SelectDataSet("USP_LoadEMailBoxDetails", hs);
        }
        public DataSet LoadNextCase(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetCaseDetailsForLoadingNextCase", hs);
        }

        public DataSet InsertProductLicense(Hashtable hs)
        {
            return this.SelectDataSet("USP_InsertProductLicenseKey", hs);
        }
        public DataSet GetUserCount()
        {
            return this.SelectDataSet("[USP_TotalNoUsersCount]");
        }

        public DataSet LoadNextCaseWithClassificationName(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetCaseDetailsForLoadingNextCase_NEW", hs);
        }

        public DataSet LoadPreviousCase(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetCaseDetailsForLoadingNextCase", hs);
        }
        public DataSet LoadPreviousCaseWithClassificationName(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetCaseDetailsForLoadingNextCase_NEW", hs);
        }

        public DataSet GetQcReAssignWorkQueueDetails(Hashtable hsparams)
        {
            return this.SelectDataSet("USP_GetUsersPushForQCQueue", hsparams);
        }

        public int UpdateDirectReAssign(Hashtable hsParms)
        {
            return this.UpdateData("USP_UpdateQCAssignPeerToPeer", hsParms);
        }
        public DataSet GetQcWorkQueueDetails(Hashtable hsparams)
        {
            return this.SelectDataSet("USP_GetQCWorkQueue", hsparams);
        }
        public DataSet GetApproverWorkQueueDetails(Hashtable hsparams)
        {
            return this.SelectDataSet("USP_GetApproverWorkQueue", hsparams);
        }

        public DataSet GetAttachmentDetails(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetattachmentDetails", hs);
        }

        public DataSet GetDynamicPageControls(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetDynamicControlstoDataEntry", hs);
        }

        public DataSet GetDynamicPageControlsForManualCase(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetDynamicControlstoDataEntryforManualCase", hs);
        }

        public DataSet GetCountryByUserId(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetCountryByUserId", hs);
        }
        public DataSet GetCountryByUserIdForDashboard(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetCountryByUserId_For_Dashboard", hs);
        }
        public DataSet LoadAttachmentList(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetAttachmentList", hs);
        }

        public DataSet GetStatus(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetStatus",hs);
        }

        //sourcenet
        public DataSet LoadConversationsList(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetConversationList", hs);
        }

        public int InsertMailConversation(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_Insert_Mail_Conversation", hs));
        }

        public void UploadAttachment(long ConversationId, IList AttachmentList, string UserId)
        {
            try
            {
                foreach (Attachment at in AttachmentList)
                {
                    DbCommand attachcommand = this.Db.GetStoredProcCommand("USP_Insert_Mail_Attachment");
                    attachcommand.Parameters.Add(new SqlParameter("AttachmentName", at.FileName));
                    attachcommand.Parameters.Add(new SqlParameter("ContentType", at.FileType));
                    attachcommand.Parameters.Add(new SqlParameter("AttachmentData", at.FileContent));
                    attachcommand.Parameters.Add(new SqlParameter("AttachmentType", at.AttachmentTypeId));
                    attachcommand.Parameters.Add(new SqlParameter("ConversationId", ConversationId));
                    attachcommand.Parameters.Add(new SqlParameter("CreatedBy", UserId));
                    this.Db.ExecuteNonQuery(attachcommand);
                    attachcommand = null;
                }
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | UploadAttachment()");
                
            }
        }
        public void UploadAttachment_Draft(long CaseId, IList AttachmentList, string UserId)
        {
            try
            {
                foreach (Attachment at in AttachmentList)
                {
                    DbCommand attachcommand = this.Db.GetStoredProcCommand("USP_Insert_Mail_Attachment_Draft_att");
                    attachcommand.Parameters.Add(new SqlParameter("AttachmentName", at.FileName));
                    attachcommand.Parameters.Add(new SqlParameter("ContentType", at.FileType));
                    attachcommand.Parameters.Add(new SqlParameter("AttachmentData", at.FileContent));
                    attachcommand.Parameters.Add(new SqlParameter("AttachmentType", at.AttachmentTypeId));
                    attachcommand.Parameters.Add(new SqlParameter("CaseId", CaseId));
                    attachcommand.Parameters.Add(new SqlParameter("CreatedBy", UserId));
                    this.Db.ExecuteNonQuery(attachcommand);
                    attachcommand = null;
                }
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | UploadAttachment_Draft()");
                //Response.Redirect("~/Errors/Error.aspx", false);
            }
        }

        public int DeleteLastDraft(long Caseid)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@Caseid", Caseid);
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | DeleteLastDraft()");
                //Response.Redirect("~/Errors/Error.aspx", false);
            }
            return this.DeleteData("USP_DeleteLastDraft", hs);
        }
        public int DeleteTotalDraft(long Caseid)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@Caseid", Caseid);
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | DeleteTotalDraft()");
                //Response.Redirect("~/Errors/Error.aspx", false);
            }
            return this.DeleteData("USP_DeleteTotalDraft", hs);
        }
        public int DraftUpdate(Hashtable ht)
        {
            return this.ExecuteNonQuery("USP_DraftUpdate", ht);
        }
        public DataSet GetProcessorsForQC(Hashtable hsParms)
        {
            return this.SelectDataSet("USP_GetProcessorsForQC", hsParms);
        }

        public DataSet GetEmailBox(Hashtable hsParms)
        {
            return this.SelectDataSet("USP_GetEmailBoxDetailsByUserID", hsParms);
        }

        public DataSet GetCountry(Hashtable hsParms)
        {
            return this.SelectDataSet("USP_GetCountryByUserId", hsParms);
        }
        public DataSet GetStatusList()
        {
            return this.SelectDataSet("USP_GetStatusList");
        }
        public DataSet previousStatusID(Hashtable hsCaseId)
        {
            return this.SelectDataSet("USP_GetPreviousStatusID",hsCaseId);
        }
        
        public DataSet GetDashboardCount(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetDashboardCount", ht);
        }
        public DataSet GetUserIdByCountryId(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetUsersFromCountry", ht);
        }

        public DataSet GetSubProcessGroup(Hashtable ht)
        {
            return this.SelectDataSet("USP_GET_SUBPROCESSGROUPS_DETAILS", ht);
        }
        public DataSet GetActiveSubProcessGroup(Hashtable ht)
        {
            return this.SelectDataSet("USP_GET_SUBPROCESSGROUPS_DETAILS_Active", ht);
        }
        public DataSet BindRoleBaseSubProcess(Hashtable ht)
        {
            return this.SelectDataSet("USP_SUBPROCESS_ROLEBASED_BIND", ht);
        }
        public DataSet GetWorkQueueList_mailboxlevel(Hashtable ht)
        {
           // return this.SelectDataSet("SP_GetDonutChartDtls", ht);
            return this.SelectDataSet_Inbox("[USP_GetWorkQueueListDetails_Pagination_NEW_withClassification_dynamic changes]", ht);
        }

         public DataSet GetWorkQueueList(Hashtable ht)
        {
           // return this.SelectDataSet("SP_GetDonutChartDtls", ht);             
            //return this.SelectDataSet_Inbox("[USP_GetWorkQueueListDetails_Pagination_NEW]", ht);
            return this.SelectDataSet_Inbox("[USP_GetWorkQueueListDetails_Pagination_NEW_dynamicchnages]", ht);
        }

        
        public DataSet GetEmailBoxDetails(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetEmailBoxDetails", hs);
        }

        public DataSet GetStatusDetails(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetManualCaseStatus", hs);
        }
        public DataSet GetTemplateDetails(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetManualCaseTemplate", hs);
        }
        public DataSet GetTemplateContent(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetTemplateContent", hs);
        }

        public DataSet GetclassificationList()
        {
            return this.SelectDataSet("USP_GetClassificationNamesList");
        }
        public int UpdateCaseDetails(Hashtable hs)
        {
            return this.UpdateData("USP_UpdateCaseDetails", hs);
        }

        public int Updatedynamicfields(Hashtable hs)
        {
            return this.UpdateData("USP_Updatedynamicfields", hs);
        }

        public int UpdateAutoAcknowledgement(Hashtable hs)
        {
            return this.UpdateData("USP_SET_AUTO_ACKNOWLEDGEMENT", hs);
        }
        public DataSet GetEMailBoxByUserId(Hashtable htUserData)
        {
            return this.SelectDataSet("USP_GetEmailBoxDetailsByUserID", htUserData);
        }


        public DataTable EmailboxNameswithclassification(string CountryId, string LoggedInUserId, string RoleId, string SelectedAssociateId, string SelectedSubProcessId, string strConnectionString)
        {
            DataSet ds = new DataSet();
            try
            {
                SqlConnection myConnection;
                SqlCommand myCommand;
                myConnection = new SqlConnection(strConnectionString);
                myConnection.Open();
                //myCommand = new SqlCommand("[USP_GetDashboardCount_Details]", myConnection);
                myCommand = new SqlCommand("[USP_GetDashboardCount_Details_With_Process_Classification]", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;
                myCommand.Parameters.Add("@CountryId", SqlDbType.Int).Value = CountryId;
                myCommand.Parameters.Add("@LoggedInUserId", SqlDbType.VarChar).Value = LoggedInUserId;
                myCommand.Parameters.Add("@RoleId", SqlDbType.Int).Value = RoleId;
                myCommand.Parameters.Add("@SelectedAssociateId", SqlDbType.VarChar).Value = SelectedAssociateId;
                //myCommand.Parameters.Add("@SelectedSubProcessId", SqlDbType.VarChar).Value = SelectedSubProcessId;

                myCommand.CommandTimeout = 120;




                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = myCommand;
                da.Fill(ds);
                da.Dispose();
                myCommand.Dispose();
                myConnection.Close();

                //string s = JsonConvert.SerializeObject(strResult, Formatting.Indented);
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | EmailboxNames()");
                //Response.Redirect("~/Errors/Error.aspx", false);
            }

            return ds.Tables[0];
        }
        public DataTable EmailboxNames(string CountryId, string LoggedInUserId, string RoleId, string SelectedAssociateId, string SelectedSubProcessId, string strConnectionString)
        {
            DataSet ds = new DataSet();
            try
            {
                SqlConnection myConnection;
                SqlCommand myCommand;
                myConnection = new SqlConnection(strConnectionString);
                myConnection.Open();
                //myCommand = new SqlCommand("[USP_GetDashboardCount_Details]", myConnection);
                myCommand = new SqlCommand("[USP_GetDashboardCount_Details_With_Process]", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;
                myCommand.Parameters.Add("@CountryId", SqlDbType.Int).Value = CountryId;
                myCommand.Parameters.Add("@LoggedInUserId", SqlDbType.VarChar).Value = LoggedInUserId;
                myCommand.Parameters.Add("@RoleId", SqlDbType.Int).Value = RoleId;
                myCommand.Parameters.Add("@SelectedAssociateId", SqlDbType.VarChar).Value = SelectedAssociateId;
                //myCommand.Parameters.Add("@SelectedSubProcessId", SqlDbType.VarChar).Value = SelectedSubProcessId;

                myCommand.CommandTimeout = 120;



               
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = myCommand;
                da.Fill(ds);
                da.Dispose();
                myCommand.Dispose();
                myConnection.Close();
                
                //string s = JsonConvert.SerializeObject(strResult, Formatting.Indented);
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | EmailboxNames()");
                //Response.Redirect("~/Errors/Error.aspx", false);
            }

            return ds.Tables[0];
        }


        public DataTable EmailboxStatuses(string CountryName, string EmailboxName,string SubProcess,string LoggedInUserId, string strConnectionString)
        {
            DataSet ds = new DataSet();
            try
            {
                SqlConnection myConnection;
                SqlCommand myCommand;
                myConnection = new SqlConnection(strConnectionString);
                myConnection.Open();
                //myCommand = new SqlCommand("[USP_GetDashboardCount_Details]", myConnection);
                myCommand = new SqlCommand("[USP_GetDynamicStatusDashboardCount_Details_Dynamic]", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;
                myCommand.Parameters.Add("@CountryName", SqlDbType.VarChar).Value = CountryName;
                myCommand.Parameters.Add("@Emailbox", SqlDbType.VarChar).Value = EmailboxName;
                myCommand.Parameters.Add("@SubProcessName", SqlDbType.VarChar).Value = SubProcess;
                myCommand.Parameters.Add("@LoggedInUserId", SqlDbType.VarChar).Value = LoggedInUserId;
                myCommand.CommandTimeout = 120;

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = myCommand;
                da.Fill(ds);
                da.Dispose();
                myCommand.Dispose();
                myConnection.Close();

                //string s = JsonConvert.SerializeObject(strResult, Formatting.Indented);
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | EmailboxNames()");
                //Response.Redirect("~/Errors/Error.aspx", false);
            }

            return ds.Tables[0];
        }


        public int Classificationcheck(string strConnectionString)
        {
            DataSet ds = new DataSet();
            try
            {                
                SqlConnection myConnection;
                SqlCommand myCommand;
                myConnection = new SqlConnection(strConnectionString);
                myConnection.Open();               
                myCommand = new SqlCommand("[USP_GetClassificationCount_Details]", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = myCommand;
                da.Fill(ds);
                da.Dispose();
                myCommand.Dispose();
                myConnection.Close();
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | EmailboxNames()");
                //Response.Redirect("~/Errors/Error.aspx", false);
            }

            return Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
        }

        public DataSet GetAllEmailBoxDetails(Hashtable htUserData)
        {
            return this.SelectDataSet("USP_GetAllEmailBoxDetails", htUserData);
        }


        public DataSet GetAllChildCaseDetails(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetAllChildCaseDetails", ht);
        }


        public int RemoveInlineAttachmentsForCaseId(Hashtable ht)
        {
            return this.ExecuteNonQuery("USP_RemoveCaseInlineAttachments", ht);
        }

        public long CreateManualCase(Hashtable hs, IList fileCollection)
        {
            int result = 0;
            Int64 CaseId = 0;

            using (DbConnection connection = Db.CreateConnection())
            {
                try
                {
                    connection.Open();
                    using (DbTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            string strCreateNewCase = "USP_CREATEMANUALCASE_test";
                            DbCommand insertQueryCommand = this.Db.GetStoredProcCommand(strCreateNewCase);
                            insertQueryCommand.Parameters.Add(new SqlParameter("FromEMailId", hs["FromEMailId"]));
                            insertQueryCommand.Parameters.Add(new SqlParameter("ToEMailId", hs["ToEMailId"]));
                            insertQueryCommand.Parameters.Add(new SqlParameter("CCEMailId", hs["CCEMailId"]));
                            insertQueryCommand.Parameters.Add(new SqlParameter("Subject", hs["Subject"]));
                            insertQueryCommand.Parameters.Add(new SqlParameter("EMailBody", hs["EMailBody"]));
                            insertQueryCommand.Parameters.Add(new SqlParameter("EMailBoxID", hs["EMailBoxID"]));
                            insertQueryCommand.Parameters.Add(new SqlParameter("UserId", hs["UserId"]));
                            insertQueryCommand.Parameters.Add(new SqlParameter("isReplyNotRequired", hs["isReplyNotRequired"]));
                            insertQueryCommand.Parameters.Add(new SqlParameter("StatusId", hs["StatusId"]));
                            insertQueryCommand.Parameters.Add(new SqlParameter("Classification", hs["Classification"]));
                            insertQueryCommand.Parameters.Add(new SqlParameter("COMPOSEGMB", hs["COMPOSEGMB"]));
                            insertQueryCommand.Parameters.Add(new SqlParameter("CaseID", CaseId));
                            insertQueryCommand.Parameters["CaseID"].Direction = ParameterDirection.Output;

                            result = result + this.Db.ExecuteNonQuery(insertQueryCommand, transaction);
                            CaseId = Int64.Parse(insertQueryCommand.Parameters["CaseID"].Value.ToString());

                            if (CaseId != 0)
                            {                                
                                //foreach (Attachment at in fileCollection)
                                //{
                                //    DbCommand attachcommand = this.Db.GetStoredProcCommand("USP_Insert_Mail_Attachment");
                                //    attachcommand.Parameters.Add(new SqlParameter("ConversationID", ConversationId));
                                //    attachcommand.Parameters.Add(new SqlParameter("AttachmentName", at.FileName));
                                //    attachcommand.Parameters.Add(new SqlParameter("ContentType", at.FileType));
                                //    attachcommand.Parameters.Add(new SqlParameter("AttachmentData", at.FileContent));
                                //    attachcommand.Parameters.Add(new SqlParameter("AttachmentType", at.AttachmentTypeId));
                                //    //attachcommand.Parameters.Add(new SqlParameter("CaseId", CaseId));
                                //    attachcommand.Parameters.Add(new SqlParameter("CreatedBy", hs["UserId"]));
                                //    this.Db.ExecuteNonQuery(attachcommand, transaction);
                                //    attachcommand = null;
                                //}
                                transaction.Commit();
                            }
                            else
                            {
                                transaction.Rollback();
                                CaseId = 0;
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            CaseId = 0;
                            errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | CreateManualCase()");
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | CreateManualCase()");
                    throw;
                }
                finally
                {
                    connection.Close();
                }
            }
            return CaseId;
        }

        public DataSet GetUserIdsByEMailboxId(Hashtable hsParms)
        {
            return this.SelectDataSet("usp_GetUserIdsByEmailboxId", hsParms);
        }

        public void IgnoreManualCase(Hashtable htCaseDetails)
        {
            using (DbConnection connection = Db.CreateConnection())
            {
                try
                {
                    connection.Open();
                    using (DbTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            string strIgnoreCase = "USP_IgnoreManualCase";
                            DbCommand insertQueryCommand = this.Db.GetStoredProcCommand(strIgnoreCase);
                            insertQueryCommand.Parameters.Add(new SqlParameter("CASEID", htCaseDetails["CaseId"]));
                            this.Db.ExecuteNonQuery(insertQueryCommand, transaction);
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | IgnoreManualCase()");
                }
                finally
                {
                    connection.Close();
                }
            }
        }
        public DataSet GetClarificationResetReason()
        {
            return this.SelectDataSet("USP_GETCLARIFICATIONRESETREASON");
        }
        public DataSet Getcategory(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetCategorybyEmailboxid", hs);
        }

        public DataSet GetSignature(string userid)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@Userid", userid);
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | GetSignature()");
            }
            return this.SelectDataSet("USP_GET_SIGNATURE", hs);
        }
        public DataSet draft_save_getdetails(string Caseid)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@Caseid", Caseid);
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | draft_save_getdetails()");
            }
            return this.SelectDataSet("USP_GET_Draft_Att", hs);
        }
        public DataSet draft_save_GetContent(string Caseid)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@Caseid", Caseid);
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | draft_save_GetContent()");
            }
            return this.SelectDataSet("USP_DRAFT_GetDraft", hs);
        }

        public DataSet GetControlValuesForBinding(Hashtable hs)
        {
            return this.SelectDataSet("USP_GETDynamicDropDownValues", hs);
        }

        //public DataSet GetContactListForEmailbox(string prefixText, long emailBoxID)
        //{
        //    Hashtable hs = new Hashtable();
        //    hs.Add("@prefixText", prefixText);
        //    hs.Add("@emailBoxID", emailBoxID);
        //    return this.SelectDataSet("USP_GetDistinctEmailIDsSent", hs);
        //}

        public DataSet GetToEmailIDofUsers(string prefixText, long emailboxid)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@prefixtext", prefixText);
                hs.Add("@emailboxId", emailboxid);
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | GetToEmailIDofUsers()");
            }
            return this.SelectDataSet("USP_GetDistinctEmailIDsSent", hs);
        }

        public DataSet GetCcEmailIDofUsers(string prefixText, long emailboxid)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@prefixtext", prefixText);
                hs.Add("@emailboxId", emailboxid);
            }
            catch (Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | CommonDataService.cs | GetCcEmailIDofUsers()");
            }
            return this.SelectDataSet("USP_GetDistinctEmailIDsSent", hs);
        }

        public DataSet LoadInlineAttachmentList(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetInlineAttachmentList", hs);
        }


        ////Pranay 28 October 2016 Function to Bind the Flag Criteria based on Mailbox selected
        public DataSet GetFlagCriteriaByEmailboxSelected(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetFlagCriteriaByEmailBoxSelected", ht);
        }

       
        //Pranay -28 October 2016
        /// <summary>
        /// Function for Inserting values to StoredProcedure for Reopen Cases
        /// </summary>
        /// <param name="ht"></param>
        /// <returns></returns>
        public int InsertDetailsForFlaggedCases(Hashtable ht)
        {

            return Convert.ToInt32(this.ExecuteNonQuery("USP_InsertDetailsForFlaggedCases", ht));
        }

        public DataSet GetAutoReply(Hashtable hs)
        {
            return this.SelectDataSet("USP_GetAutoReplyMails", hs);
        }
    }
}
