﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EMTWebApp.DataHelper;
using EMTWebApp.ExceptionHandler;
using System.Data;
using System.Collections;

namespace EMTWebApp.DataService.Utilities
{
    public class UtilitiesDataService:DBHelper, IUtilitiesDataService
    {
        public DataSet BindComments(Hashtable hsparams)
        {
            return this.SelectDataSet("USP_GetComments", hsparams);
        }

        public DataSet BindAuditLog(Hashtable hsparams)
        {
            return this.SelectDataSet("USP_GetCaseAuditLog", hsparams);
        }
    }
}
