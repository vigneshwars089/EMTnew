﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using EMTWebApp.DataHelper;
using System.Collections;
using EMTWebApp.UserManagement.Common;
using System.Web;

namespace EMTWebApp.DataService.Reports
{
    public class ReportsDataService : DBHelper, IReportsDataService
    {
        UserSession UserData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        public DataSet BindCountry(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetCountryByUserId_For_Dashboard", ht);
        }

        public DataSet BindSubProcessNames(Hashtable ht)
        {
            return this.SelectDataSet("USP_GET_SUBPROCESSGROUPS_DETAILS_Active", ht);
        }

        public DataSet BindEmailboxNames(int CountryId, int SubProcessId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@COUNTRYID", CountryId);
                hs.Add("@SUBPROCESSGROUPID", SubProcessId);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | ReportsDataService | BindEmailboxNames()");
                
            }
            return this.SelectDataSet("USP_GET_EMAILBOXNAME", hs);
        }

        public DataSet GridAgeingDetBind(string CountryId, string SubProcessId, string EmailBoxId, int Range1, int Range2, int Range3, int Range4,string offset)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@COUNTRYID", CountryId);
                hs.Add("@SUBPROCESSGROUPID", SubProcessId);
                hs.Add("@EmailBoxId", EmailBoxId);
                hs.Add("@RangeBoundary1", Range1);
                hs.Add("@RangeBoundary2", Range2);
                hs.Add("@RangeBoundary3", Range3);
                hs.Add("@RangeBoundary4", Range4);
                hs.Add("@OFFSET", offset);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | ReportsDataService | GridAgeingDetBind()");
            }
            //return this.SelectDataSet("USP_AGING_REPORT", hs);
            return this.SelectDataSet("USP_AGING_REPORT_dynamicchanges",hs);
        }


        public DataSet GetCountryByUserIdForDashboard(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetCountryByUserId_For_Dashboard", ht);
        }
        public DataSet GetSearchCaseList(Hashtable ht, int Report)
        {
            string spName= "";
            try
            {
                switch (Report)
                {
                    case 1:
                        //spName = "USP_KPI_GETTAT";
                        spName = "USP_KPI_GETTAT_dynamichanges_dynamicSP";
                        break;
                    case 2:
                        spName = "USP_Report_TAT_Casewise_Details";
                        break;
                    case 3:
                        //spName = "USP_Report_Productivity";
                        spName = "USP_Report_Productivity_dynamicchanges_dynamicSP";
                        break;
                    case 4:
                        //spName = "USP_GETOVERALLREPORT";
                        spName = "USP_GETOVERALLREPORT_dynamicchanges_dynamicSP";
                        break;
                    case 5:
                        //spName = "USP_REPORT_CLARIFICATIONSENTREPORT";
                        spName = "USP_REPORT_CLARIFICATIONSENTREPORT_dynamicchanges";
                        break;
                    case 6:
                        //spName = "USP_REPORT_OPENCLARIFICATIONAGEING";
                        spName = "USP_REPORT_OPENCLARIFICATIONAGEING_dynamicchanges";
                        break;
                    default:
                        //spName = "USP_KPI_GETTAT";
                        spName = "USP_KPI_GETTAT_dynamichanges";
                        break;
                }
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | ReportsDataService | GetSearchCaseList()");
            }
            return this.SelectDataSet(spName, ht);
        }


        public DataSet GetMailboxByCountryIdandUserId(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetEmailBoxDetailsByUserID", ht);
        }

        public DataSet GetMailboxByCountryId(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetEmailBoxByCountryId", ht);
        }

        public DataSet GetSubProcessGroup(Hashtable ht)
        {
            return this.SelectDataSet("USP_GET_SUBPROCESSGROUPS_DETAILS_Active", ht);
        }

        public DataSet BindBaseData(Hashtable ht)
        {
            return this.SelectDataSet("USP_GET_AGEING_BASE_DATA", ht);
        }

        public DataSet GetCategory(Hashtable ht)
        {
            return this.SelectDataSet("USP_GetCategorybyEmailboxid", ht);
        }
    }
}
