﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Collections;

namespace EMTWebApp.DataService.Reports
{
    public interface IReportsDataService
    {
        DataSet BindCountry(Hashtable ht);
        DataSet BindSubProcessNames(Hashtable ht);
        DataSet BindEmailboxNames(int CountryId, int SubProcessId);
        DataSet GridAgeingDetBind(string CountryId, string SubProcessId, string EmailBoxId, int Range1, int Range2, int Range3, int Range4,string offset);
        DataSet BindBaseData(Hashtable ht);
    }
}
