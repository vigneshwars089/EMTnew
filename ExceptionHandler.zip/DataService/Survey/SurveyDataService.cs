﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EMTWebApp.DataHelper;
using System.Data;
using System.Collections;

namespace EMTWebApp.DataService.Survey
{
    public class SurveyDataService : DBHelper, ISurveyDataService
    {
        public int InsertVOCSurveyDetails(Hashtable hs)
        {
            return Convert.ToInt32(this.SelectSingleValue("USP_INSERT_SURVEYDETAILS", hs));
        }
    }
}
