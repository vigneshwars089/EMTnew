﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace EMTWebApp.Common.Views
{
    public interface IManualCaseCreationView
    {
        DataSet BindCountry { set; }
        DataSet BindEMailBox { set; }
        DataSet BindEmailBoxDetails { set; }
    }
}




