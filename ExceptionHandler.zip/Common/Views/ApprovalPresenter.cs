﻿using EMTWebApp.Common;
using EMTWebApp.Common.Views;
using Microsoft.Practices.CompositeWeb;
using Microsoft.Practices.ObjectBuilder;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMTWebApp.Common.Views
{
    public class ApprovalPresenter : Presenter<IApprovalWorkQueueView>
    {
        private CommonController _CommonController;

        public ApprovalPresenter([CreateNew] CommonController controller)
        {
            _CommonController = controller;
        }

        public void GetApproverWorkQueueDetails(string intApproverUserId)
        {
            Hashtable hsParams = new Hashtable();


            hsParams.Add("@APPROVERUSERID", intApproverUserId);


            View.ApprovalWorkQueue = _CommonController.GetApproverWorkQueueDetails(hsParams);
        }
    }
}
