﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using System.Data;
using System.Collections;

namespace EMTWebApp.Common.Views
{
    public class DashboardPresenter : Presenter<IDashboardView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default

        private CommonController _controller;
        public DashboardPresenter([CreateNew] CommonController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        // TODO: Handle other view events and set state in the view

        public DataSet GetCountryByUserId(Hashtable htUserData)
        {
            return this._controller.GetCountryByUserId(htUserData);
        }
        public DataSet GetCountryByUserIdForDashboard(Hashtable htUserData)
        {
            return this._controller.GetCountryByUserIdForDashboard(htUserData);
        }
        public DataSet GetDashboardCount(Hashtable ht)
        {
            return this._controller.GetDashboardCount(ht);
        }
        public DataSet GetUserIdByCountryId(Hashtable ht)
        {
            return this._controller.GetUserIdByCountryId(ht);
        }

        public DataSet GetSubProcessGroup(Hashtable ht)
        {
            return this._controller.GetSubProcessGroup(ht);
        }
        public DataSet GetActiveSubProcessGroup(Hashtable ht)
        {
            return this._controller.GetActiveSubProcessGroup(ht);
        }
        public DataSet BindRoleBaseSubProcess(Hashtable ht)
        {
            return this._controller.BindRoleBaseSubProcess(ht);
        }
    }
}




