﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EMTWebApp.Common.Views
{
    public interface IDashboardView
    {
    }
}




