﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;

namespace EMTWebApp.Common.Views
{
    public interface IProcessingView
    {
        DataSet BindEmailBoxDetails { set; }
        DataSet BindStatus { set; }
        DataSet GetAttachments { set; }
        //sourcenet
        DataSet GetConversations { set; }
        DataSet BindClarificationResetReason { set; }
        DataSet BindComments { set; }
        DataSet BindAuditLog { set; }
    }
}




