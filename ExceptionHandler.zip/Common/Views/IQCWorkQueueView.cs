﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace EMTWebApp.Common.Views
{
    public interface IQCWorkQueueView
    {

        DataSet QCWorkQueue1 { set; }
        DataSet ReAssignQCWorkQueue { set; }
        //void GetReAssignQcWorkQueueDetails(string ReassignQCUserId, string SubProcess);
        //void GetQcWorkQueueDetails(string intQCUserId);
    }

}




