﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using System.Collections;
using System.Data;
using EMTWebApp.Constants;

namespace EMTWebApp.Common.Views
{
    public class ProcessingPresenter : Presenter<IProcessingView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        private CommonController _controller;
        public ProcessingPresenter([CreateNew] CommonController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        // TODO: Handle other view events and set state in the view

        public DataSet LoadCaseDetails(long CaseId,int EMailBoxId,string UserId,int StatusId,int RoleId)
        {
            Hashtable hsCaseDetails = new Hashtable();
            if (CaseId == 0)
            {
                hsCaseDetails.Add("@CaseID", DBNull.Value);
            }
            else
            {
                hsCaseDetails.Add("@CaseID", CaseId);
            }
            hsCaseDetails.Add("@EMAILBOXID", EMailBoxId);
            hsCaseDetails.Add("@USERID", UserId);
            hsCaseDetails.Add("@STATUSID", StatusId);
            hsCaseDetails.Add("@ROLEID", RoleId);
            return this._controller.LoadCaseDetails(hsCaseDetails);
        }

        public DataSet GetAllEmailBoxDetails(Hashtable hs)
        {
            return this._controller.GetAllEmailBoxDetails(hs);
        }


        public int RemoveInlineAttachmentsForCaseId(Hashtable ht)
        {
            return this._controller.RemoveInlineAttachmentsForCaseId(ht);

        }
        public DataSet GetAllChildCases(Hashtable hs)
        {
            return this._controller.GetAllChildCases(hs);
        }

        public int UpdateForwardToGMB(long CaseId, int ForwardToGMB)
        {
            Hashtable hsCaseDetails = new Hashtable();
            hsCaseDetails.Add("@CASEID", CaseId);
            hsCaseDetails.Add("@ForwardToGMB", ForwardToGMB);
            return this._controller.UpdateForwardToGMB(hsCaseDetails);
        }
        public DataSet LoadEMailBoxDetails(int EMailBoxId, string UserId)
        {
            Hashtable hsCaseDetails = new Hashtable();
            hsCaseDetails.Add("@EMAILBOXID", EMailBoxId);
            hsCaseDetails.Add("@USERID", UserId);
            return this._controller.LoadEMailBoxDetails(hsCaseDetails);
        }
        public DataSet LoadNextCase(long CaseId, int EMailBoxId, string UserId, int StatusId, int RoleId, int caseflag)
        {
            Hashtable hsCaseDetails = new Hashtable();
            if (CaseId == 0)
            {
                hsCaseDetails.Add("@CaseID", DBNull.Value);
            }
            else
            {
                hsCaseDetails.Add("@CaseID", CaseId);
            }
            hsCaseDetails.Add("@EMAILBOXID", EMailBoxId);
            hsCaseDetails.Add("@USERID", UserId);
            hsCaseDetails.Add("@STATUSID", StatusId);
            hsCaseDetails.Add("@ROLEID", RoleId);
            hsCaseDetails.Add("@CASEFLAG", caseflag);
            return this._controller.LoadNextCase(hsCaseDetails);
        }
        public DataSet GetUserCount()
        {
            return this._controller.GetUserCount();
        }

        public DataSet InsertProductLicense(string LicenseKey,string Clientname)
        {
            Hashtable hsCaseDetails = new Hashtable();
            hsCaseDetails.Add("@LicenseKey", LicenseKey);
            hsCaseDetails.Add("@Clientname", Clientname);
            return this._controller.InsertProductLicense(hsCaseDetails);
        }

        public DataSet LoadNextCaseWithClassficationName(string ClassificationName,long CaseId, int EMailBoxId, string UserId, int StatusId, int RoleId, int caseflag)
        {
            Hashtable hsCaseDetails = new Hashtable();
            hsCaseDetails.Add("@ClassificationName", ClassificationName);

            if (CaseId == 0)
            {
                hsCaseDetails.Add("@CaseID", DBNull.Value);
            }
            else
            {
                hsCaseDetails.Add("@CaseID", CaseId);
            }
            hsCaseDetails.Add("@EMAILBOXID", EMailBoxId);
            hsCaseDetails.Add("@USERID", UserId);
            hsCaseDetails.Add("@STATUSID", StatusId);
            hsCaseDetails.Add("@ROLEID", RoleId);
            hsCaseDetails.Add("@CASEFLAG", caseflag);
            return this._controller.LoadNextCaseWithClassificationName(hsCaseDetails);
        }

        public DataSet LoadPreviousCase(long CaseId, int EMailBoxId, string UserId, int StatusId, int RoleId, int caseflag)
        {
            Hashtable hsCaseDetails = new Hashtable();
            if (CaseId == 0)
            {
                hsCaseDetails.Add("@CaseID", DBNull.Value);
            }
            else
            {
                hsCaseDetails.Add("@CaseID", CaseId);
            }
            hsCaseDetails.Add("@EMAILBOXID", EMailBoxId);
            hsCaseDetails.Add("@USERID", UserId);
            hsCaseDetails.Add("@STATUSID", StatusId);
            hsCaseDetails.Add("@ROLEID", RoleId);
            hsCaseDetails.Add("@CASEFLAG", caseflag);
            return this._controller.LoadPreviousCase(hsCaseDetails);
        }
        public DataSet LoadPreviousCasewithClassificationName(string ClassificationName,long CaseId, int EMailBoxId, string UserId, int StatusId, int RoleId, int caseflag)
        {
            Hashtable hsCaseDetails = new Hashtable();
            hsCaseDetails.Add("@ClassificationName", ClassificationName);

            if (CaseId == 0)
            {
                hsCaseDetails.Add("@CaseID", DBNull.Value);
            }
            else
            {
                hsCaseDetails.Add("@CaseID", CaseId);
            }
            hsCaseDetails.Add("@EMAILBOXID", EMailBoxId);
            hsCaseDetails.Add("@USERID", UserId);
            hsCaseDetails.Add("@STATUSID", StatusId);
            hsCaseDetails.Add("@ROLEID", RoleId);
            hsCaseDetails.Add("@CASEFLAG", caseflag);
            return this._controller.LoadPreviousCaseWithClassificationName(hsCaseDetails);
        }

        public DataSet GetAttachmentDetails(Hashtable hs)
        {
            return this._controller.GetAttachmentDetails(hs);
        }

        public DataSet GetDynamicPageControls(Hashtable hs)
        {
            return this._controller.GetDynamicPageControls(hs);
        }

        public void LoadAttachmentList(long ConversationId)
        {
            Hashtable hsConversationId = new Hashtable();
            hsConversationId.Add("@ConversationId", ConversationId);
            View.GetAttachments = this._controller.LoadAttachmentList(hsConversationId);
        }

        //sourcenet
        public void LoadConversationsList(long CaseId)
        {
            Hashtable hsCaseId = new Hashtable();
            hsCaseId.Add("@CaseId", CaseId);
            View.GetConversations = this._controller.LoadConversationsList(hsCaseId);
        }

        public DataSet GetStatus(int SubProcessId)
        {
            Hashtable hs= new Hashtable();
            hs.Add("@SubProcessId", SubProcessId);
            return this._controller.GetStatus(hs);
        }

        public void BindComments(int caseid)
        {
            Hashtable hsParams = new Hashtable();
            hsParams.Add("@CASEID", caseid);
            View.BindComments = this._controller.BindComments(hsParams);

        }

        public void BindAuditLog(int caseid)
        {
            Hashtable hsParams = new Hashtable();
            hsParams.Add("@CASEID", caseid);
            View.BindAuditLog = this._controller.BindAuditLog(hsParams);

        }

        public DataSet GetChildCaseDetails(long CaseId)
        {
            Hashtable hsCaseDetails = new Hashtable();
            if (CaseId == 0)
            {
                hsCaseDetails.Add("@CaseID", DBNull.Value);
            }
            else
            {
                hsCaseDetails.Add("@CaseID", CaseId);
            }
            return this._controller.GetChildCaseDetails(hsCaseDetails);
        }

        public DataSet GetParentCaseDetails(int CaseId)
        {
            Hashtable hsCaseDetails = new Hashtable();
            hsCaseDetails.Add("@CaseID", CaseId);
            return this._controller.GetParentCaseDetails(hsCaseDetails);
        }

        public void UploadAttachment(long ConversationId, IList AttachmentList, string UserId)
        {
            this._controller.UploadAttachment(ConversationId, AttachmentList, UserId);
        }

        public Int32 InsertMailConversation(string CASEID,string Subject,byte[] mailContent,String EmailFrom,String EmailTo,String EmailCc,String EmailBcc,DateTime ReceivedDate,String CreatedBy )
        {
            
            Hashtable hsConversationDetails = new Hashtable();
            hsConversationDetails.Add("@Subject", Subject);
            hsConversationDetails.Add("@From_Add", EmailFrom);
            hsConversationDetails.Add("@Toaddress", EmailTo);
            hsConversationDetails.Add("@CCaddress", EmailCc);
            hsConversationDetails.Add("@BCCaddress", EmailBcc);
          
            hsConversationDetails.Add("@CaseId", CASEID);
            hsConversationDetails.Add("@AttachmentName", "");
            hsConversationDetails.Add("@ContentType", "text/html");
            hsConversationDetails.Add("@AttachmentData", mailContent);
            hsConversationDetails.Add("@AttachmentType", 1);
            hsConversationDetails.Add("@ConversationDate", DateTime.UtcNow);
            hsConversationDetails.Add("@CreatedBy", CreatedBy);
            return this._controller.InsertMailConversation(hsConversationDetails);
            
           
       }
        public DataSet GetUserIdsByCountryEmailboxRole(Hashtable ht)
        {
            return this._controller.GetUserIdsByCountryEmailboxRole(ht);
        }

        public DataSet GetCategoryNames()
        {
            return this._controller.GetCategoryNames();
        }
        public int UpdateOnReassign(Hashtable ht)
        {
            return this._controller.UpdateOnReassign(ht);
        }

        public int UpdateOnRemappingOfCategory(Hashtable ht)
        {
            return this._controller.UpdateOnRemappingOfCategory(ht);
        }
        public bool GetStatusList(int CurrentStatus,  int SubProcessId,int UserRoleId)
        {
            bool isInputFieldsEnabled = false;
            DataSet ds = new DataSet();           
            ds = null;
            Hashtable ht = new Hashtable();
            ht.Add("@SubProcessId", SubProcessId);
            ht.Add("@UserRoleId", UserRoleId);
             ds=this._controller.GetStatusTransition(ht);
            View.BindStatus = ds;
            return isInputFieldsEnabled;
        }

       

        public DataSet GetEmailBoxDetails(Hashtable hs)
        {
            return this._controller.GetEmailBoxDetails(hs);
        }



      

        public int UpdateCaseDetails(long CaseId, int Status, string Comments, string UserId, DateTime StartTime, int category)
        {
            Hashtable hsCaseDetails = new Hashtable();
            hsCaseDetails.Add("@CASEID", CaseId);
            hsCaseDetails.Add("@STATUS", Status);
            hsCaseDetails.Add("@COMMENTS", Comments);
            hsCaseDetails.Add("@USERID", UserId);
            hsCaseDetails.Add("@STARTTIME", StartTime);
            hsCaseDetails.Add("@Category", category);
            return this._controller.UpdateCaseDetails(hsCaseDetails);
        }

        public int Updatedynamicfields(long CaseId, StringBuilder sqlXMLValue, string UserId)
        {
            Hashtable hsCaseDetails = new Hashtable();
            hsCaseDetails.Add("@caseid", CaseId);
            hsCaseDetails.Add("@xml", sqlXMLValue.ToString());
            hsCaseDetails.Add("@userid", UserId);
            return this._controller.Updatedynamicfields(hsCaseDetails);
        }

        public void GetEmailBoxDetails(int EMailBoxId)
        {
            Hashtable htEMailDetails = new Hashtable();
            htEMailDetails.Add("@EMailBoxId", EMailBoxId);
            View.BindEmailBoxDetails = this._controller.GetEmailBoxDetails(htEMailDetails);
        }
        public void GetClarificationResetReason()
        {
            View.BindClarificationResetReason = this._controller.GetClarificationResetReason();
        }
        public DataSet Getcategory(Hashtable hs)
        {
            return this._controller.Getcategory(hs);
        }

        public DataSet GetSignature(string UserID)
        {
            return _controller.GetSignature(UserID);
        }
        public DataSet draft_save_getdetails(string Caseid)
        {
            return _controller.draft_save_getdetails(Caseid);
        }
        public DataSet draft_save_GetContent(string Caseid)
        {
            return _controller.draft_save_GetContent(Caseid);
        }
        public void DeleteTotalDraft(long Caseid)
        {
            this._controller.DeleteTotalDraft(Caseid);
        }
        public void DeleteLastDraft(long Caseid)
        {
            this._controller.DeleteLastDraft(Caseid);
        }
        public void UploadAttachment_Draft(long CaseId, IList AttachmentList, string UserId)
        {
            this._controller.UploadAttachment_Draft(CaseId, AttachmentList, UserId);
        }
        public int draft_save(Hashtable ht)
        {
            return this._controller.draft_save(ht);
        }

        public DataSet GetControlValuesForBinding(Hashtable hs)
        {
            return this._controller.GetControlValuesForBinding(hs);
        }

        //public DataSet GetContactListForEmailbox(string prefixText, long emailBoxID)
        //{
        //    return _controller.GetContactListForEmailbox(prefixText, emailBoxID);
        //}

        //Pranay 16 November 2016

        public DataSet GetToEmailIDofUsers(string prefixText, long emailboxid)
        {
            /*Hashtable htEmaiIds = new Hashtable();
            htEmaiIds.Add("@prefixtext", prefixText);
            htEmaiIds.Add("@emailboxId", contextKey);
            */
            return this._controller.GetToEmailIDofUsers(prefixText, emailboxid);
        }

        public DataSet GetCcEmailIDofUsers(string prefixText, long emailboxid)
        {
            /*Hashtable htEmaiIds = new Hashtable();
            htEmaiIds.Add("@prefixtext", prefixText);
            htEmaiIds.Add("@emailboxId", contextKey);
            */
            return this._controller.GetCcEmailIDofUsers(prefixText, emailboxid);
        }




        public DataSet LoadInlineAttachments(long ConversationId)
        {
            Hashtable hsConversationId = new Hashtable();
            hsConversationId.Add("@ConversationId", ConversationId);
            //hsCaseId.Add("@AttachmentTypeId", AttachmentTypeId);
            return this._controller.LoadInlineAttachmentList(hsConversationId);
        }

        ////Pranay 28 October 2016 Function to Bind the Flag Criteria based on Mailbox selected
        public DataSet GetFlagCriteriaByEmailboxSelected(Hashtable ht)
        {
            return this._controller.GetFlagCriteriaByEmailboxSelected(ht);
        }

        //Pranay -28 October 2016
        /// <summary>
        /// Function for Inserting values to StoredProcedure for Flagged Cases
        /// </summary>
        /// <param name="ht"></param>
        /// <returns></returns>
        public int InsertDetailsForFlaggedCases(Hashtable ht)
        {
            return Convert.ToInt32(this._controller.InsertDetailsForFlaggedCases(ht));
        }
    
        public DataSet GetAutoReply(long CaseId)
        {
            Hashtable hsCaseId = new Hashtable();
            hsCaseId.Add("@CaseId", CaseId);
            return this._controller.GetAutoReply(hsCaseId);
        }
    
}
}




