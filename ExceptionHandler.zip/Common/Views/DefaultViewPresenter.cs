using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;

namespace EMTWebApp.Common.Views
{
    public class DefaultViewPresenter : Presenter<IDefaultView>
    {
        private ICommonController _controller;

        public DefaultViewPresenter([CreateNew] ICommonController controller)
        {
            this._controller = controller;
        }
    }
}
