﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using System.Collections;
using System.Data;

namespace EMTWebApp.Common.Views
{
    public class ManualCaseCreationPresenter : Presenter<IManualCaseCreationView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        private CommonController _controller;
        public ManualCaseCreationPresenter([CreateNew] CommonController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        // TODO: Handle other view events and set state in the view
        public void GetCountryByUserId(string userId)
        {
            Hashtable htUserData = new Hashtable();
            htUserData.Add("@ASSOCIATEID", userId);
            View.BindCountry = this._controller.GetCountryByUserId(htUserData);
        }
        public void GetEMailBoxByUserId(string userId,int roleId,int countryId)
        {
            Hashtable htCountryandUserData = new Hashtable();
            htCountryandUserData.Add("@USERID", userId);
            htCountryandUserData.Add("@ROLEID", roleId);
            htCountryandUserData.Add("@COUNTRYID", countryId);
            View.BindEMailBox = this._controller.GetEMailBoxByUserId(htCountryandUserData);
        }
        public void GetEmailBoxDetails(int EMailBoxId)
        {
            Hashtable htEMailDetails = new Hashtable();
            htEMailDetails.Add("@EMailBoxId", EMailBoxId);
            View.BindEmailBoxDetails = this._controller.GetEmailBoxDetails(htEMailDetails);
        }

        public DataSet GetclassificationList()
        {
            return this._controller.GetclassificationList();
        }

        //public long CreateManualCase(string EMailFrom, string EMailTo, string EMailCc, string Subject, string Body, int EMailBoxId, string UserId, IList fileCollection, bool isReplyNotRequired, bool isnotification)
        public long CreateManualCase(string EMailFrom, string EMailTo, string EMailCc, string Subject, string Body, int EMailBoxId, string UserId, IList fileCollection, bool isReplyNotRequired, int StatusId, string hdnClassification, bool composegmb)
        {
            Hashtable htCaseDetails = new Hashtable();
            htCaseDetails.Add("FromEMailId", EMailFrom);
            htCaseDetails.Add("ToEMailId", EMailTo);
            htCaseDetails.Add("CCEMailId", EMailCc);
            htCaseDetails.Add("Subject", Subject);
            htCaseDetails.Add("EMailBody", Body);
            htCaseDetails.Add("EMailBoxID", EMailBoxId);
            htCaseDetails.Add("UserId", UserId);
            htCaseDetails.Add("isReplyNotRequired", isReplyNotRequired);
            htCaseDetails.Add("COMPOSEGMB", composegmb);
            htCaseDetails.Add("StatusId", StatusId);
            htCaseDetails.Add("Classification", hdnClassification);
            return this._controller.CreateManualCase(htCaseDetails, fileCollection);
        }

        public int UpdateAutoAcknowledgement(long CaseId, bool AutoAcknowledgement)
        {
            Hashtable htCaseDetails = new Hashtable();
            htCaseDetails.Add("CaseId", CaseId);
            htCaseDetails.Add("AutoAcknowledgement", AutoAcknowledgement);
            return this._controller.UpdateAutoAcknowledgement(htCaseDetails);
        }

         public DataSet GetStatusDetails(int EmailBoxId)
         {
             Hashtable ht = new Hashtable();
             ht.Add("@EmailBoxId", EmailBoxId);
             return this._controller.GetStatusDetails(ht);
         }
         public DataSet GetTemplateDetails(int EmailBoxId)
          {
              Hashtable ht = new Hashtable();
              ht.Add("@EmailBoxId", EmailBoxId);
              return this._controller.GetTemplateDetails(ht);
          }
          public DataSet GetTemplateContent(int TemplateId)
          {
              Hashtable ht = new Hashtable();
              ht.Add("@TemplateId", TemplateId);
              return this._controller.GetTemplateContent(ht);
          }
        public void UploadAttachment(long ConversationId, IList AttachmentList, string UserId)
        {
            this._controller.UploadAttachment(ConversationId, AttachmentList, UserId);
        }

        public Int32 InsertMailConversation(string CASEID, string Subject, byte[] mailContent, String EmailFrom, String EmailTo, String EmailCc, String EmailBcc, DateTime ReceivedDate, String CreatedBy)
        {

            Hashtable hsConversationDetails = new Hashtable();
            hsConversationDetails.Add("@Subject", Subject);
            hsConversationDetails.Add("@From_Add", EmailFrom);
            hsConversationDetails.Add("@Toaddress", EmailTo);
            hsConversationDetails.Add("@CCaddress", EmailCc);
            hsConversationDetails.Add("@BCCaddress", EmailBcc);
            hsConversationDetails.Add("@CaseId", CASEID);
            hsConversationDetails.Add("@AttachmentName", "");
            hsConversationDetails.Add("@ContentType", "text/html");
            hsConversationDetails.Add("@AttachmentData", mailContent);
            hsConversationDetails.Add("@AttachmentType", 1);
            hsConversationDetails.Add("@ConversationDate", DateTime.UtcNow);
            hsConversationDetails.Add("@CreatedBy", CreatedBy);
            return this._controller.InsertMailConversation(hsConversationDetails);


        }

        public void IgnoreManualCase(long CaseId)
        {
            Hashtable htCaseDetails = new Hashtable();
            htCaseDetails.Add("CaseId", CaseId);
            this._controller.IgnoreManualCase(htCaseDetails);
        }

        public DataSet GetSignature(string UserID)
        {
            return _controller.GetSignature(UserID);
        }
        public DataSet GetUserCount()
        {
            return this._controller.GetUserCount();
        }

        //Pranay 11 May 2017 --Dynamic field Configuration 
        public int Updatedynamicfields(long CaseId, StringBuilder sqlXMLValue, string UserId)
        {
            Hashtable hsCaseDetails = new Hashtable();
            hsCaseDetails.Add("@caseid", CaseId);
            hsCaseDetails.Add("@xml", sqlXMLValue.ToString());
            hsCaseDetails.Add("@userid", UserId);
            return this._controller.Updatedynamicfields(hsCaseDetails);
        }

        //Pranay 11 May 2017 --Dynamic field Configuration
        public DataSet GetDynamicPageControlsForManualCase(Hashtable hs)
        {
            return this._controller.GetDynamicPageControlsForManualCase(hs);
        }

        public DataSet GetControlValuesForBinding(Hashtable hs)
        {
            return this._controller.GetControlValuesForBinding(hs);
        }

    }
}




