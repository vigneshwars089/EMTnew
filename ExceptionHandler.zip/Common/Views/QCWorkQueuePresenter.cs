﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using System.Collections;

//using SVU.eProcess.CommonConstants;
using System.Data;

namespace EMTWebApp.Common.Views
{
    public class QCWorkQueuePresenter : Presenter<IQCWorkQueueView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        //private CommonController _controller;
        //public QCWorkQueuePresenter([CreateNew] CommonController controller)
        //{
        //    _controller = controller;
        //}

        private CommonController _CommonController;

        public QCWorkQueuePresenter([CreateNew] CommonController controller)
        {
            _CommonController = controller;
        }
        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        public void GetReAssignQcWorkQueueDetails(string LoggedInUserId, string ReassignQCUserId, string EmailBoxId, bool IsQCReassin)
        {
            Hashtable hsParams = new Hashtable();
            hsParams.Add("@LoggedInUserId", LoggedInUserId);
            hsParams.Add("@QCUserId", ReassignQCUserId);
            hsParams.Add("@EMAILBOXID", EmailBoxId);
            hsParams.Add("@IsQCReassign", IsQCReassin);
            View.ReAssignQCWorkQueue = _CommonController.GetQcReAssignWorkQueueDetails(hsParams);
        }

        public DataSet GetReAssignQcWorkQueueDetails_sort(string LoggedInUserId, string ReassignQCUserId, string EmailBoxId, bool IsQCReassin)
        {
            Hashtable hsParams = new Hashtable();
            hsParams.Add("@LoggedInUserId", LoggedInUserId);
            hsParams.Add("@QCUserId", ReassignQCUserId);
            hsParams.Add("@EMAILBOXID", EmailBoxId);
            hsParams.Add("@IsQCReassign", IsQCReassin);
            return _CommonController.GetQcReAssignWorkQueueDetails(hsParams);
        }
        public int UpdateDirectReAssign(string QCUSER, string EmailBoxId, string CASEID)
        {
            Hashtable hsParams = new Hashtable();
            hsParams.Add("@QCUSERID", QCUSER);
            hsParams.Add("@EMAILBOXID", EmailBoxId);
            hsParams.Add("@CASEID", CASEID);
            return _CommonController.UpdateDirectReAssign(hsParams);
            //return CommonController.UpdateDirectReAssign(hsParams);
        }

        public DataSet GetEmailBox(string countryid, int RoleId, string LoggedInUserId)
        {
            Hashtable hsParams = new Hashtable();
            hsParams.Add("@COUNTRYID", countryid);
            hsParams.Add("@ROLEID", RoleId);
            hsParams.Add("@USERID", LoggedInUserId);
            return _CommonController.GetEmailBox(hsParams);
        }

        public DataSet GetProcessorsForQC(string countryid, string EmailBoxId, string LoggedInUserId)
        {
            Hashtable hsParams = new Hashtable();
            hsParams.Add("@CountryId", countryid);
            hsParams.Add("@EmailBoxId", EmailBoxId);
            hsParams.Add("@LoggedInUserId", LoggedInUserId);

            return _CommonController.GetProcessorsForQC(hsParams);
        }

        public DataSet GetCountry(string userid)
        {
            Hashtable hsParams = new Hashtable();
            hsParams.Add("@AssociateId", userid);
            return _CommonController.GetCountry(hsParams);
        }

        public void GetQcWorkQueueDetails(string intQCUserId)
        {
            Hashtable hsParams = new Hashtable();

            //string strSCMboiseStatus = (int)Constant.ScmBoiseCaseStatus.Completed + "," + (int)Constant.ScmBoiseCaseStatus.QCActioned + "," + (int)Constant.ScmBoiseCaseStatus.RejectedCompleted + "," + (int)Constant.ScmBoiseCaseStatus.RejectedDuplicate;
            //string strSCMChanhassenStatus = (int)Constant.ScmChanhassenCaseStatus.Completed + "," + (int)Constant.ScmChanhassenCaseStatus.QCActioned + "," + (int)Constant.ScmChanhassenCaseStatus.RejectedCompleted + "," + (int)Constant.ScmChanhassenCaseStatus.RejectedDuplicate + "," + (int)Constant.ScmChanhassenCaseStatus.Duplicate;
            //string strExpenseboiseStatus = (int)Constant.ExpenseBoiseCaseStatus.Completed + "," + (int)Constant.ExpenseBoiseCaseStatus.QCActioned;
            //string strExpenseChanhassenStatus = (int)Constant.ExpenseChanhassenCaseStatus.Completed + "," + (int)Constant.ExpenseChanhassenCaseStatus.QCActioned;

            hsParams.Add("@QCUSERID", intQCUserId);

            //View.QCWorkQueue1 = _CommonController.GetQcWorkQueueDetails(hsParams);
            // _CommonController.GetQcWorkQueueDetails(hsParams);
            View.QCWorkQueue1 = _CommonController.GetQcWorkQueueDetails(hsParams);
        }

      

        public DataSet GetUserIdsByEMailboxId(int EMailboxId)
        {
            Hashtable hsParams = new Hashtable();
            hsParams.Add("@EmailboxId", EMailboxId);
            return _CommonController.GetUserIdsByEMailboxId(hsParams);
        }

        //

        // TODO: Handle other view events and set state in the view
    }
}




