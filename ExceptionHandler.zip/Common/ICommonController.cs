using System;

namespace EMTWebApp.Common
{
    public interface ICommonController
    {
    }
}
