﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EMTWebApp.Common.Common
{
    [Serializable]
    public class EmailAttachment
    {
        private string _AttachmentId;

        public string AttachmentId
        {
            get { return _AttachmentId; }
            set { _AttachmentId = value; }

        }

        private string _FileName;

        public string FileName
        {
            get { return _FileName; }
            set { _FileName = value; }

        }

        private Byte[] _FileContent;

        public Byte[] FileContent
        {
            get { return _FileContent; }
            set { _FileContent = value; }

        }

        private string _FileExtension;

        public string FileExtension
        {
            get { return _FileExtension; }
            set { _FileExtension = value; }
        }

    }
}
