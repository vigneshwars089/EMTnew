using System;
using EMTWebApp.DataService.Common;
using System.Data;
using System.Collections;
using EMTWebApp.Constants;
using System.Collections.Generic;

namespace EMTWebApp.Common
{
    public class CommonController : ICommonController
    {
        CommonDataService _CommonDataService = new CommonDataService();
        public CommonController()
        {
        }

        public DataSet LoadCaseDetails(Hashtable hs)
        {
            return this._CommonDataService.LoadCaseDetails(hs);
        }

        public DataSet LoadEMailBoxDetails(Hashtable hs)
        {
            return this._CommonDataService.LoadEMailBoxDetails(hs);
        }

        public DataSet GetAllEmailBoxDetails(Hashtable htUserData)
        {
            return this._CommonDataService.GetAllEmailBoxDetails(htUserData);
        }
        

        public DataSet LoadNextCase(Hashtable hs)
        {
            return this._CommonDataService.LoadNextCase(hs);
        }
        public DataSet InsertProductLicense(Hashtable hs)
        {
            return this._CommonDataService.InsertProductLicense(hs);
        }
        public int RemoveInlineAttachmentsForCaseId(Hashtable hs)
        {
            return this._CommonDataService.RemoveInlineAttachmentsForCaseId(hs);
        }
        public DataSet GetAllChildCases(Hashtable ht)
        {
            return this._CommonDataService.GetAllChildCaseDetails(ht);
        }
        public int UpdateForwardToGMB(Hashtable hs)
        {
            return this._CommonDataService.UpdateForwardToGMB(hs);
        }
        public DataSet GetUserCount()
        {
            return this._CommonDataService.GetUserCount();
        }
        public DataSet LoadNextCaseWithClassificationName(Hashtable hs)
        {
            return this._CommonDataService.LoadNextCaseWithClassificationName(hs);
        }

        public DataSet LoadPreviousCase(Hashtable hs)
        {
            return this._CommonDataService.LoadPreviousCase(hs);
        }

        public DataSet LoadPreviousCaseWithClassificationName(Hashtable hs)
        {
            return this._CommonDataService.LoadPreviousCaseWithClassificationName(hs);
        }


        internal DataSet GetQcReAssignWorkQueueDetails(Hashtable hsParams)
        {
            return this._CommonDataService.GetQcReAssignWorkQueueDetails(hsParams);
        }
        
        public DataSet GetUserIdsByCountryEmailboxRole(Hashtable ht)
        {
            return this._CommonDataService.GetUserIdsByCountryEmailboxRole(ht);
        }

        public DataSet GetCategoryNames()
        {
            return this._CommonDataService.GetCategoryNames();
        }
        public int UpdateOnReassign(Hashtable ht)
        {
            return this._CommonDataService.UpdateOnReassign(ht);
        }

        public DataSet GetStatusTransition(Hashtable ht)
        {
            return this._CommonDataService.GetStatusTransition(ht);
        }
        public int UpdateOnRemappingOfCategory(Hashtable ht)
        {
            return this._CommonDataService.UpdateOnRemappingOfCategory(ht);
        }
        internal DataSet BindComments(Hashtable hsParams)
        {
            return this._CommonDataService.BindComments(hsParams);
        }

        public DataSet BindAuditLog(Hashtable hsParams)
        {
            return this._CommonDataService.BindAuditLog(hsParams);
        }

        public int UpdateDirectReAssign(Hashtable hsParms)
        {
            return this._CommonDataService.UpdateDirectReAssign(hsParms);
        }
        internal DataSet GetQcWorkQueueDetails(Hashtable hsParams)
        {
            return this._CommonDataService.GetQcWorkQueueDetails(hsParams);
        }
        internal DataSet GetApproverWorkQueueDetails(Hashtable hsParams)
        {
            return this._CommonDataService.GetApproverWorkQueueDetails(hsParams);
        }
        public DataSet GetAttachmentDetails(Hashtable hs)
        {
            return this._CommonDataService.GetAttachmentDetails(hs);
        }

        public DataSet GetDynamicPageControls(Hashtable hs)
        {
            return this._CommonDataService.GetDynamicPageControls(hs);
        }

        public DataSet GetDynamicPageControlsForManualCase(Hashtable hs)
        {
            return this._CommonDataService.GetDynamicPageControlsForManualCase(hs);
        }

        public DataSet GetCountryByUserId(Hashtable hs)
        {
            return this._CommonDataService.GetCountryByUserId(hs);
        }
        public DataSet GetCountryByUserIdForDashboard(Hashtable hs)
        {
            return this._CommonDataService.GetCountryByUserIdForDashboard(hs);
        }
        public DataSet LoadAttachmentList(Hashtable hs)
        {
            return this._CommonDataService.LoadAttachmentList(hs);
        }

        public DataSet GetStatus(Hashtable hs)
        {
            return this._CommonDataService.GetStatus(hs);
        }

        //sourcenet
        public DataSet LoadConversationsList(Hashtable hs)
        {
            return this._CommonDataService.LoadConversationsList(hs);
        }

        public void UploadAttachment(long ConversationId, IList AttachmentList, string UserId)
        {
            this._CommonDataService.UploadAttachment(ConversationId, AttachmentList, UserId);
        }

        public int InsertMailConversation(Hashtable hs)
        {
            return this._CommonDataService.InsertMailConversation( hs);
        }

        public DataSet GetChildCaseDetails(Hashtable hs)
        {
            return this._CommonDataService.GetChildCaseDetails(hs);
        }

        public DataSet GetParentCaseDetails(Hashtable hs)
        {
            return this._CommonDataService.GetParentCaseDetails(hs);
        }

        public void UploadAttachment_Draft(long CaseId, IList AttachmentList, string UserId)
        {
            this._CommonDataService.UploadAttachment_Draft(CaseId, AttachmentList, UserId);
        }
        public int draft_save(Hashtable ht)
        {
            return this._CommonDataService.DraftUpdate(ht);

        }
        public void DeleteLastDraft(long Caseid)
        {
            this._CommonDataService.DeleteLastDraft(Caseid);
        }
        public void DeleteTotalDraft(long Caseid)
        {
            this._CommonDataService.DeleteTotalDraft(Caseid);
        }
        public DataSet draft_save_getdetails(string Caseid)
        {
            return this._CommonDataService.draft_save_getdetails(Caseid);
        }
        public DataSet draft_save_GetContent(string Caseid)
        {
            return this._CommonDataService.draft_save_GetContent(Caseid);
        }
        public DataSet GetEmailBox(Hashtable hsParams)
        {
            return this._CommonDataService.GetEmailBox(hsParams);
        }

        public DataSet GetProcessorsForQC(Hashtable hsParams)
        {
            return this._CommonDataService.GetProcessorsForQC(hsParams);
        }


        public DataSet GetCountry(Hashtable hsParams)
        {
            return this._CommonDataService.GetCountry(hsParams);
        }
        public DataSet GetStatusList(int CurrentStatus, bool IsQCRequired, string CaseAssignedTo, string QCAssignedTo, string LoginUser)
        {
            return this._CommonDataService.GetStatusList();
        }

        public DataSet previousStatusID(Hashtable hsCaseId)
        {
            return this._CommonDataService.previousStatusID(hsCaseId);
        }

        public DataSet GetDashboardCount(Hashtable ht)
        {
            return this._CommonDataService.GetDashboardCount(ht);
        }
        public DataSet GetUserIdByCountryId(Hashtable ht)
        {
            return this._CommonDataService.GetUserIdByCountryId(ht);
        }

        public DataSet GetSubProcessGroup(Hashtable ht)
        {
            return this._CommonDataService.GetSubProcessGroup(ht);
        }
        public DataSet GetActiveSubProcessGroup(Hashtable ht)
        {
            return this._CommonDataService.GetActiveSubProcessGroup(ht);
        }
        public DataSet BindRoleBaseSubProcess(Hashtable ht)
        {
            return this._CommonDataService.BindRoleBaseSubProcess(ht);
        }
        
        public DataSet GetWorkQueueList_mailboxlevel(Hashtable ht)
        {
            return this._CommonDataService.GetWorkQueueList_mailboxlevel(ht);
        }
        public DataSet GetWorkQueueList(Hashtable ht)
        {
            return this._CommonDataService.GetWorkQueueList(ht);
        }
        public DataSet GetEmailBoxDetails(Hashtable hs)
        {
            return this._CommonDataService.GetEmailBoxDetails(hs);
        }

        public DataSet GetStatusDetails(Hashtable hs)
        {

            return this._CommonDataService.GetStatusDetails(hs);
        }
        public DataSet GetTemplateDetails(Hashtable hs)
        {

            return this._CommonDataService.GetTemplateDetails(hs);
        }
        public DataSet GetTemplateContent(Hashtable hs)
        {

            return this._CommonDataService.GetTemplateContent(hs);
        }

        public DataSet GetclassificationList()
        {
            return this._CommonDataService.GetclassificationList();
        }
        public int UpdateCaseDetails(Hashtable hs)
        {
            return this._CommonDataService.UpdateCaseDetails(hs);
        }

        public int Updatedynamicfields(Hashtable hs)
        {
            return this._CommonDataService.Updatedynamicfields(hs);
        }
        
        public int UpdateAutoAcknowledgement(Hashtable hs)
        {
            return this._CommonDataService.UpdateAutoAcknowledgement(hs);
        }
        public DataSet GetEMailBoxByUserId(Hashtable htUserData)
        {
            return this._CommonDataService.GetEMailBoxByUserId(htUserData);
        }

       

        public long CreateManualCase(Hashtable hs, IList fileCollection)
        {
            return this._CommonDataService.CreateManualCase(hs, fileCollection);
        }

        public DataSet GetUserIdsByEMailboxId(Hashtable hsParams)
        {
            return this._CommonDataService.GetUserIdsByEMailboxId(hsParams);
        }

        public void IgnoreManualCase(Hashtable htCaseDetails)
        {
            this._CommonDataService.IgnoreManualCase(htCaseDetails);
        }
        public DataSet GetClarificationResetReason()
        {
            return this._CommonDataService.GetClarificationResetReason();
        }
        public DataSet Getcategory(Hashtable hs)
        {
            return this._CommonDataService.Getcategory(hs);
        }

        public DataSet GetSignature(string UserID)
        {
            return this._CommonDataService.GetSignature(UserID);
        }

        public DataSet GetControlValuesForBinding(Hashtable hs)
        {
            return this._CommonDataService.GetControlValuesForBinding(hs);
        }

        public DataTable EmailboxNameswithclassification(string CountryId, string LoggedInUserId, string RoleId, string SelectedAssociateId, string SelectedSubProcessId, string strConnectionString)
        {
            return this._CommonDataService.EmailboxNameswithclassification(CountryId, LoggedInUserId, RoleId, SelectedAssociateId, SelectedAssociateId, strConnectionString);
        }

        
        public DataTable EmailboxNames(string CountryId, string LoggedInUserId, string RoleId, string SelectedAssociateId, string SelectedSubProcessId, string strConnectionString)
        {
            return this._CommonDataService.EmailboxNames(CountryId, LoggedInUserId, RoleId, SelectedAssociateId, SelectedAssociateId, strConnectionString);
        }

        public DataTable EmailboxStatuses(string Country, string EmailboxName,string SubProcess,string LoggedInUserId, string strConnectionString)
        {
            return this._CommonDataService.EmailboxStatuses(Country, EmailboxName,SubProcess,LoggedInUserId, strConnectionString);
        }

        //public DataTable EmailboxStatuseswithclassification(string Country, string EmailboxName, string SubProcess, string LoggedInUserId, string strConnectionString)
        //{
        //    return this._CommonDataService.EmailboxStatuseswithclassification(Country, EmailboxName, SubProcess, LoggedInUserId, strConnectionString);
        //}        

        public int Classificationcheck(string strConnectionString)
        {
            return this._CommonDataService.Classificationcheck(strConnectionString);
        }


        //public DataSet GetContactListForEmailbox(string prefixText, long emailBoxID)
        //{
        //    return this._CommonDataService.GetContactListForEmailbox(prefixText, emailBoxID);
        //}

        //Pranay 16 November 2016
        public DataSet GetToEmailIDofUsers(string prefixText, long emailboxid)
        {
            return this._CommonDataService.GetToEmailIDofUsers(prefixText, emailboxid);
        }

        public DataSet GetCcEmailIDofUsers(string prefixText, long emailboxid)
        {
            return this._CommonDataService.GetCcEmailIDofUsers(prefixText, emailboxid);
        }

      


        public DataSet LoadInlineAttachmentList(Hashtable hs)
        {
            return this._CommonDataService.LoadInlineAttachmentList(hs);
        }


        //Pranay 28 October 2016 Function to Bind the Flag Criteria based on Mailbox selected
        public DataSet GetFlagCriteriaByEmailboxSelected(Hashtable ht)
        {
            return this._CommonDataService.GetFlagCriteriaByEmailboxSelected(ht);
        }

        //Pranay -28 October 2016
        /// <summary>
        /// Function for Inserting values to StoredProcedure for Flagged Cases
        /// </summary>
        /// <param name="ht"></param>
        /// <returns></returns>
        public int InsertDetailsForFlaggedCases(Hashtable ht)
        {
            return Convert.ToInt32(this._CommonDataService.InsertDetailsForFlaggedCases(ht));
        }
        public DataSet GetAutoReply(Hashtable hs)
        {
            return this._CommonDataService.GetAutoReply(hs);
        }
    }
}
