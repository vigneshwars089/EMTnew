﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
   public class AUDITConfigurationConstant
    {
       public struct S_ConfigurationrDBScripts
       {
           public const string CREATE_USERS = "USP_GET_TRANSELEMENTLIST";
           public const string UPDATE_USERS = "USP_UPDATE_USERS";
           
       }
    }
}
