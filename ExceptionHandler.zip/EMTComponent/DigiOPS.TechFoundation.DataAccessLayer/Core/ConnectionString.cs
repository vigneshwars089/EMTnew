﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
   public class ConnectionString
    {
       public string GetConnectionString(string AppId, int TenantId)
       {
           TenantDAL tenant = new TenantDAL();
           DataTable dt = new DataTable();
           dt=tenant.GetConnectionStringDetails(AppId, TenantId);
           //string ConnectionString = "<add name=" + '"' + "ConnStr" + '"' + " connectionString=" + '"' + "Data Source=" + dt.Rows[0]["szServerName"] + "; Initial Catalog=" + dt.Rows[0]["szDatabaseName"] + ";  User Id=" + dt.Rows[0]["szUserId"] + "; Password=" + dt.Rows[0]["szPassword"] + "; Min Pool Size=10; Max Pool Size=100;Trusted_Connection=No;MultipleActiveResultSets=True;" + '"' + " providerName=" + '"' + "System.Data.SqlClient" + '"' + "/>";
           string ConnectionString = "Data Source=" + dt.Rows[0]["szServerName"] + "; Initial Catalog=" + dt.Rows[0]["szDatabaseName"] + ";  User Id=" + dt.Rows[0]["szUserId"] + "; Password=" + dt.Rows[0]["szPassword"] + "; Min Pool Size=10; Max Pool Size=100;Trusted_Connection=No;MultipleActiveResultSets=True;" ;
           return ConnectionString;
       }
    }
}
