﻿using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class CaseProcessingDataAccess : CaseProcessingRepository
    {
        CaseProcessingDAO objCaseHandler = new CaseProcessingDAO();
        LoggingFactory objlog = new LoggingFactory();
        public override int GetMaxNoScreenshotCaseId(long CaseId)
        {
            int MaxNoScreenshotCaseId;

            try
            {
                MaxNoScreenshotCaseId = objCaseHandler.GetMaxNoScreenshotCaseId(CaseId);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return MaxNoScreenshotCaseId;
        }

        public override void LockEmail(int EmailBoxType, string EmailId)
        {
            try
            {
                objCaseHandler.LockEmail(EmailBoxType, EmailId);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public override void InsertEMailDetails(long CaseId, string EMailTo, string EMailCc, string Subject, string EMailBody, int EMailTypeId, DateTime EMailSentDate, bool SentStatus, string plainbody, int ishighimp, bool isVIP)
        {
            try
            {
                objCaseHandler.InsertEMailDetails(CaseId, EMailTo, EMailCc, Subject, EMailBody, EMailTypeId, EMailSentDate, SentStatus, plainbody, ishighimp, isVIP);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public override System.Data.DataSet LoadCase(string caseID)
        {
            DataSet ds = new DataSet();
            try
            {
                ds = objCaseHandler.LoadCase(caseID);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

            return ds;
        }
    }
}
