﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class CaseProcessingRepository : ICaseProcessingRepository
    {

        public virtual int GetMaxNoScreenshotCaseId(long CaseId)
        {
            throw new NotImplementedException();
        }

        public virtual void LockEmail(int EmailBoxType, string EmailId)
        {
            throw new NotImplementedException();
        }

        public virtual void InsertEMailDetails(long CaseId, string EMailTo, string EMailCc, string Subject, string EMailBody, int EMailTypeId, DateTime EMailSentDate, bool SentStatus, string plainbody, int ishighimp, bool isVIP)
        {
            throw new NotImplementedException();
        }

        public virtual System.Data.DataSet LoadCase(string caseID)
        {
            throw new NotImplementedException();
        }
    }
}
