﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Exchange.WebServices.Data;
//using ExchangeConsole;
using System.Web;
using System.Net;
using System.Net.Security;
using System.Security.Authentication;
using System.Xml;
using System.Security.Cryptography.X509Certificates;
using System.Xml.Xsl;
using System.Xml.Serialization;
using System.Diagnostics;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using DigiOPS.TechFoundation.Logging;
using System.Collections;
using System.IO;
using Microsoft.Exchange.WebServices.Autodiscover;
using System.Runtime.InteropServices;
//using DigiOPS.TechFoundation.Security;
using DigiOPS.TechFoundation.Entities;



namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class EmailCaseCreationDAO
    {

        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        //static String encryptionKey = ConfigurationSettings.AppSettings["ENCRYPTIONKEY"].ToString();
        //static String encryptionmode = ConfigurationSettings.AppSettings["ENCRYPT/DECRYPT"].ToString();       
        private string myConnection = string.Empty;
        public EmailCaseCreationDAO()
        {
            myConnection = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
        }


        //public DataSet serverchk()
        //  {
        //      DataSet ds = new DataSet();
        //      try
        //      {
        //          string spname = string.Empty;
        //          Hashtable hs = new Hashtable();
        //          spname = "USP_Get_MailBoxDetails";
        //           DBHelper db = new DBHelper();
        //          ds = db.SelectDataSet(spname, hs);

        //      }
        //      catch (ArgumentException ex)
        //      {
        //          objlog.GetLoggingHandler("Log4net").LogException(ex);
        //          throw;
        //      }
        //      catch (InvalidOperationException ex)
        //      {
        //          objlog.GetLoggingHandler("Log4net").LogException(ex);
        //          throw;

        //      }
        //      catch (SqlException ex)
        //      {
        //          objlog.GetLoggingHandler("Log4net").LogException(ex);
        //          throw;

        //      }

        //    return ds;
        //  }

        //  public int GetCaseStatus(string caseID)
        //{
        //    int currentStatus = 0;
        //    try
        //    {
        //        DataSet dsStatus = new DataSet();
        //        string spname = string.Empty;
        //        Hashtable hs = new Hashtable();
        //        spname = "USP_GetCaseCurrentStatus";
        //        hs.Add(ExchangeConstants.SP_PARAMETER_CASEID, caseID);
        //         DBHelper db = new DBHelper();
        //        dsStatus = db.SelectDataSet(spname, hs);

        //   if (dsStatus.Tables.Count > 0)
        //     {
        //        if (dsStatus.Tables[0].Rows.Count > 0)
        //        {
        //            currentStatus = db.ExecuteNonQuery(spname, hs);
        //            }
        //        }
        //      }
        //    catch (ArgumentException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (InvalidOperationException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;

        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;

        //    }
        //    return currentStatus;
        //}

        public int InsertMail(CaseCreationInput ec, string MailFolderId, string StatusId, string caseID, string subcaseid)
        {

            int value = 0;
            try
            {
                DataSet dsStatus = new DataSet();
                string spname = string.Empty;
                Hashtable hs = new Hashtable();
                spname = "USP_Insert_MailCaseDetails";
                hs.Add(ExchangeConstants.SP_PARAMETER_RECEIVED_DATE, ec.ReceivedDate);
                hs.Add(ExchangeConstants.SP_PARAMETER_MAILFOLDER_ID, MailFolderId);
                hs.Add(ExchangeConstants.SP_PARAMETER_STATUS_ID, StatusId);
                hs.Add(ExchangeConstants.SP_PARAMETER_SUBJECT, ec.Subject);
                hs.Add(ExchangeConstants.SP_PARAMETER_MESSAGE, ec.Message);
                hs.Add(ExchangeConstants.SP_PARAMETER_FROMADD, ec.Sender);
                hs.Add(ExchangeConstants.SP_PARAMETER_TOADD, ec.Toadd);
                hs.Add(ExchangeConstants.SP_PARAMETER_CCADD, ec.CCaddress);
                hs.Add(ExchangeConstants.SP_PARAMETER_BCCADD, ec.BCCaddress);
                hs.Add(ExchangeConstants.SP_PARAMETER_PRIORITY, ec.Priority);
                hs.Add("@Bodycontent", ec.Message);
                DBHelper db = new DBHelper();
                value = db.ExecuteNonQuery(spname, hs);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;

            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;

            }
            finally
            {


            }
            return value;
        }


        public int UpdateCases(CaseCreationInput ec, string MailFolderId, string StatusId, string caseID, string subcaseid)
        {


            int value = 0;
            try
            {
                DataSet dsStatus = new DataSet();
                string spname = string.Empty;
                Hashtable hs = new Hashtable();
                spname = "USP_Update_Followup_Details";
                hs.Add(ExchangeConstants.SP_PARAMETER_CASEID, caseID);
                hs.Add(ExchangeConstants.SP_PARAMETER_RECEIVED_DATE, ec.ReceivedDate);
                hs.Add(ExchangeConstants.SP_PARAMETER_MAILFOLDER_ID, MailFolderId);
                hs.Add(ExchangeConstants.SP_PARAMETER_SUBJECT, ec.Subject);
                hs.Add(ExchangeConstants.SP_PARAMETER_MESSAGE, ec.Message);
                hs.Add(ExchangeConstants.SP_PARAMETER_FROMADD, ec.Sender);
                hs.Add(ExchangeConstants.SP_PARAMETER_TOADD, ec.Toadd);
                hs.Add(ExchangeConstants.SP_PARAMETER_CCADD, ec.CCaddress);
                hs.Add(ExchangeConstants.SP_PARAMETER_BCCADD, ec.BCCaddress);
                //hs.Add(ExchangeConstants.SP_PARAMETER_SUBCASEID, subcaseid);
                hs.Add(ExchangeConstants.SP_PARAMETER_PRIORITY, ec.Priority);
                DBHelper db = new DBHelper();
                value = db.ExecuteNonQuery(spname, hs);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;

            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;

            }
            finally
            {

            }
            return value;
        }

        //public int InsertMailItemAttachment(EMailInfo ec)
        //{
        //    int result=0;

        //    try
        //    {

        //       DataSet dsStatus = new DataSet();
        //        string spname = string.Empty;
        //        Hashtable hs = new Hashtable();
        //        spname = "USP_Insert_Mail_Attachment";
        //        string FileExtension = System.IO.Path.GetExtension(ec.FileName).ToLower();
        //        hs.Add(ExchangeConstants.SP_PARAMETER_CASEID,ec.caseID );
        //        hs.Add(ExchangeConstants.SP_PARAMETER_ATTACHMENTNAME,ec.FileName);
        //        hs.Add(ExchangeConstants.SP_PARAMETER_ATTACHMENTDATA,ec.fileBytes);
        //        hs.Add(ExchangeConstants.SP_PARAMETER_CONTENTTYPE,FileExtension);
        //        if (!ec.FileName.Contains("cid:image"))
        //        {
        //        hs.Add(ExchangeConstants.SP_PARAMETER_ATTACHMENTTYPE, 2);
        //        }
        //        else
        //        {
        //             hs.Add(ExchangeConstants.SP_PARAMETER_ATTACHMENTTYPE, 3);

        //        }
        //        hs.Add(ExchangeConstants.SP_PARAMETER_CREATEDBY,0);
        //        DBHelper db = new DBHelper();
        //      result= db.ExecuteNonQuery(spname,hs);

        //    }
        //    catch (ArgumentException ex)
        //      {

        //          objlog.GetLoggingHandler("Log4net").LogException(ex);
        //          throw;
        //      }
        //      catch (InvalidOperationException ex)
        //      {
        //          objlog.GetLoggingHandler("Log4net").LogException(ex);
        //          throw;

        //      }
        //      catch (SqlException ex)
        //      {
        //          objlog.GetLoggingHandler("Log4net").LogException(ex);
        //          throw;

        //      }
        //    finally
        //    {

        //    }
        //    return result;

        //}

        //public int InsertFileName(EMailInfo ec)
        //{
        //    int result = 0;
        //    try
        //    {
        //        string spname = string.Empty;
        //        Hashtable hs = new Hashtable();
        //        spname = "USP_Insert_Mail_Attachment";
        //        Byte[] fileBytes = null;
        //        FileInfo fiInfo = new FileInfo(ec.FileName);

        //        string FileExtension = System.IO.Path.GetExtension(ec.FileName).ToLower();
        //        string strFileName = fiInfo.Name.Replace("^1^", "\"").Replace("^2^", "*").Replace("^3^", @"/").Replace("^4^", ":").Replace("^5^", "<").Replace("^6^", ">").Replace("^7^", "?").Replace("^8^", @"\").Replace("^9^", "|");
        //        string ext = System.IO.Path.GetExtension(strFileName).ToLower();
        //        fileBytes = System.IO.File.ReadAllBytes(ec.FileName);
        //        if (encryptionmode == "ON")
        //        {
        //            CryptInfo cryptInfo = new CryptInfo();
        //            SecurityFactory securityFactory = new SecurityFactory();
        //            cryptInfo.CryptKey = encryptionKey;
        //            cryptInfo.ValueToCrypt = System.Text.Encoding.UTF8.GetString(fileBytes);
        //            string encryptedfileBytes = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
        //            fileBytes = System.Text.Encoding.UTF8.GetBytes(encryptedfileBytes);
        //        }

        //          hs.Add(ExchangeConstants.SP_PARAMETER_CASEID,ec.caseID);
        //          hs.Add(ExchangeConstants.SP_PARAMETER_ATTACHMENTNAME,ec.FileName);
        //          hs.Add(ExchangeConstants.SP_PARAMETER_ATTACHMENTDATA,ec.fileBytes);
        //          hs.Add(ExchangeConstants.SP_PARAMETER_CONTENTTYPE, FileExtension);
        //          hs.Add(ExchangeConstants.SP_PARAMETER_ATTACHMENTTYPE,2);
        //          hs.Add(ExchangeConstants.SP_PARAMETER_CREATEDBY,0);
        //           DBHelper db=new DBHelper();
        //        result=db.ExecuteNonQuery(spname,hs);

        //    }


        //    catch (ArgumentException ex)
        //    {

        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (InvalidOperationException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;

        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;

        //    }
        //    finally
        //    {

        //    }

        //    return result;
        //}


    }
}
