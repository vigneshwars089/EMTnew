﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public abstract class EmailCaseCreationRepository : IEmailCaseCreationRepository
    {

        public virtual int UpdateCases(Entities.CaseCreationInput ec, string MailFolderId, string StatusId, string caseID, string subcaseid)
        {
            throw new NotImplementedException();
        }

        public virtual int InsertMail(Entities.CaseCreationInput ec, string MailFolderId, string StatusId, string caseID, string subcaseid)
        {
            throw new NotImplementedException();
        }
    }
}
