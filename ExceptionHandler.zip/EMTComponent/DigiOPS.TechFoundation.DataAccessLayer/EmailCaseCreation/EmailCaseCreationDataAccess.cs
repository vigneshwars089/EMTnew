﻿using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class EmailCaseCreationDataAccess : EmailCaseCreationRepository
    {
        EmailCaseCreationDAO objemailcaseCreation = new EmailCaseCreationDAO();
        LoggingFactory objlog = new LoggingFactory();
        public int InsertMail(CaseCreationInput ec, string MailFolderId, string StatusId, string caseID, string subcaseid)
        {
            int MaxNoScreenshotCaseId;

            try
            {
                MaxNoScreenshotCaseId = objemailcaseCreation.InsertMail(ec, MailFolderId, StatusId, caseID, subcaseid);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return MaxNoScreenshotCaseId;
        }

        public int UpdateCases(CaseCreationInput ec, string MailFolderId, string StatusId, string caseID, string subcaseid)
        {
            int rtnUpdateCases;

            try
            {
                rtnUpdateCases = objemailcaseCreation.UpdateCases(ec, MailFolderId, StatusId, caseID, subcaseid);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return rtnUpdateCases;
        }
    }
}
