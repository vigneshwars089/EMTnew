﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
//using Quart.BusinessEntity;
//using Quart.Utility;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System.Xml.Linq;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    /// <summary>
    /// Program Features DAO
    /// </summary>
    public class ProgramFeaturesDAO : IProgramFeatureRepository
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        ConnectionString connectionstring = new ConnectionString();
        
        //private string dbConnectionString = string.Empty;
        //private Logger proxyLogger = new Logger();

        /// <summary>
        /// db connection
        /// </summary>
        public ProgramFeaturesDAO(string appId, int TenantId)
        {
            dbConnectionString = connectionstring.GetConnectionString(appId, TenantId); 
            //dbConnectionString = Utility.Conversion.GetDecodedConnectionstring();
        }

        #region Program Features Data Access
        /// <summary>
        /// Method to Get Program Features
        /// </summary>
        /// <param name="objBaseEntity">BaseTransportEntity</param>
        /// <returns>DataTable</returns>
        public DataTable GetProgramFeatures(int ProgramID)
        {
            objloginfo.Message = ("GetProgramFeatures - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //proxyLogger.Log.Info("GetProgramFeatures - Called.");

            DataTable dt = new DataTable();
            DataSet _ds = new DataSet();
            try
            {
               
              
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_PROGRAM_FEATURES", sqlConnection);
                    command.Parameters.Add("@siProgramId", SqlDbType.SmallInt).Value = ProgramID;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
                
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //} 
            return (_ds.Tables[0]);

        }
        /// <summary>
        /// Method to Set Program Features
        /// </summary>
        /// <param name="objBase"></param>
        /// <returns></returns>
        public string SetProgramFeatures(ProgramFeatureSetUp objBase)
        {
            objloginfo.Message = ("SetProgramFeatures - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           // proxyLogger.Log.Info("SetProgramFeatures - Called.");
            string resultValue = "-1";
            try
            {
                ProgramFeatureSetUp objProgramFeatures = new ProgramFeatureSetUp();
                objProgramFeatures = (ProgramFeatureSetUp)objBase;
             
                XElement Parent = new XElement("root");
                XElement root = new XElement("xmlArguments",
                     new XAttribute("iProgramFeaturesSetUpId", (objProgramFeatures.ProgramFeatureSetUpId == null) ? 0 : objProgramFeatures.ProgramFeatureSetUpId),
                     new XAttribute("siProgramId", (objProgramFeatures.SelectedProgramId == null) ? 0 : objProgramFeatures.SelectedProgramId),
                     new XAttribute("bIsSupervisorAuditApplicable", (objProgramFeatures.IsSupervisorAuditApplicable == null) ? false : objProgramFeatures.IsSupervisorAuditApplicable),
                     new XAttribute("szAuditingLogic", (objProgramFeatures.SelectedAuditLogicId == null) ? string.Empty : objProgramFeatures.SelectedAuditLogicId),
                     new XAttribute("szScoringLogic", (objProgramFeatures.SelectedScoringLogicId == null) ? string.Empty : objProgramFeatures.SelectedScoringLogicId),
                     new XAttribute("bIsEmployeeApplicable", (objProgramFeatures.IsEmployeeApplicable == null) ? false : objProgramFeatures.IsEmployeeApplicable),
                     new XAttribute("bIsLineApplicable", (objProgramFeatures.IsLinesApplicable == null) ? false : objProgramFeatures.IsLinesApplicable),
                      new XAttribute("bSamplingByVolume", (objProgramFeatures.Leveld == null) ? false : objProgramFeatures.Leveld),
                      new XAttribute("bIsEnableDataEntryByAuditor", (objProgramFeatures.IsDataEntryByAuditorEnable == null) ? false : objProgramFeatures.IsDataEntryByAuditorEnable),
                     new XAttribute("bIsEnablePeerToPeerAuditInfo", (objProgramFeatures.IsPeerToPeerAuditInfoEnable == null) ? false : objProgramFeatures.IsPeerToPeerAuditInfoEnable),
                     new XAttribute("iNoOfElement", (objProgramFeatures.NoOfElement == null) ? 0 : objProgramFeatures.NoOfElement),
                     new XAttribute("szDateFormat", (objProgramFeatures.DateFormat == null) ? string.Empty : objProgramFeatures.DateFormat),
                     new XAttribute("szSystemEffects", (objProgramFeatures.SelectedSystemEffectId == null) ? string.Empty : objProgramFeatures.SelectedSystemEffectId),
                     new XAttribute("bIsDefaultRating", (objProgramFeatures.IsDefaultRating == null) ? false : objProgramFeatures.IsDefaultRating),
                     new XAttribute("bIsStratifiedSamplingRequired", (objProgramFeatures.IsStratifiedSampling == null) ? false : objProgramFeatures.IsStratifiedSampling),
                     new XAttribute("bIsFreezingOfSamples", (objProgramFeatures.IsSamplingFrozen == null) ? false : objProgramFeatures.IsSamplingFrozen),
                     new XAttribute("bIsFatalErrorApplicable", (objProgramFeatures.IsFatalErrorApplicable == null) ? false : objProgramFeatures.IsFatalErrorApplicable),
                     new XAttribute("bIsCriticalityApplicable", (objProgramFeatures.IsCriticalityApplicable == null) ? false : objProgramFeatures.IsCriticalityApplicable),
                     new XAttribute("bIsDaylimitforcorrectionApplicable", (objProgramFeatures.IsDaylimitforcorrectionApplicable == null) ? false : objProgramFeatures.IsDaylimitforcorrectionApplicable),
                     new XAttribute("bIsSLAActivityApplicable", (objProgramFeatures.IsSLAActivityApplicable == null) ? false : objProgramFeatures.IsSLAActivityApplicable),
                     new XAttribute("bIsMailTriggerRequired", (objProgramFeatures.IsFeedbackMailTriggerApplicable == null) ? false : objProgramFeatures.IsFeedbackMailTriggerApplicable),
                     new XAttribute("bIsReworkRemainderMailRequired", (objProgramFeatures.IsReworkRemainderMailTgrApplicable == null) ? false : objProgramFeatures.IsReworkRemainderMailTgrApplicable),
                     new XAttribute("iMaxRemainderCnt", (objProgramFeatures.MaxNoOfRemainder == null) ? 0 : objProgramFeatures.MaxNoOfRemainder),
                     new XAttribute("iMailSchedulerFrequency", (objProgramFeatures.MailFrequency == null) ? 0 : objProgramFeatures.MailFrequency),
                     new XAttribute("szMailboxName", (objProgramFeatures.MailBoxName == null) ? string.Empty : objProgramFeatures.MailBoxName),
                     new XAttribute("szAuditTypes", (objProgramFeatures.AuditTypes == null) ? string.Empty : objProgramFeatures.AuditTypes),
                     new XAttribute("iCreatedBy", (objProgramFeatures.createdBy == null) ? 0 : Convert.ToInt32(objProgramFeatures.createdBy)),
                     new XAttribute("iModifiedBy", (objProgramFeatures.modifiedBy == null) ? 0 : Convert.ToInt32(objProgramFeatures.modifiedBy)),
                     new XAttribute("szOpertaionName", objProgramFeatures.eventAction),
                     new XAttribute("bIsTotalVolumeApplicable", (objProgramFeatures.IsTotalVolumeApplicable == null) ? false : objProgramFeatures.IsTotalVolumeApplicable),
                     new XAttribute("IsWorkFlowNeedforCorrection", (objProgramFeatures.IsWorkFlowNeedforCorrection == null) ? false : objProgramFeatures.IsWorkFlowNeedforCorrection),
                     new XAttribute("MaxCorrectionCnt", (objProgramFeatures.MaxCorrectionCnt == null) ? 0 : objProgramFeatures.MaxCorrectionCnt),
                     new XAttribute("MaxCorrectionDaysCnt", (objProgramFeatures.MaxCorrectionDaysCnt == null) ? 0 : objProgramFeatures.MaxCorrectionDaysCnt),
                     new XAttribute("bIsExternalFreezingOfSamples", (objProgramFeatures.IsExternalSamplingFrozen == null) ? false : objProgramFeatures.IsExternalSamplingFrozen),
                     new XAttribute("bIsMetricsRequired", (objProgramFeatures.IsMetricsRequired == null) ? false : objProgramFeatures.IsMetricsRequired),
                     new XAttribute("bIsTATApplicable", (objProgramFeatures.IsTATApplicable == null) ? false : objProgramFeatures.IsTATApplicable),
                     new XAttribute("bIsCombinedAccuracy", (objProgramFeatures.IsCombinedAccuracyNeeded == null) ? false : objProgramFeatures.IsCombinedAccuracyNeeded),
                     new XAttribute("bIsDeletMailEnable", (objProgramFeatures.IsDeletMailEnableTriggerApplicable == null) ? false : objProgramFeatures.IsDeletMailEnableTriggerApplicable),
                     new XAttribute("iIntAllocCnt", (objProgramFeatures.IntAllocCnt == null) ? 0 : Convert.ToInt32(objProgramFeatures.IntAllocCnt)),
                     new XAttribute("iExtAllocCnt", (objProgramFeatures.ExtAllocCnt == null) ? 0 : Convert.ToInt32(objProgramFeatures.ExtAllocCnt)),
                     new XAttribute("iBusiAllocCnt", (objProgramFeatures.BusiAllocCnt == null) ? 0 : Convert.ToInt32(objProgramFeatures.BusiAllocCnt)),
                     new XAttribute("szSamplingMethodInternal", (objProgramFeatures.sSamplingMethodforInternal == null) ? "" : objProgramFeatures.sSamplingMethodforInternal),
                     new XAttribute("szSamplingMethodBusiness", (objProgramFeatures.sSamplingMethodforBusiness == null) ? "" : objProgramFeatures.sSamplingMethodforBusiness),
                     new XAttribute("szStaticFields", (objProgramFeatures.StaticFields == null) ? string.Empty : objProgramFeatures.StaticFields),
                     new XAttribute("blsAHTEnable", (objProgramFeatures.AHTApplicability == null) ? false : objProgramFeatures.AHTApplicability),
                     new XAttribute("blsCTQComments", (objProgramFeatures.CTQComments == null) ? false : objProgramFeatures.CTQComments),
                     new XAttribute("bIsRatingDifferenceMailEnable", (objProgramFeatures.IsRatingDifferenceMailApplicable == null) ? false : objProgramFeatures.IsRatingDifferenceMailApplicable),//Added for Rating Difference Email Configuration
                     new XAttribute("szCombinedAccuracyType", (objProgramFeatures.szCombinedAccuracyType == null) ? string.Empty : objProgramFeatures.szCombinedAccuracyType), //Added for Final Audit Update Configuration
                     new XAttribute("IsSLABasedSubProcess", (objProgramFeatures.IsSLABasedSubProcess == null) ? false : objProgramFeatures.IsSLABasedSubProcess), //Added for SLA need subprocess
                     new XAttribute("IsSamplingTypeCustommode", (objProgramFeatures.IsSamplingTypeCustommode == null) ? false : objProgramFeatures.IsSamplingTypeCustommode), //Added for Sampling type custom mode
                 new XAttribute("IsDataPurgingEnabled", (objProgramFeatures.IsDataPurgingEnabled == null) ? false : objProgramFeatures.IsDataPurgingEnabled) //Added for data purging required or not
               
                     
                     );

                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_SET_PROGRAM_FEATURES", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;


                   
                    Parent.Add(root);
                    command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);                    
                    command.Parameters.Add(Constants.PAR_RETURN_VALUE, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters[Constants.PAR_RETURN_VALUE].Value.ToString();
                }

               
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
               // throw new QuartException(ex.Message, ex.InnerException);
            }
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //} 
            return resultValue;

        }

        #endregion
    }
}
