﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    interface ICaseHandlerRepository
    {
        string SetTransRecordData(string action, string sb, int recordid, string viewname);
        string DeleteTransaction(TransRecordData objRecord);
        DataSet GetTransactionList(TransactionListView objBase);
    }
}
