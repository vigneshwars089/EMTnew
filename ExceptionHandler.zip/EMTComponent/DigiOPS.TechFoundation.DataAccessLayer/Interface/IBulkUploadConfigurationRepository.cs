﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    interface IBulkUploadConfigurationRepository
    {
        DataSet GetExcelTemplate();
        DataSet InsertAuditConfigDetails(DataSet ds);
        string defectopportunity(DataTable result1);
        string subdefectopportunity(DataTable result1);
        string Ratingtype(DataTable result1);
        string Ratinggroup(DataTable result1);
        string CombinedAccuracy(DataTable result1);
        DataSet DefectSubDefectValidation();
        DataSet RatingTypeValidation();
        DataSet CombinedAccuracyValidation();
    }
}
