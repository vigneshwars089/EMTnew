﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    interface ISupportTicketRepository
    {
        string SetSupportTicket(SupportTicketEntity Ticket);
        string SetSupportTicketTrail(SupportTicketEntity Ticket);
        DataTable GetSupportTicketEntityList(SupportTicketEntity objProgramIssuesEntity);
        string SetSupportTicketMailingDetails(BaseTransportEntity _Obj);
        DataTable GetSupportTicketEntityTrailList(SupportTicketTrailEntity objTicketTrailEntity);
        DataTable GetSupportTicketStatus(SupportTicketEntity objTicket);
        DataTable GetSupportTicketById(SupportTicketEntity objTicket);
    }
}
