﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;
using System.Data;
using System.Collections;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public interface IDataElementConfigurationRepository
    {
        string CUDDataElementRecord(DataElementEntity _DataElement);
        DataSet GetEntityListcollection(DataElementInfo _obj);
        DataSet ExcelUploadToDB(Hashtable hstbl);
        List<DataElementStaticConditon> GetChildStaticConditions(int configid);
        List<DataElementStaticConditon> GetStaticConditions(int subProcessid);
        string UpdateStaticConditions(List<DataElementStaticConditon> objConditions);
        DataTable GetDirectAuditLevelList(int SubProcessID);
        string SetCodesData(CodesEntity _Codes);
        DataSet GetCodesList(CodeGroupEntity _Codes);
        bool IsAutoAudit(DataElementInfo objdataelementinfo);
    }
}
