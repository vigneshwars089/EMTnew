﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;
using System.Data;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public interface IWorkFlowConfigurationRepository
    {
        string SetWorkflowAuditConfiguration(WorkflowConfigurationEntity objConfigEntity);
        DataTable GetEntityRecordByEntity(WorkflowConfigInfo objinfo);
    }
}
