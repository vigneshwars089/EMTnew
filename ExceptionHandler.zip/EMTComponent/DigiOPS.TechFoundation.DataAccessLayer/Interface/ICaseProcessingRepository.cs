﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    interface ICaseProcessingRepository
    {
        int GetMaxNoScreenshotCaseId(long CaseId);
        void LockEmail(int EmailBoxType, string EmailId);
        void InsertEMailDetails(long CaseId, string EMailTo, string EMailCc, string Subject, string EMailBody, int EMailTypeId, DateTime EMailSentDate, bool SentStatus, string plainbody, int ishighimp, bool isVIP);
        DataSet LoadCase(string caseID);
    }
}
