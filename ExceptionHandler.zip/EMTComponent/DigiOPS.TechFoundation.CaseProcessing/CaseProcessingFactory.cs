﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.CaseProcessing
{
    public class CaseProcessingFactory : ICaseProcessingFactory
    {
        public struct S_CaseProcessingLogic
        {
            public const string Email = "Email";
        }

        public IBaseCaseProcessing GetCaseProcessingHandler(string CaseProcessing)
        {
           switch (CaseProcessing)
             {
                     case S_CaseProcessingLogic.Email:
                         return new EmailCaseProcessing();                                
                      default:
                         return null;
            }
        }
    }
}
