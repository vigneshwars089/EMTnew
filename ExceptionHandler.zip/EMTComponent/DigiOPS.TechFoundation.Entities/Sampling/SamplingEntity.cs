﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class SamplingEntity : BaseTransportEntity
    {
        public int AuditTypeId { get; set; }
        public int SubProcessId { get; set; }
        public int SystemUserId { get; set; }
        public string samplingMethod { get; set; }
        public int CreatedBy { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public int? StartRowIndex { get; set; }
        public string SamplingPct { get; set; }
        public string SamplingType { get; set; }
        public int levelID { get; set; }
        public int? MaximumRows { get; set; }


        public int szAuditTypid { get; set; }
        public string szSubProcessName { get; set; }
        public string szAssociate { get; set; }
        public string szModifiedBy { get; set; }
        public System.DateTime dsModifiedDate { get; set; }
        public string szAuditTypeName { get; set; }
        public Nullable<decimal> dSamplingPct { get; set; }
        public string szSystemUserId { get; set; }
        public int? TotalRows { get; set; }
        public int? RowNumber { get; set; }
    }
}
