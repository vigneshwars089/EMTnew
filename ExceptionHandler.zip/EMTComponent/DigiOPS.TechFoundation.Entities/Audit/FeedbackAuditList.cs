﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// AuditRework class
    /// </summary>
    [Serializable]
    public class AuditRework : BaseTransportEntity
    {
        public int SubProcessId { get; set; }
        public int AuditId { get; set; }
        public int RecordId { get; set; }
        public int AuditFindingId { get; set; }
        public string ReworkComments { get; set; }
        public int UserId { get; set; }
        public Double Score { get; set; }
        public Nullable<bool> IsReworkReq { get; set; }
        public string AuditComments { get; set; }

        /// <summary>
        /// AuditRework constructor
        /// </summary>
        public AuditRework()
        {

        }
    }

    /// <summary>
    /// FeedbackAuditList class
    /// </summary>
    [Serializable]
    public class FeedbackAuditList : BaseTransportEntity
    {
        public int SubProcessId { get; set; }
        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public int AuditTypeId { get; set; }
        public int UserId { get; set; }
        public int AuditId { get; set; }
        public string CustomMessage { get; set; }
        public DateTime? ProcessedDate { get; set; }
        public DateTime? ProcessedToDate { get; set; }
        public string WorkFlowconfigAuditTypes { get; set; }
        /// <summary>
        /// FeedbackAuditList constructor
        /// </summary>
        public FeedbackAuditList()
        {
            AuditTransactionList = new List<TransactionList>();
            AuditTypeList = new List<TransDropDown>();
        }
        public List<TransactionList> AuditTransactionList { get; set; }
        public List<TransDropDown> AuditTypeList { get; set; }
    }

    /// <summary>
    /// FeedbackAuditListViewModel classs
    /// </summary>
    [Serializable]
    public class FeedbackAuditListViewModel : BaseTransportEntity 
    {
        public int SubProcessId { get; set; }
        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public int AuditTypeId { get; set; }
        public int UserId { get; set; }
        public int AuditId { get; set; }
        public DateTime? ProcessedDate { get; set; }

        /// <summary>
        /// FeedbackAuditListViewModel constructor
        /// </summary>
        public FeedbackAuditListViewModel()
        {
            AuditTransactionList = new List<TransactionList>();
            FeedbackAuditList = new List<FeedbackAuditList>();
            AuditTypeList = new List<TransDropDown>();
        }
        public List<TransactionList> AuditTransactionList { get; set; }
        public List<FeedbackAuditList> FeedbackAuditList { get; set; }
        public List<TransDropDown> AuditTypeList { get; set; }
    }
}
