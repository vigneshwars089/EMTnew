﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class AuditCheckItemsInfo : BaseInfo
    {
        public List<AuditCheckCategoryInfo> CheckCategories { get; set; }

    }

    public class AuditCheckCategoryInfo
    {

        public string CategoryName { get; set; }

        public string CategoryDescription { get; set; }

        public int CategoryOrdinalNumber { get; set; }

        public List<AuditCheckHeadingInfo> Headings { get; set; }

    }

    public class AuditCheckHeadingInfo
    {
        public string HeadingName { get; set; }
        public string HeadingDescription { get; set; }

        public int HeadingOrdinalNumber { get; set; }
        public List<AuditCheckItemInfo> CheckItems { get; set; }
    }

    public class AuditCheckItemInfo
    {
        public string CheckItemName { get; set; }
        public string CheckItemDescription { get; set; }

        public int CheckItemOrdinalNumber { get; set; }
    }

}
