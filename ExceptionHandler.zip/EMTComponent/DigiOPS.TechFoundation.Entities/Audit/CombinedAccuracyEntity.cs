﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;


namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// CombinedAccuracyEntity class
    /// </summary>
    [Serializable]
    public class CombinedAccuracyEntity : BaseTransportEntity
    {
        public int LevelId { get; set; }
        public int id { get; set; }
        public int HeadingID { get; set; }
        public int subProcessId { get; set; }
        public string xmlTag { get; set; }
        public string ActionName { get; set; }
     
    }
    /// <summary>
    /// RatingTableViewModel class
    /// </summary>
    [Serializable]
    public class RatingTableViewModel : CombinedAccuracyEntity
    {
    //    public string CustomMessage { get; set; }
    //    /// <summary>
    //    /// RatingTableViewModel class
    //    /// </summary>
        public RatingTableViewModel()
        {
            RatingList = new List<TransDropDown>();
           
        }

    //    public int CombinedAccuracyId { get; set; }
    //    public int DoGroupMapId { get; set; }
        public int InternalId { get; set; }
       public int ExternalId { get; set; }
    //   public string InternalText { get; set; }
    //    public string ExternalText { get; set; }
       public int CombinedId { get; set; }
       public List<TransDropDown> RatingList { get; set; }
       public string ModifiedBy { get; set; }
        public string ModifiedDate { get; set; }
    }

    /// <summary>
    /// CombinedAccuracyEntityViewModel class
    /// </summary>
    [Serializable]
    public class CombinedAccuracyEntityViewModel : AuditDetailsEntity
    {
    //    public string CustomMessage { get; set; }

    //    /// <summary>
    //    /// CombinedAccuracyEntityViewModel class
    //    /// </summary>
        public CombinedAccuracyEntityViewModel()
        {
            CategoryList = new List<TransDropDown>();
            HeadingList = new List<TransDropDown>();
            CheckpointList = new List<TransDropDown>();
            RatingTableViewModel = new List<RatingTableViewModel>();
            AuditConfigMaster = new AuditConfigEntity();
        }

    //    public int CategoryId { get; set; }
    //    public int HeadingId { get; set; }
    //    public int CheckPointId { get; set; }
        public List<TransDropDown> CategoryList { get; set; }
       public List<TransDropDown> HeadingList { get; set; }
       public List<TransDropDown> CheckpointList { get; set; }
        public List<RatingTableViewModel> RatingTableViewModel { get; set; }
        public AuditConfigEntity AuditConfigMaster { get; set; }
       public bool IsCombinedAccuracyNeeded { get; set; }
       public int SubProcessID { get; set; }
        public bool IsCombinedConfigurationDone { get; set; }
        public string CombinedAccuracyType { get; set; }
    }

    public class Transddl : CombinedAccuracyEntity
    {
        public Boolean IsSelected { get; set; }
        public Boolean IsNA { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
        public string Score { get; set; }
        public string ForeignKey { get; set; }
        public string criticality { get; set; }
        public string TempId { get; set; }
    }
}
