﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class AuditRatingInfo
    {
        public List<RatingEntity> RatingTypeNameList { get; set; }
    }
    public class AuditRatingTypeInfo
    {
        public string RatingTypeName { get; set; }
    }

    public class AuditRatingGroupInfo
    {
        public string RatingGroupName { get; set; }

    }

}
