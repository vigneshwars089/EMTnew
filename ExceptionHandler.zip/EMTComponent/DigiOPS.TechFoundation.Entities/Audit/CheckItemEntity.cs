﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// DefectOpportunityEntity class
    /// </summary>
    [Serializable]
    public class CheckItemEntity : BaseTransportEntity
    {

        public int DOId { get; set; }
        public string DODesc { get; set; }
        public string DisplayName { get; set; }
        public Nullable<bool> IsCritical { get; set; }
        public string CriticalityType { get; set; }
        public bool IsHeading { get; set; }
        public int Level { get; set; }
        public Nullable<int> ParentDOId { get; set; }
        public int SubProcessId { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsEditMode { get; set; }
        public bool IsNotApplicable { get; set; }


        public string CategoryName { get; set; }
        public int CategoryID_DOId { get; set; }
        public string HeadingName { get; set; }
        public int HeadingID_DOId { get; set; }

        //public string CheckpointName { get; set; }
        public int CheckpointID_DOId { get; set; }

        public string CTQGroupName { get; set; }
        public int CTQGroupsID_DOId { get; set; }

        public int RatingGroupID { get; set; }
        public int RatingGroupMapId { get; set; }
        public string CriticalName { get; set; }

        public string DOHeadingName { get; set; }
        public int RatingID { get; set; }
        public string RatingName { get; set; }
        public Nullable<float> Weightage { get; set; }
        public Nullable<int> DOGroupID { get; set; }
        public int DOGroupMapId { get; set; }
        public string ScoringLogic { get; set; }
        public string AuditingLogic { get; set; }
        public string CopiedCheckpoints { get; set; }
        // public string CopyCheckpointGridContent { get; set; }
        public string SearchStr { get; set; }

        public bool isDropdowndetails { get; set; }

        public int SelectedProcessId { get; set; }
        public int SelectedProgramId { get; set; }
        // public int SelectedSubProcessId { get; set; }
        //public int SelectedCategoryId { get; set; }
        // public int SelectedHeading { get; set; }
        //  public int Selectedcheckpoint { get; set; }
        // public int SelectedCriticalType { get; set; }
        // public int SelectedRatingGroup { get; set; }
        // public int SelectedDOHeading { get; set; }
        // public int SelectedAuditingLogic { get; set; }
        //  public int SelectedCTQGroupId { get; set; }

        public string ActionName { get; set; }
        public int CanRatingEnable { get; set; }

        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        // public bool IsDefaultNeeded { get; set; }


    }

    public class TransDropDownlst : CheckItemEntity
    {


        public string criticality { get; set; }
        public string ForeignKey { get; set; }
        public bool IsNA { get; set; }
        public bool IsSelected { get; set; }
        public string Score { get; set; }
        public string TempId { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
    }

    /// <summary>
    /// DefectOpportunityViewModel class
    /// </summary>
    [Serializable]
    public class DefectOpportunityViewModel
    {
        public string TabName { get; set; }
        public string CustomMessage { get; set; }
        /// <summary>
        /// defect opportunity view model
        /// </summary>
        public DefectOpportunityViewModel()
        {
            DefectOpportunityList = new List<CheckItemEntity>();

            HeadingList = new List<CheckItemEntity>();
            CategoryList = new List<CheckItemEntity>();
            DefectOpportunityMaster = new CheckItemEntity();
            CheckpointList = new List<CheckItemEntity>();
            CTQGroupList = new List<CheckItemEntity>();
            weightageConfigList = new List<CheckItemEntity>();
            RootCause1List = new List<RootCauseEntity>();
            RootCause2List = new List<RootCauseEntity>();
            RootCause3List = new List<RootCauseEntity>();
            RootCause4List = new List<RootCauseEntity>();
            RootCause5List = new List<RootCauseEntity>();
            CopyCheckpointList = new List<CheckItemEntity>();

            AuditConfigMaster = new AuditConfigEntity();
            DropDownList = new DropDownEntity();
            SubDefect1ConfigMaster = new RootCauseEntity();
            ProgHierarchy = new ProgramHierarchyEntityViewModel();


        }

        public List<CheckItemEntity> DefectOpportunityList { get; set; }
        public List<CheckItemEntity> CategoryList { get; set; }
        public List<CheckItemEntity> HeadingList { get; set; }
        public List<CheckItemEntity> CheckpointList { get; set; }
        public List<CheckItemEntity> CTQGroupList { get; set; }
        public List<CheckItemEntity> weightageConfigList { get; set; }

        public List<RootCauseEntity> RootCause1List { get; set; }
        public List<RootCauseEntity> RootCause2List { get; set; }
        public List<RootCauseEntity> RootCause3List { get; set; }
        public List<RootCauseEntity> RootCause4List { get; set; }
        public List<RootCauseEntity> RootCause5List { get; set; }
        public List<CheckItemEntity> CopyCheckpointList { get; set; }

        public ProgramHierarchyEntityViewModel ProgHierarchy { get; set; }
        public CheckItemEntity DefectOpportunityMaster { get; set; }
        public DropDownEntity DropDownList { get; set; }
        public AuditConfigEntity AuditConfigMaster { get; set; }
        public RootCauseEntity SubDefect1ConfigMaster { get; set; }


    }




}

