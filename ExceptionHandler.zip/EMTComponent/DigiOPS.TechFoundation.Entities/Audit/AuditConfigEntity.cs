﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    ///  AuditConfigEntity class
    /// </summary>
    [Serializable]
    public class AuditConfigEntity : BaseTransportEntity
    {
        public int AuditConfigId { get; set; }
        public int AuditingLogicTypeId { get; set; }
        public string AuditingLogicType { get; set; }
        public int ScoringLogicTypeId { get; set; }
        public string ScoringLogicType { get; set; }
        // public string WorkFlowAuditTypes { get; set; }
        // public string ManualAllocationApplicableAuditTypes { get; set; }
        //public bool IsAutoSamplingNeeded { get; set; }
        //public bool IsBusiAutoSamplingNeeded { get; set; }
        //public bool isExternalAutoAllocationSamplingNeeded { get; set; } 
        //public bool IsPushExternalAudit { get; set; }
        //public bool IsPushExternalAuditAuto { get; set; }
        //public int iIntAllocCnt { get; set; }
        //public int iExtAllocCnt { get; set; }
        //public int iBusiAllocCnt { get; set; }
        public bool IsEmpNeeded { get; set; }
        public byte SubDefectLevel { get; set; }
        public byte CopySubDefectLevel { get; set; }
        public byte SamplingTypeId { get; set; }
        public string SamplingType { get; set; }
        public int WorkflowConfigId { get; set; }
        public int SubProcessId { get; set; }
        //public bool IsActive { get; set; }
        public int CreatedBy { get; set; }
        public System.DateTime CreatedDate { get; set; }
        public int ModifiedBy { get; set; }
        public System.DateTime ModifiedDate { get; set; }

        //public string SamplingCalculationType { get; set; }
        //public string SamplingPctCalculation { get; set; }
    }
}
