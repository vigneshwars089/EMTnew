﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// DataElementEntity class
    /// </summary>
    [Serializable]
    public class DataElementEntity : ConfigurationInfo
    {
        public int ElementId { get; set; }
        public string ElementName { get; set; }
        public string DisplayName { get; set; } 
        public string Description { get; set; }
        public Boolean ComparisonID { get; set; }
        public string minRange { get; set; }
        public string maxRange { get; set; }
        public int ElementTypeId { get; set; }
        public string ElementTypeName { get; set; }
        public Boolean ElementIsList { get; set; }
        public int DataTypeId { get; set; }
        public string DataTypeName { get; set; }
        public string ElementSQLDataType { get; set; }
        public string CodeGroupId { get; set; }
        public int SequenceNo { get; set; }
        public Boolean MandatoryElement { get; set; }
        public Boolean AuditFormElement { get; set; }
        public Boolean UniqueElement { get; set; }
        public int ElementLength { get; set; }
        public Boolean SearchableElement { get; set; }
        public Boolean IsReportField { get; set; }
        public Boolean GridViewElement { get; set; }
        public Boolean SamplingThreshold { get; set; }
        public Boolean IsDirectAuditLevel { get; set; }
        public int DirectAuditLevelId { get; set; }
        public string DirectAuditLevel { get; set; }
        public Boolean IsPurgingField { get; set; }
        public Boolean isActive { get; set; }
        public DateTime effectiveFrom { get; set; }
        public DateTime effectiveTo { get; set; }
        public string createdBy { get; set; }
        public DateTime createdDate { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDate { get; set; }
        public Boolean IsEditMode { get; set; }
        public string splChars { get; set; }
        public string minSamplingRange { get; set; }
        public string maxSamplingRange { get; set; }
        public string minAuditRange { get; set; }
        public string maxAuditRange { get; set; }
        public string DataEntryRoleId { get; set; }

        public int selectedProgramId { get; set; }
        public string selectedProgramName { get; set; }
        public int selectedProcessId { get; set; }
        public string selectedProcessName { get; set; }
        public int selectedSubProcessId { get; set; }
        public string selectedSubProcessName { get; set; }
        public int selectedDataTypeId { get; set; }
        public string selectedDataTypeName { get; set; }
        public int selectedDataElementTypeId { get; set; }
        public string selectedDataElementTypeName { get; set; }
        public int selectedDataEntryRoleId { get; set; }
        public string selectedDataEntryRoleName { get; set; }
        public string RoleNames { get; set; }
        public string FieldType { get; set; }
        public int _TotalRows { get; set; }

        public string RoleName { get; set; }
        public string CaseID { get; set; }
        public int CountryID { get; set; }
        public int MailBoxID { get; set; }
        public string UserId { get; set; }
        public string fieldname { get; set; }
        public string FieldAliasName { get; set; }
        public string FieldTypeID { get; set; }
        // public string FieldType { get; set; }
        public string FieldDataTypeID { get; set; }
        public long ValidationTypeID { get; set; }
        public long FieldPrivilageId { get; set; }
        public int TextLength { get; set; }
        public bool Mandatory { get; set; }
        public bool chkactive { get; set; }
        public long FieldMaxLength { get; set; }
        public long FieldMasterId { get; set; }
        public string defaultValue { get; set; }
        public string btnMap { get; set; }
        public string Value { get; set; }
        public string DynamicFieldMasterId { get; set; }
        public string CodeNameValue { get; set; }
        public List<Transddldataelmnt> lsttrans{get;set;}
        public List<MultiLingualdataelement> lstmultiLingual { get; set; }
        public Boolean ISAutoAudit { get; set; }
        public Boolean isSamplingconfigured { get; set; }
        
        //  public Boolean IsPurgingField { get; set; }
    }
    public class MultiLingualdataelement : DataElementEntity
    {
        public string dataelementName { get; set; }
        public int languageId { get; set; }
    }
    public class Transddldataelmnt : DataElementEntity
    {


        public string criticality { get; set; }
        public string ForeignKey { get; set; }
        public bool IsNA { get; set; }
        public bool IsSelected { get; set; }
        public string Score { get; set; }
        public string TempId { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
    }
    /// <summary>
    ///     Static condition class
    /// </summary>
    public class DataElementStaticConditon
    {
        public int ConfigId { get; set; }
        public string FieldDescription { get; set; }
        public string YesOrNO { get; set; }
    }

    /// <summary>
    /// DataTypeEntity class
    /// </summary>
    public class DataTypeEntity : BaseEntity
    {
        public int DataTypeId { get; set; }
        public string DataTypeName { get; set; }
        
    }

    /// <summary>
    /// DataElementEntityViewModel
    /// </summary>
    public class DataElementEntityViewModel
    {
        /// <summary>
        /// Data element entity view model
        /// </summary>
        /// <returns></returns>
        public DataElementEntityViewModel()
        {
            DataElementList = new List<DataElementEntity>();
            DataElementListSeq = new List<DataElementEntity>();
            DataElement = new DataElementEntity();
            DDLDataElement = new DropDownEntity();           
        }
        public List<DataElementEntity> DataElementList { get; set; }
        public List<DataElementEntity> DataElementListSeq { get; set; }
        public DataElementEntity DataElement { get; set; }
        public DropDownEntity DDLDataElement { get; set; }
        public string CustomErrorMessage { get; set; }
        public bool IsEnableDataEntryByAuditor { get; set; }
        public bool IsEnableStarifiedSampling { get; set; }
        public bool IsDataPurgingEnabled { get; set; }
        public bool IsMetricsRequired { get; set; }
        public int ElementCount { get; set; }
    }

    /// <summary>
    /// entityXMLSerialization class
    /// </summary>
    [Serializable]
    public class entityXMLSerialization
    {
        /// <summary>
        /// Method convert string to XML format
        /// </summary>
        /// <returns>string</returns>
        //public string ToXml()
        //{
        //    StringWriter Output = new StringWriter(new StringBuilder());
        //    string Ret = "";
        //    try
        //    {
        //        XmlSerializer s = new XmlSerializer(this.GetType());
        //        s.Serialize(Output, this);
        //        Ret = Output.ToString().Replace("xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"", "");
        //        Ret = Ret.Replace("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"", "");             
        //        Ret = Ret.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", "").Trim();
        //        Ret = Ret.Replace("<Value xsi:type=\"xsd:string\">", "<Value>").Trim();
        //        Ret = Ret.Replace(Environment.NewLine, "");
        //    }
        //    catch (XmlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (ArgumentNullException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (ArgumentException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (ApplicationException ex)
        //    {
        //        throw ex;
        //    }
        //    return Ret;
        //}

          public string ToXml()
        {
            StringWriter Output = new StringWriter(new StringBuilder());
            string Ret = "";
            try
            {
                XmlSerializer s = new XmlSerializer(this.GetType());
                s.Serialize(Output, this);
                Ret = Output.ToString().Replace("xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"", "");
                Ret = Ret.Replace("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"", "");             
                Ret = Ret.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", "").Trim();
                Ret = Ret.Replace("<Value xsi:type=\"xsd:string\">", "<Value>").Trim();
                Ret = Ret.Replace(Environment.NewLine, "");
            }
           catch (XmlException ex)
            {
                throw ex;
            }
            catch (ArgumentNullException ex)
            {
                throw ex;
            }
            catch (ArgumentException ex)
            {
                throw ex;
            }
            catch (ApplicationException ex)
            {
                throw ex;
            }
            return Ret;
        }
    }

    

    /// <summary>
    /// ElementSequence class
    /// </summary>
    [Serializable]
    public class ElementSequence : BaseEntity
    {
        public List<DataElementEntity> ElementList { get; set; }   
    }

}
