﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// MasterCalibratorEntity class
    /// </summary>
    [Serializable]
    public class MasterCalibratorEntity : BaseTransportEntity
    {

        public string createRecVal { get; set; }

        public int RecordId { get; set; }
        public string Calibrators { get; set; }
        public string RecordIds { get; set; }
        //added for checkbox list
        public string Value { get; set; }
        public string Text { get; set; }
        public Boolean IsSelected { get; set; }
        //added for checkbox list

        public bool IsActive { get; set; }

        public string szCalibrators { get; set; }


        public int SystemUserId { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDate { get; set; }

        public Nullable<short> SelectedProgramId { get; set; }
        public Nullable<int> SelectedProcessId { get; set; }
        public Nullable<int> SelectedSubProcessId { get; set; }

        public List<TransDropDown> ProgramList { get; set; }
        public List<TransDropDown> ProcessList { get; set; }
        public List<TransDropDown> SubProcessList { get; set; }
        public List<CheckBoxList> CalibratorsChkBoxList { get; set; }


    }

    /// <summary>
    /// MasterCalibratorViewModel
    /// </summary>
    [Serializable]
    public class MasterCalibratorViewModel
    {
        /// <summary>
        /// MasterCalibratorViewModel constructor
        /// </summary>
        public MasterCalibratorViewModel()
        {
            MasterCalibratorView = new MasterCalibratorEntity();
            MasterCalibratorEntityViewList = new List<MasterCalibratorEntity>();
            CalibratorList = new List<CheckBoxList>();
        }
        public MasterCalibratorEntity MasterCalibratorView { get; set; }
        public List<MasterCalibratorEntity> MasterCalibratorEntityViewList { get; set; }
        public List<CheckBoxList> CalibratorList { get; set; }
        public string CustomErrorMessage { get; set; }
    }
}
