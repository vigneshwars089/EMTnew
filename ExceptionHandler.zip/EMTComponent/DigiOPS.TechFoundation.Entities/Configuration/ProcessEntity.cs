﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// Process Enity Class
    /// </summary>
    [Serializable]
    public class ProcessEntity : BaseInfo
    {
        public int processId { get; set; }

        [DisplayName("Process Name")]
        public string processName { get; set; }

        public int SelectedProgramId { get; set; }
        public string SelectedProgramName { get; set; }

        [DisplayName("isActive")]
        public Boolean isActive { get; set; }
        [DisplayName("Effective From")]
        public DateTime effectiveFrom { get; set; }
        [DisplayName("Effective To")]
        public DateTime effectiveTo { get; set; }
        [DisplayName("Created By")]
        public string createdBy { get; set; }
        [DisplayName("Created Date")]
        public DateTime createdDate { get; set; }

        [DisplayName("Last Modified By")]
        public string modifiedBy { get; set; }

        [DisplayName("Last Modified Date")]
        public DateTime modifiedDate { get; set; }

        public bool IsEditMode { get; set; }

        public string Action { get; set; }


        
        public DateTime PrgmFromDate { get; set; }

        public DateTime PrgmToDate { get; set; }

        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public string eventAction { get; set; }
    }

    /// <summary>
    /// ProcessViewModel
    /// </summary>
    public class ProcessViewModel : BaseTransportEntity
    {

        public string CustomMessage { get; set; }
        public string ResultStatus { get; set; }
        /// <summary>
        /// TO ADD PROCESS Constructor
        /// </summary>
        public ProcessViewModel()
        {


            ProcessList = new List<ProcessEntity>();
            Process = new ProcessEntity();
            DDLProgram = new DropDownEntity();

        }


        public List<ProcessEntity> ProcessList { get; set; }
        public ProcessEntity Process { get; set; }
        public DropDownEntity DDLProgram { get; set; }
        public ProcessListViewModel ProcessListDetails { get; set; }


    }

    public class Transddlprocess : ProcessEntity
    {
        public Boolean IsSelected { get; set; }
        public Boolean IsNA { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
        public string Score { get; set; }
        public string ForeignKey { get; set; }
        public string criticality { get; set; }
        public string TempId { get; set; }
    }

    /// <summary>
    /// ProcessListViewModel class
    /// </summary>
    [Serializable]
    public class ProcessListViewModel
    {
        public string CustomMessage { get; set; }
        /// <summary>
        /// FOR PROCESS LIST Constructor
        /// </summary>
        public ProcessListViewModel()
        {
            ProcessList = new List<ProcessEntity>();
            ProcessMaster = new ProcessEntity();

        }
        public List<ProcessEntity> ProcessList { get; set; }
        public ProcessEntity ProcessMaster { get; set; }

    }
}
