﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    ///  TransElementConfigViewModel class
    /// </summary>
    [Serializable]
    public class TransElementConfigViewModel
    {
        public string CustomMessage { get; set; }
        public int SubProcessId { get; set; }
        public int RecordId { get; set; }
        public int AuditId { get; set; }
        public string ViewType { get; set; }
        public string URL { get; set; }
        public int EditRecordId { get; set; }
        public int SelectedReferenceId { get; set; }
        public int SelectedReasonId { get; set; }
        public int SelectedPeerCheckerId { get; set; }
        public int SelectedSLACategoryId { get; set; }
        public string ReasonData { get; set; }
        public bool IsEdit { get; set; }
        public bool IsReset { get; set; }
        public bool isError { get; set; }
        public bool bIsEmpNeeded { get; set; }
        public bool bIsLineNeeded { get; set; }
        public int iSubcategory { get; set; }
        public bool IsEnablePeerToPeerReviewReq { get; set; }
        public bool IsSLAActivityApplicable { get; set; }
        public string NoOfEmployee { get; set; }
        public string NoOfLine { get; set; }
        public string Page { get; set; }
        public bool isSearchEdit { get; set; }
        public bool IsAuditDataExists { get; set; }
        public bool CanCrtlVisible { get; set; }
        public bool isSearchWIPEdit { get; set; }
        public string TransactionType { get; set; }
        public bool AuditStatus { get; set; }

        /// <summary>
        /// TransElementConfigViewModel constructor
        /// </summary>
        public TransElementConfigViewModel()
        {
            TransCreationList = new List<TransElementConfig>();
            ReferenceList = new List<TransReferenceConfig>();
            ReasonList = new List<TransReasonList>();
            PeerCheckerList = new List<TransDropDown>();
            SLACategoryList = new List<TransDropDown>();
            UsersList = new List<TransDropDown>();
        }
        public List<TransElementConfig> TransCreationList { get; set; }
        public List<TransReferenceConfig> ReferenceList { get; set; }
        public List<TransReasonList> ReasonList { get; set; }
        public List<TransDropDown> PeerCheckerList { get; set; }
        public List<TransDropDown> SLACategoryList { get; set; }
        public List<TransDropDown> UsersList { get; set; }
        public bool IsOnHoldAvailable { get; set; }

    }
}
