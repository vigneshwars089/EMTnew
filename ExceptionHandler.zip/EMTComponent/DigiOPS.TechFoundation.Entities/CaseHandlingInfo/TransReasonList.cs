﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// TransReasonList class
    /// </summary>
    [Serializable]
    public class TransReasonList : BaseEntity
    {
        public string ReasonCodeGroupId { get; set; }
        public int CodeId { get; set; }
        public string CodeDesc { get; set; }
        public string DisplayName { get; set; }
        public int SequenceNo { get; set; }
    }
}
