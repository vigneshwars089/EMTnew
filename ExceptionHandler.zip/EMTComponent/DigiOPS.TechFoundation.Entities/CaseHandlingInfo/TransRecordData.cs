﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// TransRecordData class
    /// </summary>
    [Serializable]
    public class TransRecordData : BaseEntity
    {
        public int RecordId { get; set; }
        public byte byTransactionTypeId { get; set; }
        public int StatusId { get; set; }
        public Nullable<int> CoreTransStatusId { get; set; }
        public Nullable<int> CoreTransStatusReasonId { get; set; }
        public Nullable<int> PeerCheckerId { get; set; }
        public Nullable<int> SLACategoryId { get; set; }
        public string CoreTransStatusReason { get; set; }
        public string Comment { get; set; }
        public string ProcessedBy { get; set; }
        public int NoOfEmployee { get; set; }
        public int NoofLine { get; set; }

        public string ProcessedDate { get; set; }
        public string ReceivedDate { get; set; }

        public int SubProcessId { get; set; }
        public string ModifiedBy { get; set; }
        public List<TransElementData> TransElement { get; set; }
        public TransStatusData TransStatus { get; set; }

        public bool IsEdit { get; set; }
        public bool IsReset { get; set; }
        public int AuditId { get; set; }
        public string ViewType { get; set; }
        public string URL { get; set; }
    }
}
