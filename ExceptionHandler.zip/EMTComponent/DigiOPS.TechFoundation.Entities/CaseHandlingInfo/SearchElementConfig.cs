﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// Search Element Config class
    /// </summary>
    [Serializable]
    public class SearchElementConfig : BaseEntity
    {

        public int ElementId { get; set; }
        public string DisplayName { get; set; }
        public string ElementValue { get; set; }
        public string ElementTypeName { get; set; }
        public string DataTypeName { get; set; }
        public string DataTypes { get; set; }
        public string ElementLength { get; set; }
        public string CustomMessage { get; set; }
        public int StartRowIndex { get; set; }
        public int MaximumRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public int? TotalRows { get; set; }
        public int NoofLines { get; set; }
    }




}

