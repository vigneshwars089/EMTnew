﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;

namespace DigiOPS.TechFoundation.Entities
{
    [Serializable]
    public class TransList : BaseEntity
    {

        public string Key { get { return keyObject; } set { keyObject = value; } }
        public object Value { get { return valueObject; } set { valueObject = value; } }

        private string keyObject;
        private object valueObject;

        /// <summary>
        /// TransactionList constructor inherits from base class object
        /// </summary>
        public TransList() : base() { }
        /// <summary>
        /// TransactionList method loads key and value public variables
        /// </summary>
        /// <param name="key">string</param>
        /// <param name="value">object</param>
        public TransList(string key, object value)
        {
            keyObject = key;
            valueObject = value;
        }
    }
    /// <summary>
    /// TransactionListViewModal class
    /// </summary>

    public class TransactionListView : BaseEntity
    {
        public int SubProcessId { get; set; }
        public int RecordId { get; set; }
        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public string CustomMessage { get; set; }
        public string RecordIds { get; set; }

        /// <summary>
        /// TransactionListViewModal Constructor initializes TransactionList and
        /// AutoAllocationEntityConfig Entities
        /// </summary>
        public TransactionListView()
        {
            TransactionList = new List<TransList>();
            AutoAllocationEntityConfigmaster = new AutoAllocationConfig();
            CalibratorList = new List<CheckBoxList>();
        }
        public List<TransList> TransactionList { get; set; }
        public AutoAllocationConfig AutoAllocationEntityConfigmaster { get; set; }
        public List<CheckBoxList> CalibratorList { get; set; }
    }
    /// <summary>
    /// AutoAllocationEntityConfig  class
    /// </summary>
    [Serializable]
    public class AutoAllocationConfig : BaseEntity
    {
        public int AuditType { get; set; }
        public int ProgramID { get; set; }
        public int ProcessID { get; set; }
        public int SubProcessID { get; set; }
        public Nullable<DateTime> ProcessingDate { get; set; }
        public Nullable<DateTime> ProcessingToDate { get; set; }
        public string WorkFlowconfigAuditTypes { get; set; }
        public bool IsSamplingConfigured { get; set; }
        public bool IsAutoSamplingNeeded { get; set; }
        public bool IsBusiAutoSamplingNeeded { get; set; }
        public bool isExternalAutoAllocationSamplingNeeded { get; set; }
        public bool IsPushExternalAudit { get; set; }
        public bool IsPushExternalAuditAuto { get; set; }
        public int iIntAllocCnt { get; set; }
        public int iExtAllocCnt { get; set; }
        public int iBusiAllocCnt { get; set; }
        public int Total { get; set; }
        public int Sampling { get; set; }
        public int Allocated { get; set; }
        public int Pending { get; set; }

        public int Total_Statrified { get; set; }
        public int Sampling_Statrified { get; set; }
        public int Allocated_Statrified { get; set; }
        public int Pending_Statrified { get; set; }
        public bool isSupervisorAuditApplicable { get; set; }
        public string szSamplingType { get; set; }

        public int DirectExternalAllocated { get; set; }
        public int InternalAllocated { get; set; }
        public int DirectBusinessAllocated { get; set; }

        public DateTime AutoSampProcessingDate { get; set; }
        public string szAuditorName { get; set; }
        public int iNoofTransAllocated { get; set; }

        public string SamplingCalculationType { get; set; }
        public string SamplingPctCalculation { get; set; }

        /// <summary>
        /// AutoAllocationEntityConfig constructor
        /// </summary>
        public AutoAllocationConfig()
        {
            AutoSamplingLists = new List<AutoAllocationConfig>();
        }
        public List<AutoAllocationConfig> AutoSamplingLists { get; set; }
    }

    [Serializable]
    public class TransactionListViewList : BaseTransportEntity
    {
        public string CustomMessage { get; set; }
        public string ProcessedDate { get; set; }
        public string ReceivedDate { get; set; }
        public string ProcessingToDate { get; set; }
        public string SelectedAuditorId { get; set; }
        public string SelectedStatusId { get; set; }
        public string SelectedUserId { get; set; }
        public string SelectedAuditTypeId { get; set; }
        public int StartRowIndex { get; set; }
        public int MaximumRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public int? TotalRows { get; set; }
        public int AuditTypeId { get; set; }
        public string AuditType { get; set; }
        public string SelectedAssociateId { get; set; }
        public string SelectedCurrentStatusId { get; set; }
        public string SelectedAssociateName { get; set; }
        public string ReferenceValue { get; set; }
        public string ReasonValue { get; set; }
        public bool IsPeerToPeerReviewReq { get; set; }
        public bool IsSLACatrgoryReq { get; set; }
        public bool IsReferenceReq { get; set; }
        public bool IsLineReq { get; set; }
        public bool IsReasonReq { get; set; }
        public int SelectedPeerCheckerId { get; set; }
        public string SelectedPeerCheckerName { get; set; }
        public int SelectedSLACategoryId { get; set; }
        public string SelectedSLACategoryName { get; set; }
        public string SelectedReferenceId { get; set; }
        public string SelectedReferenceName { get; set; }
        public string SelectedReasonId { get; set; }
        public string SelectedReasonName { get; set; }
        public string ViewType { get; set; }
        public string Page { get; set; }
        public string URL { get; set; }
        public bool IsSubProcessSelected { get; set; }
        public string filename { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }

        /// <summary>
        /// TransactionListViewModalList constructor
        /// </summary>
        public TransactionListViewList()
        {
            TransactionLists = new List<TransactionListView>();
            AuditorList = new List<TransDropDown>();
            autoallocationlists = new AutoAllocationEntityConfig();
            SearchConfigList = new List<SearchElementConfig>();
            AssociateList = new List<TransDropDown>();
            CurrentStatusList = new List<TransDropDown>();
            ReferenceList = new List<TransReferenceConfig>();
            ReasonList = new List<TransReasonList>();
            PeerCheckerList = new List<TransDropDown>();
            SLAActivityList = new List<TransDropDown>();
            StatusList = new List<TransDropDown>();
            UsersList = new List<TransDropDown>();
            StatsSubProcessList = new StatisticalSamplingViewModel();
        }
        public List<TransactionListView> TransactionLists { get; set; }
        public List<SearchElementConfig> SearchConfigList { get; set; }
        public AutoAllocationEntityConfig autoallocationlists { get; set; }
        public List<TransDropDown> AuditorList { get; set; }
        public List<TransDropDown> AuditTypeList { get; set; }
        public List<TransDropDown> AssociateList { get; set; }
        public List<TransDropDown> CurrentStatusList { get; set; }
        public List<TransReferenceConfig> ReferenceList { get; set; }
        public List<TransReasonList> ReasonList { get; set; }
        public List<TransDropDown> PeerCheckerList { get; set; }
        public List<TransDropDown> SLAActivityList { get; set; }
        public List<TransDropDown> StatusList { get; set; }
        public List<TransDropDown> UsersList { get; set; }
        public StatisticalSamplingViewModel StatsSubProcessList { get; set; }
    }

}

