﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace DigiOPS.TechFoundation.DataTransfer
{
    /// <summary>
    /// XML Serialization Class
    /// </summary>
    [Serializable]
    public class entityXMLSerialization
    {
        /// <summary>
        /// Method to Convert the info to XML
        /// </summary>
        /// <returns>string</returns>
        public string ToXml()
        {
            StringWriter Output = new StringWriter(new StringBuilder());
            string Ret = string.Empty;
            try
            {
                XmlSerializer s = new XmlSerializer(this.GetType());
                s.Serialize(Output, this);
                Ret = Output.ToString().Replace("xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"", "");
                Ret = Ret.Replace("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"", "");
                Ret = Ret.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", "").Trim();
                Output.Close();
            }
            catch (ArgumentNullException ex)
            {
                throw ex;
            }
            catch (ArgumentException ex)
            {
                throw ex;
            }
            catch (XmlException ex)
            {
                throw ex;
            }
            catch (ApplicationException ex)
            {
                throw ex;
            }
            return Ret;
        }

    }
}
