﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// TransElementItemData class
    /// </summary>
    [Serializable]
    public class TransElementItemData : BaseEntity
    {
        public int ItemId { get; set; }
        public int CodeId { get; set; }
        public string ItemValue { get; set; }
        public int ElementId { get; set; }
        public int RecordElementId { get; set; }
        public string ModifiedBy { get; set; }
        public Guid GuidItemData { get; set; }
    }
}
