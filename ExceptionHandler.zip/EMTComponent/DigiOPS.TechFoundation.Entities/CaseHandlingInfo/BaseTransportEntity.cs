﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// BaseTransportEntity class
    /// </summary>
    [Serializable]
    public class BaseEntity : entityXMLSerialization
    {
        public string SessionId { get; set; }
        public int Id { get; set; }
        public int CurrentUserID { get; set; }
        public int CurrentUserRoleID { get; set; }
        public int _ProgramID { get; set; }
        public int _ProcessID { get; set; }
        public int _SubProcessID { get; set; }
        public string ViewName { get; set; }
        public string EntityName { get; set; }
        public string eventAction { get; set; }
        public string _ProcessedDate { get; set; }
        public string _ProcessedFromDate { get; set; }
        public string _ProcessedToDate { get; set; }
        public string _ReceivedDate { get; set; }
        public int iSubCategoryId { get; set; }
        public string ExtAuditTypeName { get; set; }
        public int _StartRowIndex { get; set; }
        public int _MaximumRows { get; set; }
        public string _SortOrder { get; set; }
        public string _SortColumn { get; set; }
        public int? _TotalRows { get; set; }
        public string ReturnValue { get; set; }
        public bool bIsEmpNeeded { get; set; }
        public bool bIsLineNeeded { get; set; }
        public int iSubcategory { get; set; }
        public bool bIsLineApplicable { get; set; }
        public bool IsPeerCheckerReq { get; set; }
        public bool bIsSLAActivityApplicable { get; set; }
        public bool IsReadonDDL { get; set; }
        public bool isBusiAutoAllocationSamplingRequired { get; set; }
        public bool isExternalAutoAllocationSamplingRequired { get; set; }
        public int _ElementCount { get; set; }
        public string NoofLineReuired { get; set; }


        public bool bIsExternalAudit { get; set; }
        public bool bIsExternalAuditAuto { get; set; }
        public int ReportID { get; set; }
        public int RatingDifferenceCount { get; set; }
    }
}
