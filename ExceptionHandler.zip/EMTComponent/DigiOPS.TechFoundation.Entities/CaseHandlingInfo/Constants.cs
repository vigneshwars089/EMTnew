﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;

namespace DigiOPS.TechFoundation.DataTransfe
{
    public class Constants
    {
        //#region Default constructor for readonly variables
            
        #region ENTITY_NAMES
        
        public const string ACTION_Delete = "DELETE";
        
        public const string EDIT = "EDIT";
        
        #endregion

        #region VARIABLE_NAMES

        //Session Variables
        public const string SYSUSERID = "SYSUSERID";
        public const string ROLEID = "RoleID";
        public const string PROGRAMID = "ProgramId";
        public const string PROCESSID = "ProcessId";
        public const string SUBPROCESSID = "SubProcessId";
        #endregion

        #region APPLICATION MESSAGES

        #region  TRANSACTION CREATION MESSAGES

        private static string mSG_TransactionCreation_MANUAL_CASE_CREATION_NOT_CONFIGURED = " Manual Case Creation is either not configured or not active for this " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";
        private static string mSG_TransactionCreation_DATAELEMENT_NOT_CONFIGURED = " DataElement(s) for the current role is either not configured or not active for the " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";
        private static string mSG_TransactionCreation_CORESTATUS_NOT_CONFIGURED = RenameText("clientConfigKeyLbl-corestatus-core") + " Status is either not configured or not active for the " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";
        private static string mSG_TransactionCreation_CORESTATUSREASON_NOT_CONFIGURED = RenameText("clientConfigKeyLbl-corestatus-Status") + " Reason(s) is either not configured or not active for the status in the " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";
        private static string mSG_TransactionCreation_AUDITCONFIGURATION_NOT_CONFIGURED = " " + RenameText("clientConfigKeyLbl-audit-audit") + " Configuration is either not configured or not active for this " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";



        public static string MSG_TransactionCreation_MANUAL_CASE_CREATION_NOT_CONFIGURED { get { return mSG_TransactionCreation_MANUAL_CASE_CREATION_NOT_CONFIGURED; } set { value = mSG_TransactionCreation_MANUAL_CASE_CREATION_NOT_CONFIGURED; } }
        public static string MSG_TransactionCreation_DATAELEMENT_NOT_CONFIGURED { get { return mSG_TransactionCreation_DATAELEMENT_NOT_CONFIGURED; } set { value = mSG_TransactionCreation_DATAELEMENT_NOT_CONFIGURED; } }
        public static string MSG_TransactionCreation_CORESTATUS_NOT_CONFIGURED { get { return mSG_TransactionCreation_CORESTATUS_NOT_CONFIGURED; } set { value = mSG_TransactionCreation_CORESTATUS_NOT_CONFIGURED; } }
        public static string MSG_TransactionCreation_CORESTATUSREASON_NOT_CONFIGURED { get { return mSG_TransactionCreation_CORESTATUSREASON_NOT_CONFIGURED; } set { value = mSG_TransactionCreation_CORESTATUSREASON_NOT_CONFIGURED; } }
        public static string MSG_TransactionCreation_AUDITCONFIGURATION_NOT_CONFIGURED { get { return mSG_TransactionCreation_AUDITCONFIGURATION_NOT_CONFIGURED; } set { value = mSG_TransactionCreation_AUDITCONFIGURATION_NOT_CONFIGURED; } }



        private static string mSG_TransactionCreation_DATAELEMENT_CONFIGURATION_INCOMPLETE = " DataElement Configuration is incomplete (Data's missing for List) for the " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";
        private static string mSG_TransactionCreation_WORKFLOW_CONFIGURATION_INCOMPLETE = "Workflow Configuration is not configured for the " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";
        private static string mSG_TransactionCreation_PEER_CHECKER_INCOMPLETE = "Peer Checker is either not configured or not active - Map more than one Associate in user role mapping\n";
        private static string mSG_TransactionCreation_SLACATEGORY_INCOMPLETE = "Consolidated SLA (Category) is either not configured or not active for the " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";

        private static string mSG_TransactionCreation_CreatedSuccessfully = "Transaction Created Successfully!";
        private static string mSG_TransactionCreation_CreatedFailed = "Transaction Creation Failed ";
        private static string mSG_TransactionCreation_ALREADY_EXISTS = "Transaction Already Exists";
        private static string mSG_TransactionCreation_UpdatedSuccessfully = "Transaction Updated Successfully!";
        private static string mSG_TransactionCreation_UpdationFailed = "Transaction Updation Failed!";
        private static string mSG_TransactionCreation_UpdationFailed_Retry = "Transaction Updation Failed. Please try again!";
        private static string mSG_TransactionCreation_NotExists = "Transaction Not Exists";
        private static string mSG_TransactionCreation_DeletedSuccessfully = "Transaction Deleted Successfully!";
        private static string mSG_TransactionCreation_DeletionFailed = "Transaction Deletion Failed!";



        public static string MSG_TransactionCreation_DATAELEMENT_CONFIGURATION_INCOMPLETE { get { return mSG_TransactionCreation_DATAELEMENT_CONFIGURATION_INCOMPLETE; } set { value = mSG_TransactionCreation_DATAELEMENT_CONFIGURATION_INCOMPLETE; } }
        public static string MSG_TransactionCreation_WORKFLOW_CONFIGURATION_INCOMPLETE { get { return mSG_TransactionCreation_WORKFLOW_CONFIGURATION_INCOMPLETE; } set { value = mSG_TransactionCreation_WORKFLOW_CONFIGURATION_INCOMPLETE; } }
        public static string MSG_TransactionCreation_PEER_CHECKER_INCOMPLETE { get { return mSG_TransactionCreation_PEER_CHECKER_INCOMPLETE; } set { value = mSG_TransactionCreation_PEER_CHECKER_INCOMPLETE; } }
        public static string MSG_TransactionCreation_SLACATEGORY_INCOMPLETE { get { return mSG_TransactionCreation_SLACATEGORY_INCOMPLETE; } set { value = mSG_TransactionCreation_SLACATEGORY_INCOMPLETE; } }

        public static string MSG_TransactionCreation_CreatedSuccessfully { get { return mSG_TransactionCreation_CreatedSuccessfully; } set { value = mSG_TransactionCreation_CreatedSuccessfully; } }
        public static string MSG_TransactionCreation_CreatedFailed { get { return mSG_TransactionCreation_CreatedFailed; } set { value = mSG_TransactionCreation_CreatedFailed; } }
        public static string MSG_TransactionCreation_ALREADY_EXISTS { get { return mSG_TransactionCreation_ALREADY_EXISTS; } set { value = mSG_TransactionCreation_ALREADY_EXISTS; } }
        public static string MSG_TransactionCreation_UpdatedSuccessfully { get { return mSG_TransactionCreation_UpdatedSuccessfully; } set { value = mSG_TransactionCreation_UpdatedSuccessfully; } }
        public static string MSG_TransactionCreation_UpdationFailed { get { return mSG_TransactionCreation_UpdationFailed; } set { value = mSG_TransactionCreation_UpdationFailed; } }
        public static string MSG_TransactionCreation_UpdationFailed_Retry { get { return mSG_TransactionCreation_UpdationFailed_Retry; } set { value = mSG_TransactionCreation_UpdationFailed_Retry; } }
        public static string MSG_TransactionCreation_NotExists { get { return mSG_TransactionCreation_NotExists; } set { value = mSG_TransactionCreation_NotExists; } }
        public static string MSG_TransactionCreation_DeletedSuccessfully { get { return mSG_TransactionCreation_DeletedSuccessfully; } set { value = mSG_TransactionCreation_DeletedSuccessfully; } }
        public static string MSG_TransactionCreation_DeletionFailed { get { return mSG_TransactionCreation_DeletionFailed; } set { value = mSG_TransactionCreation_DeletionFailed; } }

        #endregion

        #endregion

        #region sp_Return_values

        public const string SUCCESS = "1";
        public const string ALREADYEXISTS = "2";
        public const string FAILURE = "3";
        public const string MAILFAILURE = "-1";
        public const string USER_NOT_EXISTS = "4";
        public const string USER_EXISTS_BUT_NOT_ACTIVE = "5";
        public const string REACTIVATED = "5";
        public const string CREATENEW = "4";
        public const string CHECK_ON_EFFECTIVETODT = "6";
        public const string REACTIVATED_USERCONFIG = "6";
        public const string DEACTIVATED = "7";
        public const string CANNOT_MODIFY_DIRECT_EXTERNAL = "8";
        public const string CANNOT_MODIFY_DIRECT_BUSINESS = "9";
        public const string CANNOT_MODIFY_DIRECT_SUPERVISOR = "10";
        public const string USERGROUP_EFFECTIVETODT = "10";
        public const string PROCESS_EFFECTIVETODT = "11";
        public const string PROGRAMFEATURES_NOT_EXISTS = "12";
        public const string FAILURE_RETRY_MSG = "13";
        public const string ALLOCATEDWITH_ALREADYALLOCATED = "14";
        public const string CATEGORY_CANNOT_DELETE = "15";
        public const string CTQGROUP_CANNOT_DELETE = "15";
        public const string SUBPROCESS_EXIST = "16";
        public const string CANNOT_DELETE_ALREADYAUDITED = "17";
        public const string GROUPEXIST = "20";
        public const string DEFAULTVALUE = "21";
        #endregion

        #region sp_Return_values_TRANSACTION_CREATION
        public const string MANUAL_CASE_CREATION_CHECK = "-1";
        public const string DATA_ELEMENT_CHECK = "-2";
        public const string CORE_STATUS_CHECK = "-3";
        public const string CORE_STATUS_REASON_CHECK = "-4";
        public const string AUDIT_CONFIG_CHECK = "-5";
        public const string DATA_ELEMENT_INCOMPLETE_CHECK = "-6";
        public const string WORKFLOW_INCOMPLETE_CHECK = "-7";
        public const string PEERCHECKERNOTENABLED = "-8";
        public const string SLACATEGORYNOTENABLED = "-9";

        #endregion

        #region Pagination and Sorting

        public const string PAGESIZE = "PageSize";
        public const int DEFAULT_MAXIMUMROWS = 0;
        public const int DEFAULT_STARTROWINDEX = 1;
        public const string DEFAULT_ORDERBY = "DESC";
        public const string DEFAULT_SORTCOLUMN_CORESTATUSREASON = "iCodeId";
        public const string DEFAULT_SORTCOLUMN_CORESTATUS = "iCoreTransStatusId";
        public const string DEFAULT_SORTCOLUMN_HOLIDAY = "iHolidayId";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_CATEGORY = "ADM.[iDOId]";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_HEADING = "Headinglist.[iDOId]";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_CTQGroup = "ADG.iDOGroupId";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_WeightageConfig = "ADG.iDOGroupId";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_CHECKPOINT = "Checkpointlist.[iDOId]";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_SUBDEFECT1 = "SUBLIST.iSubDOId";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_GROUPMAP = "iDOGroupMapId";
        public const string DEFAULT_SORTCOLUMN_RECORDID = "Record ID";
        public const string DEFAULT_SORTCOLUMN_UserGroupRoleMapId = "iUserGroupRoleMapId";
        public const string DEFAULT_SORTCOLUMN_PermissionMappingId = "iRolePermissionMappingId";
        public const string DEFAULT_SORTCOLUMN_iSystemUserId = "iSystemUserId";
        public const string DEFAULT_SORTCOLUMN_iUserGroupId = "iUserGroupId";
        public const string DEFAULT_SORTCOLUMN_iUserGroupMapId = "iUserGroupMapId";
        public const string DEFAULT_SORTCOLUMN_iUserAdminMappingId = "iUserAdminMappingId";


        #endregion     

        #region PARAMETERS     

        public const string PAR_iReturnValue = "@iReturnValue";
        public const string PAR_xmlParam = "@XMLParam";

      

        #endregion

        public static string RenameText(string txtToBeRenamed)
        {
            string replaceText = string.Empty;
            string[] arr = txtToBeRenamed.Split('-');

            if (arr != null)
            {
                if (arr.Length != 0)
                {
                    if (arr[0] == "clientConfigKeyLbl")
                    {

                        string XmlSettingPath = null;// ConfigurationManager.AppSettings["RenameConfig"];
                        XElement root = XElement.Load(System.Web.HttpContext.Current.Server.MapPath(XmlSettingPath));

                        string ProgramId = string.Empty;
                        if (HttpContext.Current.Session["ProgramId"] != null)
                        {
                            ProgramId = HttpContext.Current.Session["ProgramId"].ToString();
                        }

                        var allroot1 =
                       from e in root.Elements("Program")

                       where ((string)e.Attribute("id") == ProgramId)
                       select e;


                        var allroot =
                        from e in allroot1.Elements()
                        where ((string)e.Attribute("id") == arr[1].ToString())

                        select e;
                        var ElementCount = allroot.Count();
                        for (int i = 0; i < ElementCount; i++)
                        {
                            if (ElementCount != 0)
                            {
                                replaceText = allroot.ElementAt(i).Element(arr[2].ToString()).Value;
                            }
                        }
                    }
                }
            }
            return replaceText;
        }

    }
}

