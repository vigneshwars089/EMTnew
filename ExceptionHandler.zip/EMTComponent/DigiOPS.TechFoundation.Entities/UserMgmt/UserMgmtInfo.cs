﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class UserMgmtInfo : BaseInfo
    {
        //public string AppName { get; set; }
        //public string ResultMessage { get; set; }
        public List<UserInfo> UserList { get; set; }
        public List<UserInfo> UserGroupList { get; set; }
        public DataTable dtlist { get; set; }
    }
}

