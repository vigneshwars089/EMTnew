﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
   public class ExchangeConstants
    {
      
        #region MAIL_SP_PARAMETER
        public const string SP_PARAMETER_CASEID = "@CaseId";
        public const string SP_PARAMETER_RECEIVED_DATE = "@Received_date";
        public const string SP_PARAMETER_MAILFOLDER_ID = "@MailFolder_Id";
        public const string SP_PARAMETER_STATUS_ID = "@Status_Id";
        public const string SP_PARAMETER_SUBJECT = "@Subject";
        public const string SP_PARAMETER_MESSAGE = "@Message";
        public const string SP_PARAMETER_FROMADD = "@From_Add";
        public const string SP_PARAMETER_TOADD = "@Toaddress";
        public const string SP_PARAMETER_CCADD = "@CCaddress";
        public const string SP_PARAMETER_BCCADD = "@BCCaddress";
        public const string SP_PARAMETER_PRIORITY = "@Priority";  
        #endregion MAIL_SP_PARAMETER
             

        #region CONNECTION_PATH
        public const string CONNECTION_STRING = "connection";
        #endregion CONNECTION_PATH

        #region GENERAL
             
        public const string STAR = "***************************************************************************************************************************";
        public const string NEW_LINE = "\r\n";

        #endregion GENERAL
        
    }
}
