﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
   public class DataelementAutomatedAuditEntity
    {
       public int ElementId { get; set; }
       public string ElementData { get; set; }
       public string TransactionSource { get; set; }
       public int RecordId { get; set; }      

   }
}
