﻿//using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class ServiceOutput : BaseInfo
    {
        public int ElementId{get;set;}
        public int RecordID { get; set; }
        public string ExpectedValue { get; set; }
        public string ActualValue { get; set; }
        public Boolean IsOverride { get; set; }
        public string OCRConfidencetiality { get; set; }
        public string Comments { get; set; }
        public int CreatedBy { get; set; }
        public int ModifiedBy { get; set; }
        public int AuditStatusId { get; set; }
        public string Description { get; set; }
       
    }
}
