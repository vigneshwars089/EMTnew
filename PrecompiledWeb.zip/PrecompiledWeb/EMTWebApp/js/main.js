/// <reference path="../Common/DashBoard.aspx" />
/// <reference path="../Common/DashBoard.aspx" />
/// <reference path="../Common/content/PieChart.aspx" />
//var tempArray = [];
//var collapsableMenuString = "";
//var firstLevel = [];
//var secondLevel = [];
var countryName;
var mailBoxName;
var subProcessName;
var statusName;
var pgindex;
var pageSize;
var pageCount;
var sortExpName = 'ReceivedDate';
var sortExpOrder = 'desc';

var SelectedProcess;
var Selected
var fnameValue;
var roleName;
var roleID;
var UID;
var selectedMenuItem;
var selectedMenuText;

$("document").ready(function () {

    //setInterval('AutoRefresh();', 10000); // refresh div after 15 secs

    //debugger;		
    //var sPageURL = window.location.search.substring(1);		
    //var sQueryString=sPageURL.split('=');		
    selectedMenuItem = getUrlVars()["selectedMenu"];		
    selectedMenuText = getUrlVars()["SelectionText"];		
    if (selectedMenuText != null && selectedMenuText != undefined && selectedMenuText != '') {		
        var sQueryString = selectedMenuText.split('~');		
        countryName = sQueryString[0];		
        mailBoxName = sQueryString[2];		
        subProcessName = sQueryString[1];		
        statusName = sQueryString[3];
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
    }		
    //if (selectedMenuItem != null && selectedMenuItem != undefined && selectedMenuItem != '') {		
    //}

    AutoRefresh();

    //var selectUserID;
    //var webmethod = "../EMTSrv.asmx/EmailboxNames";
    //if (UID == undefined || UID == null) {
    //    UID = $('#UID').prop('value');//$('#fname').prop();
    //    roleID = $('#roleID').prop('value');

    //    if (roleID == 4) {
    //        selectUserID = UID;
    //    }
    //    else {
    //        selectUserID = 0;
    //    }

    //}
    //var params = { CountryId: 1, LoggedInUserId: UID, RoleId: roleID, SelectedAssociateId: selectUserID, SelectedSubProcessId: '0' };
    //$.ajax({
    //    type: "POST",
    //    url: webmethod,
    //    data: JSON.stringify(params),
    //    contentType: "application/json; charset=utf-8",
    //    dataType: "json",
    //    async: false,
    //    success: function (resultData) {
    //        var collapsbleMenu = resultData.d;
    //        traverseCollapsibleList(jQuery.parseJSON(collapsbleMenu));
    //    },
    //    error: function (error) {
    //        var data = error;
    //    }
    //});

    //debugger;

    if (fnameValue == undefined || fnameValue == null) {
        fnameValue = $('#fname').prop('value');//$('#fname').prop();
        roleName = $('#role').prop('value');//$('#role').val();

        if (roleName == "Team Lead") {
            roleName = "[TL]";
        }
        else if (roleName == "Admin") {
            roleName = "[A]";
        }
        else if (roleName == "Super Admin") {
            roleName = "[SA]";
        }
        else if (roleName == "Processor") {
            roleName = "[P]";
        }
        else if (roleName == "Client User") {
            roleName = "[CU]";
        }
    }
    ///   alert(fname);
    $('#Span1').text(fnameValue + " " + roleName);

    //creating top navigation links
    var navItems;

    if (roleName == "[SA]") {
        navItems = [{
            "parent": "Dashboard",
            "url": "../Common/DashBoard.aspx",
            "child": []
        }, {
            "parent": "User Management",
            "url": "../Common/DashBoard.aspx",
            "child": [{
                "title": "Create User",
                "url": "../UserManagement/CreateUser.aspx"
            }, {
                "title": "User Role Mapping",
                "url": "../UserManagement/UserMapping.aspx"
            }, {
                "title": "User Mailbox Mapping",
                "url": "../UserManagement/UserMailBoxMapping.aspx"
            }, {
                "title": "Change Password",
                "url": "../UserManagement/ChangePassword.aspx"
            }]
        }, {
            "parent": "Configuration",
            "url": "../Common/DashBoard.aspx",
            "child": [{
                "title": "Mail Template Configuration",
                "url": "../UserManagement/Remaindermailboxconfigure.aspx"
            }, {
                "title": "Category Configuration",
                "url": "../UserManagement/CategoryConfiguration.aspx"
            }, {
                "title": "Field Configuration",
                "url": "../UserManagement/FieldConfiguration.aspx"
            }]
        }, {
            "parent": "Client Configuration",
            "url": "../Common/DashBoard.aspx",
            "child": [{
                "title": "SubProcess",
                "url": "../Configuration/SubProcess.aspx"
            }, {
                "title": "Mailbox Login Details",
                "url": "../UserManagement/EMailBoxLoginDetails.aspx"
            }, {
                "title": "Mailbox",
                "url": "../Configuration/MailBoxCreation.aspx"
            }]
        },
        {
            "parent": "Search",
            "url": "../Search/Search.aspx",
            "child": []
        }, {
            "parent": "Reports",
            "url": "../Common/DashBoard.aspx",
            "child": [{
                "title": "TAT",
                "url": "../Reports/TATSplitUp.aspx?ReportType=1"
            }, {
                "title": "TAT SplitUp",
                "url": "../Reports/TATSplitUp.aspx?ReportType=2"
            }, {
                "title": "Ageing",
                "url": "../Reports/Ageing.aspx"
            }, {
                "title": "Productivity",
                "url": "../Reports/TATSplitUp.aspx?ReportType=3"
            }, {
                "title": "OverAll",
                "url": "../Reports/TATSplitUp.aspx?ReportType=4"
            }, {
                "title": "Clarification Sent",
                "url": "../Reports/TATSplitUp.aspx?ReportType=5"
            }, {
                "title": "Clarification with Ageing",
                "url": "../Reports/TATSplitUp.aspx?ReportType=6"
            }
            ]
        }, {
            "parent": "Change Role",
            "url": "../AuthenticationandAuthorization/ChooseRole.aspx",
            "child": []
        }];
    }
    else if (roleName == "[A]") {
        navItems = [{
            "parent": "Dashboard",
            "url": "../Common/DashBoard.aspx",
            "child": []
        }, {
            "parent": "User Management",
            "url": "../Common/DashBoard.aspx",
            "child": [{
                "title": "Create User",
                "url": "../UserManagement/CreateUser.aspx"
            }, {
                "title": "User Role Mapping",
                "url": "../UserManagement/UserMapping.aspx"
            }, {
                "title": "User Mailbox Mapping",
                "url": "../UserManagement/UserMailBoxMapping.aspx"
            }, {
                "title": "Change Password",
                "url": "../UserManagement/ChangePassword.aspx"
            }]
        }, {
            "parent": "Configuration",
            "url": "../Common/DashBoard.aspx",
            "child": [{
                "title": "Mail Template Configuration",
                "url": "../UserManagement/Remaindermailboxconfigure.aspx"
            }, {
                "title": "Category Configuration",
                "url": "../UserManagement/CategoryConfiguration.aspx"
            }, {
                "title": "Field Configuration",
                "url": "../UserManagement/FieldConfiguration.aspx"
            }]
        },
        {
            "parent": "Search",
            "url": "../Search/Search.aspx",
            "child": []
        }, {
            "parent": "Reports",
            "url": "../Common/DashBoard.aspx",
            "child": [{
                "title": "TAT",
                "url": "../Reports/TATSplitUp.aspx?ReportType=1"
            }, {
                "title": "TAT SplitUp",
                "url": "../Reports/TATSplitUp.aspx?ReportType=2"
            }, {
                "title": "Ageing",
                "url": "../Reports/Ageing.aspx"
            }, {
                "title": "Productivity",
                "url": "../Reports/TATSplitUp.aspx?ReportType=3"
            }, {
                "title": "OverAll",
                "url": "../Reports/TATSplitUp.aspx?ReportType=4"
            }, {
                "title": "Clarification Sent",
                "url": "../Reports/TATSplitUp.aspx?ReportType=5"
            }, {
                "title": "Clarification with Ageing",
                "url": "../Reports/TATSplitUp.aspx?ReportType=6"
            }
            ]
        }, {
            "parent": "Change Role",
            "url": "../AuthenticationandAuthorization/ChooseRole.aspx",
            "child": []
        }];
    }
    else if (roleName == "[TL]") {
        navItems = [{
            "parent": "Dashboard",
            "url": "../Common/DashBoard.aspx",
            "child": []
        }, {
            "parent": "User Management",
            "url": "../Common/DashBoard.aspx",
            "child": [{
                "title": "Create User",
                "url": "../UserManagement/CreateUser.aspx"
            }, {
                "title": "User Role Mapping",
                "url": "../UserManagement/UserMapping.aspx"
            }, {
                "title": "User Mailbox Mapping",
                "url": "../UserManagement/UserMailBoxMapping.aspx"
            }, {
                "title": "Change Password",
                "url": "../UserManagement/ChangePassword.aspx"
            }, {
                "title": "Change Signature",
                "url": "../UserManagement/Signature.aspx"
            }]
        }, {
            "parent": "Manual Case Creation",
            "url": "../Common/ManualCaseCreation.aspx",
            "child": []
        }, {
            "parent": "Quality Check",
            "url": "../Common/QCWorkQueue.aspx",
            "child": []
        },
        {
            "parent": "Search",
            "url": "../Search/Search.aspx",
            "child": []
        }, {
            "parent": "Reports",
            "url": "../Common/DashBoard.aspx",
            "child": [{
                "title": "TAT",
                "url": "../Reports/TATSplitUp.aspx?ReportType=1"
            }, {
                "title": "TAT SplitUp",
                "url": "../Reports/TATSplitUp.aspx?ReportType=2"
            }, {
                "title": "Ageing",
                "url": "../Reports/Ageing.aspx"
            }, {
                "title": "Productivity",
                "url": "../Reports/TATSplitUp.aspx?ReportType=3"
            }, {
                "title": "OverAll",
                "url": "../Reports/TATSplitUp.aspx?ReportType=4"
            }, {
                "title": "Clarification Sent",
                "url": "../Reports/TATSplitUp.aspx?ReportType=5"
            }, {
                "title": "Clarification with Ageing",
                "url": "../Reports/TATSplitUp.aspx?ReportType=6"
            }
            ]
        }, {
            "parent": "Change Role",
            "url": "../AuthenticationandAuthorization/ChooseRole.aspx",
            "child": []
        }];
    }
    else if (roleName == "[P]") {
        navItems = [{
            "parent": "Dashboard",
            "url": "../Common/DashBoard.aspx",
            "child": []
        }, {
            "parent": "Manual Case Creation",
            "url": "../Common/ManualCaseCreation.aspx",
            "child": []
        }, {
            "parent": "Quality Check",
            "url": "../Common/QCWorkQueue.aspx",
            "child": []
        }, {
            "parent": "User Management",
            "url": "../Common/DashBoard.aspx",
            "child": [{
                "title": "Change Password",
                "url": "../UserManagement/ChangePassword.aspx"
            }, {
                "title": "Change Signature",
                "url": "../UserManagement/Signature.aspx"
            }]
        },
        {
            "parent": "Search",
            "url": "../Search/Search.aspx",
            "child": []
        }, {
            "parent": "Change Role",
            "url": "../AuthenticationandAuthorization/ChooseRole.aspx",
            "child": []
        }];
    }
    else if (roleName == "[CU]") {
        navItems = [{
            "parent": "Dashboard",
            "url": "../Common/DashBoard.aspx",
            "child": []
        }, {
            "parent": "User Management",
            "url": "../Common/DashBoard.aspx",
            "child": [{
                "title": "Change Password",
                "url": "../UserManagement/ChangePassword.aspx"
            }]
        },
        {
            "parent": "Search",
            "url": "../Search/Search.aspx",
            "child": []
        }, {
            "parent": "Reports",
            "url": "../Common/DashBoard.aspx",
            "child": [{
                "title": "TAT",
                "url": "../Reports/TATSplitUp.aspx?ReportType=1"
            }, {
                "title": "TAT SplitUp",
                "url": "../Reports/TATSplitUp.aspx?ReportType=2"
            }, {
                "title": "Ageing",
                "url": "../Reports/Ageing.aspx"
            }, {
                "title": "Productivity",
                "url": "../Reports/TATSplitUp.aspx?ReportType=3"
            }, {
                "title": "OverAll",
                "url": "../Reports/TATSplitUp.aspx?ReportType=4"
            }, {
                "title": "Clarification Sent",
                "url": "../Reports/TATSplitUp.aspx?ReportType=5"
            }, {
                "title": "Clarification with Ageing",
                "url": "../Reports/TATSplitUp.aspx?ReportType=6"
            }
            ]
        }, {
            "parent": "Change Role",
            "url": "../AuthenticationandAuthorization/ChooseRole.aspx",
            "child": []
        }];
    }
    //alert(fname);
    createTopNavPanel(navItems);

    function createTopNavPanel(navJson) {
        var nav = $("#nav");
        $.each(navJson, function (index, element) {
            if (element.child.length > 0) {
                if (element.url != "") {
                    nav.append('<li class="pNav" id="p_nav_' + index + '" ><a class="clkpNav" id="ap_nav_' + index + '" href = "' + element.url + '">' + element.parent + '</a><ul class="pUL" id="p_UL_' + index + '">');
                }
                else {
                    nav.append('<li class="pNav" id="p_nav_' + index + '" ><a class="clkpNav" id="ap_nav_' + index + '" href = "javascript:void(0);">' + element.parent + '</a><ul class="pUL" id="p_UL_' + index + '">');
                }
                var parent = $("#p_UL_" + index);
                $.each(element.child, function (idx, childEle) {
                    parent.append('<li class="cNav" id="c_nav_' + index + '_' + idx + '" ><a class="clkcNav" id="ac_nav_' + index + '_' + idx + '"  href="' + childEle.url + '">' + childEle.title + '</a></li>');
                });
                nav.append('</ul></li>');
            } else {
                if (element.url != "") {
                    nav.append('<li class="pNav" id="p_nav_' + index + '" ><a class="clkpNav" id="ap_nav_' + index + '" href = "' + element.url + '">' + element.parent + '</a>');
                }
                else {
                    nav.append('<li class="pNav" id="p_nav_' + index + '" ><a class="clkpNav" id="ap_nav_' + index + '">' + element.parent + '</a>');
                }
            }
        });
        if (roleName == "[A]") {
            $('#ap_nav_3').css('background', 'url("../img/search_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_4').css('background', 'url("../img/report_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_5').css('background', 'url("../img/change_role_icon.png") no-repeat scroll 10px center transparent');
        }
        else if (roleName == "[P]") {

            $('#ap_nav_1').css('background', 'url("../img/config_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_2').css('background', 'url("../img/client_config.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_3').css('background', 'url("../img/user_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_4').css('background', 'url("../img/search_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_5').css('background', 'url("../img/change_role_icon.png") no-repeat scroll 10px center transparent');
        }
        else if (roleName == "[CU]") {
            $('#ap_nav_2').css('background', 'url("../img/search_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_3').css('background', 'url("../img/report_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_4').css('background', 'url("../img/change_role_icon.png") no-repeat scroll 10px center transparent')
        }
    }

    countryName = $('#c_ap_nav_0').text();
    //$("#aside").load("./content/piechart.html");
    //$("#aside").load("./content/PieChart.aspx");
     if (sQueryString != '' && sQueryString != undefined && sQueryString != null) {
         $('#frameMain').attr('src', './content/Inbox.aspx');
     }
     else {
         $('#frameMain').attr('src', './content/PieChart.aspx');
     }
    $("#ap_nav_0").addClass("selected");

    /*top Nav ele events*/
    $(".clkpNav").click(function () {
        if ($(this).hasClass("selected")) {
            // return false;
        }
        if ($(this).attr("id") === "ap_nav_0") {
            //$("#aside").load("./content/piechart.html");
            //$("#aside").load("./content/PieChart.aspx");
            $('#frameMain').attr('src', './content/PieChart.aspx');
            $("#collapsableNav,#aside").show();
            $("#underConstruction").hide();

        } else {
            $("#collapsableNav,#aside").hide();
            $("#underConstruction").show();
        }

        $(".clkpNav").removeClass("selected");
        $(this).addClass("selected");
    });

    //$("#changeRole").click(function () {
    //    $("#collapsableNav,#aside,#underConstruction").hide();
    //    $("#chooseRole").load("./content/chooseRole.html");
    //    $("#chooseRole").show();
    //});
    /*top Nav ele events*/

    //LeftMenuClicks();


    /*collapsable ele events*/
    $(".firstLevela").click(function () {
        countryName = $(this).text();
        mailBoxName = '';
        subProcessName = '';
        statusName = '';
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
        //$("#aside").load("./content/piechart.html");
        //$("#aside").load("./content/PieChart.aspx");
        $('#frameMain').attr('src', './content/PieChart.aspx');
        if ($(this).hasClass("selected")) {
            $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");
            $(this).next("ul").hide();
            $(".secondLevelul,.thirdLevelul,.fourthLevelul").hide();
            return false;
        }
        $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");
        $(this).addClass("selected");
        $(this).parent("li").addClass("selected");
        $(".secondLevelul,.thirdLevelul,.fourthLevelul").hide();
        $(this).next("ul").show();



    });

    $(".secondLevela").click(function () {
        subProcessName = $(this).text();
        mailBoxName = '';
        statusName = '';
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
        //$("#aside").load("./content/piechart.html");
        //$("#aside").load("./content/PieChart.aspx");
        $('#frameMain').attr('src', './content/PieChart.aspx');
        //alert("test")
        if ($(this).hasClass("selected")) {
            $(".secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");
            $(".thirdLevelul,.fourthLevelul").hide();
            return false;
        }
        $(".secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");
        $(this).addClass("selected");
        $(this).parent("li").addClass("selected");
        $(".thirdLevelul,.fourthLevelul").hide();
        $(this).next("ul").show();



    });

    $(".thirdLevela").click(function () {
        //debugger;
        if ($(this).hasClass("selected")) {
            $(".thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");
            $(".fourthLevelul").hide()
            return false;
        }

        mailBoxName = $(this).text();
        //statusName = 'open';
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
        $(".thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");
        $(this).addClass("selected");
        $(this).parent("li").addClass("selected");
        $(".fourthLevelul").hide();
        $(this).next("ul").show();

    });

    $(".fourthLevela").click(function () {
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
        if ($(this).hasClass("selected")) {
            $(".fourthLevela,.fourthLevelli").removeClass("selected");
            return false;
        }
        $(".fourthLevela,.fourthLevelli").removeClass("selected");
        $(this).addClass("selected");
        $(this).parent("li").addClass("selected");
        selectedMenuItem = $(this).attr('id');
    });

    /*collapsable ele events*/

    /*tempreedirecting Events*/
    $("a.firstLevela").click(function () {
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
        $(".dashBoardLabel").show();
        $("#underConstruction,.pagelevelLinks").hide();
        $("#parentNode").html($(this).text());
        resizeTreeScroll($("#collapsableNav"));
        statusName = 'open';
        selectedMenuItem = $(this).attr('id');
    });

    $("a.secondLevela").click(function () {
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
        $(".dashBoardLabel").show();
        $("#underConstruction,.pagelevelLinks").hide();
        $("#parentNode").html($(this).text());
        resizeTreeScroll($("#collapsableNav"));
        statusName = 'open';
        selectedMenuItem = $(this).attr('id');
    });

    $("a.thirdLevela").click(function () {
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
        $(".pagelevelLinks").show();
        $("#underConstruction,.dashBoardLabel").hide();

        if (typeof document.getElementById('frameMain').contentWindow.OnLeftMenuChange === 'function') {
            document.getElementById('frameMain').contentWindow.OnLeftMenuChange();
        }
        else {

            $('#frameMain').attr('src', './content/Inbox.aspx');
        }

        $("#childNode").html($(this).text());
        resizeTreeScroll($("#collapsableNav"));
        statusName = 'open';
        selectedMenuItem = $(this).attr('id');
    });

    $("a.fourthLevela").click(function () {
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
        $("#underConstruction,.dashBoardLabel").hide();
        if (typeof document.getElementById('frameMain').contentWindow.OnLeftMenuChange === 'function') {
            document.getElementById('frameMain').contentWindow.OnLeftMenuChange();
        }
        else {
            $('#frameMain').attr('src', './content/Inbox.aspx');
        }
        resizeTreeScroll($("#collapsableNav"));
        selectedMenuItem = $(this).attr('id');

    });



    $("#parentNode").click(function () {
        $("#c_ap_nav_0").removeClass("selected");
    });
    $("#childNode").click(function () {
        $("#c_ac_nav_0_0").removeClass("selected");
    });
    /*tempreedirecting Events*/

    function getstatusName(val_Status) {
        statusName = val_Status;
        selectedMenuItem = $(this).attr('id');
    }

});

function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

function AutoRefresh() {
    var selectUserID;
    var webmethod = "../EMTSrv.asmx/EmailboxNames";
    if (UID == undefined || UID == null) {
        UID = $('#UID').prop('value');//$('#fname').prop();
        roleID = $('#roleID').prop('value');
    }

    if (roleID == 4) {
        selectUserID = UID;
    }
    else {
        selectUserID = 0;
    }


    if (selectedMenuItem == null) {
        var params = { CountryId: 1, LoggedInUserId: UID, RoleId: roleID, SelectedAssociateId: selectUserID, SelectedSubProcessId: '0' };
        $.ajax({
            type: "POST",
            url: webmethod,
            data: JSON.stringify(params),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (resultData) {
                var collapsbleMenu = resultData.d;
                traverseCollapsibleList(jQuery.parseJSON(collapsbleMenu));
            },
            error: function (error) {
                var data = error;
            }
        });
    }
    else {

        if (selectedMenuItem.split('_').length - 1 >= 5) {
            var params = { CountryId: 1, LoggedInUserId: UID, RoleId: roleID, SelectedAssociateId: selectUserID, SelectedSubProcessId: '0' };
            $.ajax({
                type: "POST",
                url: webmethod,
                data: JSON.stringify(params),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                async: false,
                success: function (resultData) {
                    var collapsbleMenu = resultData.d;
                    traverseCollapsibleList(jQuery.parseJSON(collapsbleMenu));
                },
                error: function (error) {
                    var data = error;
                }
            });
            OpenSelectedMenu(selectedMenuItem);
        }
    }
}



function traverseCollapsibleList(collapsbleMenuJson) {

    var colArr = [];

    $.each(collapsbleMenuJson, function (i, item) {
        createCollapsableArray(i, item);
    });

    createHtmlCollapsableList();

    function createCollapsableArray(i, item) {
        var temp0Level = item.Country;
        var temp2level = item.EmailBox;
        var temp3level = ["Open " + item.Open, "Assigned " + item.Assigned, "Clarification Needed " + item["Clarification Needed"], "Clarification Provided " + item["Clarification Provided"], "Pending for QC " + item["Pending for QC"], "QC Accepted " + item["QC Accepted"], "QC Rejected " + item["QC Rejected"], "Completed " + item.Completed];
        var colIndex = colArr.length - 1;
        if ($.inArray(item.Country, colArr[colIndex]) < 0) {
            colArr.push([item.Country]);
        }
        colIndex = colArr.length - 1;
        var col2Index = colArr[colIndex].length - 1;
        if ($.inArray(item.SubprocessName, colArr[colIndex][col2Index]) < 0) {
            colArr[colIndex].push([item.SubprocessName, [temp2level], [temp3level]]);
        } else {
            colArr[colIndex][col2Index][1].push(temp2level);
            colArr[colIndex][col2Index][2].push(temp3level);
        }
    }

    function createHtmlCollapsableList() {
        //debugger;
        var collapsableMenuString = "";
        for (var i = 0; i < colArr.length; i++) {
            collapsableMenuString += '<li id="c_p_nav_' + i + '" class="firstLevelli"><a class="cclkpNav firstLevela" id="c_ap_nav_' + i + '" href="#" >' + colArr[i][0] + '</a>';
            collapsableMenuString += '<ul class="secondLevelul" id="c_p_UL_' + i + '" >';
            for (var j = 1; j < colArr[i].length; j++) {
                collapsableMenuString += '<li class="cNav secondLevelli" id="c_c_nav_' + i + '_' + (j - 1) + '"><a class="secondLevela" id="c_ac_nav_' + i + '_' + (j - 1) + '" href="#">' + colArr[i][j][0] + '</a>';
                collapsableMenuString += '<ul class="thirdLevelul" id="c_c_UL_' + i + '_' + (j - 1) + '" >';
                for (var k = 0; k < colArr[i][j][1].length; k++) {
                    collapsableMenuString += '<li class="thirdLevelli " id="c_c_nav_' + i + '_' + (j - 1) + '_' + k + '"><a class="thirdLevela" id="c_ac_nav_' + i + '_' + (j - 1) + '_' + k + '" href="#">' + colArr[i][j][1][k] + '</a>';
                    collapsableMenuString += '<ul class="fourthLevelul" id="c_c_UL_' + i + '_' + (j - 1) + '_' + k + '" >';
                    for (var l = 0; l < colArr[i][j][2][k].length; l++) {
                        collapsableMenuString += '<li class="fourthLevelli " id="c_c_nav_' + i + '_' + (j - 1) + '_' + k + '_' + l + '"><a class="fourthLevela" id="c_ac_nav_' + i + '_' + (j - 1) + '_' + k + '_' + l + '" onclick="getstatus(this)" href="#">' + colArr[i][j][2][k][l] + '</a></li>';
                    }
                    collapsableMenuString += '</ul></li>';
                }
                collapsableMenuString += '</ul></li>';
            }
            collapsableMenuString += '</ul></li>';
        }
        $("#collapsableNav ul").html(collapsableMenuString);
    }
}

function LeftMenuClicks() {

    /*collapsable ele events*/
    $(".firstLevela").click(function () {
        countryName = $(this).text();
        mailBoxName = '';
        subProcessName = '';
        statusName = '';
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
        //$("#aside").load("./content/piechart.html");
        //$("#aside").load("./content/PieChart.aspx");
        $('#frameMain').attr('src', './content/PieChart.aspx');
        if ($(this).hasClass("selected")) {
            $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");
            $(this).next("ul").hide();
            $(".secondLevelul,.thirdLevelul,.fourthLevelul").hide();
            return false;
        }
        $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");
        //$(this).addClass("selected");
        //$(this).parent("li").addClass("selected");
        //$(".secondLevelul,.thirdLevelul,.fourthLevelul").hide();
        //$(this).next("ul").show();


        $($(this)[0].id).addClass("selected");
        //        $($(this).parent("li")[0].id).addClass("selected");		
        $(this).parent("li").addClass("selected");
        //$(".secondLevelul,.thirdLevelul,.fourthLevelul").hide();		
        $('.firstLevelul').children().find('ul').hide();
        //$(this).next("ul").show();		

    });

    $(".secondLevela").click(function () {
        subProcessName = $(this).text();
        mailBoxName = '';
        statusName = '';
        //$("#aside").load("./content/piechart.html");
        //$("#aside").load("./content/PieChart.aspx");
        $('#frameMain').attr('src', './content/PieChart.aspx');
        //alert("test")
        if ($(this).hasClass("selected")) {
            $(".secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");
            $(".thirdLevelul,.fourthLevelul").hide();
            return false;
        }
        $(".secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");
        //$(this).addClass("selected");
        $($(this)[0].id).addClass("selected");
        $(this).parent("li").addClass("selected");
        //$(".thirdLevelul,.fourthLevelul").hide();
        $('.secondLevelul').find('ul').hide();
        //$(this).next("ul").show();

    });

    $(".thirdLevela").click(function () {
        //debugger;
        if ($(this).hasClass("selected")) {
            $(".thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");
            $(".fourthLevelul").hide()
            return false;
        }

        mailBoxName = $(this).text();
        //statusName = 'open';
        $(".thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");
        //$(this).addClass("selected");
        //$(this).parent("li").addClass("selected");
        $($(this)[0].id).addClass("selected");
        $(this).parent("li").addClass("selected");
        $('.thirdLevelul').find('ul').hide();
        //$(".fourthLevelul").hide();
        //$(this).next("ul").show();

    });

    $(".fourthLevela").click(function () {
        if ($(this).hasClass("selected")) {
            $(".fourthLevela,.fourthLevelli").removeClass("selected");
            return false;
        }
        $(".fourthLevela,.fourthLevelli").removeClass("selected");
        //$(this).addClass("selected");
        //$(this).parent("li").addClass("selected");
        $($(this)[0].id).addClass("selected");
        $(this).parent("li").addClass("selected");
        selectedMenuItem = $(this).attr('id');

    });

    /*collapsable ele events*/

    /*tempreedirecting Events*/
    $("a.firstLevela").click(function () {
        $(".dashBoardLabel").show();
        $("#underConstruction,.pagelevelLinks").hide();
        $("#parentNode").html($(this).text());
        resizeTreeScroll($("#collapsableNav"));
        statusName = 'open';
        selectedMenuItem = $(this).attr('id');
    });

    $("a.secondLevela").click(function () {
        $(".dashBoardLabel").show();
        $("#underConstruction,.pagelevelLinks").hide();
        $("#parentNode").html($(this).text());
        resizeTreeScroll($("#collapsableNav"));
        statusName = 'open';
        selectedMenuItem = $(this).attr('id');
    });

    $("a.thirdLevela").click(function () {
        $(".pagelevelLinks").show();
        $("#underConstruction,.dashBoardLabel").hide();

        if (typeof document.getElementById('frameMain').contentWindow.OnLeftMenuChange === 'function') {
            document.getElementById('frameMain').contentWindow.OnLeftMenuChange();
        }
        else {

            $('#frameMain').attr('src', './content/Inbox.aspx');
        }

        $("#childNode").html($(this).text());
        resizeTreeScroll($("#collapsableNav"));
        statusName = 'open';
        selectedMenuItem = $(this).attr('id');
    });

    $("a.fourthLevela").click(function () {
        $("#underConstruction,.dashBoardLabel").hide();
        if (typeof document.getElementById('frameMain').contentWindow.OnLeftMenuChange === 'function') {
            document.getElementById('frameMain').contentWindow.OnLeftMenuChange();
        }
        else {
            $('#frameMain').attr('src', './content/Inbox.aspx');
        }
        resizeTreeScroll($("#collapsableNav"));
        selectedMenuItem = $(this).attr('id');

    });



    $("#parentNode").click(function () {
        $("#c_ap_nav_0").removeClass("selected");
    });
    $("#childNode").click(function () {
        $("#c_ac_nav_0_0").removeClass("selected");
    });
    /*tempreedirecting Events*/

    function getstatusName(val_Status) {
        statusName = val_Status;
        selectedMenuItem = $(this).attr('id');
    }
}

function OpenSelectedMenu(selectedMenuItem) {
    //alert(selectedMenuItem);

    if (selectedMenuItem != null) {

        var stringArray = selectedMenuItem.split("_");
        //alert(stringArray);
        //$('a').click(function () {
        //    alert($(this).attr('id'));
        //});

        LeftMenuClicks();

        var elementname = '#c_p_nav_';

        //debugger;

        if ((stringArray.length - 1) == 6) //Fourth level click
        {
            $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");
           
            $('#c_p_nav_' + stringArray[3]).parent("ul").show();

            $('#c_p_nav_' + stringArray[3]).addClass("selected");
            $('#c_ap_nav_' + stringArray[3]).addClass("selected");

            $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).parent("ul").show();

            $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");
            $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");

            $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).parent("ul").show();

            $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");
            $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");

            $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6]).parent("ul").show();

            $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6]).addClass("selected");
            $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6]).addClass("selected");

            $('#' + selectedMenuItem).addClass("selected");
            $('#' + selectedMenuItem).parent("li").addClass("selected");

            $(".pagelevelLinks").show();
            $("#underConstruction,.dashBoardLabel").hide();
            $('#frameMain').attr('src', './content/Inbox.aspx');
            $("#childNode").html(statusName);




        }
        else if ((stringArray.length - 1) == 5) //Third level click
        {
            ////debugger;
            $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");

            $('#c_p_nav_' + stringArray[3]).parent("ul").show();

            $('#c_p_nav_' + stringArray[3]).addClass("selected");
            $('#c_ap_nav_' + stringArray[3]).addClass("selected");

            $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).parent("ul").show();

            $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");
            $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");

            $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).parent("ul").show();

            $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");
            $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");

            //c_ac_nav_0_0_0  c_ac_nav_0_0_0_2   c_ac_nav_0_0  c_ap_nav_0   c_p_nav_0 c_ap_nav_0   c_ac_nav_0_0_0  c_c_nav_0_0_0  c_ac_nav_0_0  c_c_nav_0_0
            $(".fourthLevelul").show();
            $('#' + selectedMenuItem).addClass("selected");
            $('#' + selectedMenuItem).parent("li").addClass("selected");
            $('#' + selectedMenuItem).next("ul").show();

            $(".pagelevelLinks").show();
            $("#underConstruction,.dashBoardLabel").hide();
            $('#frameMain').attr('src', './content/Inbox.aspx');
            $("#childNode").html(mailBoxName);


            
        }
        else if ((stringArray.length - 1) == 4) //Second level click
        {
            $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");

            $('#c_p_nav_' + stringArray[3]).parent("ul").show();

            $('#c_p_nav_' + stringArray[3]).addClass("selected");
            $('#c_ap_nav_' + stringArray[3]).addClass("selected");

            $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).parent("ul").show();

            $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");
            $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");

            $(".thirdLevelul,.fourthLevelul").hide();
            $('#' + selectedMenuItem).addClass("selected");
            $('#' + selectedMenuItem).parent("li").addClass("selected");
            $('#' + selectedMenuItem).next("ul").show();

            $(".dashBoardLabel").show();
            $("#underConstruction,.pagelevelLinks").hide();
            $('#frameMain').attr('src', './content/PieChart.aspx');
            $("#parentNode").html(subProcessName);
           
        }
        else if ((stringArray.length - 1) == 3) //First level click
        {

            $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli").removeClass("selected");

            $('#c_p_nav_' + stringArray[3]).parent("ul").show();

            
            $('#c_p_nav_' + stringArray[3]).addClass("selected");
            $('#c_ap_nav_' + stringArray[3]).addClass("selected");

            //$('#c_ap_nav_' + stringArray[3]).parent("ul").addClass("selected");

            $(".secondLevelul,.thirdLevelul,.fourthLevelul").hide();
            $('#' + selectedMenuItem).addClass("selected");
            $('#' + selectedMenuItem).parent("li").addClass("selected");
            //$('#' + selectedMenuItem).next("ul").show();

            $(".dashBoardLabel").show();
            $("#underConstruction,.pagelevelLinks").hide();
            $('#frameMain').attr('src', './content/PieChart.aspx');
            $("#parentNode").html(countryName);

        }
    }
}


function getstatus(val) {
    statusName = val.text.replace(/[ 0-9]/g, '');
    return false;
}



function resizeTreeScroll(ele) {
    var _ele = ele;
    _ele.customScrollbar({ skin: "default-skin", hScroll: false, "resize": true });
    _ele.children(".viewport").css({ "width": "252px" });
    if (_ele.children(".vertical").is(':visible')) {
        _ele.mousewheel();
    } else {
        _ele.unmousewheel();
    }
}
