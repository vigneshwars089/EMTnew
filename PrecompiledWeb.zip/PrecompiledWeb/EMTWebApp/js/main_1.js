var collapsibleList = [{
        "level": [
            {
                "title": "1",
                "level": [
                    {
                        "title": "1_1",
                        "level": [
                            {
                                "title": "1_1_1"
                            },
                            {
                                "title": "1_1_2"
                            },
                            {
                                "title": "1_1_3"
                            }
                            ,
                            {
                                "title": "1_1_4"
                            }
                            ,
                            {
                                "title": "1_1_5"
                            }

                        ]
                    }, {
                        "title": "1_2",
                        "level": [
                            {
                                "title": "1_2_1"
                            }/*,
                             {
                             "title": "1_2_2"
                             },
                             {
                             "title": "1_2_3"
                             }
                             ,
                             {
                             "title": "1_2_4"
                             }
                             ,
                             {
                             "title": "1_2_5"
                             }*/

                        ]
                    }
                ]
            }, {
                "title": "2",
                "level": [
                    {
                        "title": "2_1",
                        "level": [
                            {
                                "title": "2_1_1"
                            }/*,
                             {
                             "title": "2_1_2"
                             },
                             {
                             "title": "2_1_3"
                             }
                             ,
                             {
                             "title": "2_1_4"
                             }
                             ,
                             {
                             "title": "2_1_5"
                             }*/

                        ]
                    }, {
                        "title": "2_2",
                        "level": [
                            {
                                "title": "2_2_1"
                            }/*,
                             {
                             "title": "2_2_2"
                             },
                             {
                             "title": "2_2_3"
                             }
                             ,
                             {
                             "title": "2_2_4"
                             }
                             ,
                             {
                             "title": "2_2_5"
                             }*/

                        ]
                    }
                ]
            }
        ]
    }];


var collapsibleString = "";
//called with every property and it's value
function process(key, value) {
    if(key === "title"){
        collapsibleString += value;
        
    }
}

function traverse(o, func) {
    for (var i in o) {
        if (i === "title") {
            collapsibleString += "<li>";
        }
        if (i === "level") {
            collapsibleString += "<ul>";
        }
        func.apply(this, [i, o[i]]);

        if (o[i] !== null && typeof (o[i]) === "object") {
            traverse(o[i], func);
        }
        if (i === "title") {
            collapsibleString += "</li>";
        }
        if (i === "level") {
            collapsibleString += "</ul>";
        }
    }
}
//that's all... no magic, no bloated framework
traverse(collapsibleList, process);





$("document").ready(function () {
    var navItems = [{
            "parent": "PLink1",
            "url": "#",
            "child": []
        }, {
            "parent": "PLink2",
            "url": "#",
            "child": [/*{
             "title": "C2Link1",
             "url": "#"
             }, {
             "title": "C2Link2",
             "url": "#"
             }*/]
        }, {
            "parent": "PLink3",
            "url": "#",
            "child": [/*{
             "title": "C3Link1",
             "url": "#"
             }, {
             "title": "C3Link2",
             "url": "#"
             }*/]
        }];



//Creating Top Navigation Panel    
    createTopNavPanel(navItems);
    function createTopNavPanel(navJson) {
        var nav = $("#nav");
        $.each(navJson, function (index, element) {
            if (element.child.length > 0) {
                nav.append('<li class="pNav" id="p_nav_' + index + '" ><a class="clkpNav" id="ap_nav_' + index + '" href = "' + element.url + '">' + element.parent + '</a><ul class="pUL" id="p_UL_' + index + '">');
                var parent = $("#p_UL_" + index);
                $.each(element.child, function (idx, childEle) {
                    parent.append('<li class="cNav" id="c_nav_' + index + '_' + idx + '" >< class="clkcNav" id="ac_nav_' + index + '_' + idx + '" a href="' + childEle.url + '">' + childEle.title + '</a></li>');
                });
                nav.append('</ul></li>');
            } else {
                nav.append('<li class="pNav" id="p_nav_' + index + '" ><a class="clkpNav" id="ap_nav_' + index + '" href = "' + element.url + '">' + element.parent + '</a>');
            }
        });
    }
    $("#aside").load("./content/piechart.html");
    $("#ap_nav_0").addClass("selected");

    $(".clkpNav").click(function () {
        if ($(this).hasClass("selected")) {
            return false;
        }
        if ($(this).attr("id") === "ap_nav_0") {
            $("#aside").load("./content/piechart.html");
            $("#collapsableNav,#aside").show();

        } else {
            $("#collapsableNav,#aside").hide();
        }
        $(".clkpNav").removeClass("selected");
        $(this).addClass("selected");


    });


    var accordionsMenu = $('.cd-accordion-menu');

    if (accordionsMenu.length > 0) {

        accordionsMenu.each(function () {
            var accordion = $(this);
            //detect change in the input[type="checkbox"] value
            accordion.on('change', 'input[type="checkbox"]', function () {
                var checkbox = $(this);
                console.log(checkbox.prop('checked'));
                (checkbox.prop('checked')) ? checkbox.siblings('ul').attr('style', 'display:none;').slideDown(300) : checkbox.siblings('ul').attr('style', 'display:block;').slideUp(300);
            });
        });
    }



    $(".level1").click(function () {
        $("#aside").load("./content/piechart.html");
    });
    $(".level2").click(function () {

        $("#aside").load("./content/table.html");
    });

});

