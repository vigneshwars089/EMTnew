﻿//Dynamic Field Validation
function ValidateCheckBoxList(source, arguments) {
    var checkBoxList = document.getElementById(document.getElementById(source.id).getAttribute('ControlToValidateID'));
    var checkboxes = checkBoxList.getElementsByTagName("input");
    var isValid = false;
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            isValid = true;
            break;
        }
    }
    arguments.IsValid = isValid;
}
function checkMaxLen(txt, maxLen) {
    try {
        if (txt.value.length > (maxLen)) {
            var cont = txt.value;
            txt.value = cont.substring(0, (maxLen));
            return false;
        };
    } catch (e) {
    }
}
//Dynamic Field Validation