﻿// Numeric only control handler
function onlyNumbers(evt) {
    var e = event || evt; // for trans-browser compatibility
    var charCode = e.which || e.keyCode;
    //            alert(charCode);
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    return true;
}