﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DigiOPS.TechFoundation.Logging;
using EMTWebApp.UserManagement.Common;
using EMTWebApp.Constants;

public partial class Shared_ChangeRole : System.Web.UI.MasterPage
{
    #region DECLARATION
    UserSession userData = new UserSession();
    UserErrorLog errorlog = new UserErrorLog();
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            bool session = IsSessionValid();
            if (session == true)
            {

                if (!this.IsPostBack)
                {

                }
                fname.Value = userData.FirstName.ToString();
                role.Value = userData.RoleName.ToString();
                UID.Value = userData.UserId.ToString();
            }
            else
            {
                Response.Redirect(@"~/Errors/SessionExpired.aspx", false);
            }
        }
        catch(Exception ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | ChangeRole.master.cs | Page_Load()");  
            //errorlog.HandleError(ex, userData.UserId, " | ChangeRole.master.cs | Page_Load()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }
    }
    void Page_Init(object sender, EventArgs e)
    {
        //if (Session.IsNewSession)
        //{
        //    Session["UserDetails"] = DateTime.Now;
        //}
        Page.ViewStateUserKey = Session.SessionID;
        if (Page.EnableViewState)
        {
            if (!string.IsNullOrEmpty(Request.Params["__VIEWSTATE"]) && string.IsNullOrEmpty(Request.Form["__VIEWSTATE"]))
            {
                throw new Exception("Cross Site History Manipulation happened...");
            }
        }
    }
   
    private bool IsSessionValid()
    {
        userData = (UserSession)Session["userdetails"];
        if (userData == null)
            return false;
        else
            return true;

    }

}
