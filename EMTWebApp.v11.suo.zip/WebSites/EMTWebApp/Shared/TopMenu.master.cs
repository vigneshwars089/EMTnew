﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using EMTWebApp.UserManagement.Common;
using System.Configuration;
using System.Web.SessionState;
using DigiOPS.TechFoundation.ExceptionHandling;
using System.Web.SessionState;
using System.Reflection;
using DigiOPS.TechFoundation.Logging;
using System.Web.Security;
using System.Text;
using System.Text.RegularExpressions;
using EMTWebApp.Constants;

public partial class Shared_TopMenu : System.Web.UI.MasterPage
{

    #region DECLARATION
    UserSession userData = new UserSession();
    UserErrorLog errorlog = new UserErrorLog();
    String CurrentPage = "";
    private const string AntiXsrfTokenKey = "__AntiXsrfToken";
    private const string AntiXsrfUserNameKey = "__AntiXsrfUserName";
    private string _antiXsrfTokenValue;
    string FNAME;
    string UserID;
    string RoleName;
    #endregion
    public string CheckWhichLoginType = ConfigurationManager.AppSettings["ADLogin"].ToString();


    protected void Page_Init(object sender, EventArgs e)
    {
        // Preventing Cross site history Manipulation//
        //if (Session.IsNewSession)
        //{
        //    Session["UserDetails"] = DateTime.Now;
        //}
        Page.ViewStateUserKey = Session.SessionID;
        if (Page.EnableViewState)
        {

            if (!string.IsNullOrEmpty(Request.Params["__VIEWSTATE"]) && string.IsNullOrEmpty(Request.Form["__VIEWSTATE"]))
            {
                throw new Exception("Cross Site History Manipulation happened...");
            }
        }

        // The code below helps to protect against XSRF attacks
        var requestCookie = Request.Cookies[AntiXsrfTokenKey];
        Guid requestCookieGuidValue;
        if (requestCookie != null && Guid.TryParse(requestCookie.Value, out requestCookieGuidValue))
        {
            // Use the Anti-XSRF token from the cookie
            _antiXsrfTokenValue = requestCookie.Value;
            Page.ViewStateUserKey = _antiXsrfTokenValue;
        }
        else
        {
            // Generate a new Anti-XSRF token and save to the cookie
            _antiXsrfTokenValue = Guid.NewGuid().ToString("N");
            Page.ViewStateUserKey = _antiXsrfTokenValue;
            Session["_antiXsrfTokenValue"] = _antiXsrfTokenValue;
            var responseCookie = new HttpCookie(AntiXsrfTokenKey)
            {
                HttpOnly = true,
                Value = _antiXsrfTokenValue
            };
            if (FormsAuthentication.RequireSSL && Request.IsSecureConnection)
            {
                responseCookie.Secure = true;
            }
            Response.Cookies.Set(responseCookie);
        }


        Page.PreLoad += master_Page_PreLoad;



    }

    protected void master_Page_PreLoad(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Set Anti-XSRF token
            ViewState[AntiXsrfTokenKey] = Page.ViewStateUserKey;
            ViewState[AntiXsrfUserNameKey] = Context.User.Identity.Name ?? String.Empty;
        }
        else
        {
            // Validate the Anti-XSRF token
            if ((string)ViewState[AntiXsrfTokenKey] != _antiXsrfTokenValue
                || (string)ViewState[AntiXsrfUserNameKey] != (Context.User.Identity.Name ?? String.Empty))
            {
                Server.Transfer(@"~/Errors/BadRequest.aspx");
            }
        }
    }

    protected void ScriptManager1_AsyncPostBackError(object sender, AsyncPostBackErrorEventArgs e)
    {
        String TransferPage;
        TransferPage = "<script>window.open('/Errors/BadRequest.aspx','_self');</script>";
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "temp", TransferPage, false);
        return;
    }


    protected void Page_Load(object sender, EventArgs e)
    {

        //iterate through all the request params and check for SQL injection.

        Regex regex = new Regex(System.Configuration.ConfigurationManager.AppSettings["SQLInjectionRegex"]);
           if(Page.Page.AppRelativeVirtualPath!="~/Common/ProcessingNewUI.aspx" && Page.Page.AppRelativeVirtualPath!="~/Common/ManualCaseCreationNewUI.aspx" && Page.Page.AppRelativeVirtualPath!="~/UserManagement/Remaindermailboxconfigure.aspx")       
        foreach (string key in HttpContext.Current.Request.Form.Keys)
        {
            // if (key != "txtLoginId" && key != "txtPKeyword")
            if (!String.IsNullOrEmpty(Request.Form[key]) && regex.Match(Request.Form[key]).Success)
            {
                //Response.StatusCode = 400;
                //Response.StatusDescription = "Bad Request";
                Server.Transfer(@"~/Errors/BadRequest.aspx",false);
                
                //return;
            }
        }
        if (
               (this.Request.UrlReferrer == null
                && this.Request.Headers["Referer"] == null)
                ||
                ((this.Request.UrlReferrer != null && this.Request.UrlReferrer.Host.Equals(this.Request.Url.Host))
                && (this.Request.Headers["Referer"] != null && this.Request.Headers["Referer"].Contains(this.Request.Url.Host))
                ))
        {
            if (Request.Form["__VIEWSTATEENCRYPTED"] != null && Request.Form["__VIEWSTATEENCRYPTED"] != "")
            {

                //  Response.Redirect("~/Errors/BadRequest.aspx", false);
                Server.Transfer(@"~/Errors/BadRequest.aspx");
            }
            else
            {

                regenerateId();
                try
                {
                    if (Session["PasswordExpiration"] != null)
                    {
                        string PKeywordexpired = (Session["PasswordExpiration"]).ToString();
                        if (PKeywordexpired == "yes" && Session["CurrentPage"] == "User Management")
                        {
                            navContainer.Visible = false;
                            userData = (UserSession)Session["userdetails"];
                        }
                        //if (passwordexpired == 3)
                        //{ 
                        //    userData = (UserSession)Session["userdetails"];
                        //    Response.Redirect("~/AuthenticationandAuthorization/LockAccount.aspx", false);
                        //    return;
                        //}
                        if (Session["CurrentPage"] != null && Session["CurrentPage"] != "")
                            CurrentPage = Session["CurrentPage"].ToString();

                        bool session = IsSessionValid();
                        if (session == true)
                        {
                            FNAME = userData.FirstName.ToString();
                            UserID = userData.UserId.ToString();
                            RoleName = userData.RoleName.ToString();
                            if (!this.IsPostBack)
                            {
                                if (Request.Browser.Type.Contains("Chrome")) // replace with your check
                                {
                                    Session["BrowserName"] = "Chrome";
                                }
                                else if (Request.Browser.Type.Contains("Safari"))
                                {
                                    Session["BrowserName"] = "Safari";
                                }
                                else if (Request.Browser.Type.Contains("Opera"))
                                {
                                    Session["BrowserName"] = "Opera";
                                }
                                else if (Request.Browser.Type.Contains("Firefox"))
                                {
                                    Session["BrowserName"] = "Firefox";
                                }

                                hdnCurrentPage.Value = CurrentPage;
                                fname.Value = FNAME;
                                role.Value = RoleName;
                                UID.Value = UserID;
                            }
                            // role.Value = userData.RoleName.ToString();
                            // UID.Value = userData.UserId.ToString();
                            if (fname.Value != FNAME)
                            {
                                Session["fname"] = fname.Value;
                                fname.Value = FNAME;
                            }
                            else
                            {
                                fname.Value = userData.FirstName.ToString();
                                Session["fname"] = fname.Value;
                            }

                            if (role.Value != RoleName)
                            {
                                Session["RoleName"] = role.Value;
                                role.Value = RoleName;
                            }
                            else
                            {
                                role.Value = userData.RoleName.ToString();
                                Session["RoleName"] = role.Value;
                            }

                            if (UID.Value != UserID)
                            {
                                Session["UserID"] = UID.Value;
                                UID.Value = UserID;
                            }
                            else
                            {
                                UID.Value = userData.UserId.ToString();
                                Session["UserID"] = UID.Value;
                            }
                            if (hdnCurrentPage.Value != CurrentPage)
                            {
                                string modifiedvalue = hdnCurrentPage.Value;
                                Session["Searchmodifiedvalue"] = modifiedvalue;
                            }
                            else
                            {
                                hdnCurrentPage.Value = CurrentPage;
                                Session["Searchmodifiedvalue"] = CurrentPage;
                            }
                            ISADLogin.Value = CheckWhichLoginType;

                        }

                        else
                        {
                            Response.Redirect(@"~/Errors/SessionExpired.aspx", false);
                        }
                    }
                }
                catch (EMTException ex)
                {
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | TopMenu.master.cs | Page_Load()");     
                    //errorlog.HandleError(ex, userData.UserId, " | TopMenu.master.cs | Page_Load()");
                }
                catch (Exception ex)
                {
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | TopMenu.master.cs | Page_Load()");     
                    //errorlog.HandleError(ex, userData.UserId, " | TopMenu.master.cs | Page_Load()");
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                }
            }// end of __VIEWSTATEENCRYPTED

        }
        else
        {
            // Response.Redirect(@"~/Errors/BadRequest.aspx", false);
            Server.Transfer(@"~/Errors/BadRequest.aspx");
        }

    }

    private bool IsSessionValid()
    {
        userData = (UserSession)Session["userdetails"];
        if (userData == null)
            return false;
        else
            return true;

    }
    void regenerateId()
    {
        try
        {
            //delete session cookie
            //Session.Abandon();
            //Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));

            System.Web.SessionState.SessionIDManager manager = new System.Web.SessionState.SessionIDManager();
            string oldId = manager.GetSessionID(Context);
            string newId = manager.CreateSessionID(Context);
            bool isAdd = false, isRedir = false;
            manager.SaveSessionID(Context, newId, out isRedir, out isAdd);
            HttpApplication ctx = (HttpApplication)HttpContext.Current.ApplicationInstance;
            HttpModuleCollection mods = ctx.Modules;
            System.Web.SessionState.SessionStateModule ssm = (SessionStateModule)mods.Get("Session");
            System.Reflection.FieldInfo[] fields = ssm.GetType().GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
            SessionStateStoreProviderBase store = null;
            System.Reflection.FieldInfo rqIdField = null, rqLockIdField = null, rqStateNotFoundField = null;
            foreach (System.Reflection.FieldInfo field in fields)
            {
                if (field.Name.Equals("_store")) store = (SessionStateStoreProviderBase)field.GetValue(ssm);
                if (field.Name.Equals("_rqId")) rqIdField = field;
                if (field.Name.Equals("_rqLockId")) rqLockIdField = field;
                if (field.Name.Equals("_rqSessionStateNotFound")) rqStateNotFoundField = field;
            }
            object lockId = rqLockIdField.GetValue(ssm);
            if ((lockId != null) && (oldId != null)) store.ReleaseItemExclusive(Context, oldId, lockId);
            rqStateNotFoundField.SetValue(ssm, true);
            rqIdField.SetValue(ssm, newId);
        }
        catch (Exception ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, "TopMenu.master.cs|regenerateId()");     
           // errorlog.HandleError(ex, userData.UserId, "TopMenu.master.cs|regenerateId()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }
    }

}
