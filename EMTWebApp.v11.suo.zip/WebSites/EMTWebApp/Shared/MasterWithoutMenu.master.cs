﻿using System;
using Microsoft.Practices.ObjectBuilder;
using System.Web.Security;
using System.Web.SessionState;
using System.Reflection;
using System.Web;
using System.Web.UI;
using EMTWebApp.UserManagement.Common;
using DigiOPS.TechFoundation.Logging;
using System.Text.RegularExpressions;
using EMTWebApp.Constants;

namespace EMTWebApp.Shell.MasterPages
{
    public partial class MasterWithoutMenu : Microsoft.Practices.CompositeWeb.Web.UI.MasterPage, IMasterWithoutMenuView
    {
       
        #region DECLARATION
        UserSession userData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        private MasterWithoutMenuPresenter _presenter;
        private const string AntiXsrfTokenKey = "__AntiXsrfToken";
        private const string AntiXsrfUserNameKey = "__AntiXsrfUserName";
        private string _antiXsrfTokenValue;
        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            //iterate through all the request params and check for SQL injection.

           Regex regex = new Regex(System.Configuration.ConfigurationManager.AppSettings["SQLInjectionRegex"]);

            foreach (string key in HttpContext.Current.Request.Form.Keys)
            {
                // if (key != "txtLoginId" && key != "txtPKeyword")
                if (!String.IsNullOrEmpty(Request.Form[key]) && regex.Match(Request.Form[key]).Success)
                {
                    Context.Response.StatusCode = 400;
                    Context.Response.StatusDescription = "Bad Request";
                }
            }
            try
            {
                regenerateId();
                if (!this.IsPostBack)
                {
                    this._presenter.OnViewInitialized();
                    //if (Session["userdetails"] == null || Session.IsNewSession)
                    //{
                    //    Response.Redirect("Login.aspx", false);
                    //}
                    //else
                    //{
                    //    lblusername.Text = Session["userdetails"].ToString();
                    //    lblrolename.Text = Session["userdetails"].ToString();
                    //}

                }
                _presenter.OnViewLoaded();
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | MasterWithoutMenu.master.cs | Page_Load()");  
                //errorlog.HandleError(ex, userData.UserId, " | MasterWithoutMenu.master.cs | Page_Load()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        //protected void Page_Init(object sender, EventArgs e)
        //{
        //    regenerateId();
        //}
        //protected void master_Page_PreLoad(object sender, EventArgs e)
        //{
        //    regenerateId();
        //}

        protected void Page_Init(object sender, EventArgs e)
        {
            regenerateId();
            // The code below helps to protect against XSRF attacks
            var requestCookie = Request.Cookies[AntiXsrfTokenKey];
            Guid requestCookieGuidValue;
            if (requestCookie != null && Guid.TryParse(requestCookie.Value, out requestCookieGuidValue))
            {
                // Use the Anti-XSRF token from the cookie
                _antiXsrfTokenValue = requestCookie.Value;
                Page.ViewStateUserKey = _antiXsrfTokenValue;
            }
            else
            {
                // Generate a new Anti-XSRF token and save to the cookie
                _antiXsrfTokenValue = Guid.NewGuid().ToString("N");
                Page.ViewStateUserKey = _antiXsrfTokenValue;
                Session["_antiXsrfTokenValue"] = _antiXsrfTokenValue;

                var responseCookie = new HttpCookie(AntiXsrfTokenKey)
                {
                    HttpOnly = true,
                    Value = _antiXsrfTokenValue
                };
                if (FormsAuthentication.RequireSSL && Request.IsSecureConnection)
                {
                    responseCookie.Secure = true;
                }
                Response.Cookies.Set(responseCookie);
            }

            Page.PreLoad += master_Page_PreLoad;
        }

        protected void master_Page_PreLoad(object sender, EventArgs e)
        {
            regenerateId();
            if (!IsPostBack)
            {
                // Set Anti-XSRF token
                ViewState[AntiXsrfTokenKey] = Page.ViewStateUserKey;
                ViewState[AntiXsrfUserNameKey] = Context.User.Identity.Name ?? String.Empty;
            }
            else
            {
                // Validate the Anti-XSRF token
                if ((string)ViewState[AntiXsrfTokenKey] != _antiXsrfTokenValue
                    || (string)ViewState[AntiXsrfUserNameKey] != (Context.User.Identity.Name ?? String.Empty))
                {
                    throw new InvalidOperationException("Validation of Anti-XSRF token failed.");
                }
            }
        }

        [CreateNew]
        public MasterWithoutMenuPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }

        void regenerateId()
        {
            try
            {
                //delete session cookie
                //Session.Abandon();
                //Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));

                System.Web.SessionState.SessionIDManager manager = new System.Web.SessionState.SessionIDManager();
                string oldId = manager.GetSessionID(Context);
                string newId = manager.CreateSessionID(Context);
                bool isAdd = false, isRedir = false;
                manager.SaveSessionID(Context, newId, out isRedir, out isAdd);
                HttpApplication ctx = (HttpApplication)HttpContext.Current.ApplicationInstance;
                HttpModuleCollection mods = ctx.Modules;
                System.Web.SessionState.SessionStateModule ssm = (SessionStateModule)mods.Get("Session");
                System.Reflection.FieldInfo[] fields = ssm.GetType().GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
                SessionStateStoreProviderBase store = null;
                System.Reflection.FieldInfo rqIdField = null, rqLockIdField = null, rqStateNotFoundField = null;
                foreach (System.Reflection.FieldInfo field in fields)
                {
                    if (field.Name.Equals("_store")) store = (SessionStateStoreProviderBase)field.GetValue(ssm);
                    if (field.Name.Equals("_rqId")) rqIdField = field;
                    if (field.Name.Equals("_rqLockId")) rqLockIdField = field;
                    if (field.Name.Equals("_rqSessionStateNotFound")) rqStateNotFoundField = field;
                }
                object lockId = rqLockIdField.GetValue(ssm);
                if ((lockId != null) && (oldId != null)) store.ReleaseItemExclusive(Context, oldId, lockId);
                rqStateNotFoundField.SetValue(ssm, true);
                rqIdField.SetValue(ssm, newId);
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | MasterWithoutMenu.master.cs | regenerateId()");  
                //errorlog.HandleError(ex, userData.UserId, " | MasterWithoutMenu.master.cs | regenerateId()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        
    }
}
