﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using EMTWebApp.Constants;
using System.Text.RegularExpressions;
using Microsoft.Practices.ObjectBuilder;


namespace EMTWebApp.Survey.Views
{
    public partial class VOCSurvey : Microsoft.Practices.CompositeWeb.Web.UI.Page, ISurveyView
    {

        #region Declaration
        private SurveyPresenter _presenter;
        UserErrorLog errorlog = new UserErrorLog();
        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                try
                {

                    hdnCaseID.Value = Request.QueryString["caseId"];
                    hdnUser.Value = Request.QueryString["User"];
                    this._presenter.OnViewInitialized();
                    if (String.IsNullOrEmpty(hdnCaseID.Value) && hdnUser.Value != "GuestUser")
                    {
                        Response.Redirect("~/Errors/Error.aspx", false);
                    }
                }
                catch (Exception ex)
                {
                   // errorlog.HandleError(ex, " | VOCSurvey.aspx.cs | Page_Load()");
                    Response.Redirect("~/Errors/Error.aspx", false);
                }
             }

            this._presenter.OnViewLoaded();
        }

        #region PROPERTIES
        [CreateNew]
        public SurveyPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (!txtQOSReason.Visible)
                {
                    rqfvtxtQOSReason.Enabled = false;
                   // rqfvtxtQOSReason.ControlToValidate = null;
                }
                if (!textTATReason.Visible)
                {
                    rqfvtxtTATreason.Enabled = false;
                    //rqfvtxtTATreason.ControlToValidate = null;
                }

                string quality = ddlQualityOfService.SelectedValue;
                string qualityReason = string.Empty;
                string tat = ddlTurnaroundTime.SelectedValue;
                string tatReason = string.Empty;
                string comments = string.Empty;
                if (quality == "No")
                {
                    qualityReason = txtQOSReason.Text;
                }
                if (tat == "No")
                {
                    tatReason = textTATReason.Text;
                }
                comments = txtComments.Text;
                Hashtable hs = new Hashtable();

                hs.Add("@VOCQUALITY", quality);
                hs.Add("@VOCREASON",qualityReason);
                hs.Add("@VOCTAT", tat);
                hs.Add("@VOCTATREASON", tatReason);
                hs.Add("@COMMENTS", comments);
                hs.Add("@CASEID", Convert.ToInt32(hdnCaseID.Value));

                int returnvalue = _presenter.InsertVOCSurveyDetails(hs);

                if (returnvalue == 1)
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Survey Details Submitted Successfully');", true);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Script", "CloseWindow();", true);
                   //Response.Write("<script language=javascript>this.window.opener = null;window.open('','_self'); window.close();   </script>");
                    
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Survey Details Updated Successfully');", true);
                    
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Script", "CloseWindow();", true);
                }
                
            }
            catch (Exception ex)
            {
                //errorlog.HandleError(ex, " | VOCSurvey.aspx.cs | btnSubmit_Click()");
                Response.Redirect("~/Errors/Error.aspx", false);
            }
        }
        protected void ddlQualityOfService_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlQualityOfService.SelectedValue == "No")
            {
                lblreasonQOS.Visible = true;
                txtQOSReason.Visible = true;
            }
            else
            {
                lblreasonQOS.Visible = false;
                txtQOSReason.Visible = false;
                txtQOSReason.Text = string.Empty;
            }
        }
        protected void ddlTurnaroundTime_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlTurnaroundTime.SelectedValue == "No")
            {
                lblreasonTAT.Visible = true;
                textTATReason.Visible = true;
            }
            else
            {
                lblreasonTAT.Visible = false;
                textTATReason.Visible = false;
                textTATReason.Text = string.Empty;
            }
        }
    }
}