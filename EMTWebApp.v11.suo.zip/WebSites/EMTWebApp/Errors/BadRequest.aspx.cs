﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Errors_BadRequest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
     
        Context.Response.StatusCode = 400;
        Context.Response.StatusDescription = "Bad Request";
        Context.Session.Abandon();
    }
}