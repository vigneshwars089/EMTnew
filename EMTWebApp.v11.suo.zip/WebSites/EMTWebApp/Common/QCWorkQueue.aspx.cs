﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.Common;
using EMTWebApp.Common.Views;
using EMTWebApp.ExceptionHandler;
using System.Text.RegularExpressions;
using EMTWebApp.Constants;
using EMTWebApp.UserManagement.Common;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Security;

namespace EMTWebApp.Common.Views
{
    public partial class QCWorkQueue : Microsoft.Practices.CompositeWeb.Web.UI.Page, IQCWorkQueueView
    {

        #region DECLARATION
        private QCWorkQueuePresenter _presenter;
        private const string ASCENDING = " ASC";
        private const string DESCENDING = " DESC";
        UserSession userData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();        
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            userData = (UserSession)Session["userdetails"];
            IsSessionValid();
            Session["CurrentPage"] = "Quality Check";
            if (!this.IsPostBack)
            {
                //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                string PKeyword = (Session["PasswordExpiration"]).ToString();
                if (PKeyword == "yes")
                {
                    Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                }
                try
                {
                    LoadCountry(userData.UserId);
                    GetQCWorkQueue(userData.UserId);
                    IsValidRoleToAccessThisPage(userData);
                    if (userData.RoleId == 4)
                    {
                        rblQCAssignReassign.Items.Add(new ListItem("Assign", "0", true));
                        ListItem LIAssign = rblQCAssignReassign.Items.FindByValue("0");
                        if (LIAssign != null)
                        {
                            LIAssign.Selected = true;
                        }
                    }
                    else
                    {
                        rblQCAssignReassign.Items.Add(new ListItem("Assign", "0"));
                        rblQCAssignReassign.Items.Add(new ListItem("Reassign", "1"));
                        ListItem LIAssign = rblQCAssignReassign.Items.FindByValue("0");
                        if (LIAssign != null)
                        {
                            LIAssign.Selected = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    //  ExceptionHelper.HandleException(ex);
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | Page_Load()");     
                    //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | Page_Load()");
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                }
                this._presenter.OnViewInitialized();
            }
            this._presenter.OnViewLoaded();
        }

        #region PROPERTIES
        [CreateNew]
        public QCWorkQueuePresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion

        #region PRIVATEMETHODS

        private bool IsValidRoleToAccessThisPage(UserSession UserDetails)
        {
            try
            {
                if ((UserDetails.RoleId == (int)Constant.UserRole.TeamLead) || (UserDetails.RoleId == (int)Constant.UserRole.Processor))
                {
                    return true;
                }
                else
                {
                    Response.Redirect(@"~\Errors\AccessDenied.aspx", false);
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | QCWorkQueue.aspx.cs | IsValidRoleToAccessThisPage()");     
                //errorlog.HandleError(Ex, UserDetails.UserId, " | QCWorkQueue.aspx.cs | IsValidRoleToAccessThisPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
            return false;
        }

        /// <summary>
        /// Session Valid 
        /// </summary>
        private void IsSessionValid()
        {
            try
            {
                if (userData == null)
                    Response.Redirect(@"~\Errors\SessionExpired.aspx");
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | IsSessionValid()");     
               // errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | IsSessionValid()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        /// <summary>
        /// Bind User Id Details to Reassign  
        /// </summary>
        private void BindUserIdsToReassign()
        {
            try
            {
                DataSet ds = _presenter.GetUserIdsByEMailboxId(Convert.ToInt32(ddlEmailBox.SelectedValue));

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    ddlUserIdtoReassign.DataSource = ds;
                    ddlUserIdtoReassign.DataTextField = "UserName";
                    ddlUserIdtoReassign.DataValueField = "UserId";
                    ddlUserIdtoReassign.DataBind();
                }

                ddlUserIdtoReassign.Items.Insert(0, new ListItem("-Select-", "0"));

                ListItem selectedListItem = ddlUserIdtoReassign.Items.FindByValue(userData.UserId.ToString());

                if (selectedListItem != null)
                {
                    ddlUserIdtoReassign.SelectedValue = userData.UserId.ToString();
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | BindUserIdsToReassign()");     
               // errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | BindUserIdsToReassign()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        /// <summary>
        /// Load Reassing Cases
        /// </summary>
        private void LoadReassinQueue()
        {
            try
            {
                GetReAssignQCWorkQueue(userData.UserId, (ddlQCUserlist.SelectedValue == "0" ? "" : ddlQCUserlist.SelectedValue), ddlEmailBox.SelectedValue.Trim(), (rblQCAssignReassign.SelectedValue == "0" ? false : true));
                Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
                Match matchUserId = regex.Match(userData.UserId);
                Match matchQCUserlist = regex.Match(ddlQCUserlist.SelectedValue);
                Match matchEMailBox = regex.Match(ddlEmailBox.SelectedValue.Trim());
                Match matchrblQCAssignReassign = regex.Match(rblQCAssignReassign.SelectedValue);
                if (matchUserId.Success && matchQCUserlist.Success && matchEMailBox.Success && matchrblQCAssignReassign.Success)
                {
                GetReAssignQCWorkQueue_sort(userData.UserId, (ddlQCUserlist.SelectedValue == "0" ? "" : ddlQCUserlist.SelectedValue), ddlEmailBox.SelectedValue.Trim(), (rblQCAssignReassign.SelectedValue == "0" ? false : true));
                if (userData.RoleId == 4)
                {
                    foreach (ListItem li in rblQCAssignReassign.Items)
                    {
                        if (li.Value == "1")
                        {
                            li.Attributes.Add("style", "display:none");
                        }
                    }
                }
            }
                else
                {
                    Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | LoadReassinQueue()");     
               // errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | LoadReassinQueue()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        /// <summary>
        /// Load EmailBox Details
        /// </summary>
        private void LoadEmailBox(string CountryId, int RoleId, string LoggedInUserId)
        {
            try
            {
                ddlEmailBox.DataSource = _presenter.GetEmailBox(CountryId, RoleId, LoggedInUserId);
                ddlEmailBox.DataTextField = "EMailBoxName";
                ddlEmailBox.DataValueField = "EMailBoxId";
                ddlEmailBox.DataBind();
                ListItem lstProcess = new ListItem();
                lstProcess.Text = "-Select-";
                lstProcess.Value = "0";
                ddlEmailBox.Items.Insert(0, lstProcess);
            }
            catch (Exception ex)
            {
                // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | LoadEmailBox()");     
               // errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | LoadEmailBox()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        /// <summary>
        /// Binds Processors Details
        /// </summary>
        private void LoadProcessors(string CountryId, string EmailBoxId, string LoggedInUserId)
        {
            try
            {
                ddlQCUserlist.DataSource = _presenter.GetProcessorsForQC(CountryId, EmailBoxId, LoggedInUserId);
                ddlQCUserlist.DataTextField = "USERNAME";
                ddlQCUserlist.DataValueField = "USERID";
                ddlQCUserlist.DataBind();
                ListItem lstProcess = new ListItem();
                lstProcess.Text = "-Select-";
                lstProcess.Value = "0";
                ddlQCUserlist.Items.Insert(0, lstProcess);
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | LoadProcessors()");  
               // errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | LoadProcessors()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }
        /// <summary>
        /// Binds Country Details
        /// </summary>
        private void LoadCountry(string UserId)
        {
            try
            {
                ddlCountry.DataSource = _presenter.GetCountry(UserId);
                ddlCountry.DataTextField = "COUNTRY";
                ddlCountry.DataValueField = "COUNTRYID";
                ddlCountry.DataBind();
                //ListItem lstProcess = new ListItem();
                //lstProcess.Text = "-Select-";
                //lstProcess.Value = "0";
                //ddlCountry.Items.Insert(0, lstProcess);


                if (ddlCountry.Items.Count == 1)
                {
                    ddlCountry.SelectedIndex = -1;
                    ddlCountry.Enabled = false;

                    ddlCountry_SelectedIndexChanged(null, null);
                }
                else
                {
                    ddlCountry.Items.Insert(0, new ListItem("-Select-", "0", true));
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | LoadCountry()");  
               // errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | LoadCountry()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }
        /// <summary>
        /// To Get Reassign QC Work Queue Details 
        /// </summary>
        private void GetReAssignQCWorkQueue(string LoggedInUserId, string ReAssignUserId, string EmailBoxId, bool IsQCReassign)
        {
            try
            {
                this._presenter.GetReAssignQcWorkQueueDetails(LoggedInUserId, ReAssignUserId, EmailBoxId, (rblQCAssignReassign.SelectedValue == "0" ? false : true));
                if (userData.RoleId == 4)
                {
                    foreach (ListItem li in rblQCAssignReassign.Items)
                    {
                        if (li.Value == "1")
                        {
                            li.Attributes.Add("style", "display:none");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | GetReAssignQCWorkQueue()");  
                //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | GetReAssignQCWorkQueue()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

        }

        /// <summary>
        /// To Get Reassign QC Work Queue Details 
        /// </summary>
        private void GetReAssignQCWorkQueue_sort(string LoggedInUserId, string ReAssignUserId, string EmailBoxId, bool IsQCReassign)
        {
            try
            {
                DataSet dsReassignSort = this._presenter.GetReAssignQcWorkQueueDetails_sort(LoggedInUserId, ReAssignUserId, EmailBoxId, (rblQCAssignReassign.SelectedValue == "0" ? false : true));
                gvReassignQueue.DataSource = dsReassignSort;
                ViewState["dsReassignSort"] = dsReassignSort.Tables[0];
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | GetReAssignQCWorkQueue_sort()");  
                //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | GetReAssignQCWorkQueue_sort()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        /// <summary>
        /// Alert Box
        /// </summary>
        private void AlertBox(string Message)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert", "alert('" + Message + "')", true);
        }
        /// <summary>
        /// To Get Individual User's QC WorkQueue
        /// </summary>
        private void GetQCWorkQueue(string userId)
        {
            try
            {
                this._presenter.GetQcWorkQueueDetails(userId);
                if (userData.RoleId == 4)
                {
                    foreach (ListItem li in rblQCAssignReassign.Items)
                    {
                        if (li.Value == "1")
                        {
                            li.Attributes.Add("style", "display:none");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | GetQCWorkQueue()");  
                //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | GetQCWorkQueue()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

        }
        #endregion

        #region Events
        /// <summary>
        /// Search Click Event for QC Assign 
        /// </summary>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            IsSessionValid();
            try
            {
                if (ddlCountry.SelectedItem.Text.Contains("Select"))
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Please select Country');", true);
                    ddlCountry.Focus();
                }
                else if (ddlEmailBox.SelectedIndex == 0)
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Please select Emailbox');", true);
                    ddlEmailBox.Focus();
                }
                else
                {

                    LoadReassinQueue();
                    if (gvReassignQueue.Rows.Count > 0)
                    {

                        gvReassignQueue.Visible = true;
                        btnAssign.Visible = true;
                        if (userData.RoleId == (int)Constant.UserRole.TeamLead)
                        {
                            BindUserIdsToReassign();
                            lblUserIdsToReassign.Visible = ddlUserIdtoReassign.Visible = true;
                            //bugfix for preventing reassigning of case to same user
                            ListItem removeItem = ddlUserIdtoReassign.Items.FindByText(userData.FirstName + " " + userData.LastName + " ( " + userData.UserId + " ) ");
                            ddlUserIdtoReassign.Items.Remove(removeItem);
                            
                        }
                        else
                        {
                            lblUserIdsToReassign.Visible = ddlUserIdtoReassign.Visible = false;
                        }
                    }
                    else
                    {
                        lblUserIdsToReassign.Visible = ddlUserIdtoReassign.Visible = btnAssign.Visible = false;
                    }
                }

            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | btnSearch_Click()");  
                //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | btnSearch_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        protected void gvQcWorkQueue_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                //Setting sort direction and expression
                if (GridViewSortDirection == SortDirection.Ascending)
                {
                    GridViewSortDirection = SortDirection.Descending;

                    hiddenFieldSortDirection.Value = DESCENDING;
                    hiddenFieldSortExp.Value = e.SortExpression;

                    GetQCWorkQueue(userData.UserId);
                }
                else
                {
                    GridViewSortDirection = SortDirection.Ascending;

                    hiddenFieldSortDirection.Value = ASCENDING;
                    hiddenFieldSortExp.Value = e.SortExpression;

                    GetQCWorkQueue(userData.UserId);
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | gvQcWorkQueue_Sorting()");  
                //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | gvQcWorkQueue_Sorting()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        protected void gvQcWorkQueue_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                IsSessionValid();
                gvQcWorkQueue.PageIndex = e.NewPageIndex;
                GetQCWorkQueue(userData.UserId);
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | gvQcWorkQueue_PageIndexChanging()");  
               // errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | gvQcWorkQueue_PageIndexChanging()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        protected void gvQcWorkQueue_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow || e.Row.RowType == DataControlRowType.Header)
                {
                    for (int count = 0; count < e.Row.Cells.Count; count++)
                    {
                        e.Row.Cells[count].HorizontalAlign = HorizontalAlign.Center;

                        if (e.Row.RowType == DataControlRowType.DataRow && count == 2)
                        {
                            e.Row.Cells[count].HorizontalAlign = HorizontalAlign.Left;
                            String encryptsubject = e.Row.Cells[count].Text;
                            //Decrption
                            //cryptInfo.CryptKey = cipherpassword;
                            //cryptInfo.ValueToCrypt = encryptsubject;
                            //string decryptsubject = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
                            string decryptsubject = Constants.HelperMethods.DecryptString(encryptsubject);
                            e.Row.Cells[count].Text = decryptsubject;
                        }                        
                    }
                }

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    string strURL = "#";
                    HyperLink hypCaseId = (HyperLink)e.Row.FindControl("hypCaseId");
                    HiddenField hiddenCaseId = (HiddenField)e.Row.FindControl("hiddenCaseId");
                    Label lblStatusId = (Label)e.Row.FindControl("lblStatusId");
                    Label lblEMailboxId = (Label)e.Row.FindControl("lblEMailboxId");

                    //strURL = "ProcessingNewUI.aspx?CaseId=" + hiddenCaseId.Value + "&PreviousPage=QCWorkQueue" + "&EMailBox=" + lblEMailboxId.Text.Trim() + "&Status=" + lblStatusId.Text.Trim();
                    strURL = "NewProcessingPage.aspx?CaseId=" + hiddenCaseId.Value + "&PreviousPage=QCWorkQueue" + "&EMailBox=" + lblEMailboxId.Text.Trim() + "&Status=" + lblStatusId.Text.Trim();
                    //SAST fixes
                   // hypCaseId.NavigateUrl = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(strURL,true);
                    hypCaseId.NavigateUrl = strURL;
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | gvQcWorkQueue_RowDataBound()");  
                //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | gvQcWorkQueue_RowDataBound()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        public SortDirection GridViewReAssignSortDirection
        {
            get
            {
                if (ViewState["ReAssignsortDirection"] == null)
                    ViewState["ReAssignsortDirection"] = SortDirection.Ascending;

                return (SortDirection)ViewState["ReAssignsortDirection"];
            }
            set { ViewState["ReAssignsortDirection"] = value; }
        }
        public DataSet QCWorkQueue1
        {
            set
            {
                DataView dview = value.Tables[0].DefaultView;
                dview.Sort = hiddenFieldSortExp.Value + hiddenFieldSortDirection.Value;
                lblcount.Text = dview.Table.Rows.Count.ToString();
                gvQcWorkQueue.DataSource = dview;
                gvQcWorkQueue.DataBind();
            }
        }
        protected void gvReassignQueue_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                if (userData.RoleId == 4)
                {
                    foreach (ListItem li in rblQCAssignReassign.Items)
                    {
                        if (li.Value == "1")
                        {
                            li.Attributes.Add("style", "display:none");
                        }
                    }
                }

                gvReassignQueue.PageIndex = e.NewPageIndex;
                GetReAssignQCWorkQueue(userData.UserId, (ddlQCUserlist.SelectedValue == "0" ? "" : ddlQCUserlist.SelectedValue), ddlEmailBox.SelectedValue.Trim(), (rblQCAssignReassign.SelectedValue == "0" ? false : true));
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | gvReassignQueue_PageIndexChanging()");  
                //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | gvReassignQueue_PageIndexChanging()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        protected void gvReassignQueue_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                DataTable dtSort = new DataTable();
                dtSort = (DataTable)ViewState["dsReassignSort"];
                if (ViewState["Sort Order"] == null)
                {
                    dtSort.DefaultView.Sort = e.SortExpression + " DESC";
                    gvReassignQueue.DataSource = dtSort;
                    gvReassignQueue.DataBind();
                    ViewState["Sort Order"] = "DESC";
                }
                else
                {
                    dtSort.DefaultView.Sort = e.SortExpression + "" + " ASC";
                    gvReassignQueue.DataSource = dtSort;
                    gvReassignQueue.DataBind();
                    ViewState["Sort Order"] = null;
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | gvReassignQueue_Sorting()");  
               // errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | gvReassignQueue_Sorting()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        protected void gvReassignQueue_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow || e.Row.RowType == DataControlRowType.Header)
                {
                    for (int count = 0; count < e.Row.Cells.Count; count++)
                    {
                        e.Row.Cells[count].HorizontalAlign = HorizontalAlign.Center;

                        if (e.Row.RowType == DataControlRowType.DataRow && count == 3)
                        {
                            e.Row.Cells[count].HorizontalAlign = HorizontalAlign.Left;                            
                            String encryptsubject = e.Row.Cells[count].Text;
                            //Decrption
                            //cryptInfo.CryptKey = cipherpassword;
                            //cryptInfo.ValueToCrypt = encryptsubject;
                            //string decryptsubject = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
                            string decryptsubject = Constants.HelperMethods.DecryptString(encryptsubject);
                            e.Row.Cells[count].Text = decryptsubject;
                        }
                    }
                }

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    CheckBox headerchk = (CheckBox)gvReassignQueue.HeaderRow.FindControl("chkCheckAll");
                    CheckBox childchk = (CheckBox)e.Row.FindControl("chkCaseId");
                    childchk.Attributes.Add("onclick", "javascript:rCheckChange(this);");
                    headerchk.Attributes.Add("onclick", "javascript:hCheckChange(this);");
                }
                //if (e.Row.RowType == DataControlRowType.Header)
                //{
                //    // Find the checkbox control in header and add an attribute 
                //    ((CheckBox)e.Row.FindControl("chkCheckAll")).Attributes.Add("onclick", "javascript:CheckAll('" + ((CheckBox)e.Row.FindControl("chkCheckAll")).ClientID + "')");
                //}
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | gvReassignQueue_RowDataBound()");  
                //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | gvReassignQueue_RowDataBound()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        public DataSet ReAssignQCWorkQueue
        {
            set
            {
                DataView dview1 = value.Tables[0].DefaultView;
                dview1.Sort = hiddenFieldSortExp1.Value + hiddenFieldSortDirection1.Value;
                gvReassignQueue.DataSource = dview1;
                gvReassignQueue.DataBind();
                tdGrid.Visible = true;
            }
        }
        public SortDirection GridViewSortDirection
        {
            get
            {
                if (ViewState["sortDirection"] == null)
                    ViewState["sortDirection"] = SortDirection.Ascending;

                return (SortDirection)ViewState["sortDirection"];
            }
            set { ViewState["sortDirection"] = value; }
        }
        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                IsSessionValid();
                if (!ddlCountry.SelectedItem.Text.ToLower().Contains("select"))
                {
                    //hiddenFieldCountry.Value = ddlCountry.SelectedValue.ToString();
                    LoadEmailBox(ddlCountry.SelectedValue.Trim(), userData.RoleId, userData.UserId);
                }
                else if (ddlCountry.SelectedIndex > 0)
                {
                    LoadEmailBox(ddlCountry.SelectedValue.Trim(), userData.RoleId, userData.UserId);
                }
                else
                {
                    //LoadProcessors(ddlCountry.SelectedValue.Trim(), hiddenFieldEmailBox.Value, userData.UserId);
                    //LoadReassinQueue();
                    ddlEmailBox.SelectedIndex = 0;
                    btnAssign.Visible = false;
                    lblUserIdsToReassign.Visible = false;
                    ddlUserIdtoReassign.Visible = false;
                    gvReassignQueue.Visible = false;

                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | ddlCountry_SelectedIndexChanged()");  
                //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | ddlCountry_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        protected void ddlEmailBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                IsSessionValid();
                //hiddenFieldCountry.Value = ddlCountry.SelectedValue.ToString();
                //hiddenFieldEmailBox.Value = ddlEmailBox.SelectedValue.ToString();
                if (ddlEmailBox.SelectedIndex > 0)
                {
                    LoadProcessors(ddlCountry.SelectedValue.Trim(), ddlEmailBox.SelectedValue.Trim(), userData.UserId);
                }
                //LoadReassinQueue();
                else
                {
                    btnAssign.Visible = false;
                    lblUserIdsToReassign.Visible = false;
                    if (ddlUserIdtoReassign.Items.Count > 0)
                        ddlUserIdtoReassign.SelectedIndex = 0;
                    ddlUserIdtoReassign.Visible = false;
                    gvReassignQueue.Visible = false;
                    ddlQCUserlist.Items.Clear();
                    ListItem lstProcess = new ListItem();
                    lstProcess.Text = "-Select-";
                    lstProcess.Value = "0";
                    ddlQCUserlist.Items.Insert(0, lstProcess);

                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | ddlEmailBox_SelectedIndexChanged()");  
               // errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | ddlEmailBox_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        /// <summary>
        /// Export To Excel methods
        /// </summary>
        protected void btnExporttoExcel_Click(object sender, EventArgs e)
        {
            try
            {
                IsSessionValid();
                Response.Clear();
                string UserId = (userData.UserId != "" ? userData.UserId : "");
                Response.AddHeader("content-disposition", "attachment;filename=QCWorkQueue.xls");
                Response.Charset = "UTF-8";
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; //"application/vnd.xls";
                Response.ContentEncoding = System.Text.Encoding.Default;
                System.IO.StringWriter stringWrite = new System.IO.StringWriter();
                System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
                gvQcWorkQueue.AllowSorting = false;
                gvQcWorkQueue.AllowPaging = false;
                GetQCWorkQueue(UserId);
                foreach (GridViewRow row in gvQcWorkQueue.Rows)
                {
                    if (row.RowType == DataControlRowType.DataRow)
                    {
                        if (row.Cells[0].FindControl("hypCaseId").GetType() == typeof(HyperLink))
                        {
                            Literal l = new Literal();
                            l.Text = (row.Cells[0].FindControl("hypCaseId") as HyperLink).Text;

                            row.Cells[0].Controls.Remove(row.Cells[0].FindControl("hypCaseId"));

                            row.Cells[0].Controls.Add(l);
                        }
                    }
                }
                for (int i = 0; i < gvQcWorkQueue.Rows.Count; i++)
                {
                    gvQcWorkQueue.Rows[i].Attributes.Add("class", "textmode");
                    gvQcWorkQueue.Rows[i].Cells[1].Attributes.Add("class", "date");
                }



                gvQcWorkQueue.RenderControl(htmlWrite);
                //string style = @"<style>.date { mso-number-format:'dd/mm/yyyy h:mm:ss'; }</style>";
                string style = @"<style>.date { mso-number-format:'mm\\/dd\\/yyyy hh:mm:ss'; }</style>";
                Response.Write(style);
                Response.Write(stringWrite.ToString());
                stringWrite.Close();
                htmlWrite.Close();
                Response.End();
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | btnExporttoExcel_Click()");     
              //  errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | btnExporttoExcel_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
           // stringWrite.Close();
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                ddlCountry.SelectedIndex = ddlEmailBox.SelectedIndex = ddlQCUserlist.SelectedIndex = 0;

                ddlQCUserlist.Items.Clear();
                ListItem lstProcess = new ListItem();
                lstProcess.Text = "-Select-";
                lstProcess.Value = "0";
                ddlQCUserlist.Items.Insert(0, lstProcess);
                ddlQCUserlist.SelectedIndex = 0;

                if (!ddlCountry.SelectedItem.Text.Contains("select"))
                {
                    ddlCountry_SelectedIndexChanged(null, null);
                    //ddlEmailBox.Items.Insert(0, "-Select-");
                    ddlEmailBox.SelectedIndex = 0;                   
                }
                else
                {
                    ddlEmailBox.Items.Clear();
                    ddlEmailBox.Items.Insert(0, "-Select-");
                    ddlEmailBox.SelectedIndex = 0;                    
                }
                rblQCAssignReassign.SelectedValue = "0";
                gvReassignQueue.DataSource = null;
                tdGrid.Visible = false;
                lblUserIdsToReassign.Visible = ddlUserIdtoReassign.Visible = false;
                btnAssign.Visible = false;
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | btnReset_Click()");     
                //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | btnReset_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        //protected void rblQCAssignReassign_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    LoadReassinQueue();
        //}
        /// <summary>
        /// QC Assign - Peer to Peer
        /// </summary>
        protected void btnAssign_Click(object sender, EventArgs e)
        {
            try
            {
                IsSessionValid();
                //userData = (UserSession)Session["userdetails"];
                if (userData.RoleId == 4)
                {
                    foreach (ListItem li in rblQCAssignReassign.Items)
                    {
                        if (li.Value == "1")
                        {
                            li.Attributes.Add("style", "display:none");
                        }
                    }
                }
                string strCaseIDs, AssignToId;
                strCaseIDs = AssignToId = "";

                //string UserId = userData.UserId;
                //string ReAssignUserID = hiddenFieldReAssignUserID.Value.ToString();
                //string EmailBoxId = hiddenFieldEmailBox.Value.ToString();

                AssignToId = ((userData.RoleId == (int)(Constant.UserRole.TeamLead) && (ddlUserIdtoReassign.SelectedIndex != 0 || ddlUserIdtoReassign.SelectedIndex != -1)) ? ddlUserIdtoReassign.SelectedValue.Trim() : userData.UserId.Trim());
                bool isAssignedtoUser = false;
                bool isSameQCUser = false;
                foreach (GridViewRow gvSearchAll in gvReassignQueue.Rows)
                {
                    CheckBox chk = (CheckBox)gvSearchAll.FindControl("chkCaseId");
                    Label lblUserId = (Label)gvSearchAll.FindControl("lblUserID");
                    Label lblQCUserId = (Label)gvSearchAll.FindControl("lblQCUserID");

                    if (chk.Checked == true)
                    {
                        if (lblQCUserId.Text.Trim() != AssignToId)
                        {
                            if (lblUserId.Text.Trim() == AssignToId)
                            {
                                isAssignedtoUser = true;
                                break;
                            }

                            if (!isAssignedtoUser)
                            {
                                HiddenField hiddenCaseIdReAssign = (HiddenField)gvSearchAll.FindControl("hiddenCaseIdReAssign");

                                if (chk.Checked == true && strCaseIDs != string.Empty)
                                {
                                    strCaseIDs = strCaseIDs + "," + hiddenCaseIdReAssign.Value.ToString();
                                }
                                if (strCaseIDs == string.Empty && chk.Checked == true)
                                {
                                    strCaseIDs = hiddenCaseIdReAssign.Value.ToString();
                                }
                            }
                        }
                        else
                        {
                            isSameQCUser = true;
                            break;
                        }
                    }
                }

                if (!isSameQCUser)
                {
                    if (!isAssignedtoUser)
                    {
                        if (AssignToId != "0")
                        {
                            if (strCaseIDs != string.Empty)
                            {
                                int result = this._presenter.UpdateDirectReAssign(AssignToId, ddlEmailBox.SelectedValue.Trim(), strCaseIDs);
                                if (result != 0)
                                {
                                    AlertBox("Selected cases have been assigned successfully!!");
                                    GetReAssignQCWorkQueue(userData.UserId, (ddlQCUserlist.SelectedValue == "0" ? "" : ddlQCUserlist.SelectedValue), ddlEmailBox.SelectedValue.Trim(), (rblQCAssignReassign.SelectedValue == "0" ? false : true));
                                    GetQCWorkQueue(userData.UserId);
                                }
                                else
                                {
                                    AlertBox("Selected cases have not been assigned successfully!!");
                                }
                            }
                            else
                            {
                                AlertBox("Please select atleast one case to assign.");
                            }
                        }
                        else
                        {
                            AlertBox("Please select any user to assign case(s).");
                            ddlUserIdtoReassign.Focus();
                        }
                    }
                    else
                    {
                        AlertBox("Please select some other user. QC and processing user could not be same.");
                    }
                }
                else
                {
                    AlertBox("One of the selected case is already assigned to the selected QC user, please check.");
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | btnAssign_Click()");     
                //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | btnAssign_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        #endregion
    }
}

