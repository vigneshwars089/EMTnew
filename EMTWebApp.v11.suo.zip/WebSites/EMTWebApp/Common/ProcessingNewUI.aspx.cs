﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Windows.Input;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
//using EMTWebApp;
using EMTWebApp.Common.Common;
using EMTWebApp.Constants;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Net.Mail;
using Microsoft.Exchange.WebServices.Data;
using AjaxControlToolkit;
using AjaxControlToolkit.HTMLEditor;
using System.Net;
using EMTWebApp.Common.Views;
using EMTWebApp.Common;
using System.Globalization;
using DigiOPS.TechFoundation.Security;
using DigiOPS.TechFoundation.Logging;
using System.Collections.Specialized;
using System.Configuration;

public partial class Common_ProcessingNewUI : Microsoft.Practices.CompositeWeb.Web.UI.Page, IProcessingView
{

    #region DECLARATION
    private ProcessingPresenter _presenter = new ProcessingPresenter(new EMTWebApp.Common.CommonController());
    UserSession objUser = new UserSession();
    //private bool LoadNextCase;
    private List<EMTWebApp.Constants.Attachment> UploadedFileCollection = new List<EMTWebApp.Constants.Attachment>();
    private List<EMTWebApp.Constants.Attachment> EMailAttachmentFileCollection = new List<EMTWebApp.Constants.Attachment>();
    private List<EMTWebApp.Constants.Conversation> EmailConversationCollection = new List<EMTWebApp.Constants.Conversation>();
    private String strConversation = string.Empty;
    private EMailBoxCredentials objEMailCredentials = new EMailBoxCredentials();
    //private EMTWebApp.Constants.CaseDetails objCaseDetails = new EMTWebApp.Constants.CaseDetails();
    //private string strFollowupEMail = string.Empty;
    // private string strForwardToGMBEMail = string.Empty;
    UserErrorLog errorlog = new UserErrorLog();
    private string LoginId;

    HtmlTable tab = new HtmlTable();
    HtmlTableRow tr = new HtmlTableRow();
    HtmlTableRow tr1 = new HtmlTableRow();
    HtmlTableCell td1 = new HtmlTableCell();
    HtmlTableCell td2 = new HtmlTableCell();
    string strFieldID, strFieldName, strFieldType, strFieldDataType = "", strValue = "";
    string strInsSQL = "";
    string strSQL = "";
    string strUserID = string.Empty;
    string strValidationType = string.Empty;
    Int32 ClientID = 0, MailboxID, strFieldPrivilegeID;
    Int64 CaseID = 0, strTextLength, strValidationTypeID, strFieldMasterID;
    string encryptionmode = ConfigurationManager.AppSettings["ENCRYPT/DECRYPT"].ToString();
    string GMBtoGMBCaseTraversal = ConfigurationManager.AppSettings["GMBtoGMBCaseTraversal"].ToString();
    string subjecttxt = ConfigurationManager.AppSettings["Subjectdisable"].ToString();
    // Product License
    string ToolPurchased = ConfigurationManager.AppSettings["ToolPurchased"].ToString();
    string DateOfPurchase = ConfigurationManager.AppSettings["DateOfPurchase"].ToString();
    string Version = ConfigurationManager.AppSettings["Version"].ToString();
    string InstanceID = ConfigurationManager.AppSettings["InstanceID"].ToString();
    int MaxNoOfUser = Convert.ToInt16(ConfigurationManager.AppSettings["MaxNoOfUser"].ToString());
    string ClientName = ConfigurationManager.AppSettings["ClientName"].ToString();
    int usercount;
    string LicenseKey;
    string Errormessage;
    string LicenseStatus;
    string ErrorMessage;
    #endregion

    #region PROPERTIES
    [CreateNew]
    public ProcessingPresenter Presenter
    {
        get
        {
            return this._presenter;
        }
        set
        {
            if (value == null)
                throw new ArgumentNullException("value");

            this._presenter = value;
            this._presenter.View = this;
        }
    }
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {

        try
        {
            if (Session["UserDetails"] != null)
            {
                Session["CurrentPage"] = "Processing";
                objUser = (UserSession)Session["userdetails"];
                LoginId = objUser.UserId.ToString();



                if (!this.IsPostBack)
                {
                    //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                    string PKeyword = (Session["PasswordExpiration"]).ToString();
                    if (PKeyword == "yes")
                    {
                        Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                    }
                    //SAST fixes
                    if (Request.QueryString.ToString() != null)
                    {
                        NameValueCollection nvc = HttpUtility.ParseQueryString(Server.HtmlDecode(Server.UrlDecode(Request.QueryString.ToString())));

                        hdnPage.Value = nvc["PreviousPage"];

                        hdnCaseId.Value = nvc["CaseId"];

                        hdnEmailBoxId.Value = nvc["EMailBox"];
                        Session["ProcessingEmailbox"] = nvc["EMailBox"];

                        hdnStatusId.Value = nvc["Status"];

                        hdnQueryStringstatusId.Value = hdnStatusId.Value;


                    }

                    hdnCompleteAndSend.Value = "false";
                    ViewState["LoadNextcase"] = false;
                    if (objUser.RoleName == "Super Admin" || objUser.RoleName == "Admin" || objUser.RoleName == "Team Lead")
                    {

                        btnCaseSubmitandClose.Attributes.Add("onClick", "return false");
                        btnCompleteSend.Attributes.Add("onClick", "return false");

                    }
                    LoadCaseDetails();

                    this._presenter.OnViewInitialized();

                    //195174 GMB to GMb
                    forwardtoGMB.Visible = false;

                    //if (hdnForwardedToGMB.Value == "True" && lblcaseType.InnerText.ToLower().ToString() != "manual case")
                    //{
                    //    forwardtoGMB.Visible = false;
                    //}
                    //else 
                    //if (hdnForwardedToGMB.Value == "True" && lblcaseType.InnerText.ToLower().ToString() == "manual case")
                    //{
                    //    forwardtoGMB.Visible = true;
                    //}
                    //else if (hdnForwardedToGMB.Value != "True")
                    //{
                    //    forwardtoGMB.Visible = true;
                    //}
                    //else
                    //{
                    //    forwardtoGMB.Visible = false;
                    //}

                }

                if (lblStatusHdr.InnerText == "Completed")
                {
                    btnCaseSubmitandClose.Attributes.Add("onClick", "return false");
                    btnCompleteSend.Attributes.Add("onClick", "return false");

                }

                if (objUser.RoleId == 4)
                {
                    DataSet dsnew = new DataSet();
                    dsnew = _presenter.LoadEMailBoxDetails(Convert.ToInt32(hdnEmailBoxId.Value), objUser.UserId);
                    if (dsnew.Tables[0].Rows[0][0].ToString() != "1")
                    {
                        Response.Redirect(@"~\Errors\UserAccess_Denied.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    }
                }

                if (IsPostBack)
                {
                    _presenter.LoadConversationsList(Convert.ToInt32(hdnCaseId.Value));
                    _presenter.LoadAttachmentList(Convert.ToInt64(hdnConversationId.Value));
                    DisplayConversation(Convert.ToInt32(hdnConversationId.Value));
                    _presenter.BindAuditLog(Convert.ToInt32(hdnCaseId.Value));
                    _presenter.BindComments(Convert.ToInt32(hdnCaseId.Value));

                    if (GMBtoGMBCaseTraversal == "ON")
                    {
                        if (Convert.ToBoolean(hdnFollowUp.Value))
                        {
                            forwardtoGMB.Visible = true;
                        }

                        if (hdnForwardedToGMB.Value == "True" && lblcaseType.InnerText.ToLower().ToString() != "manual case")
                        {
                            forwardtoGMB.Visible = false;
                        }
                        else if (hdnForwardedToGMB.Value == "True" && lblcaseType.InnerText.ToLower().ToString() == "manual case")
                        {
                            forwardtoGMB.Visible = true;
                        }
                        else if (hdnForwardedToGMB.Value != "True")
                        {
                            forwardtoGMB.Visible = true;
                        }
                        else
                        {
                            forwardtoGMB.Visible = false;
                        }

                    }


                }
                if (Request.QueryString["PreviousPage"] != "ProcessingNewUI")
                {
                    Session["prevurl"] = Request.QueryString;
                    Session["prevcaseid"] = hdnCaseId.Value;
                }
                StringBuilder sb = new StringBuilder();
                sb.Append("<ul>");
                string ccid = GetChildCaseDetails();
                if (ccid == "0")
                {
                    sb.Append("</ul>");
                    lblCaseTravesal.Visible = false;
                    previous.Visible = true;
                    next.Visible = true;
                }
                else
                {
                    lblCaseTravesal.Visible = true;
                    previous.Visible = false;
                    next.Visible = false;
                    sb.Append(ccid);
                    sb.Append("</ul>");
                    Listitems.Controls.Add(new Literal { Text = sb.ToString() });
                }
                if (hdnPage.Value == "Search" || hdnPage.Value == "QCWorkQueue")
                {
                    previous.Visible = false;
                    next.Visible = false;
                }

                LoadDynamicControls();
                ////dynamic workflow chnage
                // DataSet dsStatus = (DataSet)(Session["StatusMasterData"]);
                //List<string> lstStatus = new List<string>();
                //lstStatus = dsStatus.Tables[0].AsEnumerable().Where(r => true.Equals(r.Field<bool>("IsFinalStatus")))
                //                   .Select(r => r.Field<string>("StatusId")).ToList();
                //if ((Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstStatus[0])))
                //{
                //    if (btnDFSave.Visible)
                //    {
                //        txtComments.Style.Add("height", "110px");
                //    }
                //    else
                //    {
                //        txtComments.Style.Add("height", "232px");
                //    }
                //}
                //else
                //{
                if (btnDFSave.Visible)
                {
                    txtComments.Style.Add("height", "130px");
                }
                else
                {
                    txtComments.Style.Add("height", "245px");
                }
                // }
                DisbledTopMenu();
                //show or hide submit button based on configuration
                if (System.Configuration.ConfigurationManager.AppSettings.Get("AllowAutoAllocation").ToString().ToLower() == "no")
                {
                    //commented by saranya
                    //  btnCaseSubmit.Visible = false;
                }
                ScriptManager objScript = (ScriptManager)this.Master.FindControl("scriptmanager1");

                //Pranay 22 December 2016 for binding button to Script Manager
                Button objFUAttachments = (Button)updCaseDetails.FindControl("btnUpload");
                objScript.RegisterPostBackControl(objFUAttachments);



                //OpenSendMailPopup(false);
                this._presenter.OnViewLoaded();
                if (hdnPage.Value == "QCWorkQueue") { btnCompleteSend.Visible = false; }
                if (hdnStatusId.Value == "5") { btnCompleteSend.Visible = false; }
                //hide reply reply all and forward when TL logs in
                //commented by saranya - to be reimplemented
                //if (objUser.RoleId == Convert.ToInt32(Constants.Constant.UserRole.TeamLead))
                //{
                //    radioReplyOption.Visible = false;
                //}

                divMailEditor.Visible = false;
                divMailContentParent.Visible = true;
                GetAutoReply();

                ProductLicense();
                if (LicenseStatus == "False")
                {
                    Disablecontrol();
                }
                if (ErrorMessage.CompareTo("Product License Key will expire in a week") == 0)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert(' Product License Key will expire in a week Please contact EMT team for Reneual of License key... ');", true);
                }

            }
            else
            {
                Response.Redirect(@"~\Errors\SessionExpired.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | Page_Load()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs | Page_Load()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), true);
        }
    }



    #region PRIVEATE METHODS
    protected void btnDiscard_Draft(object sender, EventArgs e)
    {
        try
        {

            _presenter.DeleteTotalDraft(Convert.ToInt64(hdnCaseId.Value));
            htmlEditorMailBody.InnerHtml = string.Empty;
            chkshowquotedtxt.Disabled = false;
            chkshowquotedtxt.Checked = false;

            chkishighimp.Checked = false;
            txtTo.Text = string.Empty;
            txtCC.Text = string.Empty;

            foreach (HtmlTableRow row in tblAttachments.Rows)
            {
                if (((HtmlInputCheckBox)row.Cells[0].Controls[0]).Checked)
                {
                    ((HtmlInputCheckBox)row.Cells[0].Controls[0]).Checked = false;
                }
            }

            //ListItem l = radioReplyOption.Items.FindByValue("Reply");
            //l.Selected = true;

            //DataSet dsresult = new DataSet();
            //dsresult = this._presenter.GetSignature(LoginId);

            lblDrafttext.Text = "Last Draft version Deleted Sucessfully";
            //OpenSendMailPopup(true);

            //Pranay 23 Dec 2016 

            divMailEditor.Visible = true;
            divMailContentParent.Visible = false;
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | btnDiscard_Draft()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs | btnDiscard_Draft()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }

    }
    protected void btnDraft_Save(object sender, EventArgs e)
    {
        try
        {
            Hashtable hsDraft = new Hashtable();
            hsDraft.Add("@CASEID", Convert.ToInt32(hdnCaseId.Value));
            hsDraft.Add("@AssignedId", objUser.UserId);
            string selectedRadioButton;
            if (hdnreplyvalue != null)
                selectedRadioButton = hdnreplyvalue.ToString();
            else
                selectedRadioButton = "1";
            //string selectedRadioButton = "one";
            string toAddress = txtTo.Text;
            string ccAddress = txtCC.Text;

            int chkHighImportance;
            if (chkishighimp.Checked == true)
            {
                chkHighImportance = 1;
            }
            else
            {
                chkHighImportance = 0;
            }

            int chkshowQuotedText;
            if (chkshowquotedtxt.Checked == true)
            {
                chkshowQuotedText = 1;
            }
            else
            {
                chkshowQuotedText = 0;
            }

            hsDraft.Add("@ToAddress", toAddress);
            hsDraft.Add("@CcAddress", ccAddress);
            hsDraft.Add("@RadioButtonSelected", selectedRadioButton);
            hsDraft.Add("@IsHighImportance", chkHighImportance);
            hsDraft.Add("@ShowQuotedText", chkshowQuotedText);

            string strattachrowids = string.Empty;
            //foreach (GridViewRow gvrow in GvAttachments.Rows)
            foreach (HtmlTableRow row in tblAttachments.Rows)
            {

                //string temp = tblAttachments.Rows[0].FindControl("AttachmentID").ToString();
                if (((HtmlInputCheckBox)row.Cells[0].Controls[0]).Checked)
                {
                    EMTWebApp.Constants.Attachment att = new EMTWebApp.Constants.Attachment();
                    String attachmentId = ((HtmlAnchor)row.Cells[2].Controls[0]).ID;
                    // Label lblattachmentid = (Label)row.FindControl("lblattachmentid");


                    strattachrowids = strattachrowids + attachmentId + ',';
                }
            }

            hsDraft.Add("@SelectedAttachments", strattachrowids);
            // htmlEditorMailBody.;
            string Source = hdnEditorMailBodyContent.Value;
            Session["DraftDetails"] = hdnEditorMailBodyContent.Value;
            //byte[] toBytes = Encoding.ASCII.GetBytes(Source);
            // hsDraft.Add("@Content", toBytes);
            DateTime now = DateTime.Now;
            hsDraft.Add("@currentdate", now);
            var imgSrcMatches_Draft = System.Text.RegularExpressions.Regex.Matches(Source,
                //string.Format("<img.+?src=[\"'](.+?)[\"'].*?>"),  
                               string.Format("<img.*src=[\"'](.+?)[\"'].*>"),
                                           RegexOptions.CultureInvariant | RegexOptions.IgnoreCase |
                                           RegexOptions.Multiline);
            List<string> imgSrcs_Draft = new List<string>();
            //int MaxNo = 0;
            // MaxNo = HelperMethods.GetMaxNoScreenshotCaseId(Convert.ToInt64(hdnCaseId.Value));

            foreach (Match match in imgSrcMatches_Draft)
            {
                string srcvalue = match.Groups[1].Value;
                try
                {
                    if (srcvalue.Contains("data:image/png;base64"))
                    {
                        imgSrcs_Draft.Add(srcvalue.Replace("data:image/png;base64,", ""));

                        byte[] imgArray = Convert.FromBase64String(srcvalue.Replace("data:image/png;base64,", "").Replace(' ', '+'));
                        //TotalMailAttachmentSize += imgArray.Length;
                    }
                    else if (srcvalue.Contains("data:image/jpeg;base64,"))
                    {
                        imgSrcs_Draft.Add(srcvalue.Replace("data:image/jpeg;base64,", ""));

                        byte[] imgArray = Convert.FromBase64String(srcvalue.Replace("data:image/jpeg;base64,", "").Replace(' ', '+'));
                        // TotalMailAttachmentSize += imgArray.Length;
                    }
                    else
                    {
                        byte[] imageArray;
                        //try
                        //{
                        using (var webClient = new WebClient())
                        {
                            imageArray = webClient.DownloadData(srcvalue);
                        }

                        //System.Threading.Thread.Sleep(2000);
                        //TotalMailAttachmentSize += imageArray.Length;
                        string base64ImageRepresentation = Convert.ToBase64String(imageArray);

                        if (base64ImageRepresentation.Contains("data:image/png;base64,"))
                            imgSrcs_Draft.Add(base64ImageRepresentation.Replace("data:image/png;base64,", ""));

                        else if (base64ImageRepresentation.Contains("data:image/jpeg;base64,"))
                            imgSrcs_Draft.Add(base64ImageRepresentation.Replace("data:image/jpeg;base64,", ""));
                        else
                            imgSrcs_Draft.Add(base64ImageRepresentation);
                    }

                    Source = Source.Replace(srcvalue, "cid:image000" + ".png");
                    // MaxNo++;
                }
                catch
                {

                }


            }
            if (imgSrcs_Draft.Count > 0)
            {
                IList InlineAttachments;
                List<EMTWebApp.Constants.Attachment> lstInline = new List<EMTWebApp.Constants.Attachment>();

                int aa = 0;

                // aa = HelperMethods.GetMaxNoScreenshotCaseId(Convert.ToInt64(hdnCaseId.Value));

                //aa = HelperMethods.GetMaxNoScreenshotCaseId(Convert.ToInt64(hdnCaseId.Value));


                foreach (string imgcontent in imgSrcs_Draft)
                {
                    EMTWebApp.Constants.Attachment at = new EMTWebApp.Constants.Attachment();

                    string Name = "";


                    //if (aa > 99)
                    Name = "cid:image000" + ".png";
                    // Name = "cid:image000" + aa + ".png";
                    // else if (aa >= 10 && aa <= 99)
                    //   Name = "cid:image0" + aa + ".png";
                    //else
                    //  Name = "cid:image00" + aa + ".png";



                    if (aa > 99)
                        Name = "cid:image0" + aa + ".png";
                    else if (aa >= 10 && aa <= 99)
                        Name = "cid:image00" + aa + ".png";
                    else
                        Name = "cid:image000" + aa + ".png";


                    at.FileName = Name;
                    at.FileType = ".png";
                    //at.FileContent = Convert.FromBase64String(imgcontent.Replace(" ", "+").ToString());
                    //Encryption
                    //string actualInlineimg = imgcontent.Replace(" ", "+");
                    //cryptInfo.CryptKey = cipherpassword;
                    //cryptInfo.ValueToCrypt = actualInlineimg;
                    //string encryptedInlineimg = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);                
                    //at.FileContent = Convert.FromBase64String(encryptedInlineimg);
                    at.FileContent = HelperMethods.EncryptAttachments(Convert.FromBase64String(imgcontent.Replace(" ", "+").ToString()));
                    at.AttachmentTypeId = 3;

                    lstInline.Add(at);
                    //aa = aa + 1;

                }
                if (lstInline.Count > 0)
                {
                    InlineAttachments = lstInline;
                    _presenter.DeleteLastDraft(Convert.ToInt64(hdnCaseId.Value));
                    _presenter.UploadAttachment_Draft(Convert.ToInt64(hdnCaseId.Value), InlineAttachments, objUser.UserId); //Upload followup file to DB
                }

            }
            else
            {
                _presenter.DeleteLastDraft(Convert.ToInt64(hdnCaseId.Value));
            }
            // string plainbody = Regex.Replace(htmlEditorMailBody.Content, @"<(.|\n)*?>", string.Empty);
            // plainbody = plainbody.Replace("&nbsp;", "");
            //htmlEditorMailBody.Content = htmlEditorMailBody.Content.Replace(srcvalue, "cid:image00"+ ".png");
            // htmlEditorMailBody.Content = htmlEditorMailBody.Content.Replace(srcvalue, "cid:image00" + ".png");
            string plainbody = Source;
            //Encryption
            //htmlEditorMailBody.Content = "Hello Worlds";
            //cryptInfo.CryptKey = cipherpassword;
            //cryptInfo.ValueToCrypt = plainbody;
            //string encryptedPlainBody = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
            string encryptedPlainBody = HelperMethods.EncryptString(plainbody);
            byte[] bt = Encoding.ASCII.GetBytes(encryptedPlainBody);
            //hsDraft.Add("@attachment", "fortesting");
            hsDraft.Add("@Content", bt);
            int count = this._presenter.draft_save(hsDraft);
            // htmlEditorMailBody.Content = Source;

            //Pranay 24 January 2017
            //String zonedDateTime = ISSWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"), true, objUser.TimeZone, false);
            DateTime zonedDateTime = TimeZoneInfo.ConvertTime(DateTime.Now,
                  TimeZoneInfo.FindSystemTimeZoneById(objUser.TimeZone));
            //lblDrafttext.Text = "Draft Updated on " + DateTime.Now;
            lblDrafttext.Text = "Draft Updated on " + zonedDateTime;
            // OpenSendMailPopup(true);
            divMailEditor.Visible = true;
            divMailContentParent.Visible = false;

            htmlEditorMailBody.InnerHtml = (string)Session["Draftdetails"];
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | btnDraft_Save()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs | btnDraft_Save()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }
    }
    /// <summary>
    /// Binds attachment details 
    /// </summary>
    ///<returns> void </returns>

    /// <summary>
    /// Returns attachment type id
    /// </summary>
    ///<returns> AttachmentTypeID </returns>
    private int GetAttachmentType(string AttachmentType)
    {
        int AttachmentTypeID = 0;
        switch (AttachmentType)
        {
            case Constant.FileSent:
                AttachmentTypeID = (int)Constant.AttachmentType.FileSent;
                break;
            case Constant.FileReceived:
                AttachmentTypeID = (int)Constant.AttachmentType.FileReceived;
                break;
            case "Inline Images":
                AttachmentTypeID = 3;
                break;
            case "GMB Inline Images":
                AttachmentTypeID = 4;
                break;
        }
        return AttachmentTypeID;
    }

    DataSet IProcessingView.BindEmailBoxDetails
    {
        set
        {
            if (value != null && value.Tables.Count > 0 && value.Tables[0].Rows.Count > 0)
            {
                objEMailCredentials.MailBoxEmailId = value.Tables[0].Rows[0]["EMAILBOXADDRESS"].ToString();
                objEMailCredentials.LoginEmailId = value.Tables[0].Rows[0]["LOGINEMAILID"].ToString();
                
                if (encryptionmode == "ON")
                {
                    objEMailCredentials.PKeyword = HelperMethods.DecryptString(value.Tables[0].Rows[0]["PASSWORD"].ToString());
                }
                else
                {
                    objEMailCredentials.PKeyword = HelperMethods.DecryptValue(value.Tables[0].Rows[0]["PASSWORD"].ToString());
                }
                
                objEMailCredentials.ServiceURL = value.Tables[0].Rows[0]["EMAILFOLDERPATH"].ToString();
                objEMailCredentials.isReplyNotRequired = Convert.ToBoolean(value.Tables[0].Rows[0]["ISREPLYNOTREQUIRED"]);
                objEMailCredentials.isLocked = Convert.ToBoolean(value.Tables[0].Rows[0]["ISLOCKED"]);
                Session["EmailCredentials"] = objEMailCredentials;
            }
        }
    }
    /// <summary>
    /// Binds status details 
    /// </summary>
    ///<returns> void </returns>
    DataSet IProcessingView.BindStatus
    {
        set
        {
            //dynamic workflow chnage
            int selectedStatus = Convert.ToInt32(hdnStatusId.Value);
            if (value != null&&value.Tables[0]!=null&&value.Tables[0].Rows.Count>0)
            {
                var dsStatusTransition = from myRow in value.Tables[0].AsEnumerable()
                                         where myRow.Field<int>("FromStatusID") == selectedStatus
                                         select myRow;
                ddlStatus.DataSource = dsStatusTransition.CopyToDataTable();
                ddlStatus.DataTextField = "ToStatus";
                ddlStatus.DataValueField = "ToStatusID";
                ddlStatus.DataBind();
                ddlStatus.Items.Insert(0, new ListItem("Status", "0"));
            }
            else
            {
                ddlStatus.DataSource = null;
                ddlStatus.DataBind();
                ddlStatus.Items.Insert(0, new ListItem("Status", "0"));
            }
        }
    }
    /// <summary>
    /// Binds attachment details 
    /// </summary>
    ///<returns> void </returns>
    DataSet IProcessingView.GetAttachments
    {
        set
        {

            if (value != null && value.Tables.Count > 0 && value.Tables[0].Rows.Count > 0)
            {
                Session.Remove("UploadedAttachment");
                UploadedFileCollection.Clear();
                foreach (DataRow dr in value.Tables[0].Rows)
                {
                    EMTWebApp.Constants.Attachment at = new EMTWebApp.Constants.Attachment();
                    at.AttachmentId = Convert.ToInt32(dr["ATTACHMENTID"]);
                    at.FileName = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(dr["FileName"].ToString().Replace(@"\", "").Replace("..", ""), true);  //SAST fix for "Path Traversal" - varma
                    at.FileContent = (byte[])dr["Content"];
                    at.AttachmentTypeId = Convert.ToInt32(System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode((GetAttachmentType(dr["ATTACHMENTTYPE"].ToString().Replace(@"\", "").Replace("..", ""))).ToString(), true)); //SAST fix for "Path Traversal" - varma
                    at.AttachmentType = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(dr["ATTACHMENTTYPE"].ToString().Replace(@"\", "").Replace("..", ""), true); //SAST fix for "Path Traversal" - varma
                    //Bug fix no 4294
                    DateTime CreatDate = DateTime.Parse(dr["CREATEDDATE"].ToString());
                    at.CreatedDate = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(CreatDate.ToString("dd/MM/yyyy HH:mm:ss"), true);
                    UploadedFileCollection.Add(at);
                }
                Session["UploadedAttachment"] = UploadedFileCollection;
            }
            else
            {
                Session.Remove("UploadedAttachment");
                UploadedFileCollection.Clear();
            }
            BindUploadedAttachmentGrid();
        }
    }


    DataSet IProcessingView.GetConversations
    {
        set
        {
            if (value != null && value.Tables.Count > 0 && value.Tables[0].Rows.Count > 0)
            {
                Session.Remove("EmailConversations");
                EmailConversationCollection.Clear();
                foreach (DataRow dr in value.Tables[0].Rows)
                {
                    EMTWebApp.Constants.Conversation conv = new EMTWebApp.Constants.Conversation();
                    conv.ConversationId = Convert.ToInt32(dr["CONVERSATIONID"]);
                    conv.Subject = (dr["SUBJECT"]).ToString();
                    conv.Content = (byte[])dr["Content"];
                    conv.FileType = "text/html";
                    conv.ConversationDate = dr["ConversationDate"].ToString();
                    conv.EmailFrom = dr["EmailFrom"].ToString();
                    conv.EmailTo = dr["EmailTo"].ToString();
                    conv.EmailCc = dr["EmailCc"].ToString();
                    conv.AttachmentType = dr["AttachmentType"].ToString();
                    //  conv.attac = Convert.ToInt32(System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode((GetAttachmentType(dr["ATTACHMENTTYPE"].ToString().Replace(@"\", "").Replace("..", ""))).ToString(), true)); //SAST fix for "Path Traversal" - varma
                    //   conv.AttachmentType = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(dr["ATTACHMENTTYPE"].ToString().Replace(@"\", "").Replace("..", ""), true); //SAST fix for "Path Traversal" - varma
                    //Bug fix no 4294
                    DateTime CreatDate = DateTime.Parse(dr["CREATEDDATE"].ToString());
                    conv.CreatedDate = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(CreatDate.ToString("dd/MM/yyyy HH:mm:ss"), true);
                    EmailConversationCollection.Add(conv);
                }
                Session["EmailConversations"] = EmailConversationCollection;
                if (!IsPostBack)
                {
                    hdnConversationId.Value = value.Tables[0].Rows[0]["ConversationId"].ToString();
                    string actualMailcontent = System.Text.Encoding.UTF8.GetString((Byte[])value.Tables[0].Rows[0]["Content"]);
                    string decryptedValue = HelperMethods.DecryptString(actualMailcontent);
                    strConversation = "</br></br>" + decryptedValue;
                    Session["strConversation"] = strConversation;
                }
                BindConversations();
            }
        }
    }

    DataSet IProcessingView.BindComments
    {
        set
        {
            if (value != null && value.Tables.Count > 0 && value.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < value.Tables[0].Rows.Count; i++)
                {

                    HtmlTableRow tr = new HtmlTableRow();
                    HtmlTableCell tdComments = new HtmlTableCell();
                    HtmlTableCell tdCreatedBy = new HtmlTableCell();
                    HtmlTableCell tdCreatedDate = new HtmlTableCell();

                    tdComments.InnerHtml = value.Tables[0].Rows[i]["COMMENTS"].ToString();
                    tdCreatedBy.InnerHtml = value.Tables[0].Rows[i]["USERNAME"].ToString();
                    DateTime dateStarted = DateTime.ParseExact(value.Tables[0].Rows[i]["CREATEDDATE"].ToString(), "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                    tdCreatedDate.InnerHtml = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(dateStarted.ToString("dd/MM/yyyy HH:mm:ss"), true, objUser.TimeZone, false);

                    tr.Controls.Add(tdComments);
                    tr.Controls.Add(tdCreatedBy);
                    tr.Controls.Add(tdCreatedDate);

                    if (i % 2 == 0)
                        tr.Attributes.Add("class", "innerdata odd");
                    else
                        tr.Attributes.Add("class", "innerdata even");
                    tblComments.Controls.Add(tr);


                }
            }
            else
            {
                HtmlTableRow tr = new HtmlTableRow();
                HtmlTableCell tdComments = new HtmlTableCell();
                HtmlTableCell tdCreatedBy = new HtmlTableCell();
                HtmlTableCell tdCreatedDate = new HtmlTableCell();
                tdComments.InnerHtml = "";
                tdCreatedBy.InnerHtml = "  NO RECORDS FOUND ";
                tdCreatedDate.InnerHtml = "";
                tr.Controls.Add(tdComments);
                tr.Controls.Add(tdCreatedBy);
                tr.Controls.Add(tdCreatedDate);
                tr.Attributes.Add("class", "innerdata even");
                tblComments.Controls.Add(tr);
            }
        }
    }


    DataSet IProcessingView.BindAuditLog
    {
        set
        {
            if (value != null && value.Tables.Count > 0 && value.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < value.Tables[0].Rows.Count; i++)
                {
                    HtmlTableRow tr = new HtmlTableRow();
                    HtmlTableCell tdFromStatus = new HtmlTableCell();
                    HtmlTableCell tdToStatus = new HtmlTableCell();
                    HtmlTableCell tdActionBy = new HtmlTableCell();
                    HtmlTableCell tdFromDate = new HtmlTableCell();
                    HtmlTableCell tdToDate = new HtmlTableCell();
                    tdFromStatus.InnerHtml = value.Tables[0].Rows[i]["FromStatus"].ToString();
                    tdToStatus.InnerHtml = value.Tables[0].Rows[i]["ToStatus"].ToString();
                    tdActionBy.InnerHtml = value.Tables[0].Rows[i]["UserName"].ToString();
                    //tdFromDate.InnerHtml = value.Tables[0].Rows[i]["StartTime"].ToString();
                    //Pranay 11 January 2017 -- for changing start time as per time zone of user
                    if (value.Tables[0].Rows[i]["StartTime"].ToString() != "-")
                    {
                        // DateTime dateStarted = Convert.ToDateTime(value.Tables[0].Rows[i]["StartTime"].ToString());
                        DateTime dateStarted = DateTime.ParseExact(value.Tables[0].Rows[i]["StartTime"].ToString(), "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                        tdFromDate.InnerHtml = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(dateStarted.ToString("dd/MM/yyyy HH:mm:ss"), true, objUser.TimeZone, false);
                    }
                    else
                    {
                        tdFromDate.InnerHtml = value.Tables[0].Rows[i]["StartTime"].ToString();
                    }
                    //tdToDate.InnerHtml = value.Tables[0].Rows[i]["EndTime"].ToString();
                    //DateTime dateEnded = Convert.ToDateTime(value.Tables[0].Rows[i]["EndTime"].ToString());
                    DateTime dateEnded = DateTime.ParseExact(value.Tables[0].Rows[i]["EndTime"].ToString(), "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                    tdToDate.InnerHtml = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(dateEnded.ToString("dd/MM/yyyy HH:mm:ss"), true, objUser.TimeZone, false);
                    tr.Controls.Add(tdFromStatus);
                    tr.Controls.Add(tdToStatus);
                    tr.Controls.Add(tdActionBy);
                    tr.Controls.Add(tdFromDate);
                    tr.Controls.Add(tdToDate);
                    if (i % 2 == 0)
                        tr.Attributes.Add("class", "innerdata odd");
                    else
                        tr.Attributes.Add("class", "innerdata even");
                    tblAuditLog.Controls.Add(tr);
                }
            }
            else
            {
                HtmlTableRow tr = new HtmlTableRow();
                HtmlTableCell tdComments = new HtmlTableCell();
                HtmlTableCell tdCreatedBy = new HtmlTableCell();
                HtmlTableCell tdCreatedDate = new HtmlTableCell();
                tdComments.InnerHtml = "";
                tdCreatedBy.InnerHtml = "  NO RECORDS FOUND ";
                tdCreatedDate.InnerHtml = "";
                tr.Controls.Add(tdComments);
                tr.Controls.Add(tdCreatedBy);
                tr.Controls.Add(tdCreatedDate);
                tr.Attributes.Add("class", "innerdata even");
                tblAuditLog.Controls.Add(tr);

            }
        }
    }

    public void BindUploadedAttachmentGrid()
    {
        try
        {
            while (tblAttachments.Rows.Count > 0)
            {
                tblAttachments.Rows.RemoveAt(tblAttachments.Rows.Count - 1);
            }
            divAttachments.Visible = false;
            divAttGrid.Visible = false;
            if (Session["UploadedAttachment"] != null)
            {
                UploadedFileCollection = (List<EMTWebApp.Constants.Attachment>)Session["UploadedAttachment"];
            }
            DataTable dtAttachments = UploadedFileCollection.ToDataTable();
            if (dtAttachments != null && dtAttachments.Rows.Count > 0)
            {
                divAttachments.Visible = true;

                for (int i = 0; i < dtAttachments.Rows.Count; i++)
                {

                    HtmlTableRow tr = new HtmlTableRow();
                    HtmlTableCell tdCheckbox = new HtmlTableCell();
                    HtmlTableCell tdFileType = new HtmlTableCell();
                    HtmlTableCell tdFileName = new HtmlTableCell();
                    HtmlTableCell tdCreatedDate = new HtmlTableCell();
                    HtmlInputCheckBox checkbox = new HtmlInputCheckBox();
                    //SAST fixes
                    checkbox.ID = "chk" + System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(dtAttachments.Rows[i]["AttachmentId"].ToString(), true);
                    tdCheckbox.Controls.Add(checkbox);
                    tdCheckbox.Style.Add("width", "30");
                    tdFileType.InnerHtml = dtAttachments.Rows[i]["AttachmentType"].ToString();
                    HtmlAnchor attachment = new HtmlAnchor();
                    attachment.ID = dtAttachments.Rows[i]["AttachmentId"].ToString();

                    attachment.ServerClick += new EventHandler(AttachmentLink_Click);
                    attachment.InnerHtml = dtAttachments.Rows[i]["FileName"].ToString();
                    tdFileName.Controls.Add(attachment);

                    //Pranay 6 January 2017 -- changing createdDate of Attachment to TimeZone of User
                    tdCreatedDate.InnerHtml = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(dtAttachments.Rows[i]["CreatedDate"].ToString(), true, objUser.TimeZone, false);
                    tr.Controls.Add(tdCheckbox);
                    tr.Controls.Add(tdFileType);
                    tr.Controls.Add(tdFileName);
                    tr.Controls.Add(tdCreatedDate);
                    divAttGrid.Visible = true;
                    divAttachments.Visible = true;
                    tblAttachments.Rows.Add(tr);


                    if (dtAttachments.Rows[i]["FILENAME"].ToString().Contains(".html"))
                    {
                        string strfilename = dtAttachments.Rows[i]["FILENAME"].ToString().ToLower().Replace(@"\", "").Replace("..", "");//SAST fix for Path Traversal - varma
                        //if ((strfilename == "followup.html" || strfilename == "followup.htm" || strfilename == "body.html" || strfilename == "body.htm" || strfilename == "forwardtogmb.html" || strfilename == "forwardtogmb.htm"))
                        //{
                        //    //DisplayAttachment(Convert.ToInt32(dtAttachments.Rows[i]["AttachmentId"].ToString()));
                        //    //if (strfilename == "followup.html" || strfilename == "followup.htm")
                        //    //{
                        //    //    lnkFollowupEmail.Visible = true;
                        //    //    lnkFollowupEmail.ID = dtAttachments.Rows[i]["AttachmentId"].ToString();
                        //    //    lnkFollowupEmail.ServerClick += new EventHandler(AttachmentLink_Click);
                        //    //}

                        //    //if (strfilename == "body.html" || strfilename == "body.htm")
                        //    //{
                        //    //    lnkInitialEmail.Visible = true;
                        //    //    lnkInitialEmail.ID = dtAttachments.Rows[i]["AttachmentId"].ToString();
                        //    //    lnkInitialEmail.ServerClick += new EventHandler(AttachmentLink_Click);
                        //    //}
                        //    //if (GMBtoGMBCaseTraversal == "ON")
                        //    //{
                        //    //    if (strfilename == "forwardtogmb.html" || strfilename == "forwardtogmb.htm")
                        //    //    {
                        //    //        lnkForwardToGMBEmail.Visible = true;
                        //    //        lnkForwardToGMBEmail.ID = dtAttachments.Rows[i]["AttachmentId"].ToString();
                        //    //        lnkForwardToGMBEmail.ServerClick += new EventHandler(AttachmentLink_Click);
                        //    //    }
                        //    //}
                        //}
                    }
                }
            }
            else
            {
            }

        }
        catch (Exception ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | BindUploadedAttachmentGrid()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }
    }

    /// <summary>
    /// Bind conversations happened in the email to the Grid 
    /// </summary>
    public void BindConversations()
    {
        if (Session["EmailConversations"] != null)
        {
            EmailConversationCollection = (List<EMTWebApp.Constants.Conversation>)Session["EmailConversations"];
        }
        DataTable dtConversations = EmailConversationCollection.ToDataTable();
        if (dtConversations != null && dtConversations.Rows.Count > 0)
        {
            //divAttachments.Visible = true;//check

            while (tblConversations.Rows.Count > 2)
            {
                tblConversations.Rows.RemoveAt(tblConversations.Rows.Count - 1);
            }


            for (int i = 0; i < dtConversations.Rows.Count; i++)
            {
                HtmlTableRow tr = new HtmlTableRow();
                HtmlTableCell tdSubject = new HtmlTableCell();
                HtmlTableCell tdFrom = new HtmlTableCell();
                HtmlTableCell tdDate = new HtmlTableCell();

                tdFrom.InnerHtml = dtConversations.Rows[i]["EmailFrom"].ToString();
                HtmlAnchor conversation = new HtmlAnchor();
                conversation.ID = dtConversations.Rows[i]["ConversationId"].ToString();

                conversation.ServerClick += new EventHandler(ConversationLink_Click);
                conversation.InnerHtml = dtConversations.Rows[i]["Subject"].ToString();
                tdSubject.Controls.Add(conversation);

                //Pranay 6 January 2017 -- changing createdDate of Attachment to TimeZone of User
                tdDate.InnerHtml = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(dtConversations.Rows[i]["CreatedDate"].ToString(), true, objUser.TimeZone, false);
                tr.Controls.Add(tdSubject);
                tr.Controls.Add(tdFrom);
                tr.Controls.Add(tdDate);

                if (i % 2 == 0)
                    tr.Attributes.Add("class", "innerdata odd");
                else
                    tr.Attributes.Add("class", "innerdata even");

                tblConversations.Controls.Add(tr);
            }
        }
    }

    /// <summary>
    /// Binds clarification reset reasons 
    /// </summary>
    ///<returns> void </returns>
    DataSet IProcessingView.BindClarificationResetReason
    {
        set
        {
            if (value != null && value.Tables.Count > 0 && value.Tables[0].Rows.Count > 0)
            {
                //ddlResetReason.DataSource = value.Tables[0];
                //ddlResetReason.DataTextField = "ResetReason";
                //ddlResetReason.DataValueField = "ResetReasonID";
                //ddlResetReason.DataBind();
                //ddlResetReason.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                //ddlResetReason.DataSource = null;
                //ddlResetReason.DataBind();
                //ddlResetReason.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
    }
    /// <summary>
    /// Redirects to previous page based on the inout parameter
    /// </summary>
    ///<returns> void </returns>
    private void RedirecttoPreviousPage(string Page)
    {
        try
        {
            string PageName = string.Empty;
            switch (Page)
            {
                //MailBoxId=1&StatusId=3&SelectedUserId=0
                case Constant.WorkQueuePage:
                    string SelectedUserId = !(Request.QueryString["SelectedUserId"] == null && Request.QueryString["SelectedUserId"] == "") ? Request.QueryString["SelectedUserId"].ToString() : "";
                    PageName = "WorkQueue.aspx?MailBoxId=" + hdnEmailBoxId.Value + "&StatusId=" + hdnQueryStringstatusId.Value + "&SelectedUserId=" + SelectedUserId;
                    break;
                case Constant.QCWorkQueuePage:
                    PageName = "QCWorkQueue.aspx";
                    break;
                case Constant.SearchPage:
                    PageName = "../Search/search.aspx?View=PreSearch";
                    break;
                case Constant.Processing:
                    string str = "";
                    if (Session["prevurl"] != null && Session["prevurl"].ToString() != "")
                    {
                        str = Session["prevurl"].ToString();
                    }
                    PageName = "ProcessingNewUI.aspx?" + str;
                    break;
                default:
                    if (string.IsNullOrEmpty(Request.QueryString["lftSelection"].ToString()))
                    {
                        PageName = "DashBoard.aspx";
                    }
                    else
                    {
                        PageName = "DashBoard.aspx?selectedMenu=" + Request.QueryString["lftSelection"].ToString() + "&SelectionText=" +
                            Request.QueryString["SelectionText"].ToString();

                    }
                    break;
            }
            Session["ProcessingEmailbox"] = null;

            ScriptManager.RegisterStartupScript(this, this.GetType(), "redirect", "location.href = '" + PageName + "'", true);
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.cs | RedirecttoPreviousPage()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.cs | RedirecttoPreviousPage()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }
    }
    /// <summary>
    /// To show the javascript alert message to the user
    /// </summary>
    ///<returns> void </returns>
    private void AlertBox(string Message)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert", "alert('" + Message + "');", true);
    }

    /// <summary>
    /// Open or close the Send email pop up based on the parameter
    /// </summary>
    /// <param name="Show">if the value is true open the send email pop up otherwise close it</param>
    ///<returns> void </returns>
    ///

    /// <summary>
    /// Enable or disable the input fields based on the user role and case status
    /// <param>EnableorDisable</param>
    /// </summary>
    ///<returns> void </returns>
    ///
    private void EnableInputFields(bool EnableorDisable)
    {
        try
        {
            objUser = (UserSession)Session["userdetails"];
            if (objUser != null)
            {
                if (((Convert.ToInt32(hdnStatusId.Value) == (int)Constant.Status.Completed) || (hdnCaseassignedTo.Value.ToString() != objUser.UserId.ToString())) || (int)objUser.RoleId != (int)Constant.UserRole.Processor)
                {
                    pnlAllocation.Disabled = true;
                    btnDFSave.Enabled = false;
                }
                else
                {
                    pnlAllocation.Disabled = false;
                    btnDFSave.Enabled = true;
                }
                //commented by saranya
                // fileupload.Enabled = EnableorDisable;
                // btnUpload.Enabled = EnableorDisable;

                ddlStatus.Enabled = EnableorDisable;
                // btnUpload.Enabled = EnableorDisable;

                //fileupload.Visible = EnableorDisable;
                txtComments.Disabled = !EnableorDisable;
                //  btnCaseSubmit.Enabled = EnableorDisable;

                //btnCompleteSend.Disabled = !EnableorDisable;
                //btnCaseSubmitandClose.Disabled = !EnableorDisable;
                //commented by saranya
                //if (EnableorDisable)
                //{
                //    this.Page.Form.DefaultButton = this.tpRatingCreation.FindControl("btnCaseSubmitandClose").UniqueID;
                //    this.Page.Form.DefaultFocus = this.tpRatingCreation.FindControl("ddlStatus").UniqueID;
                //}
                //else
                //{
                //    this.Page.Form.DefaultButton = this.tpRatingCreation.FindControl("btnCaseCancel").UniqueID;
                //}
            }
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.cs | EnableInputFields()");
            // errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.cs | EnableInputFields()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }
    }
    /// <summary>
    /// Add attachments to the file collection
    /// </summary>
    /// <param>UploadedFile</param>
    ///<returns> void </returns>
    ///
    private void Disablecontrol()
    {
        btnCaseSubmitandClose.Attributes.Add("onClick", "return false");
        btnCompleteSend.Attributes.Add("onClick", "return false");
        btnUpload.Attributes.Add("onClick", "return false");
        reply.Attributes.Add("onClick", "return false");
        lnkbtnFyiMail.Attributes.Add("onClick", "return false");
        replytoall.Attributes.Add("onClick", "return false");
        lnkreplytoall.Attributes.Add("onClick", "return false");
        lnkReply.Attributes.Add("onClick", "return false");
        forward.Attributes.Add("onClick", "return false");
        lnkforward.Attributes.Add("onClick", "return false");
        fileupload.Attributes.Add("onClick", "return false");
        // ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + Errormessage + "');", true);
        pnlAllocation.Disabled = true;
        btnDFSave.Enabled = false;
        ddlStatus.Enabled = false;
        txtComments.Disabled = true;
        btnCancel.Enabled = false;
        btnDFSave.Enabled = false;
        btnNext.Enabled = false;
        btnPrevious.Enabled = false;
        btnSend.Enabled = false;
        btnUpload.Enabled = false;
        btnShowQuotedText.Enabled = false;
        ddlAssignedTo.Enabled = false;
        if (ErrorMessage.CompareTo("Expired Product License Key") == 0)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Product License Key Expired , Please contact EMT team for Reneual of License key...');", true);
        }
        else
        {
            if (Errormessage.CompareTo("User Count exceeds the maximum value") == 0)
            {

                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('User Count exceeds the maximum value. Please Contact EMT Team for Higher version of User Count');", true);
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + Errormessage + "');", true);
            }

        }


    }
    private void AddAttachmentToFileCollection(HttpPostedFile UploadedFile)
    {
        try
        {
            if (UploadedFile.ContentLength > 0)
            {
                List<EMTWebApp.Constants.Attachment> FileUploadCollection = new List<EMTWebApp.Constants.Attachment>();
                EMTWebApp.Constants.Attachment attach = new EMTWebApp.Constants.Attachment();
                Stream strm = UploadedFile.InputStream;
                string fname = System.IO.Path.GetFileName(UploadedFile.FileName);
                byte[] buffer = new byte[strm.Length];
                strm.Read(buffer, 0, (int)strm.Length);
                strm.Close();

                //Encryption
                byte[] EncryptedFileContent;
                string encryptedValue;
                if (UploadedFile.ContentType == "text/html")
                {
                    encryptedValue = HelperMethods.EncryptString(System.Text.Encoding.UTF8.GetString(buffer));
                    EncryptedFileContent = HelperMethods.GetBytes(encryptedValue); //convert string to byte array        

                }
                else
                {
                    EncryptedFileContent = HelperMethods.EncryptAttachments(buffer);
                }

                int AttachmentId = 1;
                if (Session["UploadedAttachment"] != null)
                {
                    UploadedFileCollection = (List<EMTWebApp.Constants.Attachment>)Session["UploadedAttachment"];
                    AttachmentId = UploadedFileCollection.Count > 0 ? UploadedFileCollection[UploadedFileCollection.Count - 1].AttachmentId + 1 : 1;
                }
                //int AttachmentId = UploadedFileCollection.Count > 0 ? UploadedFileCollection[UploadedFileCollection.Count - 1].AttachmentId + 1 : 1;
                attach.AttachmentId = AttachmentId;
                attach.FileName = fname;
                attach.FileType = UploadedFile.ContentType;
                attach.FileContent = EncryptedFileContent;
                attach.AttachmentTypeId = (int)Constant.AttachmentType.FileSent;
                FileUploadCollection.Add(attach);
                _presenter.UploadAttachment(Convert.ToInt64(hdnConversationId.Value), FileUploadCollection, objUser.UserId);
                FileUploadCollection.Clear();
            }
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | AddAttachmentToFileCollection()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs | AddAttachmentToFileCollection()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }
    }


    /// <summary>
    /// To display chosen conversation and respective attachments in the reading pane
    /// </summary>
    /// <param name="ConversationID"></param>
    public void DisplayConversation(int ConversationID)
    {
        DataTable dtConversations = EmailConversationCollection.ToDataTable();
        EMTWebApp.Constants.Conversation objConver = new EMTWebApp.Constants.Conversation();
        if (dtConversations != null && dtConversations.Rows.Count > 0)
        {
            foreach (DataRow dr in dtConversations.Rows)
            {
                if (ConversationID == Convert.ToInt32(dr["ConversationId"]))
                {
                    objConver.ConversationId = Convert.ToInt32(dr["ConversationId"]);
                    objConver.Subject = dr["Subject"].ToString();
                    objConver.FileType = "text/html";
                    objConver.AttachmentType = dr["ATTACHMENTTYPE"].ToString();
                    objConver.Content = (Byte[])dr["Content"];
                    objConver.ConversationDate = dr["ConversationDate"].ToString();
                    objConver.EmailFrom = dr["EmailFrom"].ToString();
                    objConver.EmailTo = dr["EmailTo"].ToString();
                    objConver.EmailCc = dr["EmailCc"].ToString();
                    divMailContent.InnerHtml = " <iframe id=\"ifme\" scrolling=\"auto\" frameBorder=\"0\" style=\"overflow:scroll;\"  width=\"100%\" height=\"370px\" runat=\"server\" src=\"" + "ShowConversation.ashx" + "\" ></iframe>";
                    hdnConversationId.Value = (dr["ConversationId"]).ToString();
                    string actualMailcontent = System.Text.Encoding.UTF8.GetString((Byte[])dr["Content"]);
                    string decryptedValue = HelperMethods.DecryptString(actualMailcontent);
                    strConversation = "</br></br>" + decryptedValue;
                    Session["strConversation"] = strConversation;
                }
            }
        }

        DataTable foundRows = _presenter.LoadInlineAttachments(Convert.ToInt64(hdnConversationId.Value)).Tables[0];
        List<EMTWebApp.Constants.Attachment> lstInlineAttachments = new List<EMTWebApp.Constants.Attachment>();
        //   List<EMTWebApp.Constants.Attachment> lstGMBInlineAttachments = new List<EMTWebApp.Constants.Attachment>();
        if (foundRows != null && foundRows.Rows.Count > 0)
        {
            foreach (DataRow dr in foundRows.Rows)
            {
                EMTWebApp.Constants.Attachment objInlineAttach = new EMTWebApp.Constants.Attachment();
                objInlineAttach.FileName = dr["FILENAME"].ToString();
                objInlineAttach.FileType = HelperMethods.ReturnExtension(objInlineAttach.FileName);
                objInlineAttach.AttachmentId = Convert.ToInt32(dr["AttachmentId"]);
                objInlineAttach.FileContent = (Byte[])dr["Content"];
                lstInlineAttachments.Add(objInlineAttach);
            }
        }

        if (lstInlineAttachments.Count > 0)
        {
            Session["InlineAttachments"] = lstInlineAttachments;
        }

        Session["ConversationDetails"] = objConver;


    }

    /// <summary>
    /// Display attachments to user
    /// </summary>
    /// <param>AttachmentID</param>
    ///<returns> void </returns>
    ///

    // commented by saranya
    public void DisplayAttachment(int AttachmentID)
    {
        try
        {
            if (Session["UploadedAttachment"] != null)
            {
                UploadedFileCollection = (List<EMTWebApp.Constants.Attachment>)Session["UploadedAttachment"];
            }
            DataTable dtAttachments = UploadedFileCollection.ToDataTable();


            EMTWebApp.Constants.Attachment objAttach = new EMTWebApp.Constants.Attachment();
            if (dtAttachments != null && dtAttachments.Rows.Count > 0)
            {
                foreach (DataRow dr in dtAttachments.Rows)
                {
                    if (AttachmentID == Convert.ToInt32(dr["AttachmentId"]))
                    {
                        objAttach.FileName = dr["FILENAME"].ToString();
                        objAttach.FileType = HelperMethods.ReturnExtension(objAttach.FileName);
                        objAttach.AttachmentId = Convert.ToInt32(dr["AttachmentId"]);
                        objAttach.FileContent = (Byte[])dr["FileContent"];
                    }
                }

                divMailContent.InnerHtml = string.Empty;
                if (objAttach.FileType != null)
                {

                    // **display**

                    if (objAttach.FileType.ToLower() == "text/html" || objAttach.FileType.ToLower() == "text/plain")
                    {


                        //if (lstGMBInlineAttachments.Count > 0)
                        //{
                        //    Session["GMBInlineAttachments"] = lstGMBInlineAttachments;
                        //}
                        Session["AttachmentDetails"] = objAttach;
                        // ltrliframe.Text = " <iframe id=\"ifme\" scrolling=\"auto\" style=\"overflow:scroll;\"  width=\"750px\" height=\"520px\" runat=\"server\" src=\"" + "ShowImage.ashx" + "\" ></iframe>";
                        divMailContent.InnerHtml = " <iframe id=\"ifme\" scrolling=\"auto\" frameBorder=\"0\" style=\"overflow:scroll;\"  width=\"100%\" height=\"370px\" runat=\"server\" src=\"" + "ShowImage.ashx" + "\" ></iframe>";
                    }
                    else if (objAttach.FileType.ToLower() == "image/jpeg" || objAttach.FileType.ToLower() == "image/jpg" || objAttach.FileType.ToLower() == "image/png" || objAttach.FileType.ToLower() == "image/bmp" || objAttach.FileType.ToLower() == "image/gif")
                    {
                        Session["AttachmentDetails"] = objAttach;
                        // ltrliframe.Text = " <div style='height:520px; width:750px;overflow:scroll;border:solid 1px silver; '> <img  id=\"ifme\"  runat=\"server\" src=\"" + "ShowImage.ashx" + "\"  /></div>";
                        divMailContent.InnerHtml = " <div style='height:370px; width:100%;overflow:scroll;border:solid 1px silver; '> <img  id=\"ifme\"  runat=\"server\" src=\"" + "ShowImage.ashx" + "\"  /></div>";
                    }
                    else
                    {
                        byte[] MailcontentwithScreenshot = HelperMethods.DecryptAttachments(objAttach.FileContent);


                        Byte[] imgByte = MailcontentwithScreenshot;
                        HttpContext.Current.Response.Clear();
                        HttpContext.Current.Response.Buffer = true;
                        HttpContext.Current.Response.ContentType = objAttach.FileType;
                        HttpContext.Current.Response.AddHeader("content-disposition", "attachment;filename=" + objAttach.FileName);
                        HttpContext.Current.Response.Charset = "";
                        HttpContext.Current.Response.BinaryWrite(MailcontentwithScreenshot);
                        HttpContext.Current.Response.Flush();
                        HttpContext.Current.Response.End();
                        HttpContext.Current.ApplicationInstance.CompleteRequest();

                    }
                }
            }
        }
        catch (System.Threading.ThreadAbortException)
        {
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " |ProcessingNewUI.aspx.cs | DisplayAttachment()");
            //errorlog.HandleError(ex, objUser.UserId , " |ProcessingNewUI.aspx.cs | DisplayAttachment()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }
    }
    /// <summary>
    /// Submit the current case and loads the next case for processing
    /// </summary>
    /// <param>AttachmentID</param>
    ///<returns> void </returns>
    ///
    private void SubmitCaseDetails()
    {
        try
        {
            //dynamic workflow chnage
            DataSet ds = (DataSet)(Session["StatusMasterData"]);
            List<int> lstFinalStatus = new List<int>();
            lstFinalStatus = ds.Tables[0].AsEnumerable().Where(r =>true.Equals(r.Field<bool>("IsFinalStatus")))
                               .Select(r => r.Field<int>("StatusId")).ToList();
            List<int> lstClarificationStatus = new List<int>();
            lstClarificationStatus = ds.Tables[0].AsEnumerable().Where(r => true.Equals(r.Field<bool>("IsClarificationStatus")))
                               .Select(r => r.Field<int>("StatusId")).ToList();
            if (Page.IsValid)
            {
                //Show forward to GMB only if FYI is chosen, or the status is completed
                if (GMBtoGMBCaseTraversal == "ON")
                {
                    if (!(Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstFinalStatus[0])))
                    {
                        forwardtoGMB.Visible = false;
                    }
                }
                if (ddlStatus.SelectedIndex > 0)
                {

                    if ((Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstClarificationStatus[0]))
                    || (Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstFinalStatus[0])) && (Convert.ToBoolean(hdnCompleteAndSend.Value)))
                    {
                        //Bind email details and open sendmail pop up

                        divMailEditor.Visible = true;
                        divMailContentParent.Visible = false;
                        BindEMailDetails();         //commented by saranya              

                    }
                    else
                    {
                        //If the user clicks submit then load next case else if submit and close was clicked update the current document and redirect to previous page
                        UpdateCaseDetails();

                        if (Convert.ToBoolean(ViewState["LoadNextcase"].ToString()))
                        {
                            AlertBox("Case Submitted Successfully. Loading next case..");
                            LoadCaseDetails();
                            // BindDynamicValues();
                        }
                        else
                        {
                            AlertBox("Case Submitted Successfully.Redirecting to previous page.");
                            RedirecttoPreviousPage(hdnPage.Value);
                        }
                    }
                }
                else
                {
                    AlertBox("Please select a status.");
                }
            }
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.cs | SubmitCaseDetails()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.cs | SubmitCaseDetails()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }

    }


    //Pranay -28 September 2016
    protected void chkshowquotedtxt_Click(object sender, EventArgs e)
    {
        try
        {
            string TypedContent = hdntypedContent.Value;
            chkshowquotedtxt.Disabled = true;
            divMailEditor.Visible = true;
            divMailContentParent.Visible = false;
            List<EMTWebApp.Constants.Attachment> lstInline;
            string FollowupWithImages;
            if (chkshowquotedtxt.Checked == true)
            {
                FollowupWithImages = Session["strConversation"].ToString();
                lstInline = (List<EMTWebApp.Constants.Attachment>)HttpContext.Current.Session["InlineAttachments"];
                if (lstInline != null && lstInline.Count > 0)
                {
                    for (int i = 0; i < lstInline.Count; i++)
                    {
                        if (FollowupWithImages.Contains(lstInline[i].FileName.ToString()))
                        {
                            byte[] decryptresult = HelperMethods.DecryptAttachments(lstInline[i].FileContent);
                            string decryptedlstInline = Convert.ToBase64String(decryptresult);
                            FollowupWithImages = FollowupWithImages.Replace(lstInline[i].FileName.ToString(), "data:image/png;base64," + decryptedlstInline);
                        }
                    }
                }
                htmlEditorMailBody.InnerHtml = TypedContent + FollowupWithImages;
            }
        }
        catch (Exception ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.cs | chkshowquotedtxt_Click()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }

    }


    /// <summary>
    /// Update the case details
    /// </summary>
    /// <param></param>
    ///<returns> void </returns>
    ///
    private void UpdateCaseDetails()
    {
        try
        {
            //dynamic workflow chnage
            DataSet ds = (DataSet)(Session["StatusMasterData"]);
            List<int> lstFinalStatus = new List<int>();
            lstFinalStatus = ds.Tables[0].AsEnumerable().Where(r => true.Equals(r.Field<bool>("IsFinalStatus")))
                               .Select(r => r.Field<int>("StatusId")).ToList();
            List<int> lstClarificationStatus = new List<int>();
            lstClarificationStatus = ds.Tables[0].AsEnumerable().Where(r => true.Equals(r.Field<bool>("IsClarificationStatus")))
                               .Select(r => r.Field<int>("StatusId")).ToList();
            List<int> lstPendingQCStatus = new List<int>();
            lstPendingQCStatus = ds.Tables[0].AsEnumerable().Where(r => true.Equals(r.Field<bool>("IsQCPending")))
                               .Select(r => r.Field<int>("StatusId")).ToList();
            int Returnvalue = 0;
            if (objUser != null)
            {
                string Comments = txtComments.InnerText.ToString();
                int SelectedStatus = Convert.ToInt32(ddlStatus.SelectedValue);
                int SelectCategory = Convert.ToInt32(ddlCategory.SelectedValue);
                //Code merge from Stackland_EMT_Start_Nagababu

                if ((Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstClarificationStatus[0])) || (Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstFinalStatus[0])))
                {
                    Returnvalue = _presenter.UpdateCaseDetails(Convert.ToInt64(hdnCaseId.Value), SelectedStatus, Comments, objUser.UserId, Convert.ToDateTime(hdnstartTime.Value), SelectCategory);
                }
                else
                {
                    int prevCategory;
                    if (string.IsNullOrEmpty(hdncategoryid.Value))
                    {
                        prevCategory = 0;
                        Returnvalue = _presenter.UpdateCaseDetails(Convert.ToInt64(hdnCaseId.Value), SelectedStatus, Comments, objUser.UserId, Convert.ToDateTime(hdnstartTime.Value), prevCategory);
                    }
                    else
                    {
                        Returnvalue = _presenter.UpdateCaseDetails(Convert.ToInt64(hdnCaseId.Value), SelectedStatus, Comments, objUser.UserId, Convert.ToDateTime(hdnstartTime.Value), Convert.ToInt32(hdncategoryid.Value));
                    }
                }
                //Code merge from Stackland_EMT_End
            }
            //update dynamic fields when status is not CN,Pending for QC or completed
            if (Returnvalue > 0 && (Convert.ToInt32(hdnStatusId.Value) != Convert.ToInt32(lstFinalStatus[0]) && Convert.ToInt32(hdnStatusId.Value) != Convert.ToInt32(lstClarificationStatus[0]) && Convert.ToInt32(hdnStatusId.Value) != (lstPendingQCStatus.Count>0?lstPendingQCStatus[0]:0)))
            {

                StringBuilder sqlTColumn = new StringBuilder();
                StringBuilder sqlTValue = new StringBuilder();
                StringBuilder sqlCColumn = new StringBuilder();
                StringBuilder sqlCValue = new StringBuilder();
                StringBuilder sqlXMLValue = new StringBuilder();
                sqlXMLValue.Append("<root>");
                GenerateInsParams_CaseID(pnlAllocation, ref sqlTColumn, ref sqlTValue, ref sqlCColumn, ref sqlCValue, ref sqlXMLValue);
                // Combine all string builder values		
                sqlXMLValue.Append("</root>");
                _presenter.Updatedynamicfields(Convert.ToInt64(hdnCaseId.Value), sqlXMLValue, objUser.UserId);
                ClearControlValues(pnlAllocation);
            }
            //195174 GMB to GMB
            //dynamic workflow chnage
            if (Returnvalue > 0 && (Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstFinalStatus[0])))
            {
                if (hdnParentCaseId.Value != "")
                    this._presenter.UpdateForwardToGMB(Convert.ToInt64(hdnParentCaseId.Value), 0);
            }

        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | UpdateCaseDetails()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs | UpdateCaseDetails()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }
    }


    ///Case Travsersal flow
    private string GetChildCaseDetails()
    {

        StringBuilder sb = new StringBuilder();
        if (Convert.ToBoolean(ViewState["LoadNextcase"].ToString()))
        {
            hdnCaseId.Value = "0";
        }

        DataSet ds = _presenter.GetChildCaseDetails(Convert.ToInt64(hdnCaseId.Value));
        string path = "";
        if (ds.Tables[0].Rows.Count > 0)
        {
            DataSet dt = _presenter.GetParentCaseDetails(Convert.ToInt32(hdnCaseId.Value));
            int pcaseid = Convert.ToInt32(ds.Tables[0].Rows[0]["PARENTCASEID"]);
            string pid = dt.Tables[0].Rows[0]["CASEID"].ToString();
            string pidvalue = dt.Tables[0].Rows[0]["CID"].ToString();
            string pemailboxid = dt.Tables[0].Rows[0]["EMailBoxId"].ToString();
            string pstatusid = dt.Tables[0].Rows[0]["STATUSID"].ToString();
            string strid = "";
            if (Session["prevcaseid"] != null && Session["prevcaseid"].ToString() != "")
            {
                strid = Session["prevcaseid"].ToString();
            }
            if (strid == pid)
            {
                string str = "";
                if (Session["prevurl"] != null && Session["prevurl"].ToString() != "")
                {
                    str = Session["prevurl"].ToString();
                }
                path = "ProcessingNewUI.aspx?" + str;
            }
            else
            {
                path = "ProcessingNewUI.aspx?CaseId=" + pid + "&PreviousPage=ProcessingNewUI" + "&lftSelection=" + "" + "&EMailBox=" + pemailboxid + "&Status=" + pstatusid;
            }
            sb.Append("<li><a href=" + path + ">" + pidvalue + "</a>" + "</li>");
            sb.Append("<ul>");
            string temp = "";
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                string caseid = ds.Tables[0].Rows[i]["CID"].ToString();
                string caseidval = ds.Tables[0].Rows[i]["CASEID"].ToString();
                int emailboxid = Convert.ToInt32(ds.Tables[0].Rows[i]["EMailBoxId"]);
                string statusidval = ds.Tables[0].Rows[i]["STATUSID"].ToString();
                if (strid == caseidval)
                {
                    string str = "";
                    if (Session["prevurl"] != null && Session["prevurl"].ToString() != "")
                    {
                        str = Session["prevurl"].ToString();
                    }
                    temp = "ProcessingNewUI.aspx?" + str;
                }
                else
                {
                    temp = "ProcessingNewUI.aspx?CaseId=" + caseidval + "&PreviousPage=ProcessingNewUI" + "&lftSelection=" + "" + "&EMailBox=" + emailboxid + "&Status=" + statusidval;
                }
                sb.Append("<li style='margin-left:20px;'><a href=" + temp + ">");
                sb.Append(caseid + "</a>" + "</li>");
            }
            sb.Append("</ul>");
        }
        else
        {
            return "0";
        }
        return sb.ToString();
    }

    /// <summary>
    /// Gets case details from db and show it in processing page
    /// </summary>
    /// <param></param>
    ///<returns> void </returns>
    ///
    protected void LoadCaseDetails()
    {
        try
        {
            Session.Remove("UploadedAttachment");
            Session.Remove("strForwardToGMBEMail");
            Session.Remove("strFollowupEMail");
            Session.Remove("strConversation");
            Session.Remove("EmailAttachment");
            DataSet ds = new DataSet();
            if (Convert.ToBoolean(ViewState["LoadNextcase"].ToString()))
            {
                hdnCaseId.Value = "0";
            }
            ds = _presenter.LoadCaseDetails(Convert.ToInt64(hdnCaseId.Value), Convert.ToInt32(hdnEmailBoxId.Value), objUser.UserId, Convert.ToInt32(hdnQueryStringstatusId.Value), objUser.RoleId);


            // DataSet ds = _presenter.LoadCaseDetails(Convert.ToInt64(hdnCaseId.Value), Convert.ToInt32(hdnEmailBoxId.Value), objUser.UserId, Convert.ToInt32(hdnQueryStringstatusId.Value), objUser.RoleId);

            if (ds.Tables[0].Rows.Count > 0)
            {
                bool isInputFieldsEnabled = false;
                hdnstartTime.Value = DateTime.UtcNow.ToString();

                hdnCaseId.Value = ds.Tables[0].Rows[0]["CASEID"].ToString();
                //195174 GMB to GMB
                hdnParentCaseId.Value = ds.Tables[0].Rows[0]["PARENTCASEID"].ToString();
                hdnForwardedToGMB.Value = ds.Tables[0].Rows[0]["FORWARDEDTOGMB"].ToString();
                hdnStatusId.Value = ds.Tables[0].Rows[0]["STATUSID"].ToString();
                hdnisEmailTriggerRequired.Value = ds.Tables[0].Rows[0]["ISMAILTRIGGERREQUIRED"].ToString();
                hdnisQCRequired.Value = ds.Tables[0].Rows[0]["ISQCREQUIRED"].ToString();
                hdnMailBoxEmailId.Value = ds.Tables[0].Rows[0]["EMAILBOXADDRESS"].ToString();
                hdnEmailBoxId.Value = ds.Tables[0].Rows[0]["EMailBoxId"].ToString();
                hdnCaseassignedTo.Value = ds.Tables[0].Rows[0]["ASSIGNEDTOID"].ToString();
                hdnQCAssignedTo.Value = ds.Tables[0].Rows[0]["QCUSERID"].ToString();
                hdncategoryid.Value = ds.Tables[0].Rows[0]["CategoryId"].ToString();
                //   hdnEmailCC.Value = ds.Tables[0].Rows[0]["EmailCc"].ToString();
                hdnCountryId.Value = ds.Tables[0].Rows[0]["CountryId"].ToString();
                hdnMailBoxEmailIdOptional.Value = ds.Tables[0].Rows[0]["EMailBoxAddressOptional"].ToString();
                hdnSubProcessId.Value = ds.Tables[0].Rows[0]["SubProcessGroupId"].ToString();
                //fetch and store status master data in session.
                DataSet dsStatusMasterData = _presenter.GetStatus(Convert.ToInt32(hdnSubProcessId.Value));
                Session["StatusMasterData"] = dsStatusMasterData;
                //Pranay 25 January 2017
                string Offset = objUser.OffSet;
                hdnoffsetValue.Value = Offset.Replace(':', '.');

                hdnclassification.Value = ds.Tables[0].Rows[0]["ClassifiactionDescription"].ToString();
                hdnclassification_Active.Value = ds.Tables[0].Rows[0]["IsActive"].ToString();
                lblCountry.InnerText = ds.Tables[0].Rows[0]["COUNTRY"].ToString();
                lblSubProcess.InnerText = ds.Tables[0].Rows[0]["SUBPROCESSNAME"].ToString();
                //lblMailbox.InnerText = ds.Tables[0].Rows[0]["EMAILBOXNAME"].ToString();            
                string TrimMailbox = ds.Tables[0].Rows[0]["EMAILBOXNAME"].ToString();

                string Mailboxname = (TrimMailbox.Length > 10) ? TrimMailbox.Substring(0, 10) + ".." : TrimMailbox;
                lblMailbox.InnerText = Mailboxname;
                lblMailbox.Attributes.Add("title", TrimMailbox);
                //195174 GMB to GMB
                if (hdnParentCaseId.Value == "")
                    lblCaseId.InnerText = ds.Tables[0].Rows[0]["CASEID"].ToString();
                else
                    lblCaseId.InnerText = ds.Tables[0].Rows[0]["PARENTCASEID"].ToString();

                lblcaseType.InnerText = ds.Tables[0].Rows[0]["EMAILTYPE"].ToString();
                lblStatusHdr.InnerText = ds.Tables[0].Rows[0]["STATUSDESCRIPTION"].ToString();
                lblAssignedTo.InnerText = ds.Tables[0].Rows[0]["ASSIGNEDTO"].ToString();

                if (objUser.UserId != hdnCaseassignedTo.Value && objUser.UserId != hdnQCAssignedTo.Value)
                {
                    btnCaseSubmitandClose.Attributes.Add("onClick", "return false");
                    btnCompleteSend.Attributes.Add("onClick", "return false");
                }

                if (hdnPage.Value == "DashBoard")
                {
                    String queryStringSelectionMenu = Request.QueryString["lftSelection"];
                    if (queryStringSelectionMenu.Length == 12)//Subprocess
                    {
                        if ((hdnclassification.Value != null || hdnclassification.Value != "") && hdnclassification_Active.Value == "True")
                        {
                            lblSubProcess.HRef = "DashBoard.aspx?selectedMenu=" + queryStringSelectionMenu + "&SelectionText=" + lblCountry.InnerText + "~" + lblSubProcess.InnerText;
                        }
                        else
                        {
                            lblSubProcess.HRef = "DashBoard.aspx?selectedMenu=" + queryStringSelectionMenu + "&SelectionText=" + lblCountry.InnerText + "~" + lblSubProcess.InnerText;
                        }
                    }
                    else if (queryStringSelectionMenu.Length == 14)//Mailbox
                    {
                        if ((hdnclassification.Value != null || hdnclassification.Value != "") && hdnclassification_Active.Value == "True")
                        {
                            lblMailbox.HRef = "DashBoard.aspx?selectedMenu=" + queryStringSelectionMenu + "&SelectionText=" + lblCountry.InnerText + "~" + lblSubProcess.InnerText + "~" + ds.Tables[0].Rows[0]["EMAILBOXNAME"].ToString();
                            queryStringSelectionMenu = queryStringSelectionMenu.Remove(12);
                            lblSubProcess.HRef = "DashBoard.aspx?selectedMenu=" + queryStringSelectionMenu + "&SelectionText=" + lblCountry.InnerText + "~" + lblSubProcess.InnerText;
                        }
                        else
                        {
                            queryStringSelectionMenu = queryStringSelectionMenu + "_" + "0";
                            lblMailbox.HRef = "DashBoard.aspx?selectedMenu=" + queryStringSelectionMenu + "&SelectionText=" + lblCountry.InnerText + "~" + lblSubProcess.InnerText + "~" + ds.Tables[0].Rows[0]["EMAILBOXNAME"].ToString() + "~" + "open";
                            queryStringSelectionMenu = queryStringSelectionMenu.Remove(12);
                            lblSubProcess.HRef = "DashBoard.aspx?selectedMenu=" + queryStringSelectionMenu + "&SelectionText=" + lblCountry.InnerText + "~" + lblSubProcess.InnerText;
                        }
                    }
                    else if (queryStringSelectionMenu.Length == 16)//classification/Status
                    {
                        String queryStringSelectionMenu1 = queryStringSelectionMenu.Remove(14);
                        if ((hdnclassification.Value != null || hdnclassification.Value != "") && hdnclassification_Active.Value == "True")//classification        
                        {
                            lblMailbox.HRef = "DashBoard.aspx?selectedMenu=" + queryStringSelectionMenu1 + "&SelectionText=" + lblCountry.InnerText + "~" + lblSubProcess.InnerText + "~" + ds.Tables[0].Rows[0]["EMAILBOXNAME"].ToString();
                            String queryStringSelectionMenu2 = queryStringSelectionMenu.Remove(12);
                            lblSubProcess.HRef = "DashBoard.aspx?selectedMenu=" + queryStringSelectionMenu2 + "&SelectionText=" + lblCountry.InnerText + "~" + lblSubProcess.InnerText;
                        }
                        else//Status without NLP
                        {
                            queryStringSelectionMenu1 = queryStringSelectionMenu1 + "_" + "0";
                            lblMailbox.HRef = "DashBoard.aspx?selectedMenu=" + queryStringSelectionMenu1 + "&SelectionText=" + lblCountry.InnerText + "~" + lblSubProcess.InnerText + "~" + ds.Tables[0].Rows[0]["EMAILBOXNAME"].ToString() + "~" + "open";
                            String queryStringSelectionMenu2 = queryStringSelectionMenu.Remove(12);
                            lblSubProcess.HRef = "DashBoard.aspx?selectedMenu=" + queryStringSelectionMenu2 + "&SelectionText=" + lblCountry.InnerText + "~" + lblSubProcess.InnerText;
                        }
                    }
                    else//status with NLP
                    {
                        String queryStringSelectionMenu1 = queryStringSelectionMenu.Remove(14);
                        lblMailbox.HRef = "DashBoard.aspx?selectedMenu=" + queryStringSelectionMenu1 + "&SelectionText=" + lblCountry.InnerText + "~" + lblSubProcess.InnerText + "~" + ds.Tables[0].Rows[0]["EMAILBOXNAME"].ToString();
                        String queryStringSelectionMenu2 = queryStringSelectionMenu.Remove(12);
                        lblSubProcess.HRef = "DashBoard.aspx?selectedMenu=" + queryStringSelectionMenu2 + "&SelectionText=" + lblCountry.InnerText + "~" + lblSubProcess.InnerText;
                    }

                }

                if (ds.Tables[0].Rows[0]["QCASSIGNEDTO"].ToString() != "")
                {
                    lblQCAssignedTo.Visible = true;
                    lblQCAssignedToTitle.Visible = true;
                    lblQCAssignedTo.InnerText = ds.Tables[0].Rows[0]["QCASSIGNEDTO"].ToString();
                }
                else
                {
                    lblQCAssignedTo.Visible = false;
                    lblQCAssignedToTitle.Visible = false;
                }

                if (hdnclassification_Active.Value == "True")
                {
                    if ((objUser.RoleId == 4 && ds.Tables[0].Rows[0]["STATUSID"].ToString() == "2") || (objUser.RoleId == 3 && ds.Tables[0].Rows[0]["STATUSID"].ToString() == "1"))
                    {
                        lblCategorytitle.Visible = true;
                        lnkcategoryRemap.Visible = true;
                        lnkcategoryRemap.Text = ds.Tables[0].Rows[0]["ClassifiactionDescription"].ToString();
                    }
                    else
                    {
                        lblCategorytitle.Visible = false;
                        lnkcategoryRemap.Visible = false;
                    }
                }
                else
                {
                    lblCategorytitle.Visible = false;
                    lnkcategoryRemap.Visible = false;
                }
                //Pranay 6th January 2017 --for setting Recieved date as per TimeZone congifured for User
                DateTime dateRecieved = Convert.ToDateTime(ds.Tables[0].Rows[0]["EMAILRECEIVEDDATE"].ToString());

                //lblEmailReceivedDate.InnerText = ISSWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(dateRecieved.ToString("dd/MM/yyyy hh:mm:ss tt"), true, objUser.TimeZone, false) + "(" + objUser.TimeZone + ")";

                //DateTime dateRecieved = DateTime.ParseExact(ds.Tables[0].Rows[0]["EMAILRECEIVEDDATE"].ToString(), "MM/dd/yyyy hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture);
                lblEmailReceivedDate.InnerText = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(dateRecieved.ToString("dd/MM/yyyy HH:mm:ss"), true, objUser.TimeZone, false) + "(" + objUser.TimeZone + ")";


                //lblEmailReceivedDate.InnerText = ds.Tables[0].Rows[0]["EMAILRECEIVEDDATE"].ToString();
                bool isManualCase = Convert.ToBoolean(ds.Tables[0].Rows[0]["ISMANUAL"]);
                if (isManualCase)
                {
                    lblFromIdTitle.InnerText = "To EmailId :";
                }
                else
                {
                    lblFromIdTitle.InnerText = "From ID :";
                }
                lbltxtID.InnerText = ds.Tables[0].Rows[0]["EMAILFROM"].ToString();
                hdnEmailTo.Value = ds.Tables[0].Rows[0]["EMAILFROM"].ToString();
                //Decryption
                //cryptInfo.CryptKey = cipherpassword;
                //cryptInfo.ValueToCrypt = ds.Tables[0].Rows[0]["SUBJECT"].ToString();
                //string decryptedValue = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
                string decryptedValue = HelperMethods.DecryptString(ds.Tables[0].Rows[0]["SUBJECT"].ToString());
                // removing < > from subject if any
                Regex subjectrx = new Regex(@"[<>]");
                // lblSubject.InnerText = subjectrx.Replace(ds.Tables[0].Rows[0]["SUBJECT"].ToString(), " ");            
                string TrimSubjectline = decryptedValue;
                string Subjectline = (TrimSubjectline.Length > 50) ? TrimSubjectline.Substring(0, 50) + "..." : TrimSubjectline;
                lblSubject.InnerText = Subjectline;
                lblSubject.Attributes.Add("title", TrimSubjectline);
                _presenter.GetStatusList(Convert.ToInt32(hdnStatusId.Value), Convert.ToInt32(hdnSubProcessId.Value), objUser.RoleId);
                //dynamic workflow chnage
                DataSet dsStatus = (DataSet)(Session["StatusMasterData"]);
                //enable input fields if status is not final/clarification/QC


                var dsStatusTransition = from myRow in dsStatus.Tables[0].AsEnumerable()
                                         where myRow.Field<bool>("IsFinalStatus") == true  || myRow.Field<bool>("IsQCPending") == true || myRow.Field<bool>("IsQCApprovedorRejected") == true
                                         select myRow;
                
                bool contains = dsStatusTransition.CopyToDataTable().AsEnumerable().Any(row =>Convert.ToInt32( hdnStatusId.Value) == row.Field<int>("StatusId"));
                if (contains == true)
                    isInputFieldsEnabled = false;
                else
                    isInputFieldsEnabled = true;
                //195174 GMB to GMB
                if (GMBtoGMBCaseTraversal == "ON")
                {
                    if (hdnForwardedToGMB.Value == "True")
                    {
                        isInputFieldsEnabled = false;
                        forwardtoGMB.Visible = false;
                    }
                }
                _presenter.LoadConversationsList(Convert.ToInt64(hdnCaseId.Value));
                DisplayConversation(Convert.ToInt32(hdnConversationId.Value));
                _presenter.LoadAttachmentList(Convert.ToInt64(hdnConversationId.Value));
                _presenter.BindAuditLog(Convert.ToInt32(hdnCaseId.Value));
                _presenter.BindComments(Convert.ToInt32(hdnCaseId.Value));
                EnableInputFields(isInputFieldsEnabled);

                objUser = (UserSession)Session["userdetails"];

                //195174 - hide or show fyi link on page load
                if (objUser != null)
                {
                    if ((Convert.ToInt32(ds.Tables[0].Rows[0]["STATUSID"]) == (int)Constant.Status.ClarificationNeeded
                        || Convert.ToInt32(ds.Tables[0].Rows[0]["STATUSID"]) == (int)Constant.Status.Assigned
                        || Convert.ToInt32(ds.Tables[0].Rows[0]["STATUSID"]) == (int)Constant.Status.ClarificationProvided)
                        && ((objUser.RoleId == (int)Constant.UserRole.Processor && objUser.UserId == hdnCaseassignedTo.Value)
                        || objUser.RoleId == (int)Constant.UserRole.TeamLead))
                    {
                        lnkbtnFyiMail.Visible = true;
                    }
                    else
                    {
                        lnkbtnFyiMail.Visible = false;
                    }

                }

                txtComments.InnerText = "";
                ddlStatus.SelectedIndex = 0;
                Bindcategory(Convert.ToInt16(hdnEmailBoxId.Value));
                parentddlCategory.Visible = false;
                parentddlFlagCategory.Visible = false;
                ddlCategory.Visible = false;
                ddlFlagCategory.Visible = false;
            }

            else
            {
                AlertBox("No Cases Found. Redirecting to Previous Page.");
                RedirecttoPreviousPage(hdnPage.Value);
            }

            // commented by saranya - to be implemented later
            //195174 reassign
            lblAssignedTo.Visible = true;
            ddlAssignedTo.Visible = false;
            lnkUpdate.Visible = false;
            lnkReassign.Visible = false;
            lnkCancel.Visible = false;
            lnkCategoryUpdate.Visible = false;
            lnkCategoryCancel.Visible = false;
            if (Convert.ToInt32(hdnStatusId.Value) == 2 || Convert.ToInt32(hdnStatusId.Value) == 4 || Convert.ToInt32(hdnStatusId.Value) == 7 || Convert.ToInt32(hdnStatusId.Value) == 8)
            {
                if (objUser.RoleId == 3)
                    lnkReassign.Visible = true;
                else if (objUser.RoleId == 4 && objUser.UserId == hdnCaseassignedTo.Value)
                    lnkReassign.Visible = true;
            }
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.cs | LoadCaseDetails()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.cs | LoadCaseDetails()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }



    }


    /// <summary>
    /// Enable or disable the clarification reset option
    /// </summary>
    /// <param></param>
    ///<returns> void </returns>
    //commented by saranya -not required
    //private void EnableorDisableClarificationReset(bool isEnable)
    //{
    //    trResetReason.Visible = isEnable;
    //    trResetClarification.Visible = isEnable;
    //    trClarificationHeader.Visible = isEnable;
    //    if (isEnable)
    //    {
    //        _presenter.GetClarificationResetReason();
    //    }
    //}
    /// <summary>
    /// Bind category
    /// </summary>
    /// <param></param>
    ///<returns> void </returns>
    void Bindcategory(int emailboxid)
    {
        try
        {
            DataSet ds = new DataSet();
            Hashtable ht = new Hashtable();
            ht.Add("@Emailboxid", hdnEmailBoxId.Value);
            ds = _presenter.Getcategory(ht);

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                ddlCategory.DataSource = ds;
                ddlCategory.DataTextField = "Category";
                ddlCategory.DataValueField = "EmailboxCategoryId";
                ddlCategory.DataBind();
                ddlCategory.Items.Insert(0, new ListItem("Category", "0"));
            }
            else
            {
                ddlCategory.DataSource = null;
                ddlCategory.DataBind();
                ddlCategory.Items.Insert(0, new ListItem("Category", "0"));
            }
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | BindStatus()");
            //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | BindStatus()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }
    }

    private void BindFlagDetails()
    {
        try
        {

            Hashtable ht = new Hashtable();
            ht.Add("@CaseId", hdnCaseId.Value);
            ht.Add("@CountryId", hdnCountryId.Value);
            ht.Add("@EmailBoxId", hdnEmailBoxId.Value);
            ht.Add("@ReferenceId", Convert.ToInt32(ddlFlagCategory.SelectedItem.Value));
            ht.Add("@ReferencedBy", objUser.UserId);
            ht.Add("@CreatedDate", DateTime.Now);

            int val = _presenter.InsertDetailsForFlaggedCases(ht);
            if (val == 1)
            {
                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Case has been Flagged for future reference');", true);

            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Case is already flagged');", true);
            }
        }
        catch (Exception ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, "| Processing.aspx.cs | BindFlagDetails()");
            //errorlog.HandleError(ex, objUser.UserId , "| Processing.aspx.cs | BindFlagDetails()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }
    }

    /// /// <summary>
    /// Bind uploaded attachment details in grid
    /// </summary>
    /// <param></param>
    ///<returns> void </returns>
    ///
    /// <summary>
    /// Bind uploaded attachment details in grid
    /// </summary>
    /// <param></param>
    ///<returns> void </returns>
    ///


    void BindEMailBoxNames()
    {
        try
        {
            List<string> BindMailboxnames = new List<string>();
            String MailBoxEmailIdOptional = hdnMailBoxEmailIdOptional.Value;
            Char delimiter = ';';
            String[] EmailOptionalsubstrings = MailBoxEmailIdOptional.Split(delimiter);
            BindMailboxnames.Add(hdnMailBoxEmailId.Value);
            if (hdnMailBoxEmailIdOptional.Value != "")
            {
                for (int i = 0; i < EmailOptionalsubstrings.Length - 1; i++)
                {
                    if (EmailOptionalsubstrings[i].ToString() != "")
                    {
                        // BindMailboxnames.AddRange(EmailOptionalsubstrings);
                        BindMailboxnames.Add(EmailOptionalsubstrings[i].ToString());
                    }
                }
            }
            ddlFrom.DataSource = BindMailboxnames;
            ddlFrom.DataBind();

        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, "| Processing.aspx.cs | BindEMailBoxNames()");
            //errorlog.HandleError(ex, objUser.UserId + " | Processing.cs | BindEMailBoxNames()");
            Response.Redirect("~/Errors/Error.aspx");
        }
    }


    /// Bind email details in senmail pop up
    /// </summary>
    /// <param></param>
    ///<returns> void </returns>
    ///
    public void BindEMailDetails()
    {
        try
        {
            send.Disabled = false;
            //lblFrom.InnerText = hdnMailBoxEmailId.Value;
            BindEMailBoxNames();
            EMTWebApp.Constants.Conversation objConver = (EMTWebApp.Constants.Conversation)Session["ConversationDetails"];
            if (objConver.AttachmentType == "File Received")
            {
                txtTo.Text = objConver.EmailFrom.ToString();
                hdnEmailTo.Value = objConver.EmailFrom.ToString();
            }
            else
            {
                txtTo.Text = objConver.EmailTo.ToString();
                hdnEmailTo.Value = objConver.EmailTo.ToString();
            }

            hdnEmailCC.Value = objConver.EmailCc.ToString();

            chkishighimp.Checked = false;

            //195174 GMB to GMB
            String strCaseIdKeyword = ConfigurationManager.AppSettings["CaseIdKeyword"].ToString();
            if (hdnParentCaseId.Value == "")
                lblMailSubjectCaseId.InnerText = strCaseIdKeyword + ": " + hdnCaseId.Value + " - ";
            else
                lblMailSubjectCaseId.InnerText = strCaseIdKeyword + ": " + hdnParentCaseId.Value + " - ";
            txtMailSubject.Value = objConver.Subject.ToString();
            if (subjecttxt == "true")
            {
                txtMailSubject.Disabled = true;
            }
            BindEMailAttachmentsonLoad();
            DataSet dsresult = new DataSet();
            dsresult = this._presenter.GetSignature(LoginId);
            DataSet dsresult_draft = new DataSet();
            dsresult_draft = this._presenter.draft_save_getdetails(hdnCaseId.Value);
            DataSet dsresult_Dcontent = new DataSet();
            dsresult_Dcontent = this._presenter.draft_save_GetContent(hdnCaseId.Value);
            byte[] content = null;
            string Draft_content = string.Empty;
            int i = dsresult_draft.Tables[0].Rows.Count;
            string content_ds = dsresult_Dcontent.Tables[0].Rows[0]["Content"].ToString();
            string decryptedcontent_ds;
            if (content_ds != "" && content_ds != "0")
            {
                decryptedcontent_ds = HelperMethods.DecryptString(dsresult_Dcontent.Tables[0].Rows[0]["Content"].ToString());
            }
            else
            {
                decryptedcontent_ds = "";
            }

            var FinalDraft_Content = (String)null;
            htmlEditorMailBody.InnerHtml = null;
            //Converting the byte content to the image content
            if (dsresult_draft.Tables[0].Rows[0]["Content"].ToString() != "0")
            {
                for (int j = 0; j < i; j++)
                {

                    byte[] decryptresult = HelperMethods.DecryptAttachments((byte[])dsresult_draft.Tables[0].Rows[j]["Content"]);
                    string decryptedDraft_content = Convert.ToBase64String(decryptresult);
                    var regex = new Regex(Regex.Escape("cid:image000.png"));
                    FinalDraft_Content = regex.Replace(decryptedcontent_ds, "data:image/png;base64," + decryptedDraft_content + "\"", 1);
                    content_ds = FinalDraft_Content;

                }

                htmlEditorMailBody.InnerHtml = htmlEditorMailBody.InnerHtml + FinalDraft_Content;

            }
            else
            {
                if (dsresult.Tables[0].Rows[0]["SignID"].ToString() != "0")
                {
                    if (dsresult_Dcontent.Tables[0].Rows[0]["Content"].ToString() != "0" && dsresult_Dcontent.Tables[0].Rows[0]["Content"].ToString() != " ")
                    {
                        string decrypteddraftValue = HelperMethods.DecryptString(dsresult_Dcontent.Tables[0].Rows[0]["Content"].ToString());
                        htmlEditorMailBody.InnerHtml = htmlEditorMailBody.InnerHtml + decrypteddraftValue;

                    }
                    else
                    {
                        htmlEditorMailBody.InnerHtml = htmlEditorMailBody.InnerHtml + dsresult.Tables[0].Rows[0]["Signature"].ToString();
                    }
                }
                else
                {
                    if (dsresult_Dcontent.Tables[0].Rows[0]["Content"].ToString() != "0" && dsresult_Dcontent.Tables[0].Rows[0]["Content"].ToString() != " ")
                    {
                        string decrypteddraftValue = HelperMethods.DecryptString(dsresult_Dcontent.Tables[0].Rows[0]["Content"].ToString());
                        htmlEditorMailBody.InnerHtml = htmlEditorMailBody.InnerHtml + decrypteddraftValue;
                    }
                    else
                    {
                        htmlEditorMailBody.InnerHtml = htmlEditorMailBody.InnerHtml;
                    }

                }

                //textfields
                if (dsresult_Dcontent.Tables[0].Rows[0]["ToAddress"].ToString() != "0" && dsresult_Dcontent.Tables[0].Rows[0]["ToAddress"].ToString() != " ")
                {
                    txtTo.Text = dsresult_Dcontent.Tables[0].Rows[0]["ToAddress"].ToString();
                }
                else
                {
                    txtTo.Text = lbltxtID.InnerText.ToString();
                }

                if (dsresult_Dcontent.Tables[0].Rows[0]["CcAddress"].ToString() != "0" && dsresult_Dcontent.Tables[0].Rows[0]["CcAddress"].ToString() != " ")
                {
                    txtCC.Text = dsresult_Dcontent.Tables[0].Rows[0]["CcAddress"].ToString();
                }
                else
                {
                    txtCC.Text = string.Empty;
                }

                string radioOption = dsresult_Dcontent.Tables[0].Rows[0]["RadioButtonClicked"].ToString();
                if (string.IsNullOrEmpty(radioOption) || radioOption == "0")
                {
                    reply.Attributes.Add("class", "tooltip replytooltip menuactive");
                }
                else
                {
                    if (radioOption == "1")
                    {
                        reply.Attributes.Add("class", "tooltip replytooltip menuactive");
                    }
                    else if (radioOption == "2")
                    {
                        replytoall.Attributes.Add("class", "menuactive tooltip replytoalltooltip");
                    }
                    else
                    {
                        forward.Attributes.Add("class", "menuactive tooltip forwardtooltip");
                    }
                }

                if (dsresult_Dcontent.Tables[0].Rows[0]["isHighImportance"].ToString() != "0" && !string.IsNullOrEmpty(dsresult_Dcontent.Tables[0].Rows[0]["isHighImportance"].ToString()))
                {
                    if (((bool)dsresult_Dcontent.Tables[0].Rows[0]["isHighImportance"] == true))
                    {
                        chkishighimp.Checked = true;

                    }
                    else
                    {
                        chkishighimp.Checked = false;
                    }

                }
                if (dsresult_Dcontent.Tables[0].Rows[0]["IsShowQuotedText"].ToString() != "0" && !string.IsNullOrEmpty(dsresult_Dcontent.Tables[0].Rows[0]["IsShowQuotedText"].ToString()))
                {
                    if (((bool)dsresult_Dcontent.Tables[0].Rows[0]["IsShowQuotedText"] == true))
                    {
                        chkshowquotedtxt.Checked = true;
                        //chkshowquotedtxt.Enabled = false;
                        chkshowquotedtxt.Disabled = true;
                    }
                    else
                    {
                        chkshowquotedtxt.Checked = false;
                    }
                }
                string attachmentIds = dsresult_Dcontent.Tables[0].Rows[0]["SelectedAttachments"].ToString();
                if (!String.IsNullOrEmpty(attachmentIds) && attachmentIds != "0")
                {
                    int index = attachmentIds.LastIndexOf(',');

                    string attachid = attachmentIds.Substring(0, index);

                    List<string> list = new List<string>();
                    string[] attachment = attachid.Split(',');
                    foreach (string id in attachment)
                    {
                        list.Add(id);
                    }


                    foreach (HtmlTableRow row in tblAttachments.Rows)
                    {
                        //((HtmlAnchor)row.Cells[2].Controls[0]).ID
                        //Label lblattachmentid = (Label)row.FindControl("lblattachmentid");
                        //((HtmlAnchor)row.Cells[2].Controls[0]).ID
                        if (list.Count > 0)
                        {
                            for (int j = 0; j < list.Count; j++)
                            {
                                if (list[j] == ((HtmlAnchor)row.Cells[2].Controls[0]).ID.ToString())
                                {
                                    ((HtmlInputCheckBox)row.Cells[0].Controls[0]).Checked = true;
                                }

                            }
                        }
                        else
                        {
                            ((HtmlInputCheckBox)row.Cells[0].Controls[0]).Checked = false;
                        }

                    }
                }

            }

            divMailEditor.Visible = true;
            divMailContentParent.Visible = false;
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | BindEMailDetails()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs | BindEMailDetails()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }
    }

    public void CmdReply_Click(object sender, EventArgs e)
    {

        BindEMailDetails();
        hdnFollowUp.Value = "true";
        ViewState["LoadNextcase"] = false;
        ViewState["FollowUp"] = true;
    }


    /// <summary>
    /// Bind attachments to show in sendmail pop up on first time load
    /// </summary>
    /// <param></param>
    ///<returns> void </returns>
    ///
    private void BindEMailAttachmentsonLoad()
    {
        try
        {
            Session.Remove("EmailAttachment");
            if (Session["UploadedAttachment"] != null)
            {
                UploadedFileCollection = (List<EMTWebApp.Constants.Attachment>)Session["UploadedAttachment"];
            }
            if (UploadedFileCollection.Count > 0)
            {
                bool isBodyDeleted = false;
                bool isFollowupDeleted = false;
                bool isForwardToGMBDeleted = false;
                EMailAttachmentFileCollection.Clear();
                EMailAttachmentFileCollection.AddRange(UploadedFileCollection);
                DataTable dtAttachments = UploadedFileCollection.ToDataTable();

                System.Text.Encoding enc = System.Text.Encoding.UTF8;

            }
            else
            {
                EMailAttachmentFileCollection.Clear();
            }
            //commented by saranya
            BindEMailAttachments(); //Bind attachments grid in sendmail pop up
        }
        catch (Exception ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Processing.aspx.cs | BindEMailAttachmentsonLoad()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }
    }
    /// <summary>
    /// Bind attachments grid in sendmail pop up on postback from sendmail pop up
    /// </summary>
    /// <param></param>
    ///<returns> void </returns>
    ///
    //commented by saranya - to be modified later
    private void BindEMailAttachments()
    {
        try
        {

            if (EMailAttachmentFileCollection.Count > 0)
            {
                DataTable dtAttachments = EMailAttachmentFileCollection.ToDataTable();
                Session["EmailAttachment"] = EMailAttachmentFileCollection;
                Session["EmailAttachmentsend"] = dtAttachments;
            }

        }
        catch (Exception ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Processing.aspx.cs | BindEMailAttachments()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }
    }
    /// <summary>
    /// Delete attachments in file collection
    /// </summary>
    /// <param>AttachmentID</param>
    ///<returns> void </returns>
    ///
    private void DeleteEMailAttachment(int AttachmentID)
    {
        try
        {
            if (Session["EmailAttachment"] != null)
            {
                EMailAttachmentFileCollection = (List<EMTWebApp.Constants.Attachment>)Session["EmailAttachment"];
            }
            if (EMailAttachmentFileCollection.Count > 0)
            {
                int FileCollectionIndex = -1;
                foreach (var item in EMailAttachmentFileCollection)
                {
                    if (item.AttachmentId == AttachmentID)
                    {
                        FileCollectionIndex = EMailAttachmentFileCollection.IndexOf(item);
                    }
                }
                if (FileCollectionIndex != -1)
                {
                    EMailAttachmentFileCollection.RemoveAt(FileCollectionIndex);
                }
            }
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Processing.aspx.cs | DeleteEMailAttachment()");
            //errorlog.HandleError(ex, objUser.UserId, " | Processing.aspx.cs | DeleteEMailAttachment()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }

    }



    public static string FollowupHtmlEncode(string text)
    {
        string resultstring = text;

        for (int i = 0; i < text.Length; ++i)
        {
            char c = text[i];

            if (((int)c) > 127)
            {
                resultstring = resultstring.Replace(c.ToString(), "&#" + (int)c + ";");
            }
        }

        return resultstring;
    }

    #endregion

    #region EVENTS
    /// <summary>
    /// Move the case from clarification needed to provided status
    /// </summary>
    /// <param>sender</param>
    /// <param>e</param>
    ///<returns> void </returns>
    ///
    //saranya - not required
    //protected void btnResetClarification_Click(object sender, EventArgs e)
    //{
    //    objUser = (UserSession)Session["userdetails"];
    //    if (objUser != null)
    //    {
    //        if (ddlResetReason.SelectedValue != "0")
    //        {
    //            int ReturnValue = _presenter.UpdateCaseDetails(Convert.ToInt64(hdnCaseId.Value), (int)Constant.Status.ClarificationProvided, ddlResetReason.SelectedItem.ToString(), objUser.UserId, Convert.ToDateTime(hdnstartTime.Value), Convert.ToInt32(hdncategoryid.Value));
    //            if (ReturnValue != -1)
    //            {
    //                EnableorDisableClarificationReset(false);
    //                AlertBox("Clarification reset Successful");
    //                RedirecttoPreviousPage(Constant.SearchPage);
    //            }
    //        }
    //        else
    //        {
    //            AlertBox("Please select reset reason.");
    //            ddlResetReason.Focus();
    //        }
    //    }
    //    else
    //    {
    //        Response.Redirect(@"~\Errors\SessionExpired.aspx", false);
    //    }
    //}

    /// <summary>
    /// Show the file content when the user clicks on particular file in attachments grid
    /// </summary>
    /// <param>sender</param>
    /// <param>e</param>
    ///<returns> void </returns>
    ///

    /// <summary>
    /// Upload a file to the respective case
    /// </summary>
    /// <param>sender</param>
    /// <param>e</param>
    ///<returns> void </returns>
    ///

    protected void LinkUpload_Click(object sender, EventArgs e)
    {
        bool success = false;

        try
        {
            int count = fileupload.FileName.Count(f => f == '.');

            if (count == 1)
            {
                if (fileupload.HasFiles)
                {
                    foreach (HttpPostedFile file in fileupload.PostedFiles)
                    {
                        if (HelperMethods.fnCheckOtherFileExtension(file.FileName.Trim().ToLower()))
                        {
                            if (HelperMethods.ValidateAttachmentsSize(file.ContentLength))//fileupload.PostedFile.ContentLength))
                            {
                                success = true;
                            }
                            else
                            {
                                success = false;
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('File size exceeds maximum limit 5 MB.');", true);

                                break;
                            }
                        }
                        else
                        {
                            success = false;
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Invalid file type.');", true);

                            break;
                        }
                    }

                    if (success)
                    {
                        foreach (HttpPostedFile file in fileupload.PostedFiles)
                        {
                            AddAttachmentToFileCollection(file); //Add uploaded file to collection
                            _presenter.LoadAttachmentList(Convert.ToInt64(hdnConversationId.Value)); //Add uploaded file to DB
                        }
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('File(s) attached successfully.');", true);
                    }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select atleast one file to upload.');", true);
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Invalid file type.');", true);
            }
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | LinkUpload_Click()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs | LinkUpload_Click()");
            Response.Redirect("~/Errors/Error.aspx", true);
        }
    }
    public void DisbledTopMenu()
    {
        // send.Disabled = true;
        this.send.Style.Add("Enabled", "none");
        this.lnkSend.Style.Add("Enabled", "none");
        this.reply.Style.Add("Enabled", "none");
        this.replytoall.Style.Add("Enabled", "none");
        this.forward.Style.Add("Enabled", "none");
        this.discardDraft.Style.Add("Enabled", "none");
        this.saveDraft.Style.Add("Enabled", "none");

    }

    public void ProductLicense()
    {
        LicenseInfo LicenseInfo = new LicenseInfo();
        LicenseInfo.ToolPurchased = ToolPurchased;
        LicenseInfo.DateOfPurchase = DateOfPurchase;
        LicenseInfo.Version = Version;
        LicenseInfo.InstanceID = InstanceID;
        LicenseInfo.MaxNoOfUser = MaxNoOfUser;
        DataSet ds = (_presenter.GetUserCount());

        if (ds.Tables[0].Rows.Count > 0)
        {
            usercount = Convert.ToInt16(ds.Tables[0].Rows[0]["TotalNoOfUsers"]);
        }
        LicenseInfo.UserCount = usercount;
        LicenseInfo.EncryptedProductKey = "";

        ProductLicenseKey ProductLicenseKey = new ProductLicenseKey();
        LicenseInfo objlicense = new LicenseInfo();
        objlicense = ProductLicenseKey.GenerateProductKey(LicenseInfo);
        if (string.IsNullOrEmpty(objlicense.EncryptedProductKey) || objlicense.EncryptedProductKey == "null")
        {
            Errormessage = objlicense.ErrorMessage.ToString();
        }
        LicenseKey = objlicense.EncryptedProductKey;
        objlicense = ProductLicenseKey.ValidateProductLicenseKey(LicenseKey);
        //objlicense = ProductLicenseKey.ValidateProductLicenseKey(GetLicenseKey);
        // Errormessage = objlicense.ErrorMessage.ToString();
        Errormessage = objlicense.ErrorMessage.ToString();
        string str = null;
        string[] productKeyInformation = null;
        productKeyInformation = Errormessage.Split('!');
        ErrorMessage = productKeyInformation[0];
        LicenseStatus = objlicense.ResultStatus.ToString();


    }
    private bool IsAlreadyAttached()
    {
        bool IsExist = false;

        if (Session["UploadedAttachment"] != null)
        {
            UploadedFileCollection = (List<EMTWebApp.Constants.Attachment>)Session["UploadedAttachment"];
            foreach (var item in UploadedFileCollection)
            {
                if (item.FileName.Trim().ToString() == fileupload.FileName.Trim().ToString() && item.AttachmentType.Trim().ToString() == "File Sent")
                    IsExist = true;
            }
        }
        return IsExist;
    }

    //<summary>
    /// To submit a case redirects to previous page
    /// </summary>
    /// <param>sender</param>
    /// <param>e</param>
    ///<returns> void </returns>
    ///
    protected void btnCaseSubmitandClose_Click(object sender, EventArgs e)
    {
        try
        {
            hdnCompleteAndSend.Value = "false";
            ViewState["LoadNextcase"] = false;
            SubmitCaseDetails();
            //dynamic workflow chnage
            DataSet ds = (DataSet)(Session["StatusMasterData"]);
            List<int> lstStatus = new List<int>();
            lstStatus = ds.Tables[0].AsEnumerable().Where(r => true.Equals(r.Field<bool>("IsFinalStatus")))
                               .Select(r => r.Field<int>("StatusId")).ToList();
            if ((Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstStatus[0])) && (ddlFlagCategory.SelectedIndex > 0))
            {
                BindFlagDetails();
            }
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs| btnCaseSubmitandClose_Click()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs| btnCaseSubmitandClose_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }
    }

    /// <summary>
    /// To submit a case and loads next case in the queue
    /// </summary>
    /// <param>sender</param>
    /// <param>e</param>
    ///<returns> void </returns>
    ///
    protected void btnCaseSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            hdnCompleteAndSend.Value = "false";
            //hdnLoadNextCase.Value = "true";
            ViewState["LoadNextcase"] = true;
            SubmitCaseDetails();
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs| btnCaseSubmit_Click()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs| btnCaseSubmit_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }
    }

    /// <summary>
    /// To load next case in the queue
    /// </summary>    
    ///<returns> void </returns>   
    public int loadnextcaseflag = 0;
    protected void btnNextCase_Click(object sender, EventArgs e)
    {
        try
        {
            ViewState["LoadNextcase"] = true;
            loadnextcaseflag = 0;

            if (Convert.ToBoolean(ViewState["LoadNextcase"].ToString()))
            {
                loadnextcaseflag = 1;
                DataSet ds = new DataSet();
                if (loadnextcaseflag == 1)
                {
                    int caseflag = 1;
                    string Classificationname = hdnclassificationName.Value; //"Incidents";

                    if (hdnclassification_check.Value == "1" && Classificationname != "")
                    {

                        ds = _presenter.LoadNextCaseWithClassficationName(Classificationname, Convert.ToInt64(hdnCaseId.Value), Convert.ToInt32(hdnEmailBoxId.Value), objUser.UserId, Convert.ToInt32(hdnQueryStringstatusId.Value), objUser.RoleId, caseflag);
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            string currenturl = "ProcessingNewUI.aspx?" + (Request.QueryString.ToString()).Replace(hdnCaseId.Value, ds.Tables[0].Rows[0]["CASEID"].ToString());
                            currenturl = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(currenturl, true);
                            Response.Redirect(currenturl + HelperMethods.GenerateSecureRandom(), false);
                        }
                        else
                        {
                            AlertBox("No Cases Found. Redirecting to Previous Page.");
                            RedirecttoPreviousPage(hdnPage.Value);
                        }

                    }
                    else
                    {
                        ds = _presenter.LoadNextCase(Convert.ToInt64(hdnCaseId.Value), Convert.ToInt32(hdnEmailBoxId.Value), objUser.UserId, Convert.ToInt32(hdnQueryStringstatusId.Value), objUser.RoleId, caseflag);
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            string currenturl = "ProcessingNewUI.aspx?" + (Request.QueryString.ToString()).Replace(hdnCaseId.Value, ds.Tables[0].Rows[0]["CASEID"].ToString());
                            currenturl = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(currenturl, true);
                            Response.Redirect(currenturl + HelperMethods.GenerateSecureRandom(), false);
                        }
                        else
                        {
                            AlertBox("No Cases Found. Redirecting to Previous Page.");
                            RedirecttoPreviousPage(hdnPage.Value);
                        }

                    }

                }

                //BindDynamicValues();//to be uncommented once dynamicfields binding is done
            }
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs| btnNextCase_Click()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs| btnNextCase_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }
    }

    /// <summary>
    /// To load previous case in the queue
    /// </summary>    
    ///<returns> void </returns>
    public int loadprevcaseflag = 0;
    protected void btnPreviousCase_Click(object sender, EventArgs e)
    {
        try
        {
            loadprevcaseflag = 0;
            ViewState["LoadPreviouscase"] = true;
            if (Convert.ToBoolean(ViewState["LoadPreviouscase"].ToString()))
            {
                loadprevcaseflag = 1;
                DataSet ds = new DataSet();
                if (loadprevcaseflag == 1)
                {
                    int caseflag = -1;
                    string ClassificationName = hdnclassificationName.Value;  //"Incidents";
                    if (hdnclassification_check.Value == "1" && ClassificationName != "")
                    {
                        ds = _presenter.LoadPreviousCasewithClassificationName(ClassificationName, Convert.ToInt64(hdnCaseId.Value), Convert.ToInt32(hdnEmailBoxId.Value), objUser.UserId, Convert.ToInt32(hdnQueryStringstatusId.Value), objUser.RoleId, caseflag);
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            string currenturl = "ProcessingNewUI.aspx?" + (Request.QueryString.ToString()).Replace(hdnCaseId.Value, ds.Tables[0].Rows[0]["CASEID"].ToString());
                            currenturl = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(currenturl, true);
                            Response.Redirect(currenturl + HelperMethods.GenerateSecureRandom(), false);
                        }
                        else
                        {
                            AlertBox("No Cases Found. Redirecting to Previous Page.");
                            RedirecttoPreviousPage(hdnPage.Value);
                        }
                    }
                    else
                    {

                        ds = _presenter.LoadPreviousCase(Convert.ToInt64(hdnCaseId.Value), Convert.ToInt32(hdnEmailBoxId.Value), objUser.UserId, Convert.ToInt32(hdnQueryStringstatusId.Value), objUser.RoleId, caseflag);
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            string currenturl = "ProcessingNewUI.aspx?" + (Request.QueryString.ToString()).Replace(hdnCaseId.Value, ds.Tables[0].Rows[0]["CASEID"].ToString());
                            currenturl = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(currenturl, true);
                            Response.Redirect(currenturl + HelperMethods.GenerateSecureRandom(), false);
                        }
                        else
                        {
                            AlertBox("No Cases Found. Redirecting to Previous Page.");
                            RedirecttoPreviousPage(hdnPage.Value);
                        }

                    }
                }
                //BindDynamicValues();//to be uncommented once dynamicfields binding is done
            }
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs| btnPreviousCase_Click()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs| btnPreviousCase_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }

    }


    /// <summary>
    /// To submit a case and mail send option for each case and loads next case in the queue
    /// </summary>
    /// <param>sender</param>
    /// <param>e</param>
    ///<returns> void </returns>
    ///
    protected void btnCompleteSend_Click(object sender, EventArgs e)
    {
        try
        {
            //reply.Attributes.Add("style", "Background-color:#bbe3f5");
            //lnkReply.Attributes.Add("style", "Background-color:#bbe3f5");  
            hdnCompleteAndSend.Value = "true";
            ViewState["LoadNextcase"] = false;
            SubmitCaseDetails();
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs| btnCompleteSend_Click()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs| btnCompleteSend_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }
    }

    /// <summary>
    /// Go back to previous page
    /// </summary>
    /// <param>sender</param>
    /// <param>e</param>
    ///<returns> void </returns>
    ///
    protected void btnCaseCancel_Click(object sender, EventArgs e)
    {
        try
        {
            RedirecttoPreviousPage(hdnPage.Value.ToString());
        }
        catch (Exception ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs| btnCaseCancel_Click()");
            //errorlog.HandleError(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs| btnCaseCancel_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }
    }
    /// <summary>
    /// Delete attachmens in sendmail pop up
    /// </summary>
    /// <param>sender</param>
    /// <param>e</param>
    ///<returns> void </returns>
    ///


    /// <summary>
    /// Open send mail pop up on postback
    /// </summary>
    /// <param>sender</param>
    /// <param>e</param>
    ///<returns> void </returns>
    ///

    /// <summary>
    /// Close the sendmail popup
    /// </summary>
    /// <param>sender</param>
    /// <param>e</param>
    ///<returns> void </returns>
    ///
    //saranya
    //protected void imgbtnSendMailClose_OnClick(object sender, EventArgs e)
    //{
    //    OpenSendMailPopup(false);
    //    htmlEditorMailBody.Content = string.Empty;
    //}
    /// <summary>
    /// To send an email
    /// </summary>
    /// <param>sender</param>
    /// <param>e</param>
    ///<returns> void </returns>
    ///

    void AttachmentLink_Click(object sender, EventArgs e)
    {
        try
        {
            HtmlAnchor source = (HtmlAnchor)sender;
            DisplayAttachment(Convert.ToInt32(source.ID));
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs| AttachmentLink_Click()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs| AttachmentLink_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }

    }

    void ConversationLink_Click(object sender, EventArgs e)
    {
        try
        {
            HtmlAnchor source = (HtmlAnchor)sender;
            DisplayConversation(Convert.ToInt32(source.ID));
            _presenter.LoadAttachmentList(Convert.ToInt64(source.ID));

        }
        catch (Exception ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs| ConversationLink_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }
    }

    protected void CmdSend_Click(object sender, EventArgs e)
    {

        try
        {
            if (hdnEditorMailBodyContent.Value.Trim() != "" || hdnEditorMailBodyContent.Value.Trim() != string.Empty)
            {
                //validate if to address is a gmb address if 'Forward to GMB' is chosen
                DataSet dsMailBoxDetails = this._presenter.GetAllEmailBoxDetails(new Hashtable());

                if (hdnreplyvalue.Value == "4")
                {
                    String toAddress = txtTo.Text.TrimEnd(';').ToLower();

                    bool isGMBAddress = dsMailBoxDetails.Tables[0].AsEnumerable().Any(row => toAddress.ToLower() == row.Field<String>("EMAILBOXADDRESS").ToLower());
                    if (isGMBAddress == false)
                    {
                        AlertBox("Please enter a GMB address in To to forward the case to another GMB");

                        return;
                    }
                }

                //verify if the user is not allowed to enter gmb address in Reply , reply all and Forward option
                if (hdnreplyvalue.Value != "4")
                {
                    String toAddress = txtTo.Text;
                    String ccAddress = txtCC.Text;
                    if (toAddress != string.Empty)
                    {
                        bool isGMBAddress = false;
                        string[] names = toAddress.Split(';');
                        int length = names.Length;
                        for (int len = 0; len < length; len++)
                        {
                            if (names[len] != string.Empty)
                            {
                                names[len] = names[len].Replace(';', ' ').Trim();
                                isGMBAddress = dsMailBoxDetails.Tables[0].AsEnumerable().Any(row => names[len].ToLower() == row.Field<String>("EMAILBOXADDRESS").ToLower());
                                if (isGMBAddress == true)
                                {
                                    AlertBox("Please select Forward to GMB option to forward the case to another GMB");

                                    return;
                                }
                            }
                        }
                    }

                    if (ccAddress != string.Empty)
                    {
                        bool isGMBAddress = false;
                        string[] names = ccAddress.Split(';');
                        int length = names.Length;
                        for (int len = 0; len < length; len++)
                        {
                            if (names[len] != string.Empty)
                            {
                                names[len] = names[len].Replace(';', ' ').Trim();
                                isGMBAddress = dsMailBoxDetails.Tables[0].AsEnumerable().Any(row => names[len].ToLower() == row.Field<String>("EMAILBOXADDRESS").ToLower());
                                if (isGMBAddress == true)
                                {
                                    AlertBox("Please select Forward to GMB option to forward the case to another GMB");

                                    return;
                                }
                            }
                        }
                    }
                }

                _presenter.GetEmailBoxDetails(Convert.ToInt32(hdnEmailBoxId.Value)); //get emailbox details
                if (Session["EmailCredentials"] != null)
                {
                    objEMailCredentials = (EMailBoxCredentials)Session["EmailCredentials"];
                }
                if (objEMailCredentials != null)
                {
                    if (!objEMailCredentials.isLocked) // if emailbox is locked alert user
                    {
                        IList FollowupAttachment;
                        IList ForwardToGMBAttachment;
                        int EMailType = 0;
                        //dynamic workflow chnage
                        DataSet ds = (DataSet)(Session["StatusMasterData"]);
                        List<int> lstStatusFinal = new List<int>();
                        List<int> lstStatusClarification = new List<int>();
                        lstStatusFinal = ds.Tables[0].AsEnumerable().Where(r => true.Equals(r.Field<bool>("IsFinalStatus")))
                                           .Select(r => r.Field<int>("StatusId")).ToList();
                        lstStatusClarification = ds.Tables[0].AsEnumerable().Where(r => true.Equals(r.Field<bool>("IsClarificationStatus")))
                                           .Select(r => r.Field<int>("StatusId")).ToList();
                        if (Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstStatusFinal[0]))
                        {
                            EMailType = Convert.ToInt32(lstStatusFinal[0]);
                        }
                        else if (Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstStatusClarification[0]))
                        {
                            EMailType = Convert.ToInt32(lstStatusClarification[0]);
                        }

                        //start - setting high importance by ranjith 05/18/2015
                        int chkhighimp;
                        if (chkishighimp.Checked == true)
                        {
                            chkhighimp = 1;
                        }
                        else
                        {
                            chkhighimp = 0;
                        }

                        int TotalMailAttachmentSize = 0;
                        //end - setting high importance by ranjith 05/18/2015
                        bool isSuccess;
                        // start - Changed by Ranjith for selecting only the checked attachments for send mail
                        foreach (HtmlTableRow row in tblAttachments.Rows)
                        {
                            if (((HtmlInputCheckBox)row.Cells[0].Controls[0]).Checked)
                            {
                                EMTWebApp.Constants.Attachment att = new EMTWebApp.Constants.Attachment();
                                String attachmentId = ((HtmlAnchor)row.Cells[2].Controls[0]).ID;
                                String attachmentName = ((HtmlAnchor)row.Cells[2].Controls[0]).InnerHtml;
                                string expression;
                                expression = "attachmentid=" + attachmentId;
                                DataRow[] foundRows;

                                // DataTable table = new DataTable();
                                DataTable table = (DataTable)Session["EmailAttachmentsend"];
                                foundRows = table.Select(expression);
                                if (foundRows.Length > 0)
                                {
                                    att.FileName = attachmentName;
                                    att.FileContent = HelperMethods.DecryptAttachments((Byte[])foundRows[0]["FileContent"]);
                                    EMailAttachmentFileCollection.Add(att);
                                    TotalMailAttachmentSize += att.FileContent.Length;
                                }
                            }
                        }
                        // end 


                        //donot include old attachments in emailattachmentfilecollection if the user chooses show quoted text
                        DataTable oldInlineAttachments = _presenter.LoadInlineAttachments(Convert.ToInt64(hdnCaseId.Value)).Tables[0];

                        if (chkshowquotedtxt.Checked == false)  //when the user chooses show quoted text, donot load the existing inline attachments to attachment file collection
                        {
                            if (hdnreplyvalue.Value != "4")
                            {
                                if (oldInlineAttachments != null && oldInlineAttachments.Rows.Count > 0)
                                {
                                    foreach (DataRow dr in oldInlineAttachments.Rows)
                                    {
                                        if (dr["ATTACHMENTTYPE"].ToString().ToLower() != "gmb inline images")//exclude gmb inline images when the user does a followup
                                        {
                                            EMTWebApp.Constants.Attachment objInlineAttach = new EMTWebApp.Constants.Attachment();
                                            objInlineAttach.FileName = dr["FILENAME"].ToString();
                                            objInlineAttach.FileType = HelperMethods.ReturnExtension(objInlineAttach.FileName);
                                            objInlineAttach.AttachmentId = Convert.ToInt32(dr["AttachmentId"]);
                                            objInlineAttach.FileContent = (Byte[])dr["Content"];
                                            objInlineAttach.ContentID = dr["FILENAME"].ToString();
                                            EMailAttachmentFileCollection.Add(objInlineAttach);
                                            TotalMailAttachmentSize += objInlineAttach.FileContent.Length;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (oldInlineAttachments != null && oldInlineAttachments.Rows.Count > 0)
                                {
                                    foreach (DataRow dr in oldInlineAttachments.Rows)
                                    {
                                        if (dr["ATTACHMENTTYPE"].ToString().ToLower() != "inline images")//exclude inline images when the user chooses Forward to GMB
                                        {
                                            EMTWebApp.Constants.Attachment objInlineAttach = new EMTWebApp.Constants.Attachment();
                                            objInlineAttach.FileName = dr["FILENAME"].ToString();
                                            objInlineAttach.FileType = HelperMethods.ReturnExtension(objInlineAttach.FileName);
                                            objInlineAttach.AttachmentId = Convert.ToInt32(dr["AttachmentId"]);
                                            objInlineAttach.FileContent = (Byte[])dr["Content"];
                                            objInlineAttach.ContentID = dr["FILENAME"].ToString();
                                            EMailAttachmentFileCollection.Add(objInlineAttach);
                                            TotalMailAttachmentSize += objInlineAttach.FileContent.Length;
                                        }
                                    }
                                }

                            }
                        }

                        if (HelperMethods.ValidateMailAttachmentsSize(TotalMailAttachmentSize))// Checking the total size of the existing screenshots and Attachments
                        {
                            if (Session["strConversation"] != null)
                            {
                                strConversation = Session["strConversation"].ToString();
                            }

                            //if (Session["strForwardToGMBEMail"] != null)
                            //{
                            //    strForwardToGMBEMail = Session["strForwardToGMBEMail"].ToString();
                            //}

                            bool imgSuccess = true;

                            string sourceText = hdnEditorMailBodyContent.Value; ;//TEST

                            //to make a copy of the inline attachments in body.html when the 
                            //if (radioReplyOption.SelectedValue=="Forward to GMB" && Session["ForwardToGMBHTMLAvailable"].ToString() == "false" && chkshowquotedtxt.Checked == false)
                            if (chkshowquotedtxt.Checked == false)
                            {
                                string FollowupWithImages = "";

                                //if (hdnreplyvalue.Value == "4")// && Session["ForwardToGMBHTMLAvailable"].ToString() == "false")
                                //    FollowupWithImages = Session["strForwardToGMBEMail"].ToString();
                                //else
                                FollowupWithImages = Session["strConversation"].ToString();

                                List<EMTWebApp.Constants.Attachment> lstInline = (List<EMTWebApp.Constants.Attachment>)HttpContext.Current.Session["InlineAttachments"];
                                List<EMTWebApp.Constants.Attachment> lstGMBInline = (List<EMTWebApp.Constants.Attachment>)HttpContext.Current.Session["GMBInlineAttachments"];

                                if (lstInline != null && lstInline.Count > 0)
                                {
                                    for (int i = 0; i < lstInline.Count; i++)
                                    {
                                        if (FollowupWithImages.Contains(lstInline[i].FileName.ToString()))
                                        {
                                            FollowupWithImages = FollowupWithImages.Replace(lstInline[i].FileName.ToString(), "data:image/png;base64," + Convert.ToBase64String(lstInline[i].FileContent));
                                        }
                                    }
                                }

                                sourceText = hdnEditorMailBodyContent.Value + FollowupWithImages;//TEST
                            }

                            var imgSrcMatches = System.Text.RegularExpressions.Regex.Matches(sourceText,
                                //string.Format("<img.+?src=[\"'](.+?)[\"'].*?>"),  
                            string.Format("<img.*src=[\"'](.+?)[\"'].*>"),
                                        RegexOptions.CultureInvariant | RegexOptions.IgnoreCase |
                                        RegexOptions.Multiline);

                            List<string> imgSrcs = new List<string>();

                            int MaxNo = 0;
                            int InitialMaxNo = 0;

                            if (chkshowquotedtxt.Checked == false) //get maxscreenshot count from DB only if showquoted text is not selected
                            {
                                InitialMaxNo = 1;
                            }
                            else
                            {
                                InitialMaxNo = 1;
                            }

                            MaxNo = InitialMaxNo;

                            foreach (Match match in imgSrcMatches)
                            {
                                string srcvalue = match.Groups[1].Value;
                                try
                                {
                                    if (srcvalue.Contains("data:image/png;base64"))
                                    {
                                        imgSrcs.Add(srcvalue.Replace("data:image/png;base64,", ""));

                                        byte[] imgArray = Convert.FromBase64String(srcvalue.Replace("data:image/png;base64,", "").Replace(' ', '+'));
                                        TotalMailAttachmentSize += imgArray.Length;
                                    }
                                    else if (srcvalue.Contains("data:image/jpeg;base64,"))
                                    {
                                        imgSrcs.Add(srcvalue.Replace("data:image/jpeg;base64,", ""));

                                        byte[] imgArray = Convert.FromBase64String(srcvalue.Replace("data:image/jpeg;base64,", "").Replace(' ', '+'));
                                        TotalMailAttachmentSize += imgArray.Length;
                                    }
                                    else
                                    {
                                        byte[] imageArray;
                                        //try
                                        //{
                                        using (var webClient = new WebClient())
                                        {
                                            imageArray = webClient.DownloadData(srcvalue);
                                        }

                                        System.Threading.Thread.Sleep(2000);
                                        TotalMailAttachmentSize += imageArray.Length;
                                        string base64ImageRepresentation = Convert.ToBase64String(imageArray);

                                        if (base64ImageRepresentation.Contains("data:image/png;base64,"))
                                            imgSrcs.Add(base64ImageRepresentation.Replace("data:image/png;base64,", ""));

                                        else if (base64ImageRepresentation.Contains("data:image/jpeg;base64,"))
                                            imgSrcs.Add(base64ImageRepresentation.Replace("data:image/jpeg;base64,", ""));
                                        else
                                            imgSrcs.Add(base64ImageRepresentation);
                                    }


                                    if (Session["strConversation"] != null)
                                    {
                                        if (MaxNo > 99)
                                        {
                                            sourceText = sourceText.Replace(srcvalue, "cid:image" + MaxNo + ".png");
                                            hdnEditorMailBodyContent.Value = hdnEditorMailBodyContent.Value.Replace(srcvalue, "cid:image" + MaxNo + ".png");
                                        }
                                        else if (MaxNo >= 10 && MaxNo <= 99)
                                        {
                                            sourceText = sourceText.Replace(srcvalue, "cid:image0" + MaxNo + ".png");
                                            hdnEditorMailBodyContent.Value = hdnEditorMailBodyContent.Value.Replace(srcvalue, "cid:image0" + MaxNo + ".png");
                                        }
                                        else
                                        {
                                            sourceText = sourceText.Replace(srcvalue, "cid:image00" + MaxNo + ".png");
                                            hdnEditorMailBodyContent.Value = hdnEditorMailBodyContent.Value.Replace(srcvalue, "cid:image00" + MaxNo + ".png");
                                        }
                                    }
                                    MaxNo = MaxNo + 1;
                                }
                                catch (Exception exnew)
                                {
                                    // errorlog.HandleError(exnew, objUser.UserId + " | Processing.aspx.cs | CmdSend_Click()");
                                    imgSuccess = false;
                                    //break;
                                    //goto Imagefail;
                                }
                            }


                            if (imgSuccess)
                            {
                                bool success = false;
                                if (HelperMethods.ValidateMailAttachmentsSize(TotalMailAttachmentSize)) // Checking the total size of the both New & existing screenshots and Attachments
                                {
                                    //195174 GMB to GMB		
                                    ForwardToGMBAttachment = null;
                                    FollowupAttachment = null;
                                    //if (hdnreplyvalue.Value != "4")
                                    //{
                                    if (chkshowquotedtxt.Checked == true)
                                    {
                                        strConversation = hdnEditorMailBodyContent.Value;// +FollowupHtmlEncode(strFollowupEMail);
                                    }
                                    else
                                    {
                                        strConversation = sourceText;
                                    }
                                    lblMailSubject.InnerText = lblMailSubjectCaseId.InnerText.ToString() + txtMailSubject.Value.ToString();

                                    string EncodeSubjectLine = FollowupHtmlEncode(lblMailSubject.InnerText.Trim()); //lblMailSubject.Text.Trim();

                                    string plainbody = Regex.Replace(hdnEditorMailBodyContent.Value, @"<(.|\n)*?>", string.Empty);
                                    plainbody = plainbody.Replace("&nbsp;", "");

                                    //Pranay 22 May 2017 -- changing objEMailCredentials.MailBoxEmailId with ddlFrom Selected value and adding BCC address
                                    FollowupAttachment = HelperMethods.SendMail(ddlFrom.SelectedValue, objEMailCredentials.LoginEmailId, objEMailCredentials.PKeyword,
                                               objEMailCredentials.ServiceURL, txtTo.Text.Trim(), txtCC.Text.Trim(), txtBCC.Text.Trim(), EncodeSubjectLine, strConversation,
                                                       EMailAttachmentFileCollection, Convert.ToInt64(hdnCaseId.Value), EMailType, chkhighimp, plainbody, out isSuccess, imgSrcs, txtMailSubject.Value.ToString(), InitialMaxNo);
                                    byte[] convbytes = null;
                                    foreach (EMTWebApp.Constants.Conversation conv in FollowupAttachment)
                                    {
                                        convbytes = conv.Content;
                                    }
                                    success = isSuccess;

                                    if (success)
                                    {
                                        //save conversation
                                        int conversationId = _presenter.InsertMailConversation((hdnCaseId.Value).ToString(), txtMailSubject.Value.ToString(), convbytes, ddlFrom.SelectedValue, txtTo.Text.Trim(), txtCC.Text.Trim(), txtBCC.Text.Trim(), DateTime.Now, objUser.UserId); //Upload followup file to DB

                                        #region updating inline attachments in DB with respective attachment type
                                        _presenter.DeleteTotalDraft(Convert.ToInt64(hdnCaseId.Value));
                                        if (imgSrcs.Count > 0)
                                        {
                                            IList InlineAttachments;
                                            List<EMTWebApp.Constants.Attachment> lstInline = new List<EMTWebApp.Constants.Attachment>();

                                            int aa = 1;


                                            foreach (string imgcontent in imgSrcs)
                                            {
                                                EMTWebApp.Constants.Attachment at = new EMTWebApp.Constants.Attachment();

                                                string Name = "";

                                                if (aa > 99)
                                                    Name = "cid:image" + aa + ".png";
                                                else if (aa >= 10 && aa <= 99)
                                                    Name = "cid:image0" + aa + ".png";
                                                else
                                                    Name = "cid:image00" + aa + ".png";

                                                at.FileName = Name;
                                                at.FileType = ".png";

                                                at.FileContent = HelperMethods.EncryptAttachments(Convert.FromBase64String(imgcontent.Replace(" ", "+")));
                                                ////195174 GMB to GMB
                                                //if (hdnreplyvalue.Value == "4")
                                                //{
                                                //    at.AttachmentTypeId = 4;
                                                //}
                                                //else
                                                //{
                                                at.AttachmentTypeId = 3;
                                                //}

                                                lstInline.Add(at);
                                                aa = aa + 1;

                                            }
                                            if (lstInline.Count > 0)
                                            {
                                                InlineAttachments = lstInline;

                                                _presenter.UploadAttachment(conversationId, InlineAttachments, objUser.UserId); //Upload followup file to DB
                                            }

                                        }
                                        IList externaltblattachments;
                                        List<EMTWebApp.Constants.Attachment> lsttblattachments = new List<EMTWebApp.Constants.Attachment>();
                                        if (EMailAttachmentFileCollection != null)
                                        {
                                            foreach (EMTWebApp.Constants.Attachment at in EMailAttachmentFileCollection)
                                            {
                                                if (!(at.FileName.Contains("cid:image") && at.FileName.Contains(".png")))
                                                {
                                                    EMTWebApp.Constants.Attachment attachment = new EMTWebApp.Constants.Attachment();

                                                    attachment.FileName = at.FileName;
                                                    attachment.FileType = HelperMethods.ReturnExtension(at.FileName);
                                                    attachment.FileContent = HelperMethods.EncryptAttachments(at.FileContent);
                                                    //HelperMethods.EncryptAttachments(Convert.FromBase64String(imgcontent.Replace(" ", "+")));
                                                    attachment.AttachmentTypeId = 1;
                                                    lsttblattachments.Add(attachment);
                                                }
                                                //else
                                                //    objMessage.Attachments.AddFileAttachment(at.FileName, at.FileContent);
                                            }
                                        }
                                        if (lsttblattachments.Count > 0)
                                        {
                                            externaltblattachments = lsttblattachments;
                                            _presenter.UploadAttachment(conversationId, externaltblattachments, objUser.UserId); //Upload tableattachments to DB
                                        }
                                        #endregion

                                        Session["EmailAttachment"] = null;
                                        Session["strConversation"] = null;
                                        //Session["strForwardToGMBEMail"] = null;

                                        Session.Remove("EmailAttachment");
                                        Session.Remove("strConversation");
                                        //Session.Remove("strForwardToGMBEMail");

                                        //195174 GMB to GMB
                                        //if (hdnreplyvalue.Value == "4" && ForwardToGMBAttachment != null)
                                        //{
                                        //    foreach (EMTWebApp.Constants.Attachment at in ForwardToGMBAttachment)
                                        //    {
                                        //        at.FileName = "ForwardToGMB.html";
                                        //        at.AttachmentTypeId = (int)Constant.AttachmentType.FileSent;
                                        //    }
                                        //    _presenter.UploadAttachment(Convert.ToInt64(hdnCaseId.Value), ForwardToGMBAttachment, objUser.UserId); //Upload followup file to DB

                                        //}
                                        //if (hdnreplyvalue.Value != "4" && FollowupAttachment != null)
                                        //{
                                        //    foreach (EMTWebApp.Constants.Attachment at in FollowupAttachment)
                                        //    {
                                        //        at.FileName = "Followup.html";
                                        //        at.AttachmentTypeId = (int)Constant.AttachmentType.FileSent;
                                        //    }
                                        // }

                                        htmlEditorMailBody.InnerHtml = "";


                                        //need not modify as forward to gmb is a followup mail only
                                        if (!Convert.ToBoolean(hdnFollowUp.Value) || hdnFollowUp.Value == "")
                                        {
                                            UpdateCaseDetails();
                                        }


                                        #region Handle Parent -child relationships
                                        //195174 GMB to GMB
                                        if (hdnreplyvalue.Value == "4")
                                        {
                                            if (hdnForwardedToGMB.Value == "True")
                                            {
                                                AlertBox("The case is already forwarded to another GMB. Case cannot be be forwarded to multiple GMBs at a time");

                                            }
                                            else
                                            {
                                                //update forward to GMB flag of the case in DB to 1
                                                int result = this._presenter.UpdateForwardToGMB(Convert.ToInt64(hdnCaseId.Value), 1);
                                                //reset the forward to GMB flag of the  parent case if current case is child
                                                if (hdnParentCaseId.Value != "")
                                                {
                                                    int parentResult = this._presenter.UpdateForwardToGMB(Convert.ToInt64(hdnParentCaseId.Value), 0);
                                                }
                                                else //reset the forward to GMB flag of the child case if one exists, if current case is parent case
                                                {
                                                    Hashtable ht = new Hashtable();
                                                    ht.Add("@ParentCaseId", hdnCaseId.Value);
                                                    DataSet dsChildCases = this._presenter.GetAllChildCases(ht);
                                                    if (dsChildCases.Tables[0] != null && dsChildCases.Tables[0].Rows.Count > 0)
                                                    {
                                                        string ChildCaseId = dsChildCases.Tables[0].Rows[0]["CaseId"].ToString();
                                                        int childResult = this._presenter.UpdateForwardToGMB(Convert.ToInt64(ChildCaseId), 0);
                                                    }
                                                }
                                            }
                                        }


                                        #endregion

                                        if (Convert.ToBoolean(ViewState["LoadNextcase"].ToString()))
                                        {
                                            AlertBox("Case Submitted Successfully. Loading next case..");
                                            LoadCaseDetails();
                                            chkshowquotedtxt.Checked = false;
                                        }
                                        //195174
                                        else if (Convert.ToBoolean(hdnFollowUp.Value))
                                        {
                                            hdnFollowUp.Value = "false";
                                            chkshowquotedtxt.Checked = false;
                                            AlertBox("Mail Sent Successfully.");
                                            hdnConversationId.Value = conversationId.ToString();
                                            LoadCaseDetails();
                                        }
                                        else
                                        {
                                            chkshowquotedtxt.Checked = false;
                                            AlertBox("Case Submitted Successfully. Redirecting to previous page.");
                                            RedirecttoPreviousPage(hdnPage.Value);

                                            //dynamic workflow chnage


                                            if ((ddlFlagCategory.SelectedValue != "0") && (Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstStatusFinal[0])))
                                            {
                                                BindFlagDetails();
                                            }
                                        }
                                    }
                                    else
                                    {
                                        //AlertBox("Authentication failed. Unable to send email.");
                                        AlertBox("Unable to send mail, please try again. If the error occurs again, contact EMT help desk for assistance.Note: Screenshots in the composed mail will be auto removed.");

                                        htmlEditorMailBody.InnerHtml = RemoveHTMLEditorScreenshots(hdnEditorMailBodyContent.Value);
                                    }
                                } //end of followup email
                                else
                                {
                                    AlertBox("Unable to send mail. Mail Attachments/Screenshots exceeds 5 MB, Please remove some Attachments/Screenshots and try again. Note: Screenshots in the composed mail will be auto removed.");

                                    htmlEditorMailBody.InnerHtml = RemoveHTMLEditorScreenshots(hdnEditorMailBodyContent.Value);
                                }
                            }
                            else
                            {
                                AlertBox("Unable to load screenshot(s) in the Mailbody, please try remove web images and try again. Note: Screenshots in the composed mail will be auto removed.");

                                htmlEditorMailBody.InnerHtml = RemoveHTMLEditorScreenshots(hdnEditorMailBodyContent.Value);
                            }
                        }
                        //Imagefail:
                        else
                        {
                            AlertBox("Unable to send mail. Mail Attachments exceeds 5 MB, Please remove some attachments and try again. Note: Screenshots in the composed mail will be auto removed.");

                            htmlEditorMailBody.InnerHtml = RemoveHTMLEditorScreenshots(hdnEditorMailBodyContent.Value);
                        }
                    }
                    else
                    {
                        //AlertBox("Email box locked out. Unable to send email.");
                        AlertBox("Unable to send mail. Please contact EMT help desk for assistance. Note: Screenshots in the composed mail will be auto removed.");

                    }
                }
                //}
                //else
                //{
                //    AlertBox("Email body contains screenshots, Kindly remove the screenshot and send it again.");
                //}
            }
            else
            {
                AlertBox("Please enter email content.");

            }
            Session["ForwardToGMBHTMLAvailable"] = "";//reset session
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "enablesend", " $(\"#DefaultContent_send\").removeClass('lidisabled');  ", true);
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            if (ex.Message == "The message exceeds the maximum supported size.")
            {
                AlertBox("Total attachment size exceeds 5mb limit.");
            }
            else
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | CmdSend_Click()");
                //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs | CmdSend_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
    }

    string RemoveHTMLEditorScreenshots(string htmlContent)
    {
        string sourceText = htmlEditorMailBody.InnerHtml;
        var imgSrcMatches = System.Text.RegularExpressions.Regex.Matches(sourceText,
            //string.Format("<img.+?src=[\"'](.+?)[\"'].*?>"),  
        string.Format("<img.*src=[\"'](.+?)[\"'].*>"),
                    RegexOptions.CultureInvariant | RegexOptions.IgnoreCase |
                    RegexOptions.Multiline);

        foreach (Match match in imgSrcMatches)
        {
            htmlContent = htmlContent.Replace(match.Value, "");
            // break;
        }

        return htmlContent;
    }





    protected void ddlStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            //dynamic workflow chnage
            DataSet ds = (DataSet)(Session["StatusMasterData"]);
            List<int> lstStatusClarification = new List<int>();
            lstStatusClarification = ds.Tables[0].AsEnumerable().Where(r => true.Equals(r.Field<bool>("IsClarificationStatus")))
                                          .Select(r => r.Field<int>("StatusId")).ToList();
            List<int> lstStatusFinal = new List<int>();
            lstStatusFinal = ds.Tables[0].AsEnumerable().Where(r => true.Equals(r.Field<bool>("IsFinalStatus")))
                                          .Select(r => r.Field<int>("StatusId")).ToList();
            List<int> lstStatusAssigned = new List<int>();
            lstStatusAssigned = ds.Tables[0].AsEnumerable().Where(r => true.Equals(r.Field<bool>("IsAssigned")))
                                          .Select(r => r.Field<int>("StatusId")).ToList();
            List<int> lstStatusFollowup = new List<int>();
            lstStatusFollowup = ds.Tables[0].AsEnumerable().Where(r => true.Equals(r.Field<bool>("IsFollowupStatus")))
                                          .Select(r => r.Field<int>("StatusId")).ToList();
            if ((Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstStatusClarification[0])) || (Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstStatusFinal[0])))
            {
                parentddlCategory.Visible = true;
                //  overlay-inAbox.Visible=
                tblAuditLog.Style.Add("display", "inline");
                ddlCategory.Visible = true;
                ddlCategory.SelectedIndex = 0;
                if ((Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstStatusFinal[0])))
                {
                    if (btnDFSave.Visible)
                    {
                        txtComments.Style.Add("height", "110px");
                    }
                    else
                    {
                        txtComments.Style.Add("height", "232px");
                    }
                }
                else
                {
                    if (btnDFSave.Visible)
                    {
                        txtComments.Style.Add("height", "130px");
                    }
                    else
                    {
                        txtComments.Style.Add("height", "245px");
                    }
                }
            }
            else
            {
                ddlCategory.Visible = false;
                parentddlCategory.Visible = false;
                if (btnDFSave.Visible)
                {
                    txtComments.Style.Add("height", "130px");
                }
                else
                {
                    txtComments.Style.Add("height", "245px");
                }
            }


            //195174 - show and hide fyi link button based on status
            if ((Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstStatusClarification[0])) || (Convert.ToInt32(ddlStatus.SelectedValue) == Convert.ToInt32(lstStatusAssigned[0])) || (Convert.ToInt32(ddlStatus.SelectedValue) == (lstStatusFollowup.Count>0?lstStatusFollowup[0]:0)))
            {
                lnkbtnFyiMail.Visible = true;
            }
            else
            {
                lnkbtnFyiMail.Visible = false;
            }

            //Pranay 28 October 2016 ----show flag category only when status drop down value is Completed
            if ((Convert.ToInt32(ddlStatus.SelectedValue) == (int)Constant.Status.Completed))
            {
                parentddlFlagCategory.Visible = true;
                ddlFlagCategory.Visible = true;
                BindFlagonMailboxSelected();
            }
            else
            {
                parentddlFlagCategory.Visible = false;
                ddlFlagCategory.Visible = false;

            }
            //On hold statement
            if ((Convert.ToInt32(ddlStatus.SelectedValue) == (int)Constant.Status.OnHold))
            {
                btnCompleteSend.Disabled = true;
            }
            else
            {
                btnCompleteSend.Disabled = false;
            }
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs| ddlStatus_SelectedIndexChanged()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs| ddlStatus_SelectedIndexChanged()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }
    }

    private void BindFlagonMailboxSelected()
    {
        try
        {
            ddlFlagCategory.Items.Clear();
            DataSet ds = new DataSet();
            Hashtable ht = new Hashtable();

            ht.Add("@EMailboxId", hdnEmailBoxId.Value);

            ds = _presenter.GetFlagCriteriaByEmailboxSelected(ht);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                ddlFlagCategory.DataSource = ds;
                ddlFlagCategory.DataTextField = "Reference";
                ddlFlagCategory.DataValueField = "EmailboxReferenceId";

            }
            ddlFlagCategory.DataBind();
            ddlFlagCategory.Items.Insert(0, new ListItem("FlagCategory", "0"));
            ds.Dispose();
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs| BindFlagonMailboxSelected()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs| BindFlagonMailboxSelected()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }
    }

    protected void lnkbtnFyiMail_Click(object sender, EventArgs e)
    {
        try
        {
            BindEMailDetails();
            hdnFollowUp.Value = "true";
            ViewState["LoadNextcase"] = false;
            //  OpenSendMailPopup(true);
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | lnkbtnFyiMail_Click()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs | lnkbtnFyiMail_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }
    }
    //195174 reassign
    //saranya
    protected void lnkReassign_Click(object sender, EventArgs e)
    {
        try
        {
            ddlAssignedTo.Items.Clear();
            DataSet ds = new DataSet();
            Hashtable ht = new Hashtable();
            ht.Add("@CountryId", hdnCountryId.Value);
            ht.Add("@EMailbocId", hdnEmailBoxId.Value);
            ht.Add("@Roleid", Constant.UserRole.Processor);
            //ht.Add("@UserId", objUser.UserId);
            ds = _presenter.GetUserIdsByCountryEmailboxRole(ht);
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                ddlAssignedTo.DataSource = ds;
                ddlAssignedTo.DataTextField = "UserName";
                ddlAssignedTo.DataValueField = "UserId";

            }
            ddlAssignedTo.DataBind();
            ddlAssignedTo.Items.Insert(0, new ListItem("-Select-", "0"));
            //bugfix for preventing reassigning of case to same user
            ListItem removeItem = ddlAssignedTo.Items.FindByText(objUser.FirstName + " " + objUser.LastName + " ( " + objUser.UserId + " ) ");
            ddlAssignedTo.Items.Remove(removeItem);
            ds.Dispose();

            lblAssignedTo.Visible = false;
            ddlAssignedTo.Visible = true;
            lnkReassign.Visible = false;
            lnkUpdate.Visible = true;
            lnkCancel.Visible = true;
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | lnkReassign_Click()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs | lnkReassign_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }

    }



    protected void lnkcategoryRemap_Click(object sender, EventArgs e)
    {
        try
        {
            ddlcategoryMappedto.Items.Clear();
            DataSet ds = new DataSet();
            ds = _presenter.GetCategoryNames();
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                ddlcategoryMappedto.DataSource = ds;
                ddlcategoryMappedto.DataTextField = "ClassifiactionDescription";
                //ddlcategoryMappedto.DataValueField = "UserId";

            }
            ddlcategoryMappedto.DataBind();
            ddlcategoryMappedto.Items.Insert(0, new ListItem("-Select-", "0"));
            //preventing remapping of case to same category
            ListItem removeItem = ddlcategoryMappedto.Items.FindByText(lnkcategoryRemap.Text);
            ddlcategoryMappedto.Items.Remove(removeItem);
            ds.Dispose();
            ddlcategoryMappedto.Visible = true;
            lnkcategoryRemap.Visible = false;
            lnkCategoryUpdate.Visible = true;
            lnkCategoryCancel.Visible = true;
        }
        catch (Exception ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | lnkcategoryRemap_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
        }

    }




    #region Load Dynamic Controls
    private void BindDynamicValues()
    {
        string strStatusVal = "0";
        DataSet dsControls = new DataSet();
        try
        {
            if (!string.IsNullOrEmpty(lblCaseId.InnerText))
            {
                Hashtable hs = new Hashtable();
                hs.Add("@CaseID", Convert.ToInt32(lblCaseId.InnerText));
                dsControls = _presenter.GetDynamicPageControls(hs);
                if (dsControls != null && dsControls.Tables.Count > 0 && dsControls.Tables[0].Rows.Count > 0)//INPUT
                {
                    for (int iCnt = 0; iCnt <= dsControls.Tables[0].Rows.Count - 1; iCnt++)
                    {
                        // strFieldID = dsControls.Tables[0].Rows[iCnt]["DynamicFieldMaster_ID"].ToString();
                        strFieldID = dsControls.Tables[0].Rows[iCnt]["DynamicFieldMaster_ID"].ToString() + "_" + dsControls.Tables[0].Rows[iCnt]["FieldMasterID"].ToString();
                        strFieldName = dsControls.Tables[0].Rows[iCnt]["FieldAliasName"].ToString();
                        strFieldType = dsControls.Tables[0].Rows[iCnt]["FieldType"].ToString();
                        strFieldDataType = dsControls.Tables[0].Rows[iCnt]["FieldDataType"].ToString();
                        if (dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString() != "" && dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString() != null && dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString() != string.Empty)
                            strTextLength = Convert.ToInt64(dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString());
                        else
                            strTextLength = 0;

                        strFieldMasterID = Convert.ToInt64(dsControls.Tables[0].Rows[iCnt]["FieldMasterID"].ToString());

                        if (!string.IsNullOrEmpty(dsControls.Tables[0].Rows[iCnt]["ValidationTypeID"].ToString()))
                            strValidationTypeID = Convert.ToInt64(dsControls.Tables[0].Rows[iCnt]["ValidationTypeID"].ToString());
                        else
                            strValidationTypeID = 0;

                        //if (dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString() != "" && dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString() != null && dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString() != string.Empty)
                        //    strFieldPrivilegeID = Convert.ToInt32(dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString());
                        //else
                        //    strFieldPrivilegeID = 0;

                        strFieldPrivilegeID = 0;

                        if (!string.IsNullOrWhiteSpace(dsControls.Tables[0].Rows[iCnt]["Value"].ToString()))
                            strValue = dsControls.Tables[0].Rows[iCnt]["Value"].ToString();
                        else
                            strValue = string.Empty;

                        BindControls(strFieldID, strFieldName, strFieldType, strTextLength, strFieldMasterID, strValidationTypeID, strFieldPrivilegeID, strFieldDataType, strValue, iCnt);

                    }
                }
                else
                {
                    DynamicFieldsPanel.Visible = false;
                    btnDFSave.Visible = false;
                }

            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            strStatusVal = "0";
            dsControls.Dispose();
        }
    }


    public void BindControls(string strFieldID, string strFieldName, string strFieldType, Int64 strTextLength, Int64 strFieldMasterID, Int64 strValidationTypeID, Int32 strFieldPrivilegeID, string strFieldDataType, string strValue, int iCnt)
    {
        HtmlGenericControl li = new HtmlGenericControl("li");
        try
        {
            switch (strFieldType)
            {
                case "Hidden":
                    HiddenField hdnField = new HiddenField();
                    hdnField.ID = strFieldID;
                    hdnField.Value = strFieldName;
                    li.Controls.Add(hdnField);
                    break;
                case "TextBox":
                    TextBox txtBox = pnlAllocation.FindControl(strFieldID) as TextBox;
                    txtBox.ID = strFieldID;
                    txtBox.CssClass = "textbox";
                    txtBox.Text = strValue;
                    break;
                case "TextArea":
                    TextBox txtarea = pnlAllocation.FindControl(strFieldID) as TextBox;
                    txtarea.ID = strFieldID;
                    txtarea.CssClass = "Text";
                    txtarea.TextMode = TextBoxMode.MultiLine;
                    break;
                case "DropDownList":
                    DropDownList ddl = pnlAllocation.FindControl(strFieldID) as DropDownList;
                    ddl.ID = strFieldID;
                    ddl.CssClass = "dropdown";
                    Int64 fieldmasterid = strFieldMasterID;
                    FillControlValues(ddl, null, null, fieldmasterid);
                    ddl.SelectedValue = null;
                    if (strValue != string.Empty && strValue != "select")
                    {
                        if (ddl.Items.FindByText(strValue) != null)
                        {
                            ddl.Items.FindByText(strValue).Selected = true;
                        }
                    }
                    break;
                case "RadioButtonList":
                    RadioButtonList radiobtnlst = pnlAllocation.FindControl(strFieldID) as RadioButtonList;
                    radiobtnlst.ID = strFieldID;
                    radiobtnlst.CssClass = "radiobtnlst";
                    radiobtnlst.RepeatDirection = System.Web.UI.WebControls.RepeatDirection.Horizontal;
                    radiobtnlst.RepeatColumns = 2;

                    fieldmasterid = strFieldMasterID;
                    FillControlValues(null, radiobtnlst, null, fieldmasterid);
                    if (strValue != string.Empty)
                    {
                        radiobtnlst.Items.FindByText(strValue).Selected = true;
                    }
                    break;
                case "CheckBoxList":

                    CheckBoxList chkbox = pnlAllocation.FindControl(strFieldID) as CheckBoxList;

                    chkbox.ID = strFieldID;
                    chkbox.CssClass = "Checkbox";
                    chkbox.RepeatDirection = System.Web.UI.WebControls.RepeatDirection.Horizontal;
                    chkbox.RepeatColumns = 2;

                    fieldmasterid = strFieldMasterID;
                    FillControlValues(null, null, chkbox, fieldmasterid);
                    //  chkbox.SelectedValue = strValue;

                    if (!string.IsNullOrEmpty(strValue) && strValue.Length > 1)
                    {
                        List<string> strRecip = strValue.Trim().ToLower().Split(',').Select(p => p.Trim()).ToList();
                        foreach (ListItem list in chkbox.Items)
                        {
                            if (strRecip.Contains(list.Text.Trim().ToLower()))
                            {
                                list.Selected = true;
                            }
                        }
                    }
                    break;
                case "Date":

                    TextBox txtboxdate = pnlAllocation.FindControl(strFieldID) as TextBox;
                    txtboxdate.ID = strFieldID;
                    txtboxdate.CssClass = "textbox";
                    txtboxdate.Attributes.Add("readonly", "true");
                    txtboxdate.Text = fnConvertstringtodate(strValue);
                    ImageButton imgButton = new ImageButton();
                    imgButton.ID = "Img_" + strFieldMasterID;
                    imgButton.ImageUrl = "~/Images/calendar.gif";
                    imgButton.CausesValidation = false;

                    CalendarExtender calendar = new CalendarExtender();
                    calendar.ID = "Cal_" + strFieldMasterID;
                    calendar.TargetControlID = txtboxdate.ID;
                    calendar.PopupButtonID = imgButton.ID;
                    calendar.Format = "dd/MM/yyyy";

                    break;


            }

            //tr.Cells.Add(td1);
            //tr.Cells.Add(td2);
            //tab.Rows.Add(tr);

            pnlAllocation.Controls.Add(li);
        }
        catch (Exception ex)
        {

        }
        finally
        {

            //td1.Dispose();
            //lbl.Dispose();
            //txtBox.Dispose();
            //calendar.Dispose();
            //imgButton.Dispose();
            //objDefaultValues = null;
            //ddl.Dispose();
            //radiobtnlst.Dispose();
            //chkbox.Dispose();
        }

    }


    private void LoadDynamicControls()
    {
        string strStatusVal = "0";
        DataSet dsControls = new DataSet();
        try
        {
            if (!string.IsNullOrEmpty(lblCaseId.InnerText))
            {
                Hashtable hs = new Hashtable();
                hs.Add("@CaseID", Convert.ToInt32(lblCaseId.InnerText));
                dsControls = _presenter.GetDynamicPageControls(hs);
                if (dsControls != null && dsControls.Tables.Count > 0 && dsControls.Tables[0].Rows.Count > 0)//INPUT
                {
                    for (int iCnt = 0; iCnt <= dsControls.Tables[0].Rows.Count - 1; iCnt++)
                    {
                        strFieldID = dsControls.Tables[0].Rows[iCnt]["DynamicFieldMaster_ID"].ToString() + "_" + dsControls.Tables[0].Rows[iCnt]["FieldMasterID"].ToString();
                        strFieldName = dsControls.Tables[0].Rows[iCnt]["FieldAliasName"].ToString();
                        strFieldType = dsControls.Tables[0].Rows[iCnt]["FieldType"].ToString();
                        strFieldDataType = dsControls.Tables[0].Rows[iCnt]["FieldDataType"].ToString();
                        if (dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString() != "" && dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString() != null && dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString() != string.Empty)
                            strTextLength = Convert.ToInt64(dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString());
                        else
                            strTextLength = 0;

                        strFieldMasterID = Convert.ToInt64(dsControls.Tables[0].Rows[iCnt]["FieldMasterID"].ToString());

                        if (!string.IsNullOrEmpty(dsControls.Tables[0].Rows[iCnt]["ValidationTypeID"].ToString()))
                            strValidationTypeID = Convert.ToInt64(dsControls.Tables[0].Rows[iCnt]["ValidationTypeID"].ToString());
                        else
                            strValidationTypeID = 0;

                        if (dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"] != null)
                        {
                            if (dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString() != "" && dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString() != null && dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString() != string.Empty)
                                strFieldPrivilegeID = Convert.ToInt32(dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString());
                            else
                                strFieldPrivilegeID = 0;
                        }
                        else
                            strFieldPrivilegeID = 0;

                        if (objUser.RoleName.ToString() != Constant.UserRole.Processor.ToString())
                        {
                            strFieldPrivilegeID = 0;
                        }

                        if (!string.IsNullOrWhiteSpace(dsControls.Tables[0].Rows[iCnt]["Value"].ToString()))
                            strValue = dsControls.Tables[0].Rows[iCnt]["Value"].ToString();
                        else
                            strValue = string.Empty;


                        CreateControls(strFieldID, strFieldName, strFieldType, strTextLength, strFieldMasterID, strValidationTypeID, strFieldPrivilegeID, strFieldDataType, strValue, iCnt);

                    }
                    DynamicFieldsPanel.Visible = true;
                    btnDFSave.Visible = true;
                }

            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            strStatusVal = "0";
            dsControls.Dispose();
        }
    }



    public void CreateControls(string strFieldID, string strFieldName, string strFieldType, Int64 strTextLength, Int64 strFieldMasterID, Int64 strValidationTypeID, Int32 strFieldPrivilegeID, string strFieldDataType, string strValue, int iCnt)
    {
        HtmlGenericControl li = new HtmlGenericControl("li");

        Label lbl = new Label();
        TextBox txtBox = new TextBox();
        CalendarExtender calendar = new CalendarExtender();
        ImageButton imgButton = new ImageButton();
        DropDownList ddl = new DropDownList();
        RadioButtonList radiobtnlst = new RadioButtonList();
        CheckBoxList chkbox = new CheckBoxList();


        try
        {
            lbl.Text = strFieldName + " : ";
            lbl.CssClass = "DynamicFieldslabel";
            string labeltitle = "\"" + lbl.Text + "\"";
            li.Controls.Add(lbl);

            switch (strFieldType)
            {
                case "Hidden":
                    HiddenField hdnField = new HiddenField();
                    hdnField.ID = strFieldID;
                    hdnField.Value = strFieldName;
                    li.Controls.Add(hdnField);
                    break;
                case "TextBox":
                    txtBox.ID = strFieldID;
                    txtBox.CssClass = "DynamicFieldstextbox";
                    string concat = "\"" + strFieldID + "\"";
                    txtBox.Text = strValue;
                    string txtvalue = "\"" + strValue + "\"";
                    if (strTextLength != 0)
                    {
                        txtBox.MaxLength = Convert.ToInt32(strTextLength);
                    }
                    else
                    {
                        txtBox.MaxLength = 15;//Convert.ToInt32(strTextLength);
                    }

                    if (strValidationTypeID == 1 | strValidationTypeID == 3 | strValidationTypeID == 4)//Validation
                    {
                        SetFilterField(txtBox, ref li, strValidationTypeID);

                    }
                    else if (strValidationTypeID == 2 | strValidationTypeID == 7)//Date & Date Time
                    {
                        SetDateFilterField(txtBox, ref li, strValidationTypeID);

                    }
                    else if (strValidationTypeID == 8)//Email
                    {

                        SetEmailFilterField(txtBox, ref li, strValidationTypeID);
                    }
                    li.Controls.Add(txtBox);


                    if (strFieldPrivilegeID == 1)//Mandatory
                    {
                        SetMandatoryField(txtBox, ref li, "TextBox", "", strFieldName);

                    }
                    else if (strFieldPrivilegeID == 3)//Read Only
                    {
                        txtBox.Enabled = false;
                    }
                    //if (hdEditMode.Value.ToString() == "2")
                    //    txtBox.Enabled = false;

                    break;
                case "TextArea":
                    txtBox.ID = strFieldID;
                    txtBox.CssClass = "DynamicFieldstextarea";
                    concat = "\"" + strFieldID + "\"";
                    //txtBox.CssClass = "Text";
                    txtBox.TextMode = TextBoxMode.MultiLine;
                    if (strTextLength != 0)
                    {
                        txtBox.Attributes.Add("onkeyup", "return checkMaxLen(this," + strTextLength + ")");
                    }
                    //if (strTextLength != 0)
                    //{
                    //  //  txtBox.MaxLength = Convert.ToInt32(strTextLength);
                    //    SetTextAreaMaxLengthField(txtBox, ref td2, "TextArea", strTextLength.ToString());
                    //}
                    txtBox.Columns = 20;
                    txtBox.Rows = 4;
                    txtBox.Text = strValue;

                    if (strValidationTypeID == 1 | strValidationTypeID == 3 | strValidationTypeID == 4)//Validation
                    {
                        SetFilterField(txtBox, ref li, strValidationTypeID);

                    }
                    else if (strValidationTypeID == 2 | strValidationTypeID == 7)//Date & Date Time
                    {
                        SetDateFilterField(txtBox, ref li, strValidationTypeID);

                    }
                    else if (strValidationTypeID == 8)//Email
                    {
                        SetEmailFilterField(txtBox, ref li, strValidationTypeID);

                    }
                    //txtBox.RenderControl(htw1);                                        
                    li.Controls.Add(txtBox);


                    if (strFieldPrivilegeID == 1)//Mandatory
                    {
                        SetMandatoryField(txtBox, ref li, "TextArea", "", strFieldName);
                    }
                    else if (strFieldPrivilegeID == 3)//Read Only
                    {
                        txtBox.Enabled = false;
                    }
                    ////if (hdEditMode.Value.ToString() == "2")
                    //    txtBox.Enabled = false;

                    break;
                case "DropDownList":
                    ddl.ID = strFieldID;
                    ddl.CssClass = "DynamicFieldsselect";
                    concat = "\"" + strFieldID + "\"";

                    Int64 fieldmasterid = strFieldMasterID;
                    FillControlValues(ddl, null, null, fieldmasterid);
                    ddl.SelectedValue = null;

                    //  ddl.SelectedValue = strValue;
                    if (strValue != string.Empty && strValue != "select")
                    {
                        if (ddl.Items.FindByText(strValue) != null)
                        {
                            ddl.Items.FindByText(strValue).Selected = true;
                        }
                    }
                    //ddl.RenderControl(htw);                    
                    li.Controls.Add(ddl);


                    if (strFieldPrivilegeID == 1)//Mandatory
                    {
                        SetMandatoryField(ddl, ref li, "DropDownList", "0", strFieldName);

                    }
                    else if (strFieldPrivilegeID == 3)//Read Only
                    {
                        ddl.Enabled = false;
                    }
                    //if (hdEditMode.Value.ToString() == "2")
                    //    ddl.Enabled = false;

                    break;
                case "RadioButtonList":
                    radiobtnlst.ID = strFieldID;
                    radiobtnlst.CssClass = "DynamicFieldschkbox";
                    radiobtnlst.RepeatDirection = System.Web.UI.WebControls.RepeatDirection.Horizontal;
                    radiobtnlst.RepeatColumns = 2;

                    fieldmasterid = strFieldMasterID;
                    FillControlValues(null, radiobtnlst, null, fieldmasterid);
                    if (strValue != string.Empty)
                    {
                        radiobtnlst.Items.FindByText(strValue).Selected = true;
                    }
                    //radiobtnlst.RenderControl(htw);                    
                    li.Controls.Add(radiobtnlst);


                    if (strFieldPrivilegeID == 1)//Mandatory
                    {
                        SetMandatoryField(radiobtnlst, ref li, "RadioButtonList", "", strFieldName);


                    }
                    else if (strFieldPrivilegeID == 3)//Read Only
                    {
                        radiobtnlst.Enabled = false;
                    }

                    //if (hdEditMode.Value.ToString() == "2")
                    //    radiobtnlst.Enabled = false;

                    break;
                case "CheckBoxList":
                    chkbox.ID = strFieldID;
                    chkbox.CssClass = "DynamicFieldschkbox";
                    //chkbox.CssClass = "Checkbox";
                    chkbox.RepeatDirection = System.Web.UI.WebControls.RepeatDirection.Horizontal;
                    chkbox.RepeatColumns = 2;

                    fieldmasterid = strFieldMasterID;
                    FillControlValues(null, null, chkbox, fieldmasterid);
                    //  chkbox.SelectedValue = strValue;

                    if (!string.IsNullOrEmpty(strValue) && strValue.Length >= 1)
                    {
                        List<string> strRecip = strValue.Trim().ToLower().Split(',').Select(p => p.Trim()).ToList();
                        foreach (ListItem list in chkbox.Items)
                        {
                            if (strRecip.Contains(list.Text.Trim().ToLower()))
                            {
                                list.Selected = true;
                            }
                        }
                    }
                    //else
                    //{
                    //   // chkbox.SelectedItem.Text = strValue;
                    //}

                    //chkbox.RenderControl(htw);
                    li.Controls.Add(chkbox);


                    if (strFieldPrivilegeID == 1)//Mandatory
                    {
                        SetMandatoryField(chkbox, ref li, "CheckBoxList", "", strFieldName);

                    }
                    else if (strFieldPrivilegeID == 3)//Read Only
                    {
                        chkbox.Enabled = false;
                    }
                    //if (hdEditMode.Value.ToString() == "2")
                    //    chkbox.Enabled = false;
                    break;


                case "Date":
                    txtBox.ID = strFieldID;
                    txtBox.CssClass = "DynamicFieldstextboxdate";
                    txtBox.Attributes.Add("readonly", "true");
                    txtBox.Text = fnConvertstringtodate(strValue);
                    imgButton.ID = "Img_" + strFieldMasterID;
                    imgButton.ImageUrl = "~/Images/calendar.gif";
                    imgButton.CssClass = "DynamicFieldsimgbutton";
                    imgButton.CausesValidation = false;

                    calendar.ID = "Cal_" + strFieldMasterID;
                    calendar.TargetControlID = txtBox.ID;
                    calendar.PopupButtonID = imgButton.ID;
                    calendar.Format = "dd/MM/yyyy";

                    li.Controls.Add(txtBox);
                    li.Controls.Add(imgButton);
                    li.Controls.Add(calendar);

                    if (strFieldPrivilegeID == 1)//Mandatory
                    {
                        SetMandatoryField(txtBox, ref li, "Date", "", strFieldName);
                    }
                    else if (strFieldPrivilegeID == 3)//Read Only
                    {
                        txtBox.Enabled = false; //by default made as readonly
                    }

                    //if (hdEditMode.Value.ToString() == "2")
                    //    txtBox.Enabled = false;
                    break;
            }



            if ((iCnt % 2 == 0))
            {
                Listitems1.Controls.Add(li);
            }
            else
            {
                Listitems2.Controls.Add(li);
            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            // lbl.Dispose();
            // txtBox.Dispose();
            //// calendar.Dispose();
            // imgButton.Dispose();
            //objDefaultValues = null;
            // ddl.Dispose();
            // radiobtnlst.Dispose();
            // chkbox.Dispose();
        }

    }



    private string fnConvertstringtodate(string strTextValue)
    {
        if (!string.IsNullOrEmpty(strValue))
        {
            string strConvertDate = string.Empty;
            System.DateTime cellDate = default(System.DateTime);
            string format = "dd/MM/yyyy";
            if (DateTime.TryParse(strTextValue, out cellDate))
            {
                strConvertDate = Convert.ToDateTime(strTextValue).ToString(format, System.Globalization.CultureInfo.InvariantCulture);
            }
            else if (DateTime.TryParseExact(strTextValue, format, System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out cellDate))
            {
                strConvertDate = Convert.ToDateTime(strTextValue).ToString(format, System.Globalization.CultureInfo.InvariantCulture);
            }
            return strConvertDate;
        }
        else
        {
            return string.Empty;
        }
    }

    private void SetMandatoryField(Control cMand, ref HtmlGenericControl Literal1, string controlType, string InitialValue, string strFieldName)
    {
        CustomValidator cv = new CustomValidator();
        RequiredFieldValidator rfv = new RequiredFieldValidator();
        try
        {
            var span = new LiteralControl("<span style='color:red;width:20px'>*</span>");
            Literal1.Controls.Add(span);
            if (controlType == "CheckBoxList")
            {
                cv.ID = "cv" + cMand.ID;
                //cv.ErrorMessage = "Please check atleast one " + strFieldName;
                //cv.CssClass = "mandatorytext";
                //cv.Display = ValidatorDisplay.None;
                cv.Enabled = true;
                cv.ValidationGroup = "DynamicCaseSubmit";
                cv.Attributes.Add("ControlToValidateID", "DefaultContent_" + cMand.ClientID);
                cv.ClientValidationFunction = "ValidateCheckBoxList";
                cv.SetFocusOnError = true;
                Literal1.Controls.Add(cv);
                // SetValidatorCalloutExtender(td, cv);
            }
            else
            {

                rfv.ID = "rfv" + cMand.ID;
                rfv.ControlToValidate = cMand.ID;
                rfv.ErrorMessage = "Please enter " + strFieldName;
                //rfv.CssClass = "mandatorytext";
                rfv.Display = ValidatorDisplay.None;
                rfv.Enabled = true;
                rfv.ValidationGroup = "DynamicCaseSubmit";
                if (controlType == "TextBox" || controlType == "TextArea" || controlType == "DropDownList" || controlType == "Date")
                {
                    rfv.InitialValue = InitialValue;
                }
                if (controlType == "DropDownList" || controlType == "RadioButtonList")
                {
                    rfv.ErrorMessage = "Please select " + strFieldName;
                }
                //rfv.RenderControl(htw1);
                //td.Controls.Add(rfv);
                Literal1.Controls.Add(rfv);
                SetValidatorCalloutExtender(Literal1, rfv);
            }
            //td.Align = "left";
        }

        catch (Exception ex)
        {
        }
        finally
        {

            cv.Dispose();
            rfv.Dispose();
        }
    }

    //private void SetMandatoryField_Checkbox(Control cMand, ref HtmlTableCell td, string controlType, string InitialValue)
    //{
    //    CustomValidator cv = new CustomValidator();
    //    RequiredFieldValidator rfv = new RequiredFieldValidator();
    //    try
    //    {
    //        var span = new LiteralControl("<span style='color:red'>*</span>");
    //        td.Controls.Add(span);
    //        if (controlType == "CheckBoxList")
    //        {
    //            cv.ID = "cv" + cMand.ID;
    //            cv.ErrorMessage = "Please check atleast one " + strFieldName;
    //            cv.CssClass = "mandatory";
    //            cv.Display = ValidatorDisplay.None;
    //            cv.Enabled = true;
    //            cv.Attributes.Add("ControlToValidateID", "DefaultContent_" + cMand.ClientID);
    //            cv.ClientValidationFunction = "ValidateCheckBoxList";
    //            td.Controls.Add(cv);

    //            SetValidatorCalloutExtender(td, cv);
    //        }
    //        else
    //        {
    //            rfv.ID = "rfv" + cMand.ID;
    //            rfv.ControlToValidate = cMand.ID;
    //            rfv.ErrorMessage = "Please enter " + strFieldName;
    //            rfv.CssClass = "mandatory";
    //            rfv.Display = ValidatorDisplay.None;
    //            rfv.Enabled = true;
    //            if (controlType == "TextBox" || controlType == "TextArea" || controlType == "DropDownList" || controlType == "Date")
    //                rfv.InitialValue = InitialValue;

    //            if (controlType == "DropDownList" || controlType == "RadioButtonList")
    //                rfv.ErrorMessage = "Please select " + strFieldName;
    //            td.Controls.Add(rfv);
    //            SetValidatorCalloutExtender(td, rfv);
    //        }

    //        td.Align = "left";
    //    }
    //    catch (Exception ex)
    //    {
    //    }
    //    finally
    //    {

    //        cv.Dispose();
    //        rfv.Dispose();
    //    }
    //}

    private void SetValidatorCalloutExtender(HtmlGenericControl td, Control con)
    {
        //StringWriter sw1 = new StringWriter(sb1);
        //HtmlTextWriter htw1 = new HtmlTextWriter(sw1);        
        ValidatorCalloutExtender vce = new AjaxControlToolkit.ValidatorCalloutExtender();
        try
        {
            vce.ID = "val" + con.ID;
            vce.TargetControlID = con.ID;
            vce.PopupPosition = ValidatorCalloutPosition.BottomRight;
            //vce.RenderControl(htw1);
            //td.Controls.Add(vce);
            td.Controls.Add(vce);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            vce.Dispose();

        }
    }
    //private void SetTextAreaMaxLengthField(Control cMand, ref HtmlTableCell td, string controlType, string InitialValue)
    //{
    //    RegularExpressionValidator rev = new RegularExpressionValidator();
    //    try
    //    {
    //        var span = new LiteralControl("<span style='color:red'>*</span>");
    //        td.Controls.Add(span);
    //        if (controlType == "TextBox" || controlType == "TextArea")
    //        {

    //            rev.ID = "cv" + cMand.ID;
    //            //rev.ErrorMessage = "*";
    //            rev.ControlToValidate = cMand.ID;
    //            rev.CssClass = "mandatory";
    //            rev.Display = ValidatorDisplay.None;
    //            rev.Enabled = true;
    //            //    rev.ValidationGroup = "DataEntryPage";
    //            String regFormat = @"\b[a-zA-Z]{" + InitialValue.ToString() + @"}\b";

    //            rev.ValidationExpression = regFormat; //@"^[\s\S]{0," + InitialValue.ToString() + "}$";
    //            td.Controls.Add(rev);
    //            td.Controls.Add(span);
    //        }

    //        td.Align = "left";
    //    }

    //    catch (Exception ex)
    //    {
    //    }
    //    finally
    //    {

    //        rev.Dispose();
    //    }
    //}

    private void SetFilterField(Control cMand, ref HtmlGenericControl Literal1, Int64 strValidationTypeID)
    {
        //StringWriter sw1 = new StringWriter(sb1);
        //HtmlTextWriter htw1 = new HtmlTextWriter(sw1);       
        FilteredTextBoxExtender fe = new FilteredTextBoxExtender();
        try
        {
            fe.ID = "fe" + cMand.ID;
            fe.TargetControlID = cMand.ID;
            if (strValidationTypeID == 1)//Numeric
            {
                fe.FilterType = FilterTypes.Numbers;
            }
            else if (strValidationTypeID == 3)//Alphabet
            {
                fe.FilterType = FilterTypes.LowercaseLetters | FilterTypes.UppercaseLetters;//"LowercaseLetters, UppercaseLetters";       
                fe.ValidChars = " ";
            }
            else if (strValidationTypeID == 4)//AlphaNumeric
            {
                fe.FilterType = FilterTypes.Numbers | FilterTypes.LowercaseLetters | FilterTypes.UppercaseLetters;// "Numbers, UppercaseLetters, LowercaseLetters";
                fe.ValidChars = " ";
            }
            //fe.RenderControl(htw1);           
            //td.Controls.Add(fe);
            //td.Align = "left";
            Literal1.Controls.Add(fe);
        }
        catch (Exception ex)
        {
        }
        finally
        {


        }
    }

    private void SetEmailFilterField(Control cMand, ref HtmlGenericControl Literal1, Int64 strValidationTypeID)
    {
        //StringWriter sw1 = new StringWriter(sb1);
        //HtmlTextWriter htw1 = new HtmlTextWriter(sw1);        
        RegularExpressionValidator rev = new RegularExpressionValidator();
        try
        {
            rev.ID = "rev" + cMand.ID;
            rev.ControlToValidate = cMand.ID;
            //SAST Fix for "ReDoS In Validation" - Varma
            rev.ValidationExpression = @"/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$/";// SAST Fix for "ReDoS In Validation" - varma - old pattern ((\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)*([;])*)*
            rev.ErrorMessage = strFieldName + " : Invalid email format";
            rev.Display = ValidatorDisplay.None;
            //rev.RenderControl(htw1);
            //td.Controls.Add(rev);
            Literal1.Controls.Add(rev);
            SetValidatorCalloutExtender(Literal1, rev);
            //td.Align = "left";

        }

        catch (Exception ex)
        {
        }
        finally
        {

            rev.Dispose();
        }
    }

    private void SetDateFilterField(Control cMand, ref HtmlGenericControl Literal1, Int64 strValidationTypeID)
    {
        //StringWriter sw1 = new StringWriter(sb1);
        //HtmlTextWriter htw1 = new HtmlTextWriter(sw1);        
        //var span = new LiteralControl("<span style='color:red'>*</span>");
        MaskedEditExtender mee = new MaskedEditExtender();
        MaskedEditValidator mev = new MaskedEditValidator();
        try
        {
            mee.ID = "mee" + cMand.ID;
            mee.TargetControlID = cMand.ID;
            mee.MessageValidatorTip = true;
            mee.ErrorTooltipEnabled = true;
            //mee.CultureName = "en-US";

            mev.ID = "mev" + cMand.ID;
            mev.ControlExtender = "mee" + cMand.ID;
            mev.ControlToValidate = cMand.ID;
            mev.InvalidValueMessage = strFieldName + " : Invalid date format";
            mev.Display = ValidatorDisplay.None;
            mev.InvalidValueBlurredMessage = strFieldName + " : Invalid date format";
            mev.ErrorMessage = strFieldName + " : Invalid date format";

            if (strValidationTypeID == 2)//Date
            {
                mee.Mask = "99/99/9999";
                mee.MaskType = MaskedEditType.Date;
                mee.DisplayMoney = MaskedEditShowSymbol.Left;
                mee.AcceptNegative = MaskedEditShowSymbol.Left;
            }
            else if (strValidationTypeID == 7)//DateTime
            {
                mee.Mask = "99/99/9999";
                //mee.UserTimeFormat = MaskedEditUserTimeFormat.TwentyFourHour;
                mee.MaskType = MaskedEditType.Date;
                mee.AcceptAMPM = true;
            }
            //mee.RenderControl(htw1);
            //td.Controls.Add(mee);
            Literal1.Controls.Add(mee);
            //mev.RenderControl(htw1);
            //td.Controls.Add(mev);
            Literal1.Controls.Add(mev);
            SetValidatorCalloutExtender(Literal1, mev);
            //td.Align = "left";
        }

        catch (Exception ex)
        {
        }
        finally
        {

            mee.Dispose();
            mev.Dispose();
        }
    }


    public void FillControlValues(DropDownList ddl, RadioButtonList rbl, CheckBoxList cbl, Int64 FMID)
    {
        try
        {
            Hashtable hs = new Hashtable();
            hs.Add("@FieldMasterId", FMID);
            using (DataSet dsDDL = _presenter.GetControlValuesForBinding(hs))
            {
                if (dsDDL != null && dsDDL.Tables.Count > 0)
                {
                    if (ddl != null)
                    {
                        ddl.ClearSelection();
                        ddl.DataSource = dsDDL.Tables[0];
                        ddl.DataTextField = "OptionText";
                        ddl.DataValueField = "OptionValue";
                        ddl.DataBind();
                        ddl.Items.Insert(0, new ListItem("select", "0"));
                    }
                    else if (rbl != null)
                    {
                        rbl.DataSource = dsDDL.Tables[0];
                        rbl.DataTextField = "OptionText";
                        rbl.DataValueField = "OptionValue";
                        rbl.DataBind();
                    }
                    else if (cbl != null)
                    {
                        cbl.DataSource = dsDDL.Tables[0];
                        cbl.DataTextField = "OptionText";
                        cbl.DataValueField = "OptionValue";
                        cbl.DataBind();
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
    }


    protected void GenerateInsParams(Control Ctrl)
    {
        int i = 0;
        string strCurValue = string.Empty;
        try
        {
            for (i = 0; i <= Ctrl.Controls.Count - 1; i++)
            {
                strCurValue = GetControlValue(Ctrl.Controls[i]);
                if (strCurValue != string.Empty)
                {
                    strSQL += " AND " + GetControlValue(Ctrl.Controls[i]);
                }

                GenerateInsParams(Ctrl.Controls[i]);
            }
            strInsSQL = strSQL;
        }
        catch (Exception ex)
        {

        }
        finally
        {
            i = 0;
            strCurValue = string.Empty;
            strInsSQL = string.Empty;
        }



    }


    protected string GetControlValue(Control Ctrl)
    {
        string strRet = "";
        try
        {

            if (object.ReferenceEquals(Ctrl.GetType(), typeof(TextBox)))
            {
                TextBox txtBox = (TextBox)Ctrl;
                if (txtBox.Text != string.Empty)
                {
                    strRet = "[" + txtBox.ID + "] = '" + txtBox.Text.Trim().Replace("'", "''") + "'";
                }
                txtBox.Dispose();
            }
            else if (object.ReferenceEquals(Ctrl.GetType(), typeof(DropDownList)))
            {
                DropDownList ddl = (DropDownList)Ctrl;
                if (ddl.SelectedValue != string.Empty)
                {
                    strRet = "[" + ddl.ID + "] = '" + ddl.SelectedValue + "'";
                }
                ddl.Dispose();
            }
            else if (object.ReferenceEquals(Ctrl.GetType(), typeof(RadioButtonList)))
            {
                RadioButtonList rabtnlst = (RadioButtonList)Ctrl;
                strRet = "[" + rabtnlst.ID + "] = '" + rabtnlst.SelectedItem + "'";
                rabtnlst.Dispose();
            }
            else if (object.ReferenceEquals(Ctrl.GetType(), typeof(CheckBox)))
            {
                string strenabled;
                CheckBox chkbox = (CheckBox)Ctrl;
                if (chkbox.Checked)
                    strenabled = "Y";
                else
                    strenabled = "N";
                strRet = "[" + chkbox.ID + "] = '" + strenabled.ToString() + "'";
                chkbox.Dispose();
            }
            return strRet;
        }
        catch (Exception ex)
        {
            //EMTErrorLog.HandleError(ex, "DataEntry - GetControlValue");
            throw;
        }
        finally
        {
            strRet = string.Empty;
        }
    }

    protected void GenerateInsParams_CaseID(Control Ctrl, ref StringBuilder sqlTColumn, ref StringBuilder sqlTValue, ref StringBuilder sqlCColumn, ref StringBuilder sqlCValue, ref StringBuilder sqlXmlValue)
    {
        int i = 0;

        for (i = 0; i <= Ctrl.Controls.Count - 1; i++)
        {
            GetControlValue_CaseID(Ctrl.Controls[i], ref sqlTColumn, ref sqlTValue, ref sqlCColumn, ref sqlCValue, ref sqlXmlValue);
            //StringBuilder sb3 = new StringBuilder();
            //StringWriter sw3 = new StringWriter(sb3);
            //HtmlTextWriter htw3= new HtmlTextWriter(sw3);
            //Ctrl.Controls[i].RenderControl(htw3);
            //GetControlValue_CaseID(ref sb3, ref sqlTColumn, ref sqlTValue, ref sqlCColumn, ref sqlCValue, ref sqlXmlValue);
            GenerateInsParams_CaseID(Ctrl.Controls[i], ref sqlTColumn, ref sqlTValue, ref sqlCColumn, ref sqlCValue, ref sqlXmlValue);
        }

    }

    protected void GetControlValue_CaseID(Control Ctrl, ref StringBuilder sqlTColumn, ref StringBuilder sqlTValue, ref StringBuilder sqlCColumn, ref StringBuilder sqlCValue, ref StringBuilder sqlXmlValue)
    {
        string selval = string.Empty;
        try
        {
            //Control Ctrl = (Control)Page.FindControl("sb3");
            if (object.ReferenceEquals(Ctrl.GetType(), typeof(TextBox)))
            //if (object.ReferenceEquals(Ctrl.GetType(), typeof(HtmlInputButton)))
            {
                TextBox txtBox = (TextBox)Ctrl;
                if (txtBox.Text != string.Empty)
                {
                    string format = "dd/MM/yyyy";
                    DateTime dateTime;

                    //if (DateTime.TryParse(txtBox.Text, out dateTime))
                    //{
                    //    txtBox.Text =Server.HtmlEncode(DateTime.ParseExact(txtBox.Text, format, System.Globalization.CultureInfo.InvariantCulture).ToString("yyyy-MM-dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture));
                    //}
                    //else
                    if (DateTime.TryParseExact(txtBox.Text, format, System.Globalization.CultureInfo.InvariantCulture,
                        System.Globalization.DateTimeStyles.None, out dateTime))
                    {
                        txtBox.Text = Server.HtmlEncode(DateTime.ParseExact(txtBox.Text, format, System.Globalization.CultureInfo.InvariantCulture).ToString("yyyy-MM-dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture));
                    }

                    if (txtBox.ID.ToString().Split('_')[1] == "SF")//STATIC FIELD
                    {
                        sqlTValue.Append("" + txtBox.Text.Trim() + "");
                    }
                    else if (txtBox.ID.ToString().Split('_')[1] == "DF")//DYNAMIC FIELD
                    {
                        sqlXmlValue.Append("<row  FieldMasterID = '" + txtBox.ID.ToString().Split('_')[3] + "'  FieldValue =" + (txtBox.Text.Trim() == " " ? " " : "'" + txtBox.Text.Trim() + "'    IsListValue = '0' />"));
                    }
                }
            }

            else if (object.ReferenceEquals(Ctrl.GetType(), typeof(DropDownList)))
            {

                DropDownList ddl = (DropDownList)Ctrl;
                if (ddl.SelectedIndex > 0 && ddl.SelectedValue.Trim() != "select")
                {
                    if (ddl.SelectedValue != string.Empty || ddl.SelectedValue != "0")
                    {
                        if (ddl.ID.ToString().Contains("__"))
                        {
                            ddl.ID = ddl.ID.ToString().Replace("__", " ");
                        }
                        if (ddl.ID.ToString().Split('_')[1] == "DF")//DYNAMIC FIELD || ddl.ID.ToString().Split('_')[1] == "SF"
                        {
                            sqlXmlValue.Append("<row  FieldMasterID = '" + ddl.ID.ToString().Split('_')[3] + "'  FieldValue =" + (ddl.SelectedValue == " " ? " " : "'" + ddl.SelectedItem.Text.ToString() + "'    IsListValue = '0' />"));
                        }
                    }
                }
                ddl.Dispose();
            }
            else if (object.ReferenceEquals(Ctrl.GetType(), typeof(RadioButtonList)))
            {
                selval = string.Empty;
                RadioButtonList rabtnlst = (RadioButtonList)Ctrl;
                if (rabtnlst.ID.ToString().Contains("__"))
                {
                    //SAST fixes
                    rabtnlst.ID = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(rabtnlst.ID.ToString().Replace("__", " "), true);
                }
                if (rabtnlst.ID.ToString().Split('_')[1] == "DF")//DYNAMIC FIELD -- || rabtnlst.ID.ToString().Split('_')[1] == "SF"
                {
                    //  selval = rabtnlst.Items.Cast<ListItem>().Where(item => item.Selected).Aggregate(selval, (current, item) => current + (item.Value + ','));
                    //  selval.TrimEnd(',');
                    sqlXmlValue.Append("<row   FieldMasterID = '" + rabtnlst.ID.ToString().Split('_')[3] + "'  FieldValue  =" + (rabtnlst.SelectedValue == " " ? " 0 " : "'" + rabtnlst.SelectedItem.Text.ToString() + "' IsListValue = '0' />"));
                }
                rabtnlst.Dispose();
            }
            else if (object.ReferenceEquals(Ctrl.GetType(), typeof(CheckBoxList)))
            {
                selval = string.Empty;
                CheckBoxList chkbox = (CheckBoxList)Ctrl;
                if (chkbox.ID.ToString().Contains("__"))
                {
                    chkbox.ID = chkbox.ID.ToString().Replace("__", " ");
                }
                if (chkbox.ID.ToString().Split('_')[1] == "DF")//DYNAMIC FIELD  -- || chkbox.ID.ToString().Split('_')[1] == "SF"
                {
                    string strselText = string.Empty;
                    selval = chkbox.Items.Cast<ListItem>().Where(item => item.Selected).Aggregate(selval, (current, item) => current + (item.Value + ','));
                    selval = selval.Trim().Remove(selval.Length - 1);// TrimEnd(',');

                    strselText = chkbox.Items.Cast<ListItem>().Where(item => item.Selected).Aggregate(strselText, (current, item) => current + (item.Text + ','));
                    strselText = strselText.Trim().Remove(strselText.Length - 1);// TrimEnd(',');
                    // if(selval == string.Empty )
                    sqlXmlValue.Append("<row  FieldMasterID = '" + chkbox.ID.ToString().Split('_')[3] + "'  FieldValue =" + (chkbox.SelectedValue == " " ? " 0 " : "'" + selval + "'   FieldText ='" + strselText + "' IsListValue = '1' />"));
                    // else
                    //   sqlXmlValue.Append("<row  FieldMasterID = '" + chkbox.ID.ToString().Split('_')[3] + "'  FieldValue =" + (chkbox.SelectedValue == " " ? " 0 " : "'" + selval + "'   FieldText ='" + strselText + "' IsListValue = '0' />"));
                }
                chkbox.Dispose();
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            selval = string.Empty;
        }
    }

    protected void ClearControlValues(Control Ctrl)
    {
        int i = 0;

        for (i = 0; i <= Ctrl.Controls.Count - 1; i++)
        {
            ClearIndividualControlValues(Ctrl.Controls[i]);
            ClearControlValues(Ctrl.Controls[i]);
        }

    }

    protected void ClearIndividualControlValues(Control Ctrl)
    {

        string selval = string.Empty;

        try
        {

            if (object.ReferenceEquals(Ctrl.GetType(), typeof(TextBox)))
            {
                TextBox txtBox = (TextBox)Ctrl;
                if (txtBox.Text != string.Empty)
                {
                    txtBox.Text = "";
                }
            }

            else if (object.ReferenceEquals(Ctrl.GetType(), typeof(DropDownList)))
            {

                DropDownList ddl = (DropDownList)Ctrl;
                if (ddl.SelectedIndex > 0 && ddl.SelectedValue.Trim() != "select")
                {
                    ddl.SelectedIndex = 0;
                }
                ddl.Dispose();
            }
            else if (object.ReferenceEquals(Ctrl.GetType(), typeof(RadioButtonList)))
            {
                selval = string.Empty;
                RadioButtonList rabtnlst = (RadioButtonList)Ctrl;
                rabtnlst.ClearSelection();
                rabtnlst.Dispose();
            }
            else if (object.ReferenceEquals(Ctrl.GetType(), typeof(CheckBoxList)))
            {
                selval = string.Empty;
                CheckBoxList chkbox = (CheckBoxList)Ctrl;
                chkbox.ClearSelection();
                chkbox.Dispose();
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            selval = string.Empty;
        }
    }

    ////For Old Cases Already created with Special Chars
    //private static string ReplaceSpecialCharacters(string FileName)
    //{
    //    //return FileName.Replace("\"", "^1^").Replace("*", "^2^").Replace(@"/", "^3^").Replace(":", "^4^").Replace("<", "^5^").Replace(">", "^6^").Replace("?", "^7^").Replace(@"\", "^8^").Replace("|", "^9^").Replace("\t", "^10^").Replace("\r", "^11^").Replace("\n", "^12^");
    //    return FileName.Replace("\"", " ").Replace("*", " ").Replace(@"/", " ").Replace(":", " ").Replace("<", " ").Replace(">", " ").Replace("?", " ").Replace(@"\", " ").Replace("|", " ").Replace("\t", " ").Replace("\r", " ").Replace("\n", " ");
    //}




    //#endregion


    protected void btnDFSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (Page.IsValid)
            {
                if (Convert.ToInt32(hdnStatusId.Value) != (int)Constant.Status.Completed)
                {
                    StringBuilder sqlTColumn = new StringBuilder();
                    StringBuilder sqlTValue = new StringBuilder();
                    StringBuilder sqlCColumn = new StringBuilder();
                    StringBuilder sqlCValue = new StringBuilder();
                    StringBuilder sqlXMLValue = new StringBuilder();
                    sqlXMLValue.Append("<root>");
                    GenerateInsParams_CaseID(pnlAllocation, ref sqlTColumn, ref sqlTValue, ref sqlCColumn, ref sqlCValue, ref sqlXMLValue);
                    // Combine all string builder values		
                    sqlXMLValue.Append("</root>");
                    _presenter.Updatedynamicfields(Convert.ToInt64(hdnCaseId.Value), sqlXMLValue, objUser.UserId);
                    //  updateProgressDiv.Disabled = true;
                    AlertBox("Attributes has been updated successfully.");
                    //ClearControlValues(pnlAllocation);
                }
            }
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    //saranya
    //195174 reassign
    protected void lnkUpdate_Click(object sender, EventArgs e)
    {
        try
        {

            string strUserId = objUser.UserId;
            string strCaseIDs = string.Empty;

            Hashtable hsReAssign = new Hashtable();
            if (ddlAssignedTo.SelectedIndex != 0)
            {
                hsReAssign.Add("@AllocatedToId", ddlAssignedTo.SelectedValue.Trim());
                hsReAssign.Add("@CaseIds", hdnCaseId.Value);
                hsReAssign.Add("@LoggedInUserId", objUser.UserId);

                int res = this._presenter.UpdateOnReassign(hsReAssign);
                if (res != 0)
                {

                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Case Assigned to the Selected User!');", true);
                    hdnCaseassignedTo.Value = ddlAssignedTo.SelectedValue.Trim();
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Transaction is UnSuccessful!');", true);
                }

            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select User to Reassign!');", true);
            }

        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | lnkUpdate_Click()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs | lnkUpdate_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }

        lnkReassign.Visible = false;
        lnkUpdate.Visible = false;
        ddlAssignedTo.Visible = false;
        lblAssignedTo.Visible = true;
        LoadCaseDetails();
    }

    //Rajani
    //511725 remapping of category
    protected void lnkCategoryUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            string strUserId = objUser.UserId;
            string strCaseIDs = string.Empty;

            Hashtable hsReMap = new Hashtable();
            if (ddlcategoryMappedto.SelectedIndex != 0)
            {
                hsReMap.Add("@MappedCategory", ddlcategoryMappedto.SelectedValue.Trim());
                hsReMap.Add("@CaseId", hdnCaseId.Value);
                hsReMap.Add("@Modifiedby", objUser.UserId);

                int res = this._presenter.UpdateOnRemappingOfCategory(hsReMap);
                if (res != 0)
                {

                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Case Mapped to the Selected Category!');", true);
                    hdnclassificationName.Value = ddlcategoryMappedto.SelectedValue.Trim();
                    lnkcategoryRemap.Text = ddlcategoryMappedto.SelectedValue.Trim();
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Transaction is UnSuccessful!');", true);
                }

            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select Category to Remap!');", true);
            }

        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | lnkCategoryUpdate_Click()");
            //errorlog.HandleError(ex, objUser.UserId , " | ProcessingNewUI.aspx.cs | lnkUpdate_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
        }

        lnkcategoryRemap.Visible = true;
        lnkCategoryUpdate.Visible = false;
        ddlcategoryMappedto.Visible = false;
        lnkCategoryCancel.Visible = false;
        //LoadCaseDetails();
    }


    protected void lnkCancel_Click1(object sender, EventArgs e)
    {
        try
        {
            // LoadCaseDetails();
            lblAssignedTo.Visible = true;
            lnkReassign.Visible = true;
            lnkUpdate.Visible = false;
            ddlAssignedTo.Visible = false;
            lnkCancel.Visible = false;
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | lnkCancel_Click1()");
            //errorlog.HandleError(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | lnkCancel_Click1()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }

    }


    protected void lnkCategoryCancel_Click(object sender, EventArgs e)
    {
        try
        {
            lnkcategoryRemap.Visible = true;
            lnkCategoryUpdate.Visible = false;
            ddlcategoryMappedto.Visible = false;
            lnkCategoryCancel.Visible = false;
        }
        catch (Exception ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | lnkCategoryCancel_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
        }

    }

    #endregion

    //[System.Web.Script.Services.ScriptMethod]
    //[System.Web.Services.WebMethod]
    //public static List<string> GetCompletionList(string prefixText, int count)
    //{
    //    List<string> lstMailIds = new List<string>();


    //    DataSet resultDs = null;

    //    if (HttpContext.Current != null)
    //    {
    //        if (HttpContext.Current.Session != null)
    //        {
    //            resultDs = new ProcessingPresenter(new EMTWebApp.Common.CommonController()).GetContactListForEmailbox(prefixText, long.Parse(HttpContext.Current.Session["ProcessingEmailbox"].ToString()));
    //            if (resultDs != null)
    //            {
    //                if (resultDs.Tables[0] != null)
    //                {
    //                    foreach (DataRow dRow in resultDs.Tables[0].Rows)
    //                    {
    //                        lstMailIds.Add(dRow[0].ToString());
    //                    }
    //                }
    //            }
    //        }
    //    }

    //    return lstMailIds;
    //}
    [System.Web.Script.Services.ScriptMethod]
    [System.Web.Services.WebMethod]
    public static List<string> GetToEmailID(string prefixText)
    {
        List<string> lstMailIds = new List<string>();
        DataSet resultDs = null;
        if (HttpContext.Current != null)
        {
            if (HttpContext.Current.Session != null)
            {
                resultDs = new ProcessingPresenter(new CommonController()).GetToEmailIDofUsers(prefixText, long.Parse(HttpContext.Current.Session["ProcessingEmailbox"].ToString()));
                if (resultDs != null)
                {
                    if (resultDs.Tables[0] != null)
                    {
                        foreach (DataRow dRow in resultDs.Tables[0].Rows)
                        {
                            lstMailIds.Add(dRow[0].ToString().Trim());
                        }
                    }
                }
            }
        }


        return lstMailIds;
    }

    [System.Web.Script.Services.ScriptMethod]
    [System.Web.Services.WebMethod]
    public static List<string> GetCcEmailID(string prefixText)
    {
        List<string> lstMailIds = new List<string>();
        DataSet resultDs = null;
        if (HttpContext.Current != null)
        {
            if (HttpContext.Current.Session != null)
            {
                resultDs = new ProcessingPresenter(new CommonController()).GetCcEmailIDofUsers(prefixText, long.Parse(HttpContext.Current.Session["ProcessingEmailbox"].ToString()));
                if (resultDs != null)
                {
                    if (resultDs.Tables[1] != null)
                    {
                        foreach (DataRow dRow in resultDs.Tables[1].Rows)
                        {
                            lstMailIds.Add(dRow[0].ToString());
                        }
                    }
                }
            }
        }
        return lstMailIds;
    }

    #region Auto Reply METHODS
    private void GetAutoReply()
    {
        DataSet ds = _presenter.GetAutoReply(Convert.ToInt64(hdnCaseId.Value));
        if (ds.Tables[0].Rows.Count > 0)
        {
            ltrAutoreply.Text = ds.Tables[0].Rows[0]["AutoReplyText"].ToString();
        }
        if (ltrAutoreply.Text != "")
        {
            lnkbtnAutoreply.Visible = true;
            Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "openOverlay('#overlay-inAboxAutoReply');", true);
        }
        else
        {
            lnkbtnAutoreply.Visible = false;
            //Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "openOverlay('#overlay-inAboxAutoReply');", false);
        }
    }
    #endregion

}

    #endregion


