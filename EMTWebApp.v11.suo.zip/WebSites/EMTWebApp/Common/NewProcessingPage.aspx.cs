﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Windows.Input;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using EMTWebApp.Common.Common;
using EMTWebApp.Constants;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Net.Mail;
using Microsoft.Exchange.WebServices.Data;
using AjaxControlToolkit;
using AjaxControlToolkit.HTMLEditor;
using System.Net;
using EMTWebApp.Common.Views;
using EMTWebApp.Common;
using System.Globalization;
using DigiOPS.TechFoundation.Security;
using DigiOPS.TechFoundation.Logging;
using System.Collections.Specialized;
using System.Configuration;

public partial class Common_NewProcessingPage : System.Web.UI.Page
{
    UserSession objUser = new UserSession();

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["UserDetails"] != null)
            {
                Session["CurrentPage"] = "NewProcessing";
                objUser = (UserSession)Session["userdetails"];
                
                    hdnLoginId.Value = objUser.UserId.ToString();
                    hdnRoleId.Value = objUser.RoleId.ToString();

                //saranya
                    //fname.Value = objUser.FirstName.ToString();
                    //role.Value = objUser.RoleName.ToString();
                    //UID.Value = objUser.UserId.ToString();
                    //roleID.Value = objUser.RoleId.ToString();                                      
                    //ISAD.Value = ConfigurationManager.AppSettings["ADLogin"].ToString();

                    //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                    string PKeyword = (Session["PasswordExpiration"]).ToString();
                    if (PKeyword == "yes")
                    {
                        Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                    }                           
                    if (objUser.RoleName == "Super Admin" || objUser.RoleName == "Admin" || objUser.RoleName == "Team Lead")
                    {
                        
                    }                   
                }                              
                
                if (Request.QueryString["PreviousPage"] != "ProcessingNewUI")
                {
                    Session["prevurl"] = Request.QueryString;
                    Session["prevcaseid"] = hdnCaseId.Value;
                }                             
        }
        catch (Exception ex)
        {            
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ProcessingNewUI.aspx.cs | Page_Load()");         
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), true);
        }
    }
}