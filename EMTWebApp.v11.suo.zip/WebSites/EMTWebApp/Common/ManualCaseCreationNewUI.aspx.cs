﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using EMTWebApp.Common.Common;
using EMTWebApp.Constants;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Net.Mail;
using Microsoft.Exchange.WebServices.Data;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Linq;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Security;
using System.Configuration;
using AjaxControlToolkit;

namespace EMTWebApp.Common.Views
{
    public partial class ManualCaseCreationNewUI : Microsoft.Practices.CompositeWeb.Web.UI.Page, IManualCaseCreationView
    {
        #region DECLARATION

        private ManualCaseCreationPresenter _presenter;
        UserSession objUser = new UserSession();
        private EMailBoxCredentials objEMailCredentials = new EMailBoxCredentials();
        private List<EMTWebApp.Constants.Attachment> fileCollection = new List<EMTWebApp.Constants.Attachment>();
        UserErrorLog errorlog = new UserErrorLog();
        private string LoginId;
        string encryptionmode = ConfigurationManager.AppSettings["ENCRYPT/DECRYPT"].ToString();
        string GMBtoGMBCaseTraversal = ConfigurationManager.AppSettings["GMBtoGMBCaseTraversal"].ToString();
        // Product License
        string ToolPurchased = ConfigurationManager.AppSettings["ToolPurchased"].ToString();
        string DateOfPurchase = ConfigurationManager.AppSettings["DateOfPurchase"].ToString();
        string Version = ConfigurationManager.AppSettings["Version"].ToString();
        string InstanceID = ConfigurationManager.AppSettings["InstanceID"].ToString();
        int MaxNoOfUser = Convert.ToInt16(ConfigurationManager.AppSettings["MaxNoOfUser"].ToString());
        string ClientName = ConfigurationManager.AppSettings["ClientName"].ToString();
        int usercount;
        string LicenseKey;
        string Errormessage;
        string LicenseStatus;
        string ErrorMessage;

        string strFieldID, strFieldName, strFieldType, strFieldDataType = "", strValue = "";
        HtmlTable tab = new HtmlTable();
        HtmlTableRow tr = new HtmlTableRow();
        HtmlTableRow tr1 = new HtmlTableRow();
        HtmlTableCell td1 = new HtmlTableCell();
        HtmlTableCell td2 = new HtmlTableCell();
        string strInsSQL = "";
        string strSQL = "";
        string strUserID = string.Empty;
        string strValidationType = string.Empty;
        Int32 ClientID = 0, MailboxID, strFieldPrivilegeID;
        Int64 CaseID = 0, strTextLength, strValidationTypeID, strFieldMasterID;
        #endregion


        #region PROPERTIES
        [CreateNew]
        public ManualCaseCreationPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["userdetails"] != null)
            {
                Session["CurrentPage"] = "Manual Case Creation";
                objUser = (UserSession)Session["userdetails"];
                IsValidAsscess(objUser);

                LoginId = objUser.UserId.ToString();
                if (GMBtoGMBCaseTraversal == "ON")
                {
                    liComposeGMB.Visible = true;
                }
                if (!this.IsPostBack)
                {
                    Session["CheckRefresh"] = Server.UrlDecode(System.DateTime.Now.ToString());
                    try
                    {
                        Session["ManualCaseAttachment"] = null; //To initialize the attachments session
                        _presenter.GetCountryByUserId(objUser.UserId); //Bind the Country dropdown
                        #region CLASSIFICATIONDROPDOWN
                        BindClassificationlist();
                        //Session["Classification"] = null;
                        //if (Session["Classification"] == null)
                        //{
                        //    ddlClassification.Visible = false;
                        //    lblClassification.Visible = false;
                        //}
                        #endregion
                        this._presenter.OnViewInitialized();

                    }
                    catch (Exception ex)
                    {
                        //ExceptionHelper.HandleException(ex);
                        new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | Page_Load()");
                        //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | Page_Load()");
                        Response.Clear();
                        Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                        Response.End();
                    }
                }

                if (IsPostBack)
                {
                    this.Page.ClientScript.RegisterStartupScript(this.GetType(), "StartupScript", "Sys.Application.add_load(function() { bindEvents(); });", true);

                    if (Session["ManualCaseAttachment"] != null)
                    {
                        DisplayAttachments();
                    }
                    htmlEditorMailBody.InnerHtml = hdntypedContent.Value;
                   

                    string CtrlID = string.Empty;
                    if (Request.Form["__EVENTTARGET"] != null &&
                        Request.Form["__EVENTTARGET"] != string.Empty)
                    {
                        CtrlID = Request.Form["__EVENTTARGET"];
                    }

                    if (CtrlID != "ctl00$DefaultContent$ddlEMailBox")
                    {
                        LoadDynamicControls();
                    }
                    //}

                }
                //LoadDynamicControls();
                ProductLicense();
                if (LicenseStatus == "False")
                {
                    this._presenter.OnViewLoaded();
                    ddlCountry.Enabled = false;

                    if (ErrorMessage.CompareTo("Expired Product License Key") == 0)
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Product License Key Expired , Please contact EMT team for Reneual of License key...');", true);
                    }
                    else
                    {
                        if (Errormessage.CompareTo("User Count exceeds the maximum value") == 0)
                        {

                            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('User Count exceeds the maximum value. Please Contact EMT Team for Higher version of User Count');", true);
                        }
                        else
                        {
                            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + Errormessage + "');", true);
                        }

                    }
                    // ClientScript.RegisterStartupScript(this.GetType(), "LicenseStatus", "alert('" + Errormessage + "');", true);

                }
                if (ErrorMessage.CompareTo("Product License Key will expire in a week") == 0)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert(' Product License Key will expire in a week Please contact EMT team for Reneual of License key... ');", true);
                }
            }
            else
            {
                Response.Clear();
                Response.Redirect("~/Errors/SessionExpired.aspx", false);
                Response.End();
            }
            this._presenter.OnViewLoaded();

        }


        protected void Page_PreRender(object sender, EventArgs e)
        {
            ViewState["CheckRefresh"] = Session["CheckRefresh"];
        }




        #region PRIVATE METHODS


        private void IsValidAsscess(UserSession UserDetails)
        {
            try
            {
                if ((UserDetails.RoleId != (int)Constant.UserRole.Processor) && (UserDetails.RoleId != (int)Constant.UserRole.TeamLead))
                {
                    Response.Clear();
                    Response.Redirect(@"~\Errors\AccessDenied.aspx", false);
                    Response.End();
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | IsValidAsscess()");
                //errorlog.HandleError(Ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | IsValidAsscess()");
                //ExceptionHelper.HandleException(Ex);
            }
        }

        private void BindClassificationlist()
        {
            try
            {
                DataSet ds = new DataSet();

                ds = _presenter.GetclassificationList();

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    ddlClassification.DataSource = ds;
                    ddlClassification.DataTextField = "ClassifiactionDescription";
                    //ddlCategoryManualpage.DataValueField = "EmailboxCategoryId";
                    ddlClassification.DataBind();
                    ddlClassification.Items.Insert(0, new ListItem("--Select--", "0"));
                    hdnClassification.Value = "1";
                }
                else
                {
                    ddlClassification.Visible = false;
                    lblClassification.Visible = false;
                    hdnClassification.Value = "0";
                    //ddlCategoryManualpage.DataSource = null;
                    //ddlCategoryManualpage.DataBind();
                    //ddlCategoryManualpage.Items.Insert(0, new ListItem("Category", "0"));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void AddAttachmentToFileCollection(HttpPostedFile UploadedFile)
        {
            try
            {
                if (UploadedFile.ContentLength > 0)
                {
                    EMTWebApp.Constants.Attachment attach = new EMTWebApp.Constants.Attachment();
                    Stream strm = UploadedFile.InputStream;

                    string fileName = System.IO.Path.GetFileName(UploadedFile.FileName);
                    byte[] buffer = new byte[strm.Length];
                    strm.Read(buffer, 0, (int)strm.Length);
                    strm.Close();


                    int AttachmentId = 1;
                    if (Session["ManualCaseAttachment"] != null)
                    {
                        fileCollection = (List<EMTWebApp.Constants.Attachment>)Session["ManualCaseAttachment"];
                        AttachmentId = fileCollection.Count > 0 ? fileCollection[fileCollection.Count - 1].AttachmentId + 1 : 1;
                    }
                    attach.AttachmentId = AttachmentId;
                    attach.FileName = fileName;
                    attach.FileType = UploadedFile.ContentType;
                    attach.FileContent = buffer;
                    attach.AttachmentTypeId = (int)Constant.AttachmentType.FileSent;
                    fileCollection.Add(attach);
                    Session["ManualCaseAttachment"] = fileCollection;
                    DisplayAttachments();
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | AddAttachmentToFileCollection()");
                //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | AddAttachmentToFileCollection()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
                //Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }





        /// <summary>
        /// Method to Check if the logedin user has access to this page
        /// </summary>
        DataSet IManualCaseCreationView.BindCountry
        {
            set
            {
                if (value != null && value.Tables.Count > 0 && value.Tables[0].Rows.Count > 0)
                {
                    ddlCountry.DataSource = value;
                    ddlCountry.DataTextField = "Country";
                    ddlCountry.DataValueField = "CountryID";
                    ddlCountry.DataBind();
                    if (ddlCountry.Items.Count == 1)
                    {
                        ddlCountry.SelectedIndex = 0;
                        ddlCountry.Enabled = false;

                        ddlCountry_SelectedIndexChanged(null, null);
                    }
                    ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
                }

            }
        }

        /// <summary>
        /// Get EMailBox list based on the selected country from the datatbase and bind it in a dropdown
        /// </summary>
        /// <param></param>
        ///<returns>void </returns>
        DataSet IManualCaseCreationView.BindEMailBox
        {
            set
            {
                if (value != null && value.Tables.Count > 0 && value.Tables[0].Rows.Count > 0)
                {
                    ddlEMailBox.DataSource = value;
                    ddlEMailBox.DataTextField = "EMailBoxName";
                    ddlEMailBox.DataValueField = "EMailBoxId";
                    ddlEMailBox.DataBind();
                    ddlEMailBox.Items.Insert(0, new ListItem("--Select--", "0"));
                }
                else
                {
                    ddlEMailBox.DataSource = null;
                    ddlEMailBox.Items.Clear();
                    ddlEMailBox.Items.Insert(0, new ListItem("--Select--", "0"));
                }
            }
        }

        DataSet IManualCaseCreationView.BindEmailBoxDetails
        {
            set
            {
                if (value != null && value.Tables.Count > 0 && value.Tables[0].Rows.Count > 0)
                {
                    objEMailCredentials.MailBoxEmailId = value.Tables[0].Rows[0]["EMAILBOXADDRESS"].ToString();
                    objEMailCredentials.LoginEmailId = value.Tables[0].Rows[0]["LOGINEMAILID"].ToString();
                    //Decryption
                    //cryptInfo.CryptKey = cipherpassword;
                    //cryptInfo.ValueToCrypt = value.Tables[0].Rows[0]["PASSWORD"].ToString();
                    //string decryptedValue = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
                    if (encryptionmode == "ON")
                    {
                        objEMailCredentials.PKeyword = HelperMethods.DecryptString(value.Tables[0].Rows[0]["PASSWORD"].ToString());
                    }
                    else
                    {
                        objEMailCredentials.PKeyword = HelperMethods.DecryptValue(value.Tables[0].Rows[0]["PASSWORD"].ToString());
                    }

                    objEMailCredentials.ServiceURL = value.Tables[0].Rows[0]["EMAILFOLDERPATH"].ToString();
                    objEMailCredentials.isReplyNotRequired = Convert.ToBoolean(value.Tables[0].Rows[0]["ISREPLYNOTREQUIRED"]);
                    objEMailCredentials.isLocked = Convert.ToBoolean(value.Tables[0].Rows[0]["ISLOCKED"]);
                    objEMailCredentials.MailBoxEmailIdOptional = value.Tables[0].Rows[0]["EMailBoxAddressOptional"].ToString();
                    Session["ManualCaseEmailCredentials"] = objEMailCredentials;
                }
            }

        }

        /// <summary>
        /// Get the email address of the selected EMailBox from the datatbase and bind it in fromemailid label in send email popup
        /// </summary>
        /// <param name="EMailBoxId">EMailBox selected in the ddlEMailBox dropdown list</param>
        ///<returns> void </returns>
        private void BindEMailDetails(int EMailBoxId)
        {
            try
            {
                _presenter.GetEmailBoxDetails(EMailBoxId);
                if (Session["ManualCaseEmailCredentials"] != null)
                {
                    objEMailCredentials = (EMailBoxCredentials)Session["ManualCaseEmailCredentials"];
                }
                if (objEMailCredentials != null)
                {
                    if (!objEMailCredentials.isLocked)
                    {

                        List<string> bindemailboxnames = new List<string>();
                        String MailBoxEmailIdOptional = objEMailCredentials.MailBoxEmailIdOptional;
                        Char delimiter = ';';
                        String[] EmailOptionalsubstrings = MailBoxEmailIdOptional.Split(delimiter);
                        bindemailboxnames.Add(objEMailCredentials.MailBoxEmailId);
                        if (objEMailCredentials.MailBoxEmailIdOptional != "")
                        {
                            MailBoxEmailIdOptional = objEMailCredentials.MailBoxEmailIdOptional;
                            delimiter = ';';
                            EmailOptionalsubstrings = MailBoxEmailIdOptional.Split(delimiter);
                            for (int i = 0; i < EmailOptionalsubstrings.Length - 1; i++)
                            {
                                if (EmailOptionalsubstrings[i].ToString() != "")
                                {
                                    bindemailboxnames.Add(EmailOptionalsubstrings[i].ToString());
                                }
                            }
                        }

                        ddlFrom.DataSource = bindemailboxnames;
                        ddlFrom.DataBind();

                        DataSet dsresult = new DataSet();
                        dsresult = this._presenter.GetSignature(LoginId);
                        if (dsresult.Tables[0].Rows[0]["SignID"].ToString() != "0")
                        {
                            htmlEditorMailBody.InnerHtml = "<br /><br /><br />" + dsresult.Tables[0].Rows[0]["Signature"].ToString();
                        }
                        EnableField();
                    }
                    else
                    {
                        AlertBox("MailBox locked. Please contact EMT IT Team for assistance.");
                        ClearField();
                    }
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | BindEMailDetails()");

                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        private void BindStatus(int EmailBoxId)
        {
            try
            {
                DataSet dsStatus = _presenter.GetStatusDetails(EmailBoxId);
                if (dsStatus != null && dsStatus.Tables[0] != null && dsStatus.Tables[0].Rows.Count > 0)
                {
                    ddlStatus.DataSource = dsStatus;
                    ddlStatus.DataTextField = "StatusDescription";
                    ddlStatus.DataValueField = "StatusId";
                    ddlStatus.DataBind();
                    ddlStatus.Items.Insert(0, new ListItem("--Select--", "0"));
                }
                else
                {
                    ddlStatus.DataSource = null;
                    ddlStatus.DataBind();
                    ddlStatus.Items.Clear();
                    ddlStatus.Items.Insert(0, new ListItem("--Select--", "0"));
                }
            }
            catch (Exception e)
            {
            }
        }

        private void BindTemplates(int EmailBoxId)
        {
            try
            {
                DataSet dsTemplates = _presenter.GetTemplateDetails(EmailBoxId);
                if (dsTemplates != null && dsTemplates.Tables[0] != null && dsTemplates.Tables[0].Rows.Count > 0)
                {
                    ddlTemplateCategory.Enabled = true;
                    ddlTemplateCategory.DataSource = dsTemplates;
                    ddlTemplateCategory.DataTextField = "TemplateCategory";
                    ddlTemplateCategory.DataValueField = "TemplateId";
                    ddlTemplateCategory.DataBind();
                    ddlTemplateCategory.Items.Insert(0, new ListItem("--Select--", "0"));
                }
                else
                {
                    ddlTemplateCategory.DataSource = null;
                    ddlTemplateCategory.DataBind();
                    ddlTemplateCategory.Items.Clear();
                    ddlTemplateCategory.Items.Insert(0, new ListItem("--Select--", "0"));
                    ddlTemplateCategory.Enabled = false;
                }
            }
            catch (Exception e)
            {
            }
        }

        private void BindTemplateToEditor(int TemplateId)
        {
            try
            {
                //get template content and to email address 
                DataSet dsTemplate = _presenter.GetTemplateContent(TemplateId);
                htmlEditorMailBody.InnerHtml = dsTemplate.Tables[0].Rows[0]["TemplateContent"].ToString();
            }
            catch (Exception e)
            {
            }

        }

        /// <summary>
        /// Create a new case in database and return the generated caseid
        /// </summary>
        /// <param>None</param>
        ///<returns> CaseID </returns>
        ///
        private long CreateNewCase()
        {
            List<EMTWebApp.Constants.Attachment> EncryptedfileCollection = new List<EMTWebApp.Constants.Attachment>();
            long CaseId = 0;

            bool composegmb = false;
            try
            {
                //Encryption
                string encryptedValue;
                byte[] EncryptedFileContent;

                if (Session["ManualCaseAttachment"] != null)
                {
                    fileCollection = (List<EMTWebApp.Constants.Attachment>)Session["ManualCaseAttachment"];
                    foreach (EMTWebApp.Constants.Attachment at in fileCollection)
                    {
                        EMTWebApp.Constants.Attachment attach = new EMTWebApp.Constants.Attachment();
                        attach.AttachmentId = at.AttachmentId;
                        attach.FileName = at.FileName;
                        attach.FileType = at.FileType;
                        attach.AttachmentTypeId = at.AttachmentTypeId;
                        attach.FileContent = HelperMethods.EncryptAttachments(at.FileContent);
                        EncryptedfileCollection.Add(attach);
                    }
                }
                if (Session["ManualCaseEmailCredentials"] != null)
                {
                    objEMailCredentials = (EMailBoxCredentials)Session["ManualCaseEmailCredentials"];
                }
                string strbody = htmlEditorMailBody.InnerText.ToString();
                int StatusId = Convert.ToInt32(ddlStatus.SelectedValue);
                if (chkforwardgmb.Checked == true)
                {
                    composegmb = true;
                }
                //ENCRYPTION
                //cryptInfo.CryptKey = cipherpassword;
                //cryptInfo.ValueToCrypt = txtSubject.Text.ToString();
                string encryptedtxtSubject = HelperMethods.EncryptString(txtSubject.Text.ToString());
                //cryptInfo.ValueToCrypt = htmlEditorMailBody.Content.ToString();
                string encryptedhtmlEditorMailBody = HelperMethods.EncryptString(hdnEditorMailBodyContent.Value.ToString());
                CaseId = _presenter.CreateManualCase(ddlFrom.SelectedValue.ToString(), txtTo.Text.ToString(), txtCC.Text.ToString(), encryptedtxtSubject,
                                         encryptedhtmlEditorMailBody, Convert.ToInt32(ddlEMailBox.SelectedValue), objUser.UserId.ToString(), EncryptedfileCollection, objEMailCredentials.isReplyNotRequired, StatusId, hdnClassification.Value, composegmb);



            }

            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | CreateNewCase()");
                //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | CreateNewCase()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
                //Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
            return CaseId;
        }

        protected void GenerateInsParams_CaseID(Control Ctrl, ref StringBuilder sqlTColumn, ref StringBuilder sqlTValue, ref StringBuilder sqlCColumn, ref StringBuilder sqlCValue, ref StringBuilder sqlXmlValue)
        {
            int i = 0;
            for (i = 0; i <= Ctrl.Controls.Count - 1; i++)
            {
                GetControlValue_CaseID(Ctrl.Controls[i], ref sqlTColumn, ref sqlTValue, ref sqlCColumn, ref sqlCValue, ref sqlXmlValue);
                GenerateInsParams_CaseID(Ctrl.Controls[i], ref sqlTColumn, ref sqlTValue, ref sqlCColumn, ref sqlCValue, ref sqlXmlValue);
            }
        }

        protected void GetControlValue_CaseID(Control Ctrl, ref StringBuilder sqlTColumn, ref StringBuilder sqlTValue, ref StringBuilder sqlCColumn, ref StringBuilder sqlCValue, ref StringBuilder sqlXmlValue)
        {
            string selval = string.Empty;
            try
            {
                if (object.ReferenceEquals(Ctrl.GetType(), typeof(TextBox)))
                {
                    TextBox txtBox = (TextBox)Ctrl;
                    if (txtBox.Text != string.Empty)
                    {
                        string format = "dd/MM/yyyy";
                        DateTime dateTime;
                        if (DateTime.TryParse(txtBox.Text, out dateTime))
                        {
                            txtBox.Text = DateTime.ParseExact(txtBox.Text, format, System.Globalization.CultureInfo.InvariantCulture).ToString("yyyy-MM-dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture);
                        }
                        else if (DateTime.TryParseExact(txtBox.Text, format, System.Globalization.CultureInfo.InvariantCulture,
                            System.Globalization.DateTimeStyles.None, out dateTime))
                        {
                            txtBox.Text = DateTime.ParseExact(txtBox.Text, format, System.Globalization.CultureInfo.InvariantCulture).ToString("yyyy-MM-dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture);
                        }
                        if (txtBox.ID.ToString().Split('_')[1] == "SF")//STATIC FIELD		
                        {
                            sqlTValue.Append("" + txtBox.Text.Trim() + "");
                        }
                        else if (txtBox.ID.ToString().Split('_')[1] == "DF")//DYNAMIC FIELD		
                        {
                            sqlXmlValue.Append("<row  FieldMasterID = '" + txtBox.ID.ToString().Split('_')[3] + "'  FieldValue =" + (txtBox.Text.Trim() == " " ? " " : "'" + txtBox.Text.Trim() + "'    IsListValue = '0' />"));
                        }
                    }
                }
                else if (object.ReferenceEquals(Ctrl.GetType(), typeof(DropDownList)))
                {
                    DropDownList ddl = (DropDownList)Ctrl;
                    if (ddl.SelectedIndex > 0 && ddl.SelectedValue.Trim() != "--Select--")
                    {
                        if (ddl.SelectedValue != string.Empty || ddl.SelectedValue != "0")
                        {
                            if (ddl.ID.ToString().Contains("__"))
                            {
                                ddl.ID = ddl.ID.ToString().Replace("__", " ");
                            }
                            if (ddl.ID.ToString().Split('_')[1] == "DF")//DYNAMIC FIELD || ddl.ID.ToString().Split('_')[1] == "SF"		
                            {
                                sqlXmlValue.Append("<row  FieldMasterID = '" + ddl.ID.ToString().Split('_')[3] + "'  FieldValue =" + (ddl.SelectedValue == " " ? " " : "'" + ddl.SelectedItem.Text.ToString() + "'    IsListValue = '0' />"));
                            }
                        }
                    }
                    ddl.Dispose();
                }
                else if (object.ReferenceEquals(Ctrl.GetType(), typeof(RadioButtonList)))
                {
                    selval = string.Empty;
                    RadioButtonList rabtnlst = (RadioButtonList)Ctrl;
                    if (rabtnlst.ID.ToString().Contains("__"))
                    {
                        rabtnlst.ID = rabtnlst.ID.ToString().Replace("__", " ");
                    }
                    if (rabtnlst.ID.ToString().Split('_')[1] == "DF")//DYNAMIC FIELD -- || rabtnlst.ID.ToString().Split('_')[1] == "SF"		
                    {
                        //  selval = rabtnlst.Items.Cast<ListItem>().Where(item => item.Selected).Aggregate(selval, (current, item) => current + (item.Value + ','));		
                        //  selval.TrimEnd(',');		
                        sqlXmlValue.Append("<row   FieldMasterID = '" + rabtnlst.ID.ToString().Split('_')[3] + "'  FieldValue  =" + (rabtnlst.SelectedValue == " " ? " 0 " : "'" + rabtnlst.SelectedItem.Text.ToString() + "' IsListValue = '0' />"));
                    }
                    rabtnlst.Dispose();
                }
                else if (object.ReferenceEquals(Ctrl.GetType(), typeof(CheckBoxList)))
                {
                    selval = string.Empty;
                    CheckBoxList chkbox = (CheckBoxList)Ctrl;
                    if (chkbox.ID.ToString().Contains("__"))
                    {
                        chkbox.ID = chkbox.ID.ToString().Replace("__", " ");
                    }
                    if (chkbox.ID.ToString().Split('_')[1] == "DF")//DYNAMIC FIELD  -- || chkbox.ID.ToString().Split('_')[1] == "SF"		
                    {
                        string strselText = string.Empty;
                        selval = chkbox.Items.Cast<ListItem>().Where(item => item.Selected).Aggregate(selval, (current, item) => current + (item.Value + ','));
                        selval = selval.Trim().Remove(selval.Length - 1);// TrimEnd(',');		
                        strselText = chkbox.Items.Cast<ListItem>().Where(item => item.Selected).Aggregate(strselText, (current, item) => current + (item.Text + ','));
                        strselText = strselText.Trim().Remove(strselText.Length - 1);// TrimEnd(',');		
                        // if(selval == string.Empty )		
                        sqlXmlValue.Append("<row  FieldMasterID = '" + chkbox.ID.ToString().Split('_')[3] + "'  FieldValue =" + (chkbox.SelectedValue == " " ? " 0 " : "'" + selval + "'   FieldText ='" + strselText + "' IsListValue = '1' />"));
                        // else		
                        //   sqlXmlValue.Append("<row  FieldMasterID = '" + chkbox.ID.ToString().Split('_')[3] + "'  FieldValue =" + (chkbox.SelectedValue == " " ? " 0 " : "'" + selval + "'   FieldText ='" + strselText + "' IsListValue = '0' />"));		
                    }
                    chkbox.Dispose();
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {
                selval = string.Empty;
            }
        }


        /// <summary>
        /// Bind attachment list in the send email popup
        /// </summary>
        /// <param name="dtAttachmentList"></param>
        ///<returns>void</returns>
        ///
        private void DisplayAttachments()
        {
            try
            {
                if (Session["ManualCaseAttachment"] != null)
                {

                    fileCollection = (List<EMTWebApp.Constants.Attachment>)Session["ManualCaseAttachment"];
                }
                DataTable dtAttachments = fileCollection.ToDataTable();
                if (dtAttachments != null && dtAttachments.Rows.Count > 0)
                {
                    divAttachments.Visible = true;
                    while (tblAttachments.Rows.Count > 0)
                    {
                        tblAttachments.Rows.RemoveAt(tblAttachments.Rows.Count - 1);
                    }

                    for (int i = 0; i < dtAttachments.Rows.Count; i++)
                    {

                        HtmlTableRow tr = new HtmlTableRow();
                        HtmlTableCell tdCheckbox = new HtmlTableCell();
                        //HtmlTableCell tdFileType = new HtmlTableCell();
                        HtmlTableCell tdFileName = new HtmlTableCell();
                        HtmlTableCell tdCreatedDate = new HtmlTableCell();
                        //Pranay 27 April 2017 adding option for deleting records from Attcahment Grid
                        HtmlTableCell tddeleterecord = new HtmlTableCell();
                        //tdCheckbox.InnerHtml = "<input type=\"checkbox\" id=chk" + dtAttachments.Rows[i]["AttachmentId"].ToString() + ">";
                        HtmlInputCheckBox checkbox = new HtmlInputCheckBox();
                        //SAST fixes
                        checkbox.ID = "chk" + System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(dtAttachments.Rows[i]["AttachmentId"].ToString(), true);
                        //checkbox.ID = "chk" +dtAttachments.Rows[i]["AttachmentId"].ToString();
                        tdCheckbox.Controls.Add(checkbox);
                        tdCheckbox.Style.Add("width", "30");
                        //tdFileType.InnerHtml = dtAttachments.Rows[i]["AttachmentType"].ToString();
                        HtmlAnchor attachment = new HtmlAnchor();
                        attachment.ID = dtAttachments.Rows[i]["AttachmentId"].ToString();

                        attachment.ServerClick += new EventHandler(AttachmentsLink_Click);
                        attachment.InnerHtml = dtAttachments.Rows[i]["FileName"].ToString();
                        //tdFileName.InnerHtml = "<a href=\"\" onclick=\"return true;\" runat=\"server\" onserverclick=\"AttachmentLink_Click\">" +  + "</a>";
                        tdFileName.Controls.Add(attachment);

                        HtmlAnchor deletion = new HtmlAnchor();
                        deletion.ID = (Convert.ToInt32(dtAttachments.Rows[i]["AttachmentId"].ToString()) + 100).ToString();
                        deletion.ServerClick += new EventHandler(DeleteAttachment_Click);
                        deletion.InnerHtml = "Delete";
                        tddeleterecord.Controls.Add(deletion);

                        //Varma - Timezone Feature On&OFF functionality 
                        if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                        {
                            //Pranay 6 January 2017 -- changing createdDate of Attachment to TimeZone of User
                            //DateTime dateRecieved = Convert.ToDateTime(dtAttachments.Rows[i]["CreatedDate"].ToString());
                            //tdCreatedDate.InnerHtml = ISSWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(dtAttachments.Rows[i]["CreatedDate"].ToString(), true, objUser.TimeZone, false);
                            tdCreatedDate.InnerHtml = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(DateTime.UtcNow.ToString("dd/MM/yyyy HH:mm:ss"), true, objUser.TimeZone, false);
                        }
                        else
                        {
                            tdCreatedDate.InnerHtml = dtAttachments.Rows[i]["CreatedDate"].ToString();
                        }
                        tr.Controls.Add(tdCheckbox);
                        // tr.Controls.Add(tdFileType);
                        tr.Controls.Add(tdFileName);
                        tr.Controls.Add(tdCreatedDate);
                        tr.Controls.Add(tddeleterecord);
                        //if (i > 0)
                        //{
                        tblAttachments.Rows.Add(tr);
                        //}
                        //else if (tblAttachments.FindControl("tdFileName").ToString()!=null && (tblAttachments.FindControl("tdFileName").ToString() != dtAttachments.Rows[i]["FileName"].ToString()))
                        //{
                        //    tblAttachments.Rows.Add(tr);
                        //}

                    }
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | DisplayAttachments()");
                //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | CreateNewCase()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
                //Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }


        /// <summary>
        /// Delete the attachment from the session and update the display list
        /// </summary>
        /// <param name="AttachmentID">Delete the attachment which matches the attachmentid passed to this method</param>
        ///<returns>void</returns>
        ///
        private void DeleteAttachmentFromFileCollection(int ID)
        {
            try
            {
                if (Session["ManualCaseAttachment"] != null)
                {
                    fileCollection = (List<EMTWebApp.Constants.Attachment>)Session["ManualCaseAttachment"];
                }
                if (fileCollection.Count > 0)
                {
                    int FileCollectionIndex = -1;
                    int FileLength = 0;
                    foreach (var item in fileCollection)
                    {
                        if (item.AttachmentId == ID)
                        {
                            FileCollectionIndex = fileCollection.IndexOf(item);
                            FileLength = item.FileContent.Length;
                        }
                    }
                    if (FileCollectionIndex != -1)
                    {
                        // Session["FileSize"] = (int)(Session["FileSize"]) - FileLength;

                        fileCollection.RemoveAt(FileCollectionIndex);
                    }
                }
                Session["ManualCaseAttachment"] = fileCollection;
                DisplayAttachments(); //Display the updated list
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | DeleteAttachmentFromFileCollection()");
                //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | DeleteAttachmentFromFileCollection()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
                //Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }


        /// <summary>
        /// Display javascript alert message to the user
        /// </summary>
        /// <param name="Message">Message text shown to the user</param>
        ///<returns>void</returns>
        ///
        private void AlertBox(string Message)
        {
            //ClientScript.RegisterStartupScript(this.GetType(), "SuccessMsg"
            //    , "<script type='text/javascript' language='javascript'> alert('" + Message + "'); </script>");
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert", "alert('" + Message + "')", true);
        }

        //Pranay 11 May 2017 --Pranay ==For Dynamic Field Configuration
        private void LoadDynamicControls()
        {
            string strStatusVal = "0";
            DataSet dsControls = new DataSet();
            try
            {
                if (ddlCountry.SelectedValue != "0" && ddlEMailBox.SelectedValue != "0")
                {
                    Hashtable hs = new Hashtable();
                    hs.Add("@CountryID", Convert.ToInt32(ddlCountry.SelectedValue));
                    hs.Add("@MailboxID", Convert.ToInt32(ddlEMailBox.SelectedValue));
                    dsControls = _presenter.GetDynamicPageControlsForManualCase(hs);
                    if (dsControls != null && dsControls.Tables.Count > 0 && dsControls.Tables[0].Rows.Count > 0)//INPUT		
                    {
                        for (int iCnt = 0; iCnt <= dsControls.Tables[0].Rows.Count - 1; iCnt++)
                        {
                            // strFieldID = dsControls.Tables[0].Rows[iCnt]["DynamicFieldMaster_ID"].ToString();		
                            strFieldID = dsControls.Tables[0].Rows[iCnt]["DynamicFieldMaster_ID"].ToString() + "_" + dsControls.Tables[0].Rows[iCnt]["FieldMasterID"].ToString();
                            strFieldName = dsControls.Tables[0].Rows[iCnt]["FieldAliasName"].ToString();
                            strFieldType = dsControls.Tables[0].Rows[iCnt]["FieldType"].ToString();
                            strFieldDataType = dsControls.Tables[0].Rows[iCnt]["FieldDataType"].ToString();
                            if (dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString() != "" && dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString() != null && dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString() != string.Empty)
                                strTextLength = Convert.ToInt64(dsControls.Tables[0].Rows[iCnt]["TextLength"].ToString());
                            else
                                strTextLength = 0;
                            strFieldMasterID = Convert.ToInt64(dsControls.Tables[0].Rows[iCnt]["FieldMasterID"].ToString());
                            if (!string.IsNullOrEmpty(dsControls.Tables[0].Rows[iCnt]["ValidationTypeID"].ToString()))
                                strValidationTypeID = Convert.ToInt64(dsControls.Tables[0].Rows[iCnt]["ValidationTypeID"].ToString());
                            else
                                strValidationTypeID = 0;
                            if (dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"] != null)
                            {
                                if (dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString() != "" && dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString() != null && dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString() != string.Empty)
                                    strFieldPrivilegeID = Convert.ToInt32(dsControls.Tables[0].Rows[iCnt]["FieldPrivilegeID"].ToString());
                                else
                                    strFieldPrivilegeID = 0;
                            }
                            else
                                strFieldPrivilegeID = 0;
                            //strFieldPrivilegeID = 0;		
                            if (!string.IsNullOrWhiteSpace(dsControls.Tables[0].Rows[iCnt]["Value"].ToString()))
                                strValue = dsControls.Tables[0].Rows[iCnt]["Value"].ToString();
                            else
                                strValue = string.Empty;
                            //tr = new HtmlTableRow();
                            //tab.Width = "36%";
                            //tab.Style.Add("align", "center");
                            //tab.Border = 0;
                            //td1.Width = "30%";
                            //td2.Width = "70%";
                            CreateControls(strFieldID, strFieldName, strFieldType, strTextLength, strFieldMasterID, strValidationTypeID, strFieldPrivilegeID, strFieldDataType, strValue, iCnt);
                        }
                        DynamicFieldsPanel.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {
                strStatusVal = "0";
                dsControls.Dispose();
                tr.Dispose();
            }
        }

        public void CreateControls(string strFieldID, string strFieldName, string strFieldType, Int64 strTextLength, Int64 strFieldMasterID, Int64 strValidationTypeID, Int32 strFieldPrivilegeID, string strFieldDataType, string strValue, int iCnt)
        {
            HtmlGenericControl li = new HtmlGenericControl("li");

            Label lbl = new Label();
            TextBox txtBox = new TextBox();
            CalendarExtender calendar = new CalendarExtender();
            ImageButton imgButton = new ImageButton();
            DropDownList ddl = new DropDownList();
            RadioButtonList radiobtnlst = new RadioButtonList();
            CheckBoxList chkbox = new CheckBoxList();


            try
            {
                lbl.Text = strFieldName + " : ";
                lbl.CssClass = "DynamicFieldslabel";
                string labeltitle = "\"" + lbl.Text + "\"";
                li.Controls.Add(lbl);

                switch (strFieldType)
                {
                    case "Hidden":
                        HiddenField hdnField = new HiddenField();
                        hdnField.ID = strFieldID;
                        hdnField.Value = strFieldName;
                        li.Controls.Add(hdnField);
                        break;
                    case "TextBox":
                        txtBox.ID = strFieldID;
                        txtBox.CssClass = "DynamicFieldstextbox";
                        string concat = "\"" + strFieldID + "\"";
                        txtBox.Text = strValue;
                        string txtvalue = "\"" + strValue + "\"";
                        if (strTextLength != 0)
                        {
                            txtBox.MaxLength = Convert.ToInt32(strTextLength);
                        }
                        else
                        {
                            txtBox.MaxLength = 15;//Convert.ToInt32(strTextLength);
                        }

                        if (strValidationTypeID == 1 | strValidationTypeID == 3 | strValidationTypeID == 4)//Validation
                        {
                            SetFilterField(txtBox, ref li, strValidationTypeID);

                        }
                        else if (strValidationTypeID == 2 | strValidationTypeID == 7)//Date & Date Time
                        {
                            SetDateFilterField(txtBox, ref li, strValidationTypeID);

                        }
                        else if (strValidationTypeID == 8)//Email
                        {

                            SetEmailFilterField(txtBox, ref li, strValidationTypeID);
                        }
                        li.Controls.Add(txtBox);


                        if (strFieldPrivilegeID == 1)//Mandatory
                        {
                            SetMandatoryField(txtBox, ref li, "TextBox", "", strFieldName);

                        }
                        else if (strFieldPrivilegeID == 3)//Read Only
                        {
                            txtBox.Enabled = false;
                        }
                        //if (hdEditMode.Value.ToString() == "2")
                        //    txtBox.Enabled = false;

                        break;
                    case "TextArea":
                        txtBox.ID = strFieldID;
                        txtBox.CssClass = "DynamicFieldstextarea";
                        concat = "\"" + strFieldID + "\"";
                        //txtBox.CssClass = "Text";
                        txtBox.TextMode = TextBoxMode.MultiLine;
                        if (strTextLength != 0)
                        {
                            txtBox.Attributes.Add("onkeyup", "return checkMaxLen(this," + strTextLength + ")");
                        }
                        //if (strTextLength != 0)
                        //{
                        //  //  txtBox.MaxLength = Convert.ToInt32(strTextLength);
                        //    SetTextAreaMaxLengthField(txtBox, ref td2, "TextArea", strTextLength.ToString());
                        //}
                        txtBox.Columns = 20;
                        txtBox.Rows = 4;
                        txtBox.Text = strValue;

                        if (strValidationTypeID == 1 | strValidationTypeID == 3 | strValidationTypeID == 4)//Validation
                        {
                            SetFilterField(txtBox, ref li, strValidationTypeID);

                        }
                        else if (strValidationTypeID == 2 | strValidationTypeID == 7)//Date & Date Time
                        {
                            SetDateFilterField(txtBox, ref li, strValidationTypeID);

                        }
                        else if (strValidationTypeID == 8)//Email
                        {
                            SetEmailFilterField(txtBox, ref li, strValidationTypeID);

                        }
                        //txtBox.RenderControl(htw1);                                        
                        li.Controls.Add(txtBox);


                        if (strFieldPrivilegeID == 1)//Mandatory
                        {
                            SetMandatoryField(txtBox, ref li, "TextArea", "", strFieldName);
                        }
                        else if (strFieldPrivilegeID == 3)//Read Only
                        {
                            txtBox.Enabled = false;
                        }
                        ////if (hdEditMode.Value.ToString() == "2")
                        //    txtBox.Enabled = false;

                        break;
                    case "DropDownList":
                        ddl.ID = strFieldID;
                        ddl.CssClass = "DynamicFieldsselect";
                        concat = "\"" + strFieldID + "\"";

                        Int64 fieldmasterid = strFieldMasterID;
                        FillControlValues(ddl, null, null, fieldmasterid);
                        ddl.SelectedValue = null;

                        //  ddl.SelectedValue = strValue;
                        if (strValue != string.Empty && strValue != "select")
                        {
                            if (ddl.Items.FindByText(strValue) != null)
                            {
                                ddl.Items.FindByText(strValue).Selected = true;
                            }
                        }
                        //ddl.RenderControl(htw);                    
                        li.Controls.Add(ddl);


                        if (strFieldPrivilegeID == 1)//Mandatory
                        {
                            SetMandatoryField(ddl, ref li, "DropDownList", "0", strFieldName);

                        }
                        else if (strFieldPrivilegeID == 3)//Read Only
                        {
                            ddl.Enabled = false;
                        }
                        //if (hdEditMode.Value.ToString() == "2")
                        //    ddl.Enabled = false;

                        break;
                    case "RadioButtonList":
                        radiobtnlst.ID = strFieldID;
                        radiobtnlst.CssClass = "DynamicFieldschkbox";
                        radiobtnlst.RepeatDirection = System.Web.UI.WebControls.RepeatDirection.Horizontal;
                        radiobtnlst.RepeatColumns = 2;

                        fieldmasterid = strFieldMasterID;
                        FillControlValues(null, radiobtnlst, null, fieldmasterid);
                        if (strValue != string.Empty)
                        {
                            radiobtnlst.Items.FindByText(strValue).Selected = true;
                        }
                        //radiobtnlst.RenderControl(htw);                    
                        li.Controls.Add(radiobtnlst);


                        if (strFieldPrivilegeID == 1)//Mandatory
                        {
                            SetMandatoryField(radiobtnlst, ref li, "RadioButtonList", "", strFieldName);


                        }
                        else if (strFieldPrivilegeID == 3)//Read Only
                        {
                            radiobtnlst.Enabled = false;
                        }

                        //if (hdEditMode.Value.ToString() == "2")
                        //    radiobtnlst.Enabled = false;

                        break;
                    case "CheckBoxList":
                        chkbox.ID = strFieldID;
                        chkbox.CssClass = "DynamicFieldschkbox";
                        //chkbox.CssClass = "Checkbox";
                        chkbox.RepeatDirection = System.Web.UI.WebControls.RepeatDirection.Horizontal;
                        chkbox.RepeatColumns = 2;

                        fieldmasterid = strFieldMasterID;
                        FillControlValues(null, null, chkbox, fieldmasterid);
                        //  chkbox.SelectedValue = strValue;

                        if (!string.IsNullOrEmpty(strValue) && strValue.Length >= 1)
                        {
                            List<string> strRecip = strValue.Trim().ToLower().Split(',').Select(p => p.Trim()).ToList();
                            foreach (ListItem list in chkbox.Items)
                            {
                                if (strRecip.Contains(list.Text.Trim().ToLower()))
                                {
                                    list.Selected = true;
                                }
                            }
                        }
                        //else
                        //{
                        //   // chkbox.SelectedItem.Text = strValue;
                        //}

                        //chkbox.RenderControl(htw);
                        li.Controls.Add(chkbox);


                        if (strFieldPrivilegeID == 1)//Mandatory
                        {
                            SetMandatoryField(chkbox, ref li, "CheckBoxList", "", strFieldName);

                        }
                        else if (strFieldPrivilegeID == 3)//Read Only
                        {
                            chkbox.Enabled = false;
                        }
                        //if (hdEditMode.Value.ToString() == "2")
                        //    chkbox.Enabled = false;
                        break;


                    case "Date":
                        txtBox.ID = strFieldID;
                        txtBox.CssClass = "DynamicFieldstextboxdate";
                        txtBox.Attributes.Add("readonly", "true");
                        txtBox.Text = fnConvertstringtodate(strValue);
                        imgButton.ID = "Img_" + strFieldMasterID;
                        imgButton.ImageUrl = "~/Images/calendar.gif";
                        imgButton.CssClass = "DynamicFieldsimgbutton";
                        imgButton.CausesValidation = false;

                        calendar.ID = "Cal_" + strFieldMasterID;
                        calendar.TargetControlID = txtBox.ID;
                        calendar.PopupButtonID = imgButton.ID;
                        calendar.Format = "dd/MM/yyyy";

                        li.Controls.Add(txtBox);
                        li.Controls.Add(imgButton);
                        li.Controls.Add(calendar);

                        if (strFieldPrivilegeID == 1)//Mandatory
                        {
                            SetMandatoryField(txtBox, ref li, "Date", "", strFieldName);
                        }
                        else if (strFieldPrivilegeID == 3)//Read Only
                        {
                            txtBox.Enabled = false; //by default made as readonly
                        }

                        //if (hdEditMode.Value.ToString() == "2")
                        //    txtBox.Enabled = false;
                        break;
                }



                if ((iCnt % 2 == 0))
                {
                    Listitems1.Controls.Add(li);
                }
                else
                {
                    Listitems2.Controls.Add(li);
                }

            }
            catch (Exception ex)
            {

            }
            finally
            {
                // lbl.Dispose();
                // txtBox.Dispose();
                //// calendar.Dispose();
                // imgButton.Dispose();
                //objDefaultValues = null;
                // ddl.Dispose();
                // radiobtnlst.Dispose();
                // chkbox.Dispose();
            }

        }



        private string fnConvertstringtodate(string strTextValue)
        {
            if (!string.IsNullOrEmpty(strValue))
            {
                string strConvertDate = string.Empty;
                System.DateTime cellDate = default(System.DateTime);
                string format = "dd/MM/yyyy";
                if (DateTime.TryParse(strTextValue, out cellDate))
                {
                    strConvertDate = Convert.ToDateTime(strTextValue).ToString(format, System.Globalization.CultureInfo.InvariantCulture);
                }
                else if (DateTime.TryParseExact(strTextValue, format, System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.None, out cellDate))
                {
                    strConvertDate = Convert.ToDateTime(strTextValue).ToString(format, System.Globalization.CultureInfo.InvariantCulture);
                }
                return strConvertDate;
            }
            else
            {
                return string.Empty;
            }
        }
        private void SetMandatoryField(Control cMand, ref HtmlGenericControl Literal1, string controlType, string InitialValue, string strFieldName)
        {
            CustomValidator cv = new CustomValidator();
            RequiredFieldValidator rfv = new RequiredFieldValidator();
            try
            {
                var span = new LiteralControl("<span style='color:red'>*</span>");
                Literal1.Controls.Add(span);
                if (controlType == "CheckBoxList")
                {
                    cv.ID = "cv" + cMand.ID;
                    cv.ErrorMessage = "Please check atleast one " + strFieldName;
                    cv.CssClass = "mandatorytext";
                    //cv.Display = ValidatorDisplay.None;		
                    cv.Enabled = true;
                    cv.ValidationGroup = "DynamicCaseSubmit";
                    cv.Attributes.Add("ControlToValidateID", "DefaultContent_" + cMand.ClientID);
                    cv.ClientValidationFunction = "ValidateCheckBoxList";
                    cv.SetFocusOnError = true;
                    Literal1.Controls.Add(cv);
                    //SetValidatorCalloutExtender(td, cv);		
                }
                else
                {
                    rfv.ID = "rfv" + cMand.ID;
                    rfv.ControlToValidate = cMand.ID;
                    rfv.ErrorMessage = "Please enter " + strFieldName;
                    rfv.CssClass = "mandatorytext";
                    rfv.Display = ValidatorDisplay.None;
                    rfv.ValidationGroup = "DynamicCaseSubmit";
                    rfv.Enabled = true;
                    if (controlType == "TextBox" || controlType == "TextArea" || controlType == "DropDownList" || controlType == "Date")
                    {
                        rfv.InitialValue = InitialValue;
                    }
                    if (controlType == "DropDownList" || controlType == "RadioButtonList")
                    {
                        rfv.ErrorMessage = "Please select " + strFieldName;
                    }
                    Literal1.Controls.Add(rfv);
                    SetValidatorCalloutExtender(Literal1, rfv);
                }
                // Literal1.Align = "left";
            }
            catch (Exception ex)
            {
            }
            finally
            {
                // cv.Dispose();		
                rfv.Dispose();
            }
        }
        private void SetValidatorCalloutExtender(HtmlGenericControl td, Control con)
        {
            ValidatorCalloutExtender vce = new AjaxControlToolkit.ValidatorCalloutExtender();
            try
            {
                vce.ID = "val" + con.ID;
                vce.TargetControlID = con.ID;
                //vce.css		
                //if (!con.ID.ToString().Contains("CheckBox"))		
                //{		
                vce.PopupPosition = ValidatorCalloutPosition.Right;
                //}		
                //else 		
                //{		
                //   vce.CssClass = "CustomValidator";		
                //}		
                vce.Enabled = true;

                td.Controls.Add(vce);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                //vce.Dispose();		
            }
        }
        //private void SetTextAreaMaxLengthField(Control cMand, ref HtmlGenericControl Literal1, string controlType, string InitialValue)
        //{
        //    RegularExpressionValidator rev = new RegularExpressionValidator();
        //    try
        //    {
        //        var span = new LiteralControl("<span style='color:red'>*</span>");
        //        Literal1.Controls.Add(span);
        //        if (controlType == "TextBox" || controlType == "TextArea")
        //        {
        //            rev.ID = "cv" + cMand.ID;
        //            //rev.ErrorMessage = "*";		
        //            rev.ControlToValidate = cMand.ID;
        //            rev.CssClass = "mandatory";
        //            rev.Display = ValidatorDisplay.None;
        //            rev.Enabled = true;
        //            //    rev.ValidationGroup = "DataEntryPage";		
        //            String regFormat = @"\b[a-zA-Z]{" + InitialValue.ToString() + @"}\b";
        //            rev.ValidationExpression = regFormat; //@"^[\s\S]{0," + InitialValue.ToString() + "}$";		
        //            Literal1.Controls.Add(rev);
        //            Literal1.Controls.Add(span);
        //        }
        //        td.Align = "left";
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    finally
        //    {
        //        rev.Dispose();
        //    }
        //}
        private void SetFilterField(Control cMand, ref HtmlGenericControl Literal1, Int64 strValidationTypeID)
        {
            FilteredTextBoxExtender fe = new FilteredTextBoxExtender();
            try
            {
                fe.ID = "fe" + cMand.ID;
                fe.TargetControlID = cMand.ID;
                if (strValidationTypeID == 1)//Numeric		
                {
                    fe.FilterType = FilterTypes.Numbers;
                }
                if (strValidationTypeID == 9)//Numeric with decimal	
                {
                    fe.FilterType = FilterTypes.Numbers | FilterTypes.Custom;
                    fe.ValidChars = ".";
                }
                else if (strValidationTypeID == 3)//Alphabet		
                {
                    fe.FilterType = FilterTypes.LowercaseLetters | FilterTypes.UppercaseLetters;//"LowercaseLetters, UppercaseLetters";       		
                    fe.ValidChars = " ";
                }
                else if (strValidationTypeID == 4)//AlphaNumeric		
                {
                    fe.FilterType = FilterTypes.Numbers | FilterTypes.LowercaseLetters | FilterTypes.UppercaseLetters;// "Numbers, UppercaseLetters, LowercaseLetters";		
                    fe.ValidChars = " ";
                }
                Literal1.Controls.Add(fe);
                //td.Align = "left";
            }
            catch (Exception ex)
            {
            }
            finally
            {
            }
        }
        private void SetEmailFilterField(Control cMand, ref HtmlGenericControl Literal1, Int64 strValidationTypeID)
        {
            RegularExpressionValidator rev = new RegularExpressionValidator();
            try
            {
                rev.ID = "rev" + cMand.ID;
                rev.ControlToValidate = cMand.ID;
                rev.ValidationExpression = @"((\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)*([;])*)*";
                rev.ErrorMessage = strFieldName + " : Invalid email format";
                rev.Display = ValidatorDisplay.None;
                Literal1.Controls.Add(rev);
                SetValidatorCalloutExtender(Literal1, rev);
                //td.Align = "left";
            }
            catch (Exception ex)
            {
            }
            finally
            {
                rev.Dispose();
            }
        }
        private void SetDateFilterField(Control cMand, ref HtmlGenericControl Literal1, Int64 strValidationTypeID)
        {
            //var span = new LiteralControl("<span style='color:red'>*</span>");		
            MaskedEditExtender mee = new MaskedEditExtender();
            MaskedEditValidator mev = new MaskedEditValidator();
            try
            {
                mee.ID = "mee" + cMand.ID;
                mee.TargetControlID = cMand.ID;
                mee.MessageValidatorTip = true;
                mee.ErrorTooltipEnabled = true;
                //mee.CultureName = "en-US";		
                mev.ID = "mev" + cMand.ID;
                mev.ControlExtender = "mee" + cMand.ID;
                mev.ControlToValidate = cMand.ID;
                mev.InvalidValueMessage = strFieldName + " : Invalid date format";
                mev.Display = ValidatorDisplay.None;
                mev.InvalidValueBlurredMessage = strFieldName + " : Invalid date format";
                mev.ErrorMessage = strFieldName + " : Invalid date format";
                if (strValidationTypeID == 2)//Date		
                {
                    mee.Mask = "99/99/9999";
                    mee.MaskType = MaskedEditType.Date;
                    mee.DisplayMoney = MaskedEditShowSymbol.Left;
                    mee.AcceptNegative = MaskedEditShowSymbol.Left;
                }
                else if (strValidationTypeID == 7)//DateTime		
                {
                    mee.Mask = "99/99/9999";
                    //mee.UserTimeFormat = MaskedEditUserTimeFormat.TwentyFourHour;		
                    mee.MaskType = MaskedEditType.Date;
                    mee.AcceptAMPM = true;
                }
                Literal1.Controls.Add(mee);
                Literal1.Controls.Add(mev);
                SetValidatorCalloutExtender(Literal1, mev);
                //td.Align = "left";
            }
            catch (Exception ex)
            {
            }
            finally
            {
                mee.Dispose();
                mev.Dispose();
            }
        }
        public void FillControlValues(DropDownList ddl, RadioButtonList rbl, CheckBoxList cbl, Int64 FMID)
        {
            try
            {
                Hashtable hs = new Hashtable();
                hs.Add("@FieldMasterId", FMID);
                using (DataSet dsDDL = _presenter.GetControlValuesForBinding(hs))
                {
                    if (dsDDL != null && dsDDL.Tables.Count > 0)
                    {
                        if (ddl != null)
                        {
                            ddl.ClearSelection();
                            ddl.DataSource = dsDDL.Tables[0];
                            ddl.DataTextField = "OptionText";
                            ddl.DataValueField = "OptionValue";
                            ddl.DataBind();
                            ddl.Items.Insert(0, new ListItem("--Select--", "0"));
                        }
                        else if (rbl != null)
                        {
                            rbl.DataSource = dsDDL.Tables[0];
                            rbl.DataTextField = "OptionText";
                            rbl.DataValueField = "OptionValue";
                            rbl.DataBind();
                        }
                        else if (cbl != null)
                        {
                            cbl.DataSource = dsDDL.Tables[0];
                            cbl.DataTextField = "OptionText";
                            cbl.DataValueField = "OptionValue";
                            cbl.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        //Pranay 16November 2016--Service method for getting  ToEmailIds
        [System.Web.Script.Services.ScriptMethod]
        [System.Web.Services.WebMethod]
        public static List<string> GetToEmailID(string prefixText)
        {

            List<string> lstMailIds = new List<string>();

            DataSet resultDs = null;

            if (HttpContext.Current != null)
            {
                if (HttpContext.Current.Session != null)
                {
                    resultDs = new ProcessingPresenter(new CommonController()).GetToEmailIDofUsers(prefixText, long.Parse(HttpContext.Current.Session["ManualCaseEmailbox"].ToString()));
                    if (resultDs != null)
                    {
                        if (resultDs.Tables[0] != null)
                        {
                            foreach (DataRow dRow in resultDs.Tables[0].Rows)
                            {
                                lstMailIds.Add(dRow[0].ToString().Trim());
                            }
                        }
                    }
                }
            }
            return lstMailIds;

        }

        //Pranay 16November 2016--Service Methhod for gettign CcEmailIds
        [System.Web.Script.Services.ScriptMethod]
        [System.Web.Services.WebMethod]
        public static List<string> GetCcEmailID(string prefixText)
        {
            List<string> lstMailIds = new List<string>();
            DataSet resultDs = null;
            if (HttpContext.Current != null)
            {
                if (HttpContext.Current.Session != null)
                {
                    resultDs = new ProcessingPresenter(new CommonController()).GetCcEmailIDofUsers(prefixText, long.Parse(HttpContext.Current.Session["ManualCaseEmailbox"].ToString()));
                    if (resultDs != null)
                    {
                        if (resultDs.Tables[1] != null)
                        {
                            foreach (DataRow dRow in resultDs.Tables[1].Rows)
                            {
                                lstMailIds.Add(dRow[0].ToString());
                            }
                        }
                    }
                }
            }
            return lstMailIds;
        }


        #endregion


        #region Events
        public void ProductLicense()
        {
            LicenseInfo LicenseInfo = new LicenseInfo();
            LicenseInfo.ToolPurchased = ToolPurchased;
            LicenseInfo.DateOfPurchase = DateOfPurchase;
            LicenseInfo.Version = Version;
            LicenseInfo.InstanceID = InstanceID;
            LicenseInfo.MaxNoOfUser = MaxNoOfUser;
            DataSet ds = (_presenter.GetUserCount());

            if (ds.Tables[0].Rows.Count > 0)
            {
                usercount = Convert.ToInt16(ds.Tables[0].Rows[0]["TotalNoOfUsers"]);
            }
            LicenseInfo.UserCount = usercount;
            LicenseInfo.EncryptedProductKey = "";

            ProductLicenseKey ProductLicenseKey = new ProductLicenseKey();
            LicenseInfo objlicense = new LicenseInfo();
            objlicense = ProductLicenseKey.GenerateProductKey(LicenseInfo);
            if (string.IsNullOrEmpty(objlicense.EncryptedProductKey) || objlicense.EncryptedProductKey == "null")
            {
                Errormessage = objlicense.ErrorMessage.ToString();
            }
            LicenseKey = objlicense.EncryptedProductKey;
            objlicense = ProductLicenseKey.ValidateProductLicenseKey(LicenseKey);
            //LicenseKey = new2.GenerateProductKey(LicenseInfo).ToString();
            //  DataSet InsertLicenseKey = _presenter.InsertProductLicense(LicenseKey, ClientName);

            //  LicenseInfo objlicense = new LicenseInfo();
            //  objlicense = new2.ValidateProductLicenseKey(LicenseKey);
            Errormessage = objlicense.ErrorMessage.ToString();
            string str = null;
            string[] productKeyInformation = null;
            productKeyInformation = Errormessage.Split('!');
            ErrorMessage = productKeyInformation[0];
            //LicenseStatus = objlicense.ResultStatus.ToString();  
            //Errormessage = objlicense.ErrorMessage.ToString();
            LicenseStatus = objlicense.ResultStatus.ToString();


        }

        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                _presenter.GetEMailBoxByUserId(objUser.UserId, objUser.RoleId, Convert.ToInt32(ddlCountry.SelectedValue));
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | ddlCountry_SelectedIndexChanged()");
                //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | ddlCountry_SelectedIndexChanged()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
                //Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }

        protected void ddlEMailBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlEMailBox.SelectedIndex == 0)
                {
                    ddlFrom.Items.Clear();
                }
                else
                {
                    BindStatus(Convert.ToInt32(ddlEMailBox.SelectedValue));
                    BindTemplates(Convert.ToInt32(ddlEMailBox.SelectedValue));
                    BindEMailDetails(Convert.ToInt32(ddlEMailBox.SelectedValue));
                    Session["ManualCaseEmailbox"] = ddlEMailBox.SelectedValue;
                    LoadDynamicControls();
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | ddlEMailBox_SelectedIndexChanged");
                //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | ddlCountry_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }


        protected void ddlTemplateCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlTemplateCategory.SelectedItem.Text.ToLower() != "template")
                {
                    txtSubject.Text = ddlTemplateCategory.SelectedItem.Text;
                    BindTemplateToEditor(Convert.ToInt32(ddlTemplateCategory.SelectedValue));
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | ddlEMailBox_SelectedIndexChanged");
                //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | ddlCountry_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }


        /// <summary>
        /// On Create button click open the mail send popup and bind the EMail address based on the EMailbox selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        ///<returns> void </returns>
        protected void btnCreateCase_Click(object sender, EventArgs e)
        {


        }


        void AttachmentsLink_Click(object sender, EventArgs e)
        {
            HtmlAnchor source = (HtmlAnchor)sender;
            //ShowAttachment(Convert.ToInt32(source.ID));
            if (Session["ManualCaseAttachment"] != null)
            {
                DataTable dtAttachments = ((List<EMTWebApp.Constants.Attachment>)Session["ManualCaseAttachment"]).ToDataTable();
                EMTWebApp.Constants.Attachment objAttach = new EMTWebApp.Constants.Attachment();

                foreach (DataRow dr in dtAttachments.Rows)
                {
                    if (Convert.ToInt32(source.ID) == Convert.ToInt32(dr["AttachmentId"]))
                    {
                        objAttach.FileName = dr["FILENAME"].ToString();
                        objAttach.FileType = HelperMethods.ReturnExtension(objAttach.FileName);
                        objAttach.AttachmentId = Convert.ToInt32(dr["AttachmentId"]);
                        objAttach.FileContent = (byte[])dr["FileContent"];
                    }
                }

                try
                {
                    Byte[] imgByte = objAttach.FileContent;
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.ClearContent();
                    HttpContext.Current.Response.ClearHeaders();
                    HttpContext.Current.Response.Buffer = true;
                    HttpContext.Current.Response.AddHeader("content-disposition", "attachment;filename=" + objAttach.FileName);
                    HttpContext.Current.Response.ContentType = objAttach.FileType;
                    HttpContext.Current.Response.Charset = "";
                    HttpContext.Current.Response.BinaryWrite(objAttach.FileContent);
                    //HttpContext.Current.Response.End();
                    // HttpContext.Current.Response.SuppressContent = true;
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
                catch (System.Threading.ThreadAbortException ex)
                {
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | lnkAttachments_click()");
                    //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | lnkAttachments_click()");
                    Response.Clear();
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                    //Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
                }
            }

        }

        void DeleteAttachment_Click(object sender, EventArgs e)
        {
            try
            {
                HtmlAnchor source = (HtmlAnchor)sender;
                //if (Session["ManualCaseAttachment"] != null)
                //{
                //    tblAttachments.Rows.RemoveAt(Convert.ToInt32(source.ID));
                //    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('File(s) removed successfully.');", true);

                //}
                // DeleteAttachmentFromFileCollection(Convert.ToInt32(source.ID));
                //tblAttachments.Rows.RemoveAt(Convert.ToInt32(source.ID));

                if (Session["ManualCaseAttachment"] != null)
                {
                    fileCollection = (List<EMTWebApp.Constants.Attachment>)Session["ManualCaseAttachment"];
                }
                if (fileCollection.Count > 0)
                {
                    int FileCollectionIndex = -1;
                    int FileLength = 0;
                    foreach (var item in fileCollection)
                    {
                        if (item.AttachmentId == (Convert.ToInt32(source.ID) - 100))
                        {
                            FileCollectionIndex = fileCollection.IndexOf(item);
                            FileLength = item.FileContent.Length;
                        }
                    }
                    if (FileCollectionIndex != -1)
                    {
                        // Session["FileSize"] = (int)(Session["FileSize"]) - FileLength;

                        fileCollection.RemoveAt(FileCollectionIndex);
                        tblAttachments.Rows.RemoveAt(FileCollectionIndex);
                        AlertBox("Attachment Deleted Successfully.");
                    }
                }
                Session["ManualCaseAttachment"] = fileCollection;
                DisplayAttachments(); //Display the updated list
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | lnkAttachments_click()");
                //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | lnkAttachments_click()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
                //Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }

        /// <summary>
        /// On Send button click create a new case in database and send the email
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        ///<returns> void </returns>
        protected void CmdSend_Click(object sender, EventArgs e)
        {
            string encryptedValue;
            //fadeActionPlan.Style.Add("display", "false");

            long CaseId = CreateNewCase(); //Create a new case in database and get the caseid
            if (CaseId != 0) //If the caseid is valid send an email
            {
                IList FollowupAttachment;
                try
                {
                    if (Session["ManualCaseEmailCredentials"] != null)
                    {
                        objEMailCredentials = (EMailBoxCredentials)Session["ManualCaseEmailCredentials"];
                    }
                    if (objEMailCredentials != null)
                    {
                        int TotalMailAttachmentSize = 0;

                        if (Session["ManualCaseAttachment"] != null)
                        {
                            fileCollection = (List<EMTWebApp.Constants.Attachment>)Session["ManualCaseAttachment"];
                        }

                        foreach (var item in fileCollection)
                        {
                            if (item.FileContent.Length > 0)
                            {
                                TotalMailAttachmentSize += item.FileContent.Length;
                            }
                        }
                        String strCaseIdKeyword = ConfigurationManager.AppSettings["CaseIdKeyword"].ToString();
                        string strSubject = strCaseIdKeyword + ": " + CaseId + " - " + txtSubject.Text; //EMail Subject
                        Regex regex = new Regex(@"[<>]");
                        Match MatchstrSubject = regex.Match(strSubject);
                        if (!MatchstrSubject.Success)
                        {
                            if (HelperMethods.ValidateMailAttachmentsSize(TotalMailAttachmentSize)) // Checking the total size of the uploaded Attachments
                            {
                                int chkhighimp;
                                if (chkHighImp.Checked == true)
                                {
                                    chkhighimp = 1;
                                }
                                else
                                {
                                    if (txtSubject.Text.ToLower().ToString().Contains("urgent"))
                                    {
                                        chkhighimp = 1;
                                    }
                                    else
                                    {
                                        chkhighimp = 0;
                                    }
                                }

                                int EMailType = (int)Constant.EMailType.Clarification_ManualCaseCreation;

                                bool isSuccess;

                                bool imgSuccess = true;

                                //string mailcontent = htmlEditorMailBody.Content.Replace("\n","");
                                string sourceText = hdnEditorMailBodyContent.Value;
                                //string sourceText = Constants.HelperMethods.StripHtml(mailcontent);
                                var imgSrcMatches = System.Text.RegularExpressions.Regex.Matches(sourceText,
                                string.Format("<img.*src=[\"'](.+?)[\"'].*>"),
                                            RegexOptions.CultureInvariant | RegexOptions.IgnoreCase |
                                            RegexOptions.Multiline);


                                List<string> imgSrcs = new List<string>();


                                int MaxNo = 0;

                                //loop for body.html
                                foreach (Match match in imgSrcMatches)
                                {
                                    string srcvalue = match.Groups[1].Value;
                                    try
                                    {
                                        if (srcvalue.Contains("data:image/png;base64"))
                                        {
                                            imgSrcs.Add(srcvalue.Replace("data:image/png;base64,", ""));

                                            byte[] imgArray = Convert.FromBase64String(srcvalue.Replace("data:image/png;base64,", "").Replace(' ', '+'));
                                            TotalMailAttachmentSize += imgArray.Length;
                                        }
                                        else if (srcvalue.Contains("data:image/jpeg;base64,"))
                                        {
                                            imgSrcs.Add(srcvalue.Replace("data:image/jpeg;base64,", ""));

                                            byte[] imgArray = Convert.FromBase64String(srcvalue.Replace("data:image/jpeg;base64,", "").Replace(' ', '+'));
                                            TotalMailAttachmentSize += imgArray.Length;
                                        }
                                        else
                                        {
                                            byte[] imageArray;

                                            using (var webClient = new WebClient())
                                            {
                                                imageArray = webClient.DownloadData(srcvalue);
                                            }

                                            System.Threading.Thread.Sleep(3000);

                                            TotalMailAttachmentSize += imageArray.Length;

                                            string base64ImageRepresentation = Convert.ToBase64String(imageArray);

                                            if (base64ImageRepresentation.Contains("data:image/png;base64,"))
                                                imgSrcs.Add(base64ImageRepresentation.Replace("data:image/png;base64,", ""));

                                            else if (base64ImageRepresentation.Contains("data:image/jpeg;base64,"))
                                                imgSrcs.Add(base64ImageRepresentation.Replace("data:image/jpeg;base64,", ""));
                                            else
                                                imgSrcs.Add(base64ImageRepresentation);
                                        }


                                        string Name = "";

                                        if (MaxNo > 99)
                                            Name = "cid:image" + MaxNo + ".png";
                                        else if (MaxNo >= 10 && MaxNo <= 99)
                                            Name = "cid:image0" + MaxNo + ".png";
                                        else
                                            Name = "cid:image00" + MaxNo + ".png";

                                        //htmlEditorMailBody.InnerHtml = htmlEditorMailBody.InnerHtml.Replace(srcvalue, Name);
                                        hdnEditorMailBodyContent.Value = hdnEditorMailBodyContent.Value.Replace(srcvalue, Name);
                                        MaxNo = MaxNo + 1;
                                    }
                                    catch (Exception exnew)
                                    {
                                        new LoggingFactory().GetLoggingHandler("Log4net").LogException(exnew, System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(objUser.UserId, true), " | ManualCaseCreation.aspx.cs | CmdSend_Click()");
                                        //errorlog.HandleError(exnew, objUser.UserId, " | ManualCaseCreation.aspx.cs | CmdSend_Click()");

                                        imgSuccess = false;
                                    }
                                }

                                if (imgSuccess)
                                {
                                    if (HelperMethods.ValidateMailAttachmentsSize(TotalMailAttachmentSize))//Checking the total size of the both New screenshots & existing Attachments
                                    {
                                        string plainbody = Regex.Replace(hdnEditorMailBodyContent.Value, @"<(.|\n)*?>", string.Empty);
                                        //Pranay 7 Feb 2017 -- clearing the html content and script content
                                        string mailContent = Constants.HelperMethods.StripHtml(hdnEditorMailBodyContent.Value);
                                        //string mailContent = Constants.HelperMethods.StripHtml(plainbody);
                                        //FollowupAttachment = HelperMethods.SendMail(objEMailCredentials.MailBoxEmailId, objEMailCredentials.LoginEmailId, objEMailCredentials.Password, objEMailCredentials.ServiceURL, txtTo.Text.Trim(), txtCC.Text.Trim(), strSubject, htmlEditorMailBody.Content, fileCollection, CaseId, EMailType, chkhighimp, plainbody, out isSuccess, imgSrcs, txtSubject.Text);
                                        //Pranay 18 MAY 2017 -- for optional from Name in s
                                        //FollowupAttachment = HelperMethods.SendMail(objEMailCredentials.MailBoxEmailId, objEMailCredentials.LoginEmailId, objEMailCredentials.PKeyword, objEMailCredentials.ServiceURL, txtTo.Text.Trim(), txtCC.Text.Trim(), strSubject, mailContent, fileCollection, CaseId, EMailType, chkhighimp, plainbody, out isSuccess, imgSrcs, txtSubject.Text,1);
                                        FollowupAttachment = HelperMethods.SendMail(ddlFrom.SelectedValue, objEMailCredentials.LoginEmailId, objEMailCredentials.PKeyword, objEMailCredentials.ServiceURL, txtTo.Text.Trim(), txtCC.Text.Trim(), txtBCC.Text.Trim(), strSubject, mailContent, fileCollection, CaseId, EMailType, chkhighimp, plainbody, out isSuccess, imgSrcs, txtSubject.Text, 1);


                                        if (isSuccess)
                                        {
                                            //sourcenet change
                                            byte[] convbytes = null;
                                            foreach (EMTWebApp.Constants.Conversation conv in FollowupAttachment)
                                            {
                                                convbytes = conv.Content;
                                            }

                                            int ConversationId = _presenter.InsertMailConversation(CaseId.ToString(), txtSubject.Text, convbytes, ddlFrom.SelectedValue.ToString(), txtTo.Text.ToString(), txtCC.Text.ToString(), txtBCC.Text.ToString(), DateTime.UtcNow, objUser.UserId);

                                            if (imgSrcs.Count > 0)
                                            {
                                                IList InlineAttachments;
                                                List<Constants.Attachment> lstInline = new List<Constants.Attachment>();

                                                int aa = 0;

                                                foreach (string imgcontent in imgSrcs)
                                                {
                                                    Constants.Attachment at = new Constants.Attachment();
                                                    string Name = "";
                                                    if (aa > 99)
                                                        Name = "cid:image" + aa + ".png";
                                                    else if (aa >= 10 && aa <= 99)
                                                        Name = "cid:image0" + aa + ".png";
                                                    else
                                                        Name = "cid:image00" + aa + ".png";

                                                    at.FileName = Name;
                                                    at.FileType = ".png";

                                                    at.FileContent = HelperMethods.EncryptAttachments(Convert.FromBase64String(imgcontent.Replace(" ", "+")));
                                                    at.AttachmentTypeId = 3;

                                                    lstInline.Add(at);

                                                    aa = aa + 1;
                                                }
                                                if (lstInline.Count > 0)
                                                {
                                                    InlineAttachments = lstInline;
                                                    //sourcenet change
                                                    _presenter.UploadAttachment(ConversationId, InlineAttachments, objUser.UserId); //Upload followup file to DB
                                                }


                                            }

                                            IList externaltblattachments;
                                            List<EMTWebApp.Constants.Attachment> lsttblattachments = new List<EMTWebApp.Constants.Attachment>();
                                            if (fileCollection != null)
                                            {
                                                foreach (EMTWebApp.Constants.Attachment at in fileCollection)
                                                {
                                                    if (!(at.FileName.Contains("cid:image") && at.FileName.Contains(".png")))
                                                    {
                                                        EMTWebApp.Constants.Attachment attachment = new EMTWebApp.Constants.Attachment();

                                                        attachment.FileName = at.FileName;
                                                        attachment.FileType = HelperMethods.ReturnExtension(at.FileName);
                                                        attachment.FileContent = HelperMethods.EncryptAttachments(at.FileContent);
                                                        //HelperMethods.EncryptAttachments(Convert.FromBase64String(imgcontent.Replace(" ", "+")));
                                                        attachment.AttachmentTypeId = 1;
                                                        lsttblattachments.Add(attachment);
                                                    }
                                                    //else
                                                    //    objMessage.Attachments.AddFileAttachment(at.FileName, at.FileContent);
                                                }
                                            }
                                            if (lsttblattachments.Count > 0)
                                            {
                                                externaltblattachments = lsttblattachments;
                                                _presenter.UploadAttachment(ConversationId, externaltblattachments, objUser.UserId); //Upload tableattachments to DB
                                            }
                                            //Pranay 11 May 2017 ---For Dynamic Field Configuration
                                            StringBuilder sqlTColumn = new StringBuilder();
                                            StringBuilder sqlTValue = new StringBuilder();
                                            StringBuilder sqlCColumn = new StringBuilder();
                                            StringBuilder sqlCValue = new StringBuilder();
                                            StringBuilder sqlXMLValue = new StringBuilder();
                                            sqlXMLValue.Append("<root>");
                                            GenerateInsParams_CaseID(pnlAllocation, ref sqlTColumn, ref sqlTValue, ref sqlCColumn, ref sqlCValue, ref sqlXMLValue);
                                            // Combine all string builder values
                                            sqlXMLValue.Append("</root>");
                                            _presenter.Updatedynamicfields(Convert.ToInt64(CaseId), sqlXMLValue, objUser.UserId);



                                            {
                                                AlertBox("Case Created . Case ID - " + CaseId);
                                            }
                                            fileCollection.Clear();
                                            Session["FileSize"] = null;
                                            Session["ManualCaseAttachment"] = null;
                                            Session["ManualCaseEmailCredentials"] = null;
                                            Session.Remove("FileSize");
                                            Session.Remove("ManualCaseAttachment");
                                            Session.Remove("ManualCaseEmailCredentials");
                                            DisplayAttachments();
                                            ClearField();
                                            tblAttachments.Rows.Clear();
                                        }
                                        else
                                        {
                                            IgnoreManualCase(CaseId);
                                            AlertBox("Unable to send mail, please try again. If the error occurs again, contact EMT IT Team for assistance.");
                                        }
                                        //OpenSendMailPopup(false); //Close the send email popup
                                    }
                                    else
                                    {
                                        IgnoreManualCase(CaseId);
                                        AlertBox("Unable to send mail. Mail Attachments/Screenshots exceeds 5 MB, Please remove some Attachments/Screenshots and try again. Note: Screenshots in the composed mail will be auto removed.");
                                        //OpenSendMailPopup(true);
                                        htmlEditorMailBody.InnerHtml = RemoveHTMLEditorScreenshots(htmlEditorMailBody.InnerHtml);
                                    }
                                }
                                //Imagefail:
                                //if (!imgSuccess)
                                else
                                {
                                    IgnoreManualCase(CaseId);
                                    AlertBox("Unable to load screenshot(s) in the Mailbody, please try remove web images and try again. Note: Screenshots in the composed mail will be auto removed.");
                                    //OpenSendMailPopup(true);
                                    htmlEditorMailBody.InnerHtml = RemoveHTMLEditorScreenshots(htmlEditorMailBody.InnerHtml);
                                }
                            }
                            else
                            {
                                IgnoreManualCase(CaseId);
                                AlertBox("Unable to send mail. Mail Attachments exceeds 5 MB, Please remove some attachments and try again. Note: Screenshots in the composed mail will be auto removed.");
                                //OpenSendMailPopup(true);
                                htmlEditorMailBody.InnerHtml = RemoveHTMLEditorScreenshots(htmlEditorMailBody.InnerHtml);
                            }
                        }
                        else
                        {

                            Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                        }
                    }
                }
                catch (Exception ex)
                {
                    //ExceptionHelper.HandleException(ex);
                    if (ex.Message == "The message exceeds the maximum supported size.")
                    {
                        AlertBox("Total attachment size exceeds 5mb limit.");
                    }
                    else
                    {
                        new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(objUser.UserId, true), " | ManualCaseCreation.aspx.cs | CmdSend_Click()");
                        //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | CmdSend_Click()");
                    }
                }
            }
        }


        public string RemoveHTMLEditorScreenshots(string htmlContent)
        {

            try
            {
                string sourceText = htmlEditorMailBody.InnerHtml;
                var imgSrcMatches = System.Text.RegularExpressions.Regex.Matches(sourceText,
                    //string.Format("<img.+?src=[\"'](.+?)[\"'].*?>"),  		
                string.Format("<img.*src=[\"'](.+?)[\"'].*>"),
                            RegexOptions.CultureInvariant | RegexOptions.IgnoreCase |
                            RegexOptions.Multiline);
                foreach (Match match in imgSrcMatches)
                {
                    htmlContent = htmlContent.Replace(match.Value, "");
                    // break;		
                }

            }
            catch (Exception ex)
            {
                // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | RemoveHTMLEditorScreenshots()");
                //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | RemoveHTMLEditorScreenshots()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
                //Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }

            return htmlContent;
        }

        /// <summary>
        /// Ignore manual case if case is created but email send failed
        /// </summary>
        /// <param name="CaseId"></param>
        ///<returns> void </returns>
        private void IgnoreManualCase(long CaseId)
        {
            try
            {
                _presenter.IgnoreManualCase(CaseId);
            }
            catch (Exception ex)
            {
                // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | IgnoreManualCase()");
                //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | IgnoreManualCase()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
                //Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }

        /// <summary>
        /// On close button click close the send email popup
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        ///<returns> void </returns>
        protected void imgbtnSendMailClose_OnClick(object sender, EventArgs e)
        {
            try
            {
                //OpenSendMailPopup(false);//Close the send email popup
            }
            catch (Exception ex)
            {
                // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | imgbtnSendMailClose_OnClick()");
                //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | imgbtnSendMailClose_OnClick()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
                //Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }
        #endregion

        /// <summary>
        /// On upload button click save the uploaded file in session
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        ///<returns> void </returns>
        protected void LinkUpload_Click(object sender, EventArgs e)
        {

            bool success = false;

            try
            {   //Functionality to check if browser refresh button has been clicked #for attachments getting duplicated in Attachments column
                if (Session["CheckRefresh"].ToString() == ViewState["CheckRefresh"].ToString())
                {
                    if (fileupload.HasFiles)
                    {
                        int totalAttachSize = 0;

                        foreach (HttpPostedFile file in fileupload.PostedFiles)
                        {
                            Regex regex = new Regex(@"^(([a-zA-Z]:)|(\\{2}\w+)\$?)(\\(\w[\w].*))");
                            Match matchFileName = regex.Match(file.FileName.Trim());
                            Regex regex1 = new Regex(@"(.*[\\\/]|^)(.*?)(?:[\.]|$)([^\.\s]*$)");
                            Match matchContentType = regex1.Match(file.ContentType);
                            if (matchFileName.Success && matchContentType.Success)
                            {
                                if (HelperMethods.fnCheckOtherFileExtension(file.FileName.Trim().ToLower()))
                                {
                                    totalAttachSize += file.ContentLength;
                                    //if (HelperMethods.ValidateMailAttachmentsSize(file.ContentLength))
                                    if (HelperMethods.ValidateMailAttachmentsSize(totalAttachSize))
                                    {
                                        success = true;
                                    }
                                    else
                                    {
                                        success = false;
                                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('File size exceeds maximum limit 5 MB.');", true);
                                        break;
                                    }
                                }
                                else
                                {
                                    success = false;
                                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Invalid file type.');", true);
                                    //Label1.Text = "File size exceeds maximum limit 20 MB.";
                                    break;
                                }
                            }
                            else
                            {
                                success = false;
                                Response.Redirect("~/Errors/BadRequest.aspx", false);
                                break;
                            }
                        }

                        if (success)
                        {
                            foreach (HttpPostedFile file in fileupload.PostedFiles)
                            {
                                AddAttachmentToFileCollection(file);
                            }
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('File(s) attached successfully.');", true);

                            //foreach (GridViewRow row in GvAttachments.Rows)
                            //{
                            //    LinkButton lnkFull = row.FindControl("lnkAttachments") as LinkButton;
                            //    ScriptManager.GetCurrent(this).RegisterPostBackControl(lnkFull);
                            //}
                        }
                    }
                    Session["CheckRefresh"] = Server.UrlDecode(System.DateTime.Now.ToString());
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | ManualCaseCreationNewUI.aspx.cs | LinkUpload_Click()");
                //errorlog.HandleError(ex, objUser.UserId, " | ManualCaseCreation.aspx.cs | LinkUpload_Click()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
                //Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }




        /// <summary>
        /// Go back to previous page
        /// </summary>
        /// <param>sender</param>
        /// <param>e</param>
        ///<returns> void </returns>
        ///
        protected void btnCaseCancel_Click(object sender, EventArgs e)
        {
            //EnableField();
            Session["ManualCaseAttachment"] = null;
            BindEMailDetails(Convert.ToInt32(ddlEMailBox.SelectedValue));
            ClearField();
        }

        private void ClearField()
        {
            lblFrom.Text = "";
            txtTo.Text = string.Empty;
            txtTo.Enabled = false;
            txtCC.Text = string.Empty;
            txtCC.Enabled = false;
            txtBCC.Text = string.Empty;
            txtBCC.Enabled = false;
            chkHighImp.Checked = false;
            txtSubject.Text = string.Empty;
            txtSubject.Enabled = false;
            htmlEditorMailBody.InnerHtml = null;
            ddlEMailBox.SelectedIndex = 0;
            ddlStatus.Items.Clear();
            ddlStatus.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlStatus.SelectedIndex = 0;
            ddlTemplateCategory.Items.Clear();
            ddlTemplateCategory.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlTemplateCategory.SelectedIndex = 0;
            chkHighImp.Disabled = true;

            if (ddlClassification.Visible == true)
            {
                ddlClassification.SelectedIndex = 0;
            }
            tblAttachments.Rows.Clear();
            DynamicFieldsPanel.Visible = false;
            DynamicFieldsPanel.Controls.Clear();
            ddlFrom.Items.Clear();
            ddlFrom.Enabled = false;

        }

        private void EnableField()
        {
            txtTo.Text = string.Empty;
            txtTo.Enabled = true;
            txtCC.Text = string.Empty;
            txtCC.Enabled = true;
            txtBCC.Text = string.Empty;
            txtBCC.Enabled = true;
            chkHighImp.Checked = false;
            txtSubject.Text = string.Empty;
            txtSubject.Enabled = true;
            chkHighImp.Disabled = false;
            ddlFrom.Enabled = true;
            //lblFrom.Text = "";
            //ddlEMailBox.SelectedIndex = 0;
            //ddlCountry.SelectedIndex = 0;
            //htmlEditorMailBody.InnerHtml = null;
        }

    }
}