﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.Common;
using EMTWebApp.Common.Views;
using EMTWebApp.ExceptionHandler;
using System.Text.RegularExpressions;
using EMTWebApp.Constants;
using EMTWebApp.UserManagement.Common;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Security;

namespace EMTWebApp.Common.Views
{
    public partial class Approval : Microsoft.Practices.CompositeWeb.Web.UI.Page,IApprovalWorkQueueView
    {

        #region DECLARATION
        private ApprovalPresenter _presenter;
        private const string ASCENDING = " ASC";
        private const string DESCENDING = " DESC";
        UserSession userData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            userData = (UserSession)Session["userdetails"];
            IsSessionValid();
            Session["CurrentPage"] = "Approver";
            if (!this.IsPostBack)
            {
                //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                string PKeyword = (Session["PasswordExpiration"]).ToString();
                if (PKeyword == "yes")
                {
                    Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                }
                try
                {
                    
                    GetApprovalWorkQueue(userData.UserId);
                    IsValidRoleToAccessThisPage(userData);
                   
                }
                catch (Exception ex)
                {
                    //  ExceptionHelper.HandleException(ex);
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | Page_Load()");
                    //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | Page_Load()");
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                }
                this._presenter.OnViewInitialized();
            }
            this._presenter.OnViewLoaded();
        }

        #region PROPERTIES
        [CreateNew]
        public ApprovalPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion

        #region PRIVATEMETHODS

        private bool IsValidRoleToAccessThisPage(UserSession UserDetails)
        {
            try
            {
                if ((UserDetails.RoleId == (int)Constant.UserRole.TeamLead) || (UserDetails.RoleId == (int)Constant.UserRole.Processor))
                {
                    return true;
                }
                else
                {
                    Response.Redirect(@"~\Errors\AccessDenied.aspx", false);
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | QCWorkQueue.aspx.cs | IsValidRoleToAccessThisPage()");
                
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
            return false;
        }

        /// <summary>
        /// Session Valid 
        /// </summary>
        private void IsSessionValid()
        {
            try
            {
                if (userData == null)
                    Response.Redirect(@"~\Errors\SessionExpired.aspx");
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | IsSessionValid()");
              
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
      
        private void AlertBox(string Message)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert", "alert('" + Message + "')", true);
        }
        /// <summary>
        /// To Get Individual User's QC WorkQueue
        /// </summary>
        private void GetApprovalWorkQueue(string userId)
        {
            try
            {
                this._presenter.GetApproverWorkQueueDetails(userId);
               
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | GetQCWorkQueue()");
               
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

        }
       
        
        protected void gvApprovalWorkQueue_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                IsSessionValid();
                gvApprovalWorkQueue.PageIndex = e.NewPageIndex;
                GetApprovalWorkQueue(userData.UserId);
            }
            catch (Exception ex)
            {
                
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | gvQcWorkQueue_PageIndexChanging()");
              Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        protected void gvApprovalWorkQueue_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow || e.Row.RowType == DataControlRowType.Header)
                {
                    for (int count = 0; count < e.Row.Cells.Count; count++)
                    {
                        e.Row.Cells[count].HorizontalAlign = HorizontalAlign.Center;

                        if (e.Row.RowType == DataControlRowType.DataRow && count == 2)
                        {
                            e.Row.Cells[count].HorizontalAlign = HorizontalAlign.Left;
                            String encryptsubject = e.Row.Cells[count].Text;                            
                            string decryptsubject = Constants.HelperMethods.DecryptString(encryptsubject);
                            e.Row.Cells[count].Text = decryptsubject;
                        }
                    }
                }

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    string strURL = "#";
                    HyperLink hypCaseId = (HyperLink)e.Row.FindControl("hypCaseId");
                    HiddenField hiddenCaseId = (HiddenField)e.Row.FindControl("hiddenCaseId");
                    Label lblStatusId = (Label)e.Row.FindControl("lblStatusId");
                    Label lblEMailboxId = (Label)e.Row.FindControl("lblEMailboxId");

                    //strURL = "ProcessingNewUI.aspx?CaseId=" + hiddenCaseId.Value + "&PreviousPage=QCWorkQueue" + "&EMailBox=" + lblEMailboxId.Text.Trim() + "&Status=" + lblStatusId.Text.Trim();
                    strURL = "NewProcessingPage.aspx?CaseId=" + hiddenCaseId.Value + "&PreviousPage=QCWorkQueue" + "&EMailBox=" + lblEMailboxId.Text.Trim() + "&Status=" + lblStatusId.Text.Trim();
                    //SAST fixes
                    // hypCaseId.NavigateUrl = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(strURL,true);
                    hypCaseId.NavigateUrl = strURL;
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | gvQcWorkQueue_RowDataBound()");
                //errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | gvQcWorkQueue_RowDataBound()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        protected void gvApprovalWorkQueue_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                //Setting sort direction and expression
                if (GridViewSortDirection == SortDirection.Ascending)
                {
                    GridViewSortDirection = SortDirection.Descending;

                    hiddenFieldSortDirection.Value = DESCENDING;
                    hiddenFieldSortExp.Value = e.SortExpression;

                    GetApprovalWorkQueue(userData.UserId);
                }
                else
                {
                    GridViewSortDirection = SortDirection.Ascending;

                    hiddenFieldSortDirection.Value = ASCENDING;
                    hiddenFieldSortExp.Value = e.SortExpression;

                    GetApprovalWorkQueue(userData.UserId);
                }
            }
            catch (Exception ex)
            {             
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | gvQcWorkQueue_Sorting()");                
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        public SortDirection GridViewReAssignSortDirection
        {
            get
            {
                if (ViewState["ReAssignsortDirection"] == null)
                    ViewState["ReAssignsortDirection"] = SortDirection.Ascending;

                return (SortDirection)ViewState["ReAssignsortDirection"];
            }
            set { ViewState["ReAssignsortDirection"] = value; }
        }
        public DataSet ApprovalWorkQueue
        {
            set
            {
                DataView dview = value.Tables[0].DefaultView;
                dview.Sort = hiddenFieldSortExp.Value + hiddenFieldSortDirection.Value;
                lblcount.Text = dview.Table.Rows.Count.ToString();
                gvApprovalWorkQueue.DataSource = dview;
                gvApprovalWorkQueue.DataBind();
            }
        }
        
        public SortDirection GridViewSortDirection
        {
            get
            {
                if (ViewState["sortDirection"] == null)
                    ViewState["sortDirection"] = SortDirection.Ascending;

                return (SortDirection)ViewState["sortDirection"];
            }
            set { ViewState["sortDirection"] = value; }
        }

        protected void btnExporttoExcel_Click(object sender, EventArgs e)
        {
            try
            {
                IsSessionValid();
                Response.Clear();
                string UserId = (userData.UserId != "" ? userData.UserId : "");
                Response.AddHeader("content-disposition", "attachment;filename=QCWorkQueue.xls");
                Response.Charset = "UTF-8";
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; //"application/vnd.xls";
                Response.ContentEncoding = System.Text.Encoding.Default;
                System.IO.StringWriter stringWrite = new System.IO.StringWriter();
                System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
                gvApprovalWorkQueue.AllowSorting = false;
                gvApprovalWorkQueue.AllowPaging = false;
                GetApprovalWorkQueue(UserId);
                foreach (GridViewRow row in gvApprovalWorkQueue.Rows)
                {
                    if (row.RowType == DataControlRowType.DataRow)
                    {
                        if (row.Cells[0].FindControl("hypCaseId").GetType() == typeof(HyperLink))
                        {
                            Literal l = new Literal();
                            l.Text = (row.Cells[0].FindControl("hypCaseId") as HyperLink).Text;

                            row.Cells[0].Controls.Remove(row.Cells[0].FindControl("hypCaseId"));

                            row.Cells[0].Controls.Add(l);
                        }
                    }
                }
                for (int i = 0; i < gvApprovalWorkQueue.Rows.Count; i++)
                {
                    gvApprovalWorkQueue.Rows[i].Attributes.Add("class", "textmode");
                    gvApprovalWorkQueue.Rows[i].Cells[1].Attributes.Add("class", "date");
                }



                gvApprovalWorkQueue.RenderControl(htmlWrite);
                //string style = @"<style>.date { mso-number-format:'dd/mm/yyyy h:mm:ss'; }</style>";
                string style = @"<style>.date { mso-number-format:'mm\\/dd\\/yyyy hh:mm:ss'; }</style>";
                Response.Write(style);
                Response.Write(stringWrite.ToString());
                stringWrite.Close();
                htmlWrite.Close();
                Response.End();
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | QCWorkQueue.aspx.cs | btnExporttoExcel_Click()");
                //  errorlog.HandleError(ex, userData.UserId , " | QCWorkQueue.aspx.cs | btnExporttoExcel_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
            // stringWrite.Close();
        }
        
       
        #endregion
    }
}

