﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using EMTWebApp.UserManagement.Common;
using System.Web.SessionState;
using System.Reflection;
using DigiOPS.TechFoundation.ExceptionHandling;
using System.Text.RegularExpressions;
using DigiOPS.TechFoundation.Logging;
using System.Web.Security;
using EMTWebApp.Constants;

public partial class Common_Dashboard : System.Web.UI.Page
{
    #region Declaration
    UserSession userData = new UserSession();
    UserErrorLog errorlog = new UserErrorLog();
    UserSession objUser;
    private const string AntiXsrfTokenKey = "__AntiXsrfToken";
    private const string AntiXsrfUserNameKey = "__AntiXsrfUserName";
    private string _antiXsrfTokenValue;
    #endregion


    protected void Page_Load(object sender, EventArgs e)
    {


        //iterate through all the request params and check for SQL injection.

        Regex regex = new Regex(System.Configuration.ConfigurationManager.AppSettings["SQLInjectionRegex"]);
                      
                      
        foreach (string key in HttpContext.Current.Request.Form.Keys)
        {
            // if (key != "txtLoginId" && key != "txtPKeyword")
            if (!String.IsNullOrEmpty(Request.Form[key]) && regex.Match(Request.Form[key]).Success)
            {
                Server.Transfer(@"~/Errors/BadRequest.aspx");
            }
        }

        if (
               (this.Request.UrlReferrer == null
                && this.Request.Headers["Referer"] == null)
                ||
                ((this.Request.UrlReferrer != null && this.Request.UrlReferrer.Host.Equals(this.Request.Url.Host))
                && (this.Request.Headers["Referer"] != null && this.Request.Headers["Referer"].Contains(this.Request.Url.Host))
                ))
        {

            {
                Session["CurrentPage"] = "Dashboard";
                bool session = IsSessionValid();
                try
                {
                    if (session == true)
                    {
                        if (Request.Form["__VIEWSTATEENCRYPTED"] != null && Request.Form["__VIEWSTATEENCRYPTED"] != "")
                        {

                            //  Response.Redirect("~/Errors/BadRequest.aspx", false);
                            Server.Transfer(@"~/Errors/BadRequest.aspx?r=" + HelperMethods.GenerateSecureRandom());

                        }
                        else
                        {
                            if (!this.IsPostBack)
                            {
                                //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                                string PKeyword = (Session["PasswordExpiration"]).ToString();
                                if (PKeyword == "yes")
                                {
                                    Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                                }
                                //string text = Session["RoleListForUser"].ToString();
                                if (Session["RoleIDForUser"] != null && Session["RoleIDForUser"] != null && Session["UserID"] != null)
                                {
                                    List<string> listroleid= (List<string>)Session["RoleIDForUser"];
                                    List<string> listrolename = (List<string>)Session["RoleNameForUser"];
                                    string userid = Session["UserID"].ToString();
                                    if (!listroleid.Contains(userData.RoleId.ToString()) || !listrolename.Contains(userData.RoleName.ToString()) || userid!=userData.UserId)
                                    {
                                        //Server.Transfer(@"~/Errors/AccessDenied.aspx?r=(new Random()).nextInt()");
                                        Response.Redirect(@"~\Errors\AccessDenied.aspx", false);
                                    }

                            }
                            }

                            regex = new Regex(@"^[a-zA-Z0-9 ]*$");
                            //saranya DAST fix
                            if (regex.Match(hdnCountry.Value).Success && regex.Match(hdnMailBoxname.Value).Success && regex.Match(hdnSubProcessName.Value).Success &&
                                regex.Match(fname.Value).Success && regex.Match(UID.Value).Success && regex.Match(role.Value).Success && regex.Match(roleID.Value).Success && regex.Match(ISAD.Value).Success)
                            {
                                fname.Value = userData.FirstName.ToString();
                                role.Value = userData.RoleName.ToString();
                                UID.Value = userData.UserId.ToString();
                                roleID.Value = userData.RoleId.ToString();
                                //ISAD.Value = ConfigurationManager.AppSettings["ADLogin"].ToString();
                                ViewState["ISADValue"] = ConfigurationManager.AppSettings["ADLogin"].ToString();
                                ISAD.Value = ViewState["ISADValue"].ToString();
                            }
                            else
                            {
                                //Response.StatusCode = 400;
                                //Response.Redirect(@"~/Errors/Error.aspx", false);
                                Server.Transfer(@"~/Errors/BadRequest.aspx");
                            }
                        }//end of view state encrypted check

                    }
                    else
                    {
                        Response.Clear();
                        Response.Redirect(@"~/Errors/SessionExpired.aspx", false);
                        Response.End();
                    }
                    regenerateId();//to regenerate session id - saranya 
                }
                catch (Exception ex)
                {
                    //ExceptionHelper.HandleException(ex);
                    
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Dashboard.aspx.cs | Page_Load()");
                    Response.Clear();
                    //errorlog.HandleError(ex, objUser.UserId, " | Dashboard.aspx.cs | Page_Load()");
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
        }//end of url referrer check
        else
        {
            //Response.Redirect(@"~/Errors/BadRequest.aspx", false);
            Server.Transfer(@"~/Errors/BadRequest.aspx");
        }
    }

    void Page_Init(object sender, EventArgs e)
    {
        //if (Session.IsNewSession)
        //{
        //    Session["UserDetails"] = DateTime.Now;
        //}
        this.ViewStateUserKey = Session.SessionID;
        if (Page.EnableViewState)
        {
            if (!string.IsNullOrEmpty(Request.Params["__VIEWSTATE"]) && string.IsNullOrEmpty(Request.Form["__VIEWSTATE"]))
            {
                throw new Exception("Cross Site History Manipulation happened...");
            }
        }

        // The code below helps to protect against XSRF attacks
        var requestCookie = Request.Cookies[AntiXsrfTokenKey];
        Guid requestCookieGuidValue;
        if (requestCookie != null && Guid.TryParse(requestCookie.Value, out requestCookieGuidValue))
        {
            // Use the Anti-XSRF token from the cookie
            _antiXsrfTokenValue = requestCookie.Value;
            Page.ViewStateUserKey = _antiXsrfTokenValue;
            Session["_antiXsrfTokenValue"] = _antiXsrfTokenValue;
        }
        else
        {
            // Generate a new Anti-XSRF token and save to the cookie
            _antiXsrfTokenValue = Guid.NewGuid().ToString("N");
            Page.ViewStateUserKey = _antiXsrfTokenValue;
            Session["_antiXsrfTokenValue"] = _antiXsrfTokenValue;

            var responseCookie = new HttpCookie(AntiXsrfTokenKey)
            {
                HttpOnly = true,
                Value = _antiXsrfTokenValue
            };
            if (FormsAuthentication.RequireSSL && Request.IsSecureConnection)
            {
                responseCookie.Secure = true;
            }
            Response.Cookies.Set(responseCookie);
        }


        Page.PreLoad += Page_PreLoad;

    }

    protected void Page_PreLoad(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Set Anti-XSRF token
            ViewState[AntiXsrfTokenKey] = Page.ViewStateUserKey;
            ViewState[AntiXsrfUserNameKey] = Context.User.Identity.Name ?? String.Empty;
        }
        else
        {
            // Validate the Anti-XSRF token
            if ((string)ViewState[AntiXsrfTokenKey] != _antiXsrfTokenValue
                || (string)ViewState[AntiXsrfUserNameKey] != (Context.User.Identity.Name ?? String.Empty))
            {
                //throw new InvalidOperationException("Validation of Anti-XSRF token failed.");
                Server.Transfer(@"~/Errors/BadRequest.aspx");
            }
        }
    }

    private bool IsSessionValid()
    {
        userData = (UserSession)Session["userdetails"];
        if (userData == null)
            return false;
        else
            return true;
    }

    void regenerateId()
    {
        try
        {
            System.Web.SessionState.SessionIDManager manager = new System.Web.SessionState.SessionIDManager();
            string oldId = manager.GetSessionID(Context);
            string newId = manager.CreateSessionID(Context);
            bool isAdd = false, isRedir = false;
            manager.SaveSessionID(Context, newId, out isRedir, out isAdd);
            HttpApplication ctx = (HttpApplication)HttpContext.Current.ApplicationInstance;
            HttpModuleCollection mods = ctx.Modules;
            System.Web.SessionState.SessionStateModule ssm = (SessionStateModule)mods.Get("Session");
            System.Reflection.FieldInfo[] fields = ssm.GetType().GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
            SessionStateStoreProviderBase store = null;
            System.Reflection.FieldInfo rqIdField = null, rqLockIdField = null, rqStateNotFoundField = null;
            foreach (System.Reflection.FieldInfo field in fields)
            {
                if (field.Name.Equals("_store")) store = (SessionStateStoreProviderBase)field.GetValue(ssm);
                if (field.Name.Equals("_rqId")) rqIdField = field;
                if (field.Name.Equals("_rqLockId")) rqLockIdField = field;
                if (field.Name.Equals("_rqSessionStateNotFound")) rqStateNotFoundField = field;
            }
            object lockId = rqLockIdField.GetValue(ssm);
            if ((lockId != null) && (oldId != null)) store.ReleaseItemExclusive(Context, oldId, lockId);
            rqStateNotFoundField.SetValue(ssm, true);
            rqIdField.SetValue(ssm, newId);
        }
        catch (EMTException ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, "", " | Login.aspx.cs|regenerateId");  
            //errorlog.HandleError(ex, "", " | Login.aspx.cs|regenerateId");
        }
        catch (Exception ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, "", "Login.aspx.cs|regenerateId");  
            //errorlog.HandleError(ex, "", "Login.aspx.cs|regenerateId");
            //ExceptionHelper.HandleException(ex);
            Response.Clear();
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            Response.End();
        }

    }
}