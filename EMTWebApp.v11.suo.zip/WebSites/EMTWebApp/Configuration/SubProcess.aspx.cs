﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using DigiOPS.TechFoundation.Logging;
using System.Web.UI.WebControls.WebParts;
using EMTWebApp.Constants;

namespace EMTWebApp.Configuration.Views
{
    public partial class SubProcess : Microsoft.Practices.CompositeWeb.Web.UI.Page, ISubProcessView
    {
        #region DECLARATION
        private SubProcessPresenter _presenter;
        private string LoginId;
        UserSession UserDetails = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        private string SubProcessId;
        #endregion
        /// <summary>
        /// TO BIND THE GRID AND INITIALIZE THE FIELDS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                UserDetails = (UserSession)Session["UserDetails"];
                IsValidRoleToAccessThisPage(UserDetails);
                Session["CurrentPage"] = "Client Configuration";
                if (Session["UserDetails"] == null)
                {
                    Response.Clear();
                    //RedirectToErrorPage(UserDetails);
                    Response.Redirect(@"~\Errors\SessionExpired.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
                if (!this.IsPostBack)
                {
                    ddlCntryName.Focus();
                    Page.Form.DefaultButton = btnSubmit.UniqueID;
                    if (Session["UserDetails"] != null)
                    {

                        LoginId = UserDetails.UserId.ToString();
                        BindCountry();
                        BindSubProcess();
                    }
                    else
                    {
                        Response.Clear();
                        Response.Redirect("~/Errors/AccessDenied.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                        Response.End();
                    }
                    this._presenter.OnViewInitialized();
                    //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                    string PKeyword = (Session["PasswordExpiration"]).ToString();
                    if (PKeyword == "yes")
                    {
                        Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                }
                }
                this._presenter.OnViewLoaded();
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                if (UserDetails == null)
                {
                    Response.Clear();
                    Response.Redirect(@"~\Errors\SessionExpired.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
                else
                {
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | SubProcess.cs | Page_Load()");
                    Response.Clear();
                    //errorlog.HandleError(Ex, UserDetails.UserId , " | SubProcess.cs | Page_Load()");
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
        }

        #region PROPERTIES
        [CreateNew]
        public SubProcessPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion
        #region METHODS
        /// <summary>
        /// Function to bind the country names to the dropdown
        /// </summary>
        public void BindCountry()
        {
            try
            {

                DataSet dsCountryNames = _presenter.BindCountryForSubProcess();
                ddlCntryName.DataSource = dsCountryNames;
                ddlCntryName.DataValueField = "CountryID";
                ddlCntryName.DataTextField = "Country";
                ddlCntryName.DataBind();
                if (dsCountryNames.Tables[0].Rows.Count == 1)
                {
                    ddlCntryName.SelectedIndex = -1;
                    ddlCntryName.Enabled = false;
                }
                else
                {
                    ddlCntryName.Items.Insert(0, new ListItem("-Select-", "0", true));
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | MailBoxCreation.cs | BindCountry()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | MailBoxCreation.cs | BindCountry()");
                Response.Redirect("~/Errors/Error.aspx",false);
                Response.End();
            }
        }
        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserDetails)
        {
            try
            {
                if ((UserDetails.RoleId == (int)Constant.UserRole.SuperAdmin))
                {
                    return true;
                }
                else
                {
                    //sprint 3 security fixes
                    //Response.Redirect(@"~\Errors\Error.aspx", false);
                    Response.Clear();
                    Response.Redirect("~/Errors/AccessDenied.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | SubProcess.cs | IsValidRoleToAccessThisPage()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | SubProcess.cs | IsValidRoleToAccessThisPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            return false;
        }

        /// <summary>
        /// Method to redirect to Error page if userdetails are null
        /// </summary>
        private void RedirectToErrorPage(UserSession UserDetails)
        {
            try
            {
                if (UserDetails == null)
                {
                    Response.Clear();
                    Response.Redirect(@"~\Errors\Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | SubProcess.cs | IsValidRoleToAccessThisPage()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | SubProcess.cs | IsValidRoleToAccessThisPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();

            }
        }


        protected void sort(string strParam)
        {
            try
            {
                if (ViewState["SortDirection"] == null)
                {
                    ViewState["SortDirection"] = "asc";
                }
                else if (ViewState["SortDirection"].ToString() == "asc")
                {
                    ViewState["SortDirection"] = "desc";
                }
                else
                {
                    ViewState["SortDirection"] = "asc";
                }
                BindGrid(strParam);
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | SubProcess.cs | sort()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | SubProcess.cs | sort()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        private void BindGrid(string strparameter)
        {
            try
            {
                string Sortexpression = "";
                string sortdirection = "";
                if (ViewState["Sort"] == null)
                {
                    Sortexpression = strparameter;
                }
                else
                {
                    Sortexpression = ViewState["Sort"].ToString();
                }
                if (ViewState["SortDirection"] == null)
                {
                    sortdirection = "asc";
                }
                else
                {
                    sortdirection = ViewState["SortDirection"].ToString();
                }
                DataTable dtWorkList = new DataTable();
                GetWorkList(Sortexpression, sortdirection);
            }
            catch (Exception Ex)
            {
                // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | SubProcess.cs | BindGrid()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | SubProcess.cs | BindGrid()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// TO CLEAR THE FIELDS
        /// </summary>
        public void Clearfields()
        {
            try
            {

                ddlCntryName.SelectedIndex = 0;
                txtSubProcessName.Text = "";
                chkSubProcessActive.Checked = true;
                txtProcessOwnId.Text = "";
                btnSubmit.Text = "Configure";
                ddlCntryName.Enabled = false;
                txtSubProcessName.Focus();
            }
            catch (Exception ex)
            {
                // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | SubProcess.cs | Clearfields()");
                Response.Clear();
                //errorlog.HandleError(ex, UserDetails.UserId , " | SubProcess.cs | Clearfields()");
                Response.Redirect("~/Errors/Error.aspx",false);
                Response.End();
            }
        }
        protected void GetWorkList(string SortExpression, string SortDirection)
        {
            try
            {
                DataSet ds = new DataSet();
                ds = (DataSet)ViewState["SubProcessGroupsGrid"];
                DataView dv = new DataView();
                dv = ds.Tables[0].DefaultView;
                dv.Sort = SortExpression + " " + SortDirection;
                grdSubProcess.DataSource = dv;
                grdSubProcess.DataBind();
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | SubProcess.cs | GetWorkList()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId, " | SubProcess.cs | GetWorkList()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        /// <summary>
        /// TO BIND THE DETAILS OF THE SUBPROCESS TO THE GRID
        /// </summary>
        public void BindSubProcess()
        {
            try
            {
                grdSubProcess.DataSource = this._presenter.GridSubProcessGroupsBind();
                grdSubProcess.DataBind();
                ViewState["SubProcessGroupsGrid"] = grdSubProcess.DataSource;
            }
            catch (Exception ex)
            {
                // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | SubProcess.cs | BindSubProcess()");
                Response.Clear();
                //errorlog.HandleError(ex, UserDetails.UserId , " | SubProcess.cs | BindSubProcess()");
                Response.Redirect("~/Errors/Error.aspx",false);
                Response.End();
            }
        }
        #endregion

        #region EVENTS
        /// <summary>
        /// TO ADD THE SUBPROCESS NAMES
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
            try
            {
                SubProcessId = HddnSProcId.Value;
                string SubProcessName = txtSubProcessName.Text.Trim();
                string ProcessOwnerId = txtProcessOwnId.Text.Trim();
                int CountryId = Convert.ToInt32(ddlCntryName.SelectedItem.Value.ToString());
                int Active;
                if (chkSubProcessActive.Checked == true)
                {
                    Active = 1;
                }
                else
                {
                    Active = 0;
                }
                UserDetails = (UserSession)Session["UserDetails"];
                LoginId = UserDetails.UserId.ToString();

                if (btnSubmit.Text == "Configure")
                {
                    int returnvalue = _presenter.ConfigureSubProcessNames(CountryId, SubProcessName, ProcessOwnerId, Active, LoginId);
                    if (returnvalue == 0)//TO SHOW SUBPROCESS ALREADY EXISTS
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('SubProcess Name Already exists!');", true);
                        BindSubProcess();
                    }
                    if (returnvalue == 1)//TO SHOW SUBPROCESS HAS BEEN ADDED
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('SubProcess Configuration is Successful!');", true);
                        Clearfields();
                        BindSubProcess();
                    }
                }
                else
                {
                    SubProcessId = HddnSProcId.Value;
                        int returnvalue = _presenter.UpdateSubProcessNames(CountryId, SubProcessId, SubProcessName, ProcessOwnerId, Active, LoginId, hdnSubProcessName.Value);
                    if (returnvalue == 0)//UPDATE FAILURE ALERT
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Same Subprocess name already configured for this country.');", true);
                        Clearfields();
                        BindSubProcess();
                        btnSubmit.Text = "Configure";
                        btnSubmit.ValidationGroup = "Submit";
                    }
                    if (returnvalue == 1)//UPDATE SUCCESS
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update is Successful!');", true);
                        Clearfields();
                        BindSubProcess();
                        btnSubmit.Text = "Configure";
                        btnSubmit.ValidationGroup = "Submit";
                    }
                }
            }
            catch (Exception Ex)
            {
                // ExceptionHelper.HandleException(Ex);
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | SubProcess.cs | btnSubmit_Click()");
                    //errorlog.HandleError(Ex, UserDetails.UserId , " | SubProcess.cs | btnSubmit_Click()");
                }
            }
        }
        /// <summary>
        /// BUTTON EVENT TO CLEAR THE FIELDS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                Clearfields();
            }
            catch (Exception ex)
            {
                // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | SubProcess.cs | btnClear_Click()");
                Response.Clear();
                //errorlog.HandleError(ex, UserDetails.UserId , " | SubProcess.cs | btnClear_Click()");
                Response.Redirect("~/Errors/Error.aspx",false);
                Response.End();
            }
        }

        /// <summary>
        /// to sort the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdSubProcess_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                ViewState["Sort"] = e.SortExpression;
                sort("SubProcessGroupID");
            }
            catch (Exception Ex)
            {
                // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | SubProcess.cs | grdSubProcess_Sorting()");  
                //errorlog.HandleError(Ex, UserDetails.UserId , " | SubProcess.cs | grdSubProcess_Sorting()");
            }
        }
        /// <summary>
        /// ROW COMMAND EVENT TO EDIT THE VALUES FROM THE GRID
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdSubProcess_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "EditSubProcess")
                {
                    int RowIndex = Convert.ToInt32(e.CommandArgument);
                    string CountryID = ((Label)grdSubProcess.Rows[RowIndex].FindControl("lblCountryId")).Text.ToString().Trim();
                    string SubProId = ((Label)grdSubProcess.Rows[RowIndex].FindControl("lblSubProcessId")).Text.ToString().Trim();
                    string SProcName = ((Label)grdSubProcess.Rows[RowIndex].FindControl("lblSubProcessName")).Text.ToString().Trim();
                    string PrOwnId = ((Label)grdSubProcess.Rows[RowIndex].FindControl("lblProOwnId")).Text.ToString().Trim();
                    string IsActive = ((Label)grdSubProcess.Rows[RowIndex].FindControl("lblIsActive")).Text.ToString().Trim();
                    hdnSubProcessName.Value = SProcName;
                    HddnSProcId.Value = SubProId;
                    ddlCntryName.SelectedValue = CountryID;
                    txtSubProcessName.Text = SProcName;
                    txtProcessOwnId.Text = PrOwnId;
                    if (IsActive == "Yes")
                    {
                        chkSubProcessActive.Checked = true;
                    }
                    else
                    {
                        chkSubProcessActive.Checked = false;
                    }
                    btnSubmit.Text = "Update";
                    btnSubmit.ValidationGroup = "Submit";
                    ddlCntryName.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | SubProcess.cs | grdSubProcess_RowCommand()");
                Response.Clear();
                //errorlog.HandleError(ex, UserDetails.UserId , " | SubProcess.cs | grdSubProcess_RowCommand()");
                Response.Redirect("~/Errors/Error.aspx",false);
                Response.End();
            }
        }
        /// <summary>
        /// TO CHANGE THE PAGE OF THE GRID
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdSubProcess_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdSubProcess.PageIndex = e.NewPageIndex;
                grdSubProcess.EditIndex = -1;
                BindSubProcess();
            }
            catch (Exception ex)
            {
                // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | SubProcess.cs | grdSubProcess_PageIndexChanging()");
                Response.Clear();
                //errorlog.HandleError(ex, UserDetails.UserId , " | SubProcess.cs | grdSubProcess_PageIndexChanging()");
                Response.Redirect(@"~\Errors\Error.aspx",false);
                Response.End();
            }
        }
        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            //_presenter.GetEMailBoxByUserId(objUser.UserId, objUser.RoleId, Convert.ToInt32(ddlCountry.SelectedValue));
        }

        #endregion
    }
}

