﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using DigiOPS.TechFoundation.Logging;
using EMTWebApp.Constants;


namespace EMTWebApp.Configuration.Views
{
    public partial class Holiday : Microsoft.Practices.CompositeWeb.Web.UI.Page, IHolidayView
    {
        #region DECLARATION
        private HolidayPresenter _presenter;
        private string LoginId;
        UserSession UserDetail = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        #endregion

        /// <summary>
        /// TO INITIALIZE OTHER CONTROLS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                UserDetail = (UserSession)Session["UserDetails"];
                IsValidRoleToAccessThisPage(UserDetail);
                RedirectToErrorPage(UserDetail);
                btnSubmit.Attributes.Add("onclick", string.Format("return ValidateSearch({0},{1})",txtHolidayDesc.ClientID, txtHolidayDate.ClientID));
                //txtHolidayDate_CalendarExtende.StartDate = DateTime.Today;
                if (!this.IsPostBack)
                {
                    txtHolidayDesc.Focus();
                    Page.Form.DefaultButton = btnSubmit.UniqueID;
                    if (Session["UserDetails"] != null)
                    {
                        LoginId = UserDetail.UserId.ToString();
                    }
                    else
                    {
                        Response.Clear();
                        Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                        Response.End();
                    }
                    BindHolidayDetails();
                    this._presenter.OnViewInitialized();
                    //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                    string PKeyword = (Session["PasswordExpiration"]).ToString();
                    if (PKeyword == "yes")
                    {
                        Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                }
                }
                this._presenter.OnViewLoaded();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | Holiday.cs | Page_Load()");  
                Response.Clear();
                //errorlog.HandleError(ex, UserDetail.UserId , " | Holiday.cs | Page_Load()");
                Response.Redirect("~/Errors/Error.aspx",false);
                Response.End();
            }
        }

        #region PROPERTIES
        [CreateNew]
        public HolidayPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion

        #region METHODS
        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserDetail)
        {
            try
            {
                if ((UserDetail.RoleId == (int)Constant.UserRole.SuperAdmin))
                {
                    return true;
                }
                else
                {
                    Response.Clear();
                    Response.Redirect("~/Errors/AccessDenied.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | Holiday.cs | IsValidRoleToAccessThisPage()");  
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetail.UserId , " | Holiday.cs | IsValidRoleToAccessThisPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            return false;
        }

        /// <summary>
        /// Method to redirect to Error page if userdetails are null
        /// </summary>
        private void RedirectToErrorPage(UserSession UserDetail)
        {
            try
            {
                if (UserDetail == null)
                {
                    Response.Clear();
                    Response.Redirect(@"~\Errors\Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | Holiday.cs | RedirectToErrorPage()");  
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetail.UserId , " | Holiday.cs | RedirectToErrorPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        protected void sort(string strParam)
        {
            try
            {
                if (ViewState["SortDirection"] == null)
                {
                    ViewState["SortDirection"] = "asc";
                }
                else if (ViewState["SortDirection"].ToString() == "asc")
                {
                    ViewState["SortDirection"] = "desc";
                }
                else
                {
                    ViewState["SortDirection"] = "asc";
                }
                BindGrid(strParam);
            }
            catch (Exception Ex)
            {
                //    ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | Holiday.cs | sort()");  
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetail.UserId , " | Holiday.cs | sort()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        private void BindGrid(string strparameter)
        {
            try
            {
                string Sortexpression = "";
                string sortdirection = "";
                if (ViewState["Sort"] == null)
                {
                    Sortexpression = strparameter;
                }
                else
                {
                    Sortexpression = ViewState["Sort"].ToString();
                }
                if (ViewState["SortDirection"] == null)
                {
                    sortdirection = "asc";
                }
                else
                {
                    sortdirection = ViewState["SortDirection"].ToString();
                }
                DataTable dtWorkList = new DataTable();
                GetWorkList(Sortexpression, sortdirection);
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | Holiday.cs | BindGrid()");  
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetail.UserId , " | Holiday.cs | BindGrid()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// TO BIND THE DETAILS OF THE HOLIDAYS TO THE GRID
        /// </summary>
        public void BindHolidayDetails()
        {
            try
            {
                grdConfigureHoliday.DataSource = this._presenter.GridBindHolidayDet();
                grdConfigureHoliday.DataBind();
                ViewState["HolidayGrid"] = grdConfigureHoliday.DataSource;
            }
            catch (Exception ex)
            {
                //   ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | Holiday.cs | BindHolidayDetails()");  
                Response.Clear();
                //errorlog.HandleError(ex, UserDetail.UserId , " | Holiday.cs | BindHolidayDetails()");
                Response.Redirect("~/Errors/Error.aspx",false);
                Response.End();
            }
        }
        /// <summary>
        /// TO CLEAR THE FIELDS
        /// </summary>
        public void Clearfields()
        {
            try
            {
                txtHolidayDesc.Text = "";
                txtHolidayDate.Text = "";
                chkHolidayActive.Checked = true;
                btnSubmit.Text = "Configure";
                txtHolidayDesc.Focus();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | Holiday.cs | Clearfields()");  
                Response.Clear();
                //errorlog.HandleError(ex, UserDetail.UserId , " | Holiday.cs | Clearfields()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        protected void GetWorkList(string SortExpression, string SortDirection)
        {
            try
            {
                DataSet ds = new DataSet();
                ds = (DataSet)ViewState["HolidayGrid"];
                DataView dv = new DataView();
                dv = ds.Tables[0].DefaultView;
                dv.Sort = SortExpression + " " + SortDirection;
                grdConfigureHoliday.DataSource = dv;
                grdConfigureHoliday.DataBind();
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | Holiday.cs | GetWorkList()");  
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetail.UserId , " | Holiday.cs | GetWorkList()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        #endregion

        #region EVENTS
        /// <summary>
        /// TO ADD THE COUNTRY DETAILS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
            try
            {
                string Holiday = txtHolidayDesc.Text.Trim();
                DateTime HolidayDate = Convert.ToDateTime(txtHolidayDate.Text.Trim());
                int Active;
                if (chkHolidayActive.Checked == true)
                {
                    Active = 1;
                }
                else
                {
                    Active = 0;
                }
                UserDetail = (UserSession)Session["UserDetails"];
                LoginId = UserDetail.UserId.ToString();
                //if (HolidayDate > DateTime.Today)
                //{
                if (btnSubmit.Text == "Configure")
                {

                    int returnvalue = _presenter.ConfigureHolidays(Holiday, HolidayDate, Active, LoginId);
                    if (returnvalue == 0)//TO SHOW COUNTRY ALREADY EXISTS
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Provided Holiday Date Already exists!');", true);
                        BindHolidayDetails();
                    }
                    if (returnvalue == 1)//TO SHOW COUNTRY HAS BEEN ADDED
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Holiday Date is Added Successfully!');", true);
                        Clearfields();
                        BindHolidayDetails();
                    }
                }
                else
                {
                    string HolidayId = HddnHolidayId.Value;
                    int returnvalue = _presenter.UpdateHoliday(HolidayId, Holiday, HolidayDate, Active, LoginId);
                    if (returnvalue == 0)//UPDATE FAILURE ALERT
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update Falied!');", true);
                        Clearfields();
                        BindHolidayDetails();
                        btnSubmit.Text = "Configure";
                        btnSubmit.ValidationGroup = "Submit";
                    }
                    if (returnvalue == 1)//UPDATE SUCCESS
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update is successful!');", true);
                        Clearfields();
                        BindHolidayDetails();
                        btnSubmit.Text = "Configure";
                        btnSubmit.ValidationGroup = "Submit";
                    }
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | Holiday.cs | btnSubmit_Click()");
                    Response.Clear();
                    //errorlog.HandleError(Ex, UserDetail.UserId , " | Holiday.cs | btnSubmit_Click()");
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
        }
        /// <summary>
        /// BUTTON EVENT TO CLEAR THE FIELDS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                Clearfields();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | Holiday.cs | btnClear_Click()");
                Response.Clear();
                //errorlog.HandleError(ex, UserDetail.UserId , " | Holiday.cs | btnClear_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        /// <summary>
        /// to sort the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdConfigureHoliday_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                ViewState["Sort"] = e.SortExpression;
                sort("HOLIDAYID");
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | Holiday.cs | grdConfigureHoliday_Sorting()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetail.UserId , " | Holiday.cs | grdConfigureHoliday_Sorting()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// ROW COMMAND EVENT TO EDIT THE VALUES FROM THE GRID
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdConfigureHoliday_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "EditHoliday")
                {
                    int RowIndex = Convert.ToInt32(e.CommandArgument);
                    string HId = ((Label)grdConfigureHoliday.Rows[RowIndex].FindControl("lblHolidayID")).Text.ToString().Trim();
                    string HolName = ((Label)grdConfigureHoliday.Rows[RowIndex].FindControl("lblHolidayDesc")).Text.ToString().Trim();
                    DateTime HolDate = Convert.ToDateTime(((Label)grdConfigureHoliday.Rows[RowIndex].FindControl("lblHolidayDate")).Text.ToString().Trim());
                    string IsActive = ((Label)grdConfigureHoliday.Rows[RowIndex].FindControl("lblIsActive")).Text.ToString().Trim();
                    HddnHolidayId.Value = HId;
                    txtHolidayDesc.Text = HolName;

                    txtHolidayDate.Text = HolDate.ToString("MM/dd/yyyy");
                    if (IsActive == "Yes")
                    {
                        chkHolidayActive.Checked = true;
                    }
                    else
                    {
                        chkHolidayActive.Checked = false;
                    }
                    btnSubmit.Text = "Update";
                    btnSubmit.ValidationGroup = "Submit";
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | Holiday.cs | grdConfigureHoliday_RowCommand()");
                Response.Clear();
                //errorlog.HandleError(ex, UserDetail.UserId , " | Holiday.cs | grdConfigureHoliday_RowCommand()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// TO CHANGE THE PAGE OF THE GRID
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdConfigureHoliday_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdConfigureHoliday.PageIndex = e.NewPageIndex;
                grdConfigureHoliday.EditIndex = -1;
                BindHolidayDetails();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | Holiday.cs | grdConfigureHoliday_PageIndexChanging()");
                Response.Clear();
               // errorlog.HandleError(ex, UserDetail.UserId , " | Holiday.cs | grdConfigureHoliday_PageIndexChanging()");
                Response.Redirect(@"~\Errors\Error.aspx", false);
                Response.End();
            }
        }
        #endregion

    }
}

