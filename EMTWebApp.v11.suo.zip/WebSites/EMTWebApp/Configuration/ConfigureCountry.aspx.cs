﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using DigiOPS.TechFoundation.Logging;
using EMTWebApp.Constants;


namespace EMTWebApp.Configuration.Views
{
    public partial class ConfigureCountry : Microsoft.Practices.CompositeWeb.Web.UI.Page, IConfigureCountryView
    {
        #region DECLARATION
        private ConfigureCountryPresenter _presenter;
        private string LoginId;
        UserSession UserDetail = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        #endregion
        /// <summary>
        /// TO BIND THE COUNTRY NAMES TO THE DROPDWON AND TO INITIALIZE OTHER CONTROLS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                UserDetail = (UserSession)Session["UserDetails"];
                IsValidRoleToAccessThisPage(UserDetail);
                RedirectToErrorPage(UserDetail);

                if (!this.IsPostBack)
                {
                    txtCountryName.Focus();
                    Page.Form.DefaultButton = btnSubmit.UniqueID;
                    if (Session["UserDetails"] != null)
                    {
                        LoginId = UserDetail.UserId.ToString();
                    }
                    else
                    {
                        Response.Clear();
                        Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                        Response.End();
                    }
                    BindCountryDetails();
                    this._presenter.OnViewInitialized();
                    //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                    string PKeyword = (Session["PasswordExpiration"]).ToString();
                    if (PKeyword == "yes")
                    {
                        Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                }
                }
                this._presenter.OnViewLoaded();
            }
            catch (Exception ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | ConfigureCountry.cs | Page_Load()");  
                Response.Clear();
                //errorlog.HandleError(ex, UserDetail.UserId , " | ConfigureCountry.cs | Page_Load()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
                
            }
        }
        #region PROPERTIES
        [CreateNew]
        public ConfigureCountryPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion
        #region METHODS

        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserDetail)
        {
            try
            {
                if ((UserDetail.RoleId == (int)Constant.UserRole.SuperAdmin))
                {
                    return true;
                }
                else
                {
                    Response.Clear();
                    Response.Redirect("~/Errors/AccessDenied.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | ConfigureCountry.cs | IsValidRoleToAccessThisPage()");  
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetail.UserId , " | ConfigureCountry.cs | IsValidRoleToAccessThisPage()");
                Response.Redirect(@"~\Errors\Error.aspx", false);
                Response.End();
            }
            return false;
        }

        /// <summary>
        /// Method to redirect to Error page if userdetails are null
        /// </summary>
        private void RedirectToErrorPage(UserSession UserDetail)
        {
            try
            {
                if (UserDetail == null)
                {
                    Response.Clear();
                    Response.Redirect(@"~\Errors\Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | ConfigureCountry.cs | RedirectToErrorPage()");  
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetail.UserId , " | ConfigureCountry.cs | RedirectToErrorPage()");
                Response.Redirect(@"~\Errors\Error.aspx", false);
                Response.End();
            }
        }

        protected void sort(string strParam)
        {
            try
            {
                if (ViewState["SortDirection"] == null)
                {
                    ViewState["SortDirection"] = "asc";
                }
                else if (ViewState["SortDirection"].ToString() == "asc")
                {
                    ViewState["SortDirection"] = "desc";
                }
                else
                {
                    ViewState["SortDirection"] = "asc";
                }
                BindGrid(strParam);
            }
            catch (Exception Ex)
            {
             //   ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | ConfigureCountry.cs | sort()");  
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetail.UserId , " | ConfigureCountry.cs | sort()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        private void BindGrid(string strparameter)
        {
            try
            {
                string Sortexpression = "";
                string sortdirection = "";
                if (ViewState["Sort"] == null)
                {
                    Sortexpression = strparameter;
                }
                else
                {
                    Sortexpression = ViewState["Sort"].ToString();
                }
                if (ViewState["SortDirection"] == null)
                {
                    sortdirection = "asc";
                }
                else
                {
                    sortdirection = ViewState["SortDirection"].ToString();
                }
                DataTable dtWorkList = new DataTable();
                GetWorkList(Sortexpression, sortdirection);
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | ConfigureCountry.cs | BindGrid()");  
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetail.UserId , " | ConfigureCountry.cs | BindGrid()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// TO CLEAR THE FIELDS
        /// </summary>
        public void Clearfields()
        {
            try
            {
                txtCountryName.Text = "";
                chkCountryActive.Checked = true;
                btnSubmit.Text = "Configure";
                txtCountryName.Focus();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | ConfigureCountry.cs | Clearfields()");  
                Response.Clear();
                //errorlog.HandleError(ex, UserDetail.UserId , " | ConfigureCountry.cs | Clearfields()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        protected void GetWorkList(string SortExpression, string SortDirection)
        {
            try
            {
                DataSet ds = new DataSet();
                ds = (DataSet)ViewState["CountryGrid"];
                DataView dv = new DataView();
                dv = ds.Tables[0].DefaultView;
                dv.Sort = SortExpression + " " + SortDirection;
                grdConfigureCountry.DataSource = dv;
                grdConfigureCountry.DataBind();
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | ConfigureCountry.cs | GetWorkList()");  
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetail.UserId , " | ConfigureCountry.cs | GetWorkList()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// TO BIND THE DETAILS OF THE COUNTRY TO THE GRID
        /// </summary>
        public void BindCountryDetails()
        {
            try
            {
                grdConfigureCountry.DataSource = this._presenter.GridCountryDetBind();
                grdConfigureCountry.DataBind();
                ViewState["CountryGrid"] = grdConfigureCountry.DataSource;
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | ConfigureCountry.cs | BindCountryDetails()");  
                Response.Clear();
                //errorlog.HandleError(ex, UserDetail.UserId , " | ConfigureCountry.cs | BindCountryDetails()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        #endregion
        #region EVENTS
        /// <summary>
        /// TO ADD THE COUNTRY DETAILS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
            try
            {
                string CountryName = txtCountryName.Text.Trim();
                int Active;
                if (chkCountryActive.Checked == true)
                {
                    Active = 1;
                }
                else
                {
                    Active = 0;
                }
                UserDetail = (UserSession)Session["UserDetails"];
                LoginId = UserDetail.UserId.ToString();

                if (btnSubmit.Text == "Configure")
                {
                    int returnvalue = _presenter.ConfigureCountry(CountryName, Active, LoginId);
                    if (returnvalue == 0)//TO SHOW COUNTRY ALREADY EXISTS
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Country Name Already exists!');", true);
                        BindCountryDetails();
                    }
                    if (returnvalue == 1)//TO SHOW COUNTRY HAS BEEN ADDED
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Country configuration is Successful!');", true);
                        Clearfields();
                        BindCountryDetails();
                    }
                }
                else
                {
                    string CountryId = HddnCntryId.Value;
                    int returnvalue = _presenter.UpdateCountry(CountryId, CountryName, Active, LoginId);
                    if (returnvalue == 0)//UPDATE FAILURE ALERT
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update Falied!');", true);
                        Clearfields();
                        BindCountryDetails();
                        btnSubmit.Text = "Configure";
                        btnSubmit.ValidationGroup = "Submit";
                    }
                    if (returnvalue == 1)//UPDATE SUCCESS
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update is successful!');", true);
                        Clearfields();
                        BindCountryDetails();
                        btnSubmit.Text = "Configure";
                        BindCountryDetails();
                        btnSubmit.ValidationGroup = "Submit";
                    }
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                     new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | ConfigureCountry.cs | btnSubmit_Click()");
                     Response.Clear();
                    //errorlog.HandleError(Ex, UserDetail.UserId, " | ConfigureCountry.cs | btnSubmit_Click()");
                     Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                     Response.End();
                }
            }
           
        }
        /// <summary>
        /// BUTTON EVENT TO CLEAR THE FIELDS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                Clearfields();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | ConfigureCountry.cs | btnClear_Click()");
                Response.Clear();
                //errorlog.HandleError(ex, UserDetail.UserId , " | ConfigureCountry.cs | btnClear_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// to sort the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdConfigureCountry_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                ViewState["Sort"] = e.SortExpression;
                sort("CountryID");
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | ConfigureCountry.cs | grdConfigureCountry_Sorting()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetail.UserId , " | ConfigureCountry.cs | grdConfigureCountry_Sorting()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();

            }
        }
        /// <summary>
        /// ROW COMMAND EVENT TO EDIT THE VALUES FROM THE GRID
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdConfigureCountry_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "EditCountry")
                {
                    int RowIndex = Convert.ToInt32(e.CommandArgument);
                    string CntryId = ((Label)grdConfigureCountry.Rows[RowIndex].FindControl("lblCountryId")).Text.ToString().Trim();
                    string CntryName = ((Label)grdConfigureCountry.Rows[RowIndex].FindControl("lblCountryName")).Text.ToString().Trim();
                    string IsActive = ((Label)grdConfigureCountry.Rows[RowIndex].FindControl("lblIsActive")).Text.ToString().Trim();
                    HddnCntryId.Value = CntryId;
                    txtCountryName.Text = CntryName;
                    if (IsActive == "Yes")
                    {
                        chkCountryActive.Checked = true;
                    }
                    else
                    {
                        chkCountryActive.Checked = false;
                    }
                    btnSubmit.Text = "Update";
                    btnSubmit.ValidationGroup = "Submit";
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | ConfigureCountry.cs | grdConfigureCountry_RowCommand()");
                Response.Clear();
                //errorlog.HandleError(ex, UserDetail.UserId , " | ConfigureCountry.cs | grdConfigureCountry_RowCommand()");
                Response.Redirect("~/Errors/Error.aspx",false);
                Response.End();

            }
        }
        /// <summary>
        /// TO CHANGE THE PAGE OF THE GRID
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdConfigureCountry_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdConfigureCountry.PageIndex = e.NewPageIndex;
                grdConfigureCountry.EditIndex = -1;
                BindCountryDetails();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | ConfigureCountry.cs | grdConfigureCountry_PageIndexChanging()");
                Response.Clear();
                //errorlog.HandleError(ex, UserDetail.UserId , " | ConfigureCountry.cs | grdConfigureCountry_PageIndexChanging()");
                Response.Redirect(@"~\Errors\Error.aspx", false);
                Response.End();
            }
        }
        #endregion
    }
}