﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.ProvisioningManagement;
using DigiOPS.TechFoundation.Configuration;
using DigiOPS.TechFoundation.Security;
using System.Web.UI.WebControls.WebParts;
using EMTWebApp.Constants;
using System.Collections.Generic;

namespace EMTWebApp.Configuration.Views
{

 

    public partial class MailBoxCreation : Microsoft.Practices.CompositeWeb.Web.UI.Page, IMailBoxCreationView
    {



        
        #region DECLARATION
        private MailBoxCreationPresenter _presenter;
        UserSession UserDetails = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        string LoginId;
        private int QcReq;
        private int MailTrigger;
        private int ReplyNotReq;
        #endregion
        #region PROPERTIES
        [CreateNew]
        public MailBoxCreationPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion
        /// <summary>
        /// To bind teh Country details, Email Login Details and EmailBox Details Grid and initialize other controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Session["CurrentPage"] = "Client Configuration";
                UserDetails = (UserSession)Session["UserDetails"];
                IsValidRoleToAccessThisPage(UserDetails);
                RedirectToErrorPage(UserDetails);

                if (!this.IsPostBack)
                {
                    this._presenter.OnViewInitialized();
                    txtEmailBoxName.Focus();
                    Page.Form.DefaultButton = btnSubmit.UniqueID;
                    if (Session["UserDetails"] != null)
                    {

                        LoginId = UserDetails.UserId.ToString();
                        BindMailBoxDetGrid();
                        BindCountry();
                        BindEmailBoxLoginID();
                        BindTimeZone();
                        txtEMailFolderPath.Text = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("ClientServiceURL"));
                        // BindSubProcessNames();
                    }
                    else
                    {
                        Response.Clear();
                        Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                        Response.End();
                    }

                    this._presenter.OnViewLoaded();
                    //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                    string PKeyword = (Session["PasswordExpiration"]).ToString();
                    if (PKeyword == "yes")
                    {
                        Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                    }
                }
            }

            catch (Exception ex)
            {

                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | Holiday.cs | Page_Load()");
                Response.Clear();
                //errorlog.HandleError(ex,UserDetails.UserId, " | Holiday.cs | Page_Load()");
                Response.Redirect(@"~\Errors\Error.aspx", false);
                Response.End();
            }
        }
        #region PRIVATE METHODS

        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserDetails)
        {
            try
            {
                if ((UserDetails.RoleId == (int)Constant.UserRole.SuperAdmin))
                {
                    return true;
                }
                else
                {
                    Response.Clear();
                    Response.Redirect("~/Errors/AccessDenied.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);

                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | MailBoxCreation.cs | IsValidRoleToAccessThisPage()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | MailBoxCreation.cs | IsValidRoleToAccessThisPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            return false;
        }


        #region Paging and Sorting
        /// <summary>
        /// To sort the Page
        /// </summary>
        protected DataView SortDataTable(DataTable dataTable, bool isPageIndexChanging)
        {


            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (GridViewSortExpression != string.Empty)
                {

                    if (isPageIndexChanging)
                    {

                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GridViewSortDirection);
                    }

                    else
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GetSortDirection());
                    }
                }

                return dataView;
            }
            else
            {
                return new DataView();
            }


        }

        private string GetSortDirection()
        {
            try
            {
                switch (GridViewSortDirection)
                {
                    case "ASC":
                        GridViewSortDirection = "DESC";
                        break;
                    case "DESC":
                        GridViewSortDirection = "ASC";
                        break;
                }
            }
            catch (Exception ex)
            {

                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | Holiday.cs | GetSortDirection()");
                Response.Clear();
                //errorlog.HandleError(ex,UserDetails.UserId, " | Holiday.cs | GetSortDirection()");
                Response.Redirect(@"~\Errors\Error.aspx", false);
                Response.End();
            }
            return GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }

        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }


        #endregion

        /// <summary>
        /// Method to redirect to Error page if userdetails are null
        /// </summary>
        private void RedirectToErrorPage(UserSession UserDetails)
        {
            try
            {
                if (UserDetails == null)
                {
                    Response.Clear();
                    Response.Redirect(@"~\Errors\Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | MailBoxCreation.cs | RedirectToErrorPage()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | MailBoxCreation.cs | RedirectToErrorPage()");
                Response.Redirect("~/Errors/Error.aspx", false);
                Response.End();
            }
        }

        /// <summary>
        /// Function to bind the country names to the dropdown
        /// </summary>
        public void BindCountry()
        {
            try
            {
                DataSet dsCountryNames = _presenter.BindCountry();
                ddlCntryName.DataSource = dsCountryNames;
                ddlCntryName.DataValueField = "CountryID";
                ddlCntryName.DataTextField = "Country";
                ddlCntryName.DataBind();
                if (dsCountryNames.Tables[0].Rows.Count == 1)
                {
                    ddlCntryName.SelectedIndex = -1;
                    ddlCntryName.Enabled = false;

                    ddlCntryName_SelectedIndexChanged(null, null);
                }
                else
                {
                    ddlCntryName.Items.Insert(0, new ListItem("-Select-", "0", true));
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | MailBoxCreation.cs | BindCountry()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | MailBoxCreation.cs | BindCountry()");
                Response.Redirect("~/Errors/Error.aspx", false);
                Response.End();
            }
        }

        /// <summary>
        /// Function to clear the fields 
        /// </summary>
        public void Clearfields()
        {
            try
            {
                txtEmailBoxName.Text = "";
                //txtEMailFolderPath.Text = "";
                txtEmailBoxAddrs.Text = "";
                //Pranay 18 May 2017--Code Merge for selecting FROM mail id while sending emails from emt 
                txtEmailBoxOpt.Text = "";
                ddlEmailBoxMailId.SelectedIndex = 0;
                ddlCntryName.SelectedIndex = 0;
                txtSLAHrs.Text = "";
                chkMBoxActive.Checked = true;
                chkMailTrig.Checked = true;
                chkQCRequired.Checked = true;
                chkMailTrig.Enabled = true;
                chkQCRequired.Enabled = true;
                chkReplyNotReq.Checked = false;
                chkApprovalRequired.Checked = false;
                chkSkillBasedAllocREQ.Checked = false;
                ddlSubProcessName.SelectedIndex = 0;
                //Varma - Timezone Feature On&OFF functionality 
                if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("ClientServiceURL")) == "ON")
                {
                    ddlTimeZone.SelectedIndex = 0;
                }
                //if (ddlSubProcessName.Visible == true)
                //{
                //    ddlSubProcessName.Items.Clear();
                //    ddlSubProcessName.SelectedIndex = -1;
                //    trSubProcess.Visible = false;
                //}
                //else
                //{
                //    trSubProcess.Visible = false;
                //}
                chkLocked.Checked = false;
                btnSubmit.Text = "Submit";
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | MailBoxCreation.cs | Clearfields()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | MailBoxCreation.cs | Clearfields()");
                Response.Redirect("~/Errors/Error.aspx", false);
                Response.End();
            }
        }

        /// <summary>
        /// Function to bind the Mail box details into the grid
        /// </summary>

        public DataTable BindMailBoxDetGrid()
        {
            DataTable dt = null;
            try
            {
                DataSet dsGridMailBoxDetBind = this._presenter.GridMailBoxDetBind();
                ViewState["MailBoxName"] = dsGridMailBoxDetBind;
                grdMailBoxConfigure.DataSource = dsGridMailBoxDetBind;
                grdMailBoxConfigure.DataBind();
                dt = dsGridMailBoxDetBind.Tables[0];
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | MailBoxCreation.cs | BindMailBoxDetGrid()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | MailBoxCreation.cs | BindMailBoxDetGrid()");
                Response.Redirect("~/Errors/Error.aspx", false);
                Response.End();
            }
            return dt;
        }

        /// <summary>
        /// Function to bind the Emailbox login ids to the dropdown
        /// </summary>
        public void BindEmailBoxLoginID()
        {
            try
            {
                DataSet dsLoginMailId = _presenter.BindEmailBoxMailId();
                ddlEmailBoxMailId.DataSource = dsLoginMailId;
                ddlEmailBoxMailId.DataValueField = "emailboxlogindetailid";
                ddlEmailBoxMailId.DataTextField = "emailid";
                ddlEmailBoxMailId.DataBind();
                ListItem select = new ListItem();
                select.Text = "- Select -";
                select.Value = "0";
                ddlEmailBoxMailId.Items.Insert(0, select);
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | MailBoxCreation.cs | BindEmailBoxLoginID()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | MailBoxCreation.cs | BindEmailBoxLoginID()");
                Response.Redirect("~/Errors/Error.aspx", false);
                Response.End();
            }
        }

        /// <summary>
        /// Function to bind the SubProcess Names to the dropdown
        /// </summary>
        public void BindSubProcessNames()
        {
            try
            {
                DataSet dsSubProcessName = _presenter.BindSubProcessNames();
                ddlSubProcessName.DataSource = dsSubProcessName;
                ddlSubProcessName.DataValueField = "SUBPROCESSGROUPID";
                ddlSubProcessName.DataTextField = "SUBPROCESSNAME";
                ddlSubProcessName.DataBind();
                ListItem select = new ListItem();
                select.Text = "- Select -";
                select.Value = "0";
                ddlSubProcessName.Items.Insert(0, select);
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | MailBoxCreation.cs | BindSubProcessNames()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | MailBoxCreation.cs | BindSubProcessNames()");
                Response.Redirect("~/Errors/Error.aspx", false);
                Response.End();
            }
        }

        //Pranay 2nd January 2017 
        // Get all timezone from local system and bind it in dropdownlist
        private void BindTimeZone()
        {
            try
            {
                //Varma - Timezone Feature On&OFF functionality 
                if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                {
                    foreach (TimeZoneInfo z in TimeZoneInfo.GetSystemTimeZones())
                    {
                        //ddlTimeZone.Items.Add(new ListItem(z.DisplayName, z.Id));
                        ddlTimeZone.Items.Add(new ListItem(z.StandardName, z.Id));
                    }
                    ListItem select = new ListItem();
                    select.Text = "--Select--";
                    select.Value = "0";
                    ddlTimeZone.Items.Insert(0, select);
                }
                else
                {
                    trTimezone.Visible = false;
                    ddlTimeZone.Visible = false;
                    RFddlTimeZone.Enabled = false;
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | MailBoxCreation.cs | BindTimeZone()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | MailBoxCreation.cs | BindTimeZone()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        //protected void sort(string StrParam)
        //{
        //    try
        //    {
        //        if (ViewState["SortDirection"] == null)
        //        {
        //            ViewState["SortDirection"] = "asc";
        //        }
        //        else if (ViewState["SortDirection"].ToString() == "asc")
        //        {
        //            ViewState["SortDirection"] = "desc";
        //        }
        //        else
        //        {
        //            ViewState["SortDirection"] = "asc";
        //        }
        //        BindGrid(StrParam);
        //    }
        //    catch (Exception Ex)
        //    {
        //        errorlog.HandleError(Ex, UserDetails.UserId + " | MailBoxCreation.cs | sort()");
        //        Response.Clear(); Response.Redirect("~/Errors/Error.aspx",false);
        //    }
        //}

        //private void BindGrid(string StrParameter)
        //{
        //    try
        //    {
        //        string Sortexpression = "";
        //        string sortdirection = "";
        //        if (ViewState["Sort"] == null)
        //        {
        //            Sortexpression = StrParameter;
        //        }
        //        else
        //        {
        //            Sortexpression = ViewState["Sort"].ToString();
        //        }
        //        if (ViewState["SortDirection"] == null)
        //        {
        //            sortdirection = "asc";
        //        }
        //        else
        //        {
        //            sortdirection = ViewState["SortDirection"].ToString();
        //        }
        //        DataTable dtWorkList = new DataTable();
        //        GetWorkList(Sortexpression, sortdirection);
        //    }
        //    catch (Exception Ex)
        //    {
        //        errorlog.HandleError(Ex, UserDetails.UserId + " | MailBoxCreation.cs | BindGrid()");
        //        Response.Clear(); Response.Redirect("~/Errors/Error.aspx",false);
        //    }
        //}

        //protected void GetWorkList(string SortExpression, string SortDirection)
        //{
        //    try
        //    {
        //        DataSet ds = new DataSet();
        //        ds = (DataSet)ViewState["MailBoxName"];
        //        DataView dv = new DataView();
        //        dv = ds.Tables[0].DefaultView;
        //        dv.Sort = SortExpression + " " + SortDirection;
        //        grdMailBoxConfigure.DataSource = dv;
        //        grdMailBoxConfigure.DataBind();
        //    }
        //    catch (Exception Ex)
        //    {
        //        errorlog.HandleError(Ex, UserDetails.UserId + " | MailBoxCreation.cs | GetWorkList()");
        //        Response.Clear(); Response.Redirect("~/Errors/Error.aspx",false);
        //    }
        //}

        #endregion
        #region EVENTS
        /// <summary>
        /// To add the EMail Box details
        /// </summary>   #region EVENTS
        /// <param name="sender"></param>
        /// <param name="e"></param>

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
           
            //if (Page.IsValid)
            //{
            //    try
            //    {
            //        string EmailBox = txtEmailBoxName.Text.Trim();
            //        string MailFoldPath = txtEMailFolderPath.Text.Trim();
            //        string EmailAddrs = txtEmailBoxAddrs.Text.Trim();
            //        //Pranay 18 May 2017--Code Merge for selecting FROM mail id while sending emails from emt 
            //        string EmailAddrsOpt = txtEmailBoxOpt.Text.Trim();
            //        string Domain = "";
            //        string UserId = "";
            //        string EncryptConfirmPKeyword = "";
            //        string EMailid = ddlEmailBoxMailId.SelectedItem.ToString();
            //        string CountryName = ddlCntryName.SelectedItem.ToString();
            //        string SubProcessId = ddlSubProcessName.SelectedValue.ToString();


            //        //Varma - Timezone Feature On&OFF functionality 
            //        string TimeZone = "", OffSet = "";

            //        if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
            //        {
            //            //Pranay 3rd January 2017 --adding string for retrieving value of TimeZone selected
            //            TimeZone = ddlTimeZone.SelectedItem.ToString();

            //            TimeZoneInfo cst = TimeZoneInfo.FindSystemTimeZoneById(TimeZone);
            //            TimeSpan offset = cst.GetUtcOffset(DateTime.Now);

            //            OffSet = offset.ToString();
            //        }
            //        string SLA = txtSLAHrs.Text.Trim();
            //        int Active;
            //        int IsVocSurvey;
            //        int IsLocked;
            //        int IsSkillBasedAllocation;
            //        int IsApprovalRequired;
            //        UserDetails = (UserSession)Session["UserDetails"];
            //        LoginId = UserDetails.UserId.ToString();
            //        if (chkMBoxActive.Checked == true)
            //        {
            //            Active = 1;
            //        }
            //        else
            //        {
            //            Active = 0;
            //        }

            //        if (chkMailTrig.Checked == true)
            //        {
            //            MailTrigger = 1;
            //        }
            //        else
            //        {
            //            MailTrigger = 0;
            //        }
            //        if (chkQCRequired.Checked == true)
            //        {
            //            QcReq = 1;
            //        }
            //        else
            //        {
            //            QcReq = 0;
            //        }
            //        //chkReplyNotReq_CheckedChanged(sender, e);

            //        if (chkReplyNotReq.Checked == true)
            //        {
            //            ReplyNotReq = 1;
            //            //MailTrigger = 0;
            //            //QcReq = 0;
            //            if (chkMailTrig.Checked == true)
            //            {
            //                MailTrigger = 1;
            //            }
            //            else
            //            {
            //                MailTrigger = 0;
            //            }
            //            if (chkQCRequired.Checked == true)
            //            {
            //                QcReq = 1;
            //            }
            //            else
            //            {
            //                QcReq = 0;
            //            }
            //            chkMailTrig.Enabled = false;
            //            chkQCRequired.Enabled = false;
            //        }
            //        else
            //        {
            //            ReplyNotReq = 0;
            //            //MailTrigger = 1;
            //            //QcReq = 1;
            //            if (chkMailTrig.Checked == true)
            //            {
            //                MailTrigger = 1;
            //            }
            //            else
            //            {
            //                MailTrigger = 0;
            //            }
            //            if (chkQCRequired.Checked == true)
            //            {
            //                QcReq = 1;
            //            }
            //            else
            //            {
            //                QcReq = 0;
            //            }
            //            chkMailTrig.Enabled = true;
            //            chkQCRequired.Enabled = true;
            //        }
            //        //if (chkQCRequired.Checked == true)
            //        //{
            //        //    QcReq = 1;
            //        //}
            //        //else
            //        //{
            //        //    QcReq = 0;
            //        //}

            //        if (chkApprovalRequired.Checked == true)
            //        {
            //            IsApprovalRequired = 1;
            //        }
            //        else
            //        {
            //            IsApprovalRequired = 0;
            //        }
            //        if (chkLocked.Checked == true)
            //        {
            //            IsLocked = 1;
            //        }
            //        else
            //        {
            //            IsLocked = 0;
            //        }

            //        //Pranay 9 December 2016
            //        if (chkIsVocSurveyReq.Checked == true)
            //        {
            //            IsVocSurvey = 1;
            //        }
            //        else
            //        {
            //            IsVocSurvey = 0;
            //        }
            //        //Saranya Sep 2017
            //        if (chkSkillBasedAllocREQ.Checked == true)
            //        {
            //            IsSkillBasedAllocation = 1;
            //        }
            //        else
            //        {
            //            IsSkillBasedAllocation = 0;
            //        }

            //        if (btnSubmit.Text == "Submit")
            //        {
            
            CreateTenant("Tenantnew","195174","2017-08-11","2017-08-11","tenantnew1","ctsc00617635601","emtuser","password-1","vertical","IPA",true,"","new","3","5");

            //            //Varma - Timezone Feature On&OFF functionality 
            //            int returnvalue = 0;

            //            if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
            //            {
            //                //Pranay 2nd January 2017---added parameter TimeZone 
            //                returnvalue = _presenter.MailBoxCreation(EmailBox, EmailAddrs, EmailAddrsOpt, MailFoldPath, Domain, UserId, EncryptConfirmPKeyword, CountryName, SubProcessId, SLA, Active, QcReq,IsApprovalRequired, MailTrigger, LoginId, EMailid, ReplyNotReq, IsVocSurvey, IsSkillBasedAllocation, IsLocked, TimeZone, OffSet, true);
            //            }
            //            else
            //            {
            //                returnvalue = _presenter.MailBoxCreation(EmailBox, EmailAddrs, EmailAddrsOpt, MailFoldPath, Domain, UserId, EncryptConfirmPKeyword, CountryName, SubProcessId, SLA, Active, QcReq,IsApprovalRequired, MailTrigger, LoginId, EMailid, ReplyNotReq, IsVocSurvey, IsSkillBasedAllocation, IsLocked, TimeZone, OffSet, false);
            //            }


            //            if (returnvalue == 0)//Failure message for Insert
            //            {
            //                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Mailbox Address already exists!');", true);
            //                txtEmailBoxAddrs.Focus();
            //            }
            //            if (returnvalue == 1)//Success message for Insert
            //            {
            //                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Mailbox Configuration is Successful!');", true);
            //                Clearfields();
            //                BindMailBoxDetGrid();
            //            }
            //        }
            //        else
            //        {
            //            string MailBoxId = hddnMBId.Value;
            //            //Varma - Timezone Feature On&OFF functionality 
            //            int returnvalue = 0;

            //            if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
            //            {
            //                //Pranay 2nd January 2017---added parameter TimeZone to method UpdateMailBoxDet
            //                returnvalue = _presenter.UpdateMailBoxDet(MailBoxId, EmailBox, EmailAddrs, EmailAddrsOpt, MailFoldPath, Domain, UserId, EncryptConfirmPKeyword, CountryName, SubProcessId, SLA, Active, QcReq,IsApprovalRequired, MailTrigger, LoginId, EMailid, ReplyNotReq, IsVocSurvey, IsSkillBasedAllocation, IsLocked, TimeZone, OffSet, true);
            //            }
            //            else
            //            {
            //                returnvalue = _presenter.UpdateMailBoxDet(MailBoxId, EmailBox, EmailAddrs, EmailAddrsOpt, MailFoldPath, Domain, UserId, EncryptConfirmPKeyword, CountryName, SubProcessId, SLA, Active, QcReq,IsApprovalRequired, MailTrigger, LoginId, EMailid, ReplyNotReq, IsVocSurvey, IsSkillBasedAllocation, IsLocked, TimeZone, OffSet, false);
            //            }

            //            if (returnvalue == 0)//Failure message for Update
            //            {
            //                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update Falied! Provided EmailBox Address already exists');", true);
            //            }
            //            else if (returnvalue == 1)//Success message for Update
            //            {
            //                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('EMailBox Details Updated successfully!');", true);
            //                Clearfields();
            //                BindMailBoxDetGrid();
            //                btnSubmit.Text = "Submit";
            //            }
            //            else //Alert message for duplicate Emailbox Address
            //            {
            //                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('EmailBox address should be unique. Given Address already exists!');", true);
            //                txtEmailBoxAddrs.Focus();
            //            }
            //        }
            //    }
            //    catch (Exception Ex)
            //    {
            //        new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | MailBoxCreation.cs | btnSubmit_Click()");
            //        Response.Clear();
            //        //errorlog.HandleError(Ex, UserDetails.UserId , " | MailBoxCreation.cs | btnSubmit_Click()");
            //        Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            //        Response.End();
            //    }
            //}
        }

        /// <summary>
        /// Clears the fields on the Clear button click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClear_Click(object sender, EventArgs e)
        {
            Clearfields();
        }


        /// <summary>
        /// To sort the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdMailBoxConfigure_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                GridViewSortExpression = e.SortExpression;
                int pageIndex = grdMailBoxConfigure.PageIndex;
                grdMailBoxConfigure.DataSource = SortDataTable(BindMailBoxDetGrid() as DataTable, false);
                grdMailBoxConfigure.DataBind();
                grdMailBoxConfigure.PageIndex = pageIndex;
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | MailBoxCreation.cs | grdMailBoxConfigure_Sorting()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | MailBoxCreation.cs | grdMailBoxConfigure_Sorting()");
                Response.Redirect("~/Errors/Error.aspx", false);
                Response.End();
            }
        }

        //protected void grdMailBoxConfigure_Command(object sender, GridViewCommandEventArgs e)
        //{
        //    if (e.CommandName.ToUpper() == "SORT")
        //    {
        //    }
        //    else if (e.CommandName.ToUpper() == "PAGE")
        //    {
        //    }
        //    else
        //    {
        //        int index = Convert.ToInt32(e.CommandArgument);
        //    }
        //}

        /// <summary>
        /// Row command to edit the values from the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        protected void grdMailBoxConfigure_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "EditMailBoxName")
                {
                    int RowIndex = Convert.ToInt32(e.CommandArgument);
                    string hiddenMailBoxId = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblId")).Text.ToString().Trim();
                    string MailBoxName = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblName")).Text.ToString().Trim();
                    string MailBoxAddress = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblAddress")).Text.ToString().Trim();
                    string MailBoxAddressOpt = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblAddressOpt")).Text.ToString().Trim();
                    //string FolderPath = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblFolderPath")).Text.ToString().Trim();
                    string CountryName = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblCountryName")).Text.ToString().Trim();
                    string SubProcName = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblSubProcess")).Text.ToString().Trim();
                    string SLAHrs = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblSLATime")).Text.ToString().Trim();
                    string Active = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblIsActive")).Text.ToString().Trim();
                    string QCreq = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblIsQCRequired")).Text.ToString().Trim();
                    string TriggerMail = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblTriggerMail")).Text.ToString().Trim();
                    string MailId = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lbleMailId")).Text.ToString().Trim();
                    string ReplyNotReqd = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblReplyNotRequired")).Text.ToString().Trim();
                    string Locked = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblLocked")).Text.ToString().Trim();
                    //Pranay 23rd January 2017
                    string VocSurvey = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblIsVocSurveyRequired")).Text.ToString().Trim();
                    string SkillBasedAllocation = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblIsSkillBasedAllocation")).Text.ToString().Trim();
                    string timezone = "";
                    string ApprovalRequired = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("lblIsApprovalRequired")).Text.ToString().Trim();

                    //Varma - Timezone Feature On&OFF functionality 
                    if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                    {
                        timezone = ((Label)grdMailBoxConfigure.Rows[RowIndex].FindControl("labelTimeZone")).Text.ToString().Trim();
                    }

                    hddnMBId.Value = hiddenMailBoxId;
                    txtEmailBoxName.Text = MailBoxName;
                    txtEmailBoxAddrs.Text = MailBoxAddress;
                    //Pranay 18 May 2017--Code Merge for selecting FROM mail id while sending emails from emt 
                    txtEmailBoxOpt.Text = MailBoxAddressOpt;
                    txtEMailFolderPath.Text = System.Configuration.ConfigurationManager.AppSettings.Get("ClientServiceURL");
                    ddlCntryName_SelectedIndexChanged(sender, e);
                    ddlCntryName.SelectedIndex = ddlCntryName.Items.IndexOf(ddlCntryName.Items.FindByText(CountryName));
                    trSubProcess.Visible = true;
                    lblSubProcessName.Visible = true;
                    ddlSubProcessName.Visible = true;
                    //BindSubProcessNames();
                    _presenter.GetSubProcessByCountryId(UserDetails.UserId, UserDetails.RoleId, Convert.ToInt32(ddlCntryName.SelectedValue));

                    ddlSubProcessName.SelectedIndex = ddlSubProcessName.Items.IndexOf(ddlSubProcessName.Items.FindByText(SubProcName));
                    ddlEmailBoxMailId.SelectedIndex = ddlEmailBoxMailId.Items.IndexOf(ddlEmailBoxMailId.Items.FindByText(MailId));

                    //Varma - Timezone Feature On&OFF functionality 
                    if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                    {
                        //Pranay 3rd January 2017 ---binding TimeZone on click in edit button
                        ddlTimeZone.SelectedIndex = ddlTimeZone.Items.IndexOf(ddlTimeZone.Items.FindByText(timezone));
                    }
                    txtSLAHrs.Text = SLAHrs;
                    if (Active == "Yes")
                    {
                        chkMBoxActive.Checked = true;
                    }
                    else
                    {
                        chkMBoxActive.Checked = false;
                    }
                    //Pranay 23rd January 2017
                    if (VocSurvey == "Yes")
                    {
                        chkIsVocSurveyReq.Checked = true;
                    }
                    else
                    {
                        chkIsVocSurveyReq.Checked = false;
                    }
                    //saranya
                    if (SkillBasedAllocation == "Yes")
                    {
                        chkSkillBasedAllocREQ.Checked = true;
                    }
                    else
                    {
                        chkSkillBasedAllocREQ.Checked = false;
                    }

                    //approval workflow

                    if (ApprovalRequired == "Yes")
                    {
                        chkApprovalRequired.Checked = true;
                    }
                    else
                    {
                        chkApprovalRequired.Checked = false;
                    }

                    if (QCreq == "Yes")
                    {
                        chkQCRequired.Checked = true;
                    }
                    else
                    {
                        chkQCRequired.Checked = false;
                    }

                    if (TriggerMail == "Yes")
                    {
                        chkMailTrig.Checked = true;
                    }
                    else
                    {
                        chkMailTrig.Checked = false;
                    }

                    if (ReplyNotReqd == "Yes")
                    {
                        chkReplyNotReq.Checked = true;
                        chkQCRequired.Checked = false;
                        chkQCRequired.Enabled = false;
                        chkMailTrig.Checked = false;
                        chkMailTrig.Enabled = false;
                    }
                    else
                    {
                        chkReplyNotReq.Checked = false;
                        chkQCRequired.Enabled = true;
                        chkMailTrig.Enabled = true;
                        if (chkMailTrig.Checked == true)
                        {
                            MailTrigger = 1;
                        }
                        else
                        {
                            MailTrigger = 0;
                        }
                        if (chkQCRequired.Checked == true)
                        {
                            QcReq = 1;
                        }
                        else
                        {
                            QcReq = 0;
                        }
                    }

                    //if (ReplyNotReqd == "Yes")
                    //{
                    //    chkReplyNotReq.Checked = true;
                    //}
                    //else
                    //{
                    //    chkMailTrig.Checked = false;
                    //}

                    if (Locked == "Yes")
                    {
                        chkLocked.Checked = true;
                    }
                    else
                    {
                        chkLocked.Checked = false;
                    }

                    grdMailBoxConfigure.EditIndex = -1;
                    btnSubmit.Text = "Update";
                    btnSubmit.ValidationGroup = "Submit";
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | MailBoxCreation.cs | grdMailBoxConfigure_RowCommand()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId , " | MailBoxCreation.cs | grdMailBoxConfigure_RowCommand()");
                Response.Redirect("~/Errors/Error.aspx", false);
                Response.End();
            }
        }

        /// <summary>
        /// To change the page of the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdMailBoxConfigure_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdMailBoxConfigure.DataSource = SortDataTable(BindMailBoxDetGrid() as DataTable, true);
                grdMailBoxConfigure.PageIndex = e.NewPageIndex;
                grdMailBoxConfigure.DataBind();
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | MailBoxCreation.cs | grdMailBoxConfigure_PageIndexChanging()");
                Response.Clear();
                //errorlog.HandleError(ex, UserDetails.UserId , " | MailBoxCreation.cs | grdMailBoxConfigure_PageIndexChanging()");
                Response.Redirect("~/Errors/Error.aspx", false);
                Response.End();
            }
        }
        protected void chkReplyNotReq_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkReplyNotReq.Checked == true)
                {
                    ReplyNotReq = 1;
                    chkQCRequired.Checked = false;
                    chkQCRequired.Enabled = false;
                    chkMailTrig.Checked = false;
                    chkMailTrig.Enabled = false;
                }
                else
                {
                    ReplyNotReq = 0;
                    chkQCRequired.Enabled = true;
                    chkMailTrig.Enabled = true;
                    chkQCRequired.Checked = true;
                    chkMailTrig.Checked = true;

                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | MailBoxCreation.cs | chkReplyNotReq_CheckedChanged()");
                Response.Clear();
                //errorlog.HandleError(ex, UserDetails.UserId , " | MailBoxCreation.cs | chkReplyNotReq_CheckedChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        DataSet IMailBoxCreationView.BindSubProcessByCountryId
        {
            set
            {
                if (value != null && value.Tables.Count > 0 && value.Tables[0].Rows.Count > 0)
                {
                    ddlSubProcessName.DataSource = value;
                    ddlSubProcessName.DataTextField = "SubProcessGroupName";
                    ddlSubProcessName.DataValueField = "SubProcessGroupId";
                    ddlSubProcessName.DataBind();
                    ddlSubProcessName.Items.Insert(0, new ListItem("--Select--", "0"));
                }
            }
        }



        protected void ddlCntryName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                _presenter.GetSubProcessByCountryId(UserDetails.UserId, UserDetails.RoleId, Convert.ToInt32(ddlCntryName.SelectedValue));

                //if (ddlCntryName.SelectedIndex != 0)
                if (!ddlCntryName.SelectedItem.Text.Contains("select"))
                {
                    trSubProcess.Visible = true;
                    lblSubProcessName.Visible = true;
                    ddlSubProcessName.Visible = true;
                }
                else
                {
                    trSubProcess.Visible = false;
                    lblSubProcessName.Visible = false;
                    ddlSubProcessName.Visible = false;
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | MailBoxCreation.cs | ddlCntryName_SelectedIndexChanged()");
                Response.Clear();
                //errorlog.HandleError(ex, UserDetails.UserId , " | MailBoxCreation.cs | ddlCntryName_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }

        }
        #endregion

        //Varma - Timezone Feature On&OFF functionality 
        protected void grdMailBoxConfigure_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                //Varma - Timezone Feature On&OFF functionality 
                if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                {
                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        DataSet ds = new DataSet();
                        ds = (DataSet)ViewState["MailBoxName"];

                        if (ds != null)
                        {
                            DataTable dt = ds.Tables[0];

                            if (dt.Columns["TimeZone"] != null)
                            {
                                grdMailBoxConfigure.Columns[14].Visible = true;

                                Label labelTimeZone = (Label)e.Row.FindControl("labelTimeZone");

                                if (labelTimeZone != null)
                                {
                                    labelTimeZone.Text = dt.Rows[e.Row.RowIndex]["TimeZone"].ToString();
                                }
                            }
                        }
                    }
                }
                else
                {
                    grdMailBoxConfigure.Columns[14].Visible = false;
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | MailBoxCreation.cs | grdMailBoxConfigure_RowDataBound()");

                Response.Clear(); Response.Redirect("~/Errors/Error.aspx", false);
            }
        }

        public void CreateTenant(string tenantName, string userId, string effectivefromdate, string effectiveTodate, string InstanceName, string DBServerName, string DBUserName, string DBPassword, string Vertical, string Account, bool SameURL, string customUrl, string OperationName, string UserCount, string MaxNoOfUser)
        {
            //ProxyLogger.Log.Info("TenantController - CreateTenant - Called.");
            string message = string.Empty;
            DigiOPS.TechFoundation.Entities.TenantInfo objmtoup = new DigiOPS.TechFoundation.Entities.TenantInfo();
            // MultiTenantOutput objmtoup = new MultiTenantOutput();
            // MultiTenant objMultiTenancy = new MultiTenant();
            // MultiTenancyInfo objinfo = new MultiTenancyInfo();
            try
            {
                Tenant objMultiTenancy = new Tenant();
                DigiOPS.TechFoundation.Entities.TenantInfo objinfo = new DigiOPS.TechFoundation.Entities.TenantInfo();

                //objinfo.AppID = "1";

                objinfo.DatabaseDetails.ServerName = DBServerName;
                objinfo.DatabaseDetails.DataBaseName = InstanceName;
                objinfo.DatabaseDetails.UserName = DBUserName;
                objinfo.DatabaseDetails.Password = DBPassword;

                objinfo.AppID = ConfigurationManager.AppSettings["AppID"].ToString();
                objinfo.TenantName = tenantName;
                //objinfo.TenantID = Convert.ToInt32(userId);
                objinfo.TenantDetails = new List<DigiOPS.TechFoundation.Entities.TenantInstanceInfo>();
                DigiOPS.TechFoundation.Entities.TenantInstanceInfo objtenat = new DigiOPS.TechFoundation.Entities.TenantInstanceInfo();

                objtenat.TenantUserID = Convert.ToInt32(userId);
                objtenat.InstanceName = InstanceName;// "INST1";
                objtenat.URL = customUrl;
                objtenat.SameURL = SameURL;
                ProductLicenseKey objProductLicenseKey = new ProductLicenseKey();
                LicenseInfo objlinfo = new LicenseInfo();
                LicenseInfo objoutlicinfo = new LicenseInfo();
                objlinfo.MaxNoOfUser = Convert.ToInt32(MaxNoOfUser);
                objlinfo.ToolPurchased = "";
                objlinfo.DateOfPurchase = Convert.ToString(DateTime.Now);
                objlinfo.Version = "1.0";
                objlinfo.InstanceID = InstanceName;
                objlinfo.UserCount = Convert.ToInt32(UserCount);
                //ProxyLogger.Log.Info("TenantController - CreateTenant - Called.");
                objoutlicinfo = objProductLicenseKey.GenerateProductKey(objlinfo);
                if (Convert.ToString(objoutlicinfo.ErrorMessage) != null)
                    objtenat.LicenseKey = objoutlicinfo.EncryptedProductKey;
                else
                    objtenat.LicenseKey = null;

                // objtenat.LicenseKey = objProductLicenseKey.GenerateProductKey(objlinfo);
                // objtenat.LicenseKey = "ABC";
                objtenat.EffectiveFrom = Convert.ToDateTime(effectivefromdate);
                objtenat.EffectiveTo = Convert.ToDateTime(effectiveTodate);
                objtenat.Vertical = Convert.ToInt32(Vertical);
                objtenat.AccountId = Convert.ToInt32(Account);
                objinfo.TenantDetails.Add(objtenat);
                objinfo.OperationName = OperationName;


                //objinfo.AppID = "";
                //objinfo.ServerName = DBServerName;
                //objinfo.DataBaseName = InstanceName;
                //objinfo.UserName = DBUserName;
                //objinfo.Password = DBPassword;

                //objinfo.InstanceName = InstanceName;// "INST1";
                //objinfo.TenantName = tenantName;
                //objinfo.TenantUserID = Convert.ToInt32(userId);
                //objinfo.URL = customUrl;
                //objinfo.SameURL = SameURL;
                //ProductLicenseKey objProductLicenseKey = new ProductLicenseKey();
                //LicenseInfo objlinfo = new LicenseInfo();
                //objlinfo.MaxNoOfUser = Convert.ToInt32(MaxNoOfUser);
                //objlinfo.ToolPurchased = "";
                //objlinfo.DateOfPurchase = Convert.ToString(DateTime.Now);
                //objlinfo.Version = "1.0";
                //objlinfo.InstanceID = InstanceName;
                //objlinfo.UserCount = Convert.ToInt32(UserCount);
                //objinfo.LicenseKey = objProductLicenseKey.GenerateProductKey(objlinfo);
                //objinfo.EffectiveFrom = Convert.ToDateTime(effectivefromdate);
                //objinfo.EffectiveTo = Convert.ToDateTime(effectiveTodate);
                //objinfo.Vertical = Convert.ToInt32(Vertical);
                //objinfo.AccountId = Convert.ToInt32(Account);
                //objinfo.OperationName = OperationName;

                ////objmtoup = objMultiTenancy.SaveTenantDetails(objinfo);

                //if (OperationName == "INSERT")
                //{

                //    string PSScriptPath = ConfigurationManager.AppSettings["PSScript"].ToString();
                //    string SQLScriptPath = ConfigurationManager.AppSettings["SQLScript"].ToString();
                //    objinfo.PSScriptPath = PSScriptPath;
                //    //objMultiTenancyInfo.PSScriptPath = PSScriptPath;
                //    objinfo.SQLScriptPath = SQLScriptPath;
                //    //objMultiTenancyInfo.SQLScriptPath = SQLScriptPath;
                //    objmtoup = objMultiTenancy.GenerateDataBase(objinfo);
                //    if (objmtoup.ResultStatus == false)
                //    {
                //        // message = objmtoup.Output.ToString();
                //    }
                //}
                //else
                //{
                //    objinfo.TenantDBID = Convert.ToInt32(tenantName);
                //}

                //objmtoup = objMultiTenancy.SaveTenantDetails(objinfo);
                //if (objmtoup.ResultStatus == false)
                //{
                //    message = objmtoup.Output.ToString();
                //}
                //else
                //{
                //    message = "Tenant created successfully!";
                //}


                if (OperationName == "INSERT")
                {
                    string PSScriptPath = ConfigurationManager.AppSettings["PSScript"].ToString();
                    string SQLScriptPath = ConfigurationManager.AppSettings["SQLScript"].ToString();
                    objinfo.DatabaseDetails.PSScriptPath = PSScriptPath;
                    //objMultiTenancyInfo.PSScriptPath = PSScriptPath;
                    objinfo.DatabaseDetails.SQLScriptPath = SQLScriptPath;
                    //objMultiTenancyInfo.SQLScriptPath = SQLScriptPath;
                    objmtoup = objMultiTenancy.GenerateDataBase(objinfo); //to generatedb
                    if (objmtoup.ResultStatus == true)
                    {
                        message = objmtoup.Output;
                        objmtoup = objMultiTenancy.SaveTenantDetails(objinfo);//to save tenant info in tool tenant db

                    }
                    else
                    {
                        message = objmtoup.Output.ToString();
                    }
                }
                else
                {
                    objinfo.TenantID = Convert.ToInt32(tenantName);
                    objmtoup = objMultiTenancy.SaveTenantDetails(objinfo);

                    message = objmtoup.Output.ToString();

                }
                //if (string.IsNullOrEmpty(message) || message == "Incorrect syntax near '?'.")
                //{

                //}

            }
            catch (ApplicationException ex)
            {
                //ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
                //objmtoup.Output = Utility.Constants.mSG_Tnt_InsertionFailed;
            }
            catch (Exception ex)
            {
                //ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
                //objmtoup.Output = Utility.Constants.mSG_Tnt_InsertionFailed;
            }

            //return Json(new { message }, JsonRequestBehavior.AllowGet);
        }
    }

}