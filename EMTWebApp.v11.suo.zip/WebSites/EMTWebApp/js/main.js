/// <reference path="../Common/DashBoard.aspx" />
/// <reference path="../Common/DashBoard.aspx" />
/// <reference path="../Common/content/PieChart.aspx" />
//var tempArray = [];
//var collapsableMenuString = "";
//var firstLevel = [];
//var secondLevel = [];
var countryName;
var mailBoxName;
var subProcessName;
var statusName;
var classificationName;
var leftnavigation_classification;
var pgindex;
var pageSize;
var pageCount;
var sortExpName = 'ReceivedDate';
var sortExpOrder = 'desc';

var SelectedProcess;
var Selected
var fnameValue;
var roleName;
var roleID;
var roleid;
var UID;
var selectedMenuItem;
var selectedMenuText;
var AD;

$("document").ready(function () {

    //setInterval('AutoRefresh();', 10000); // refresh div after 15 secs

    // debugger;		
    //var sPageURL = window.location.search.substring(1);		
    //var sQueryString=sPageURL.split('=');		    
    selectedMenuItem = getUrlVars()["selectedMenu"];
    selectedMenuText = getUrlVars()["SelectionText"];
    if (selectedMenuText != null && selectedMenuText != undefined && selectedMenuText != '') {
        var sQueryString = selectedMenuText.split('~');
        countryName = sQueryString[0];
        mailBoxName = sQueryString[2];
        subProcessName = sQueryString[1];
        statusName = sQueryString[4];

        if (statusName != undefined) {
            classificationName = sQueryString[3];
        }
        else {
            classificationName = "";
            statusName = sQueryString[3];

        }
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
    }
    //if (selectedMenuItem != null && selectedMenuItem != undefined && selectedMenuItem != '') {		
    //}

    AutoRefresh();

    //var selectUserID;
    //var webmethod = "../EMTSrv.asmx/EmailboxNames";
    //if (UID == undefined || UID == null) {
    //    UID = $('#UID').prop('value');//$('#fname').prop();
    //    roleID = $('#roleID').prop('value');

    //    if (roleID == 4) {
    //        selectUserID = UID;
    //    }
    //    else {
    //        selectUserID = 0;
    //    }

    //}
    //var params = { CountryId: 1, LoggedInUserId: UID, RoleId: roleID, SelectedAssociateId: selectUserID, SelectedSubProcessId: '0' };
    //$.ajax({
    //    type: "POST",
    //    url: webmethod,
    //    data: JSON.stringify(params),
    //    contentType: "application/json; charset=utf-8",
    //    dataType: "json",
    //    async: false,
    //    success: function (resultData) {
    //        var collapsbleMenu = resultData.d;
    //        traverseCollapsibleList(jQuery.parseJSON(collapsbleMenu));
    //    },
    //    error: function (error) {
    //        var data = error;
    //    }
    //});

    //debugger;

    if (fnameValue == undefined || fnameValue == null) {
        fnameValue = $('#fname').prop('value');//$('#fname').prop();
        roleName = $('#role').prop('value');//$('#role').val();
        ADLogin = document.getElementById("ISAD").value;
        //if (roleName == "Team Lead") {
        //    roleName = "[TL]";
        //}
        //else if (roleName == "Admin") {
        //    roleName = "[A]";
        //}
        //else if (roleName == "Super Admin") {
        //    roleName = "[SA]";
        //}
        //else if (roleName == "Processor") {
        //    roleName = "[P]";
        //}
        //else if (roleName == "Client User") {
        //    roleName = "[CU]";
        //}


        var dataparam = {};
        dataparam['roleName'] = roleName;
        var webmethod = "../EMTSrv.asmx/getRoleID";
        $.ajax({
            type: "POST",
            url: webmethod,
            data: JSON.stringify(dataparam),
            contentType: "application/json; charset=utf-8",
            dataType: 'json',
            async: false,
            success: function (result) {
                //roleid = result.d
                //roleID = roleid;
                var array = result.d.split("~");
                $("#roleID").val(array[0]);
                $("#role").val(array[1]);
                roleid = array[0];
                roleID = array[0];
            },
            error: OnError
        });

        function OnError(result) {
            alert("error");
        }

        var roledes = [];
        roledes = roleName.split(" ");
        roleName = $.map(roledes, function (val, index) {
            var str = val.charAt(0);
            return str;
        }).join("");
    }
    ///   alert(fname);
    $('#Span1').text(fnameValue + " [" + roleName + "]");

    //creating top navigation links
    //debugger;
    var navItems;

    var role = null
    if (UID == undefined || UID == null) {
        UID = $('#UID').prop('value');
    }
    var dataparam = {};
    dataparam['UserID'] = UID;
    dataparam['RoleID'] = roleid;
    var webmethod = "../EMTSrv.asmx/GetACLMenu";

    $.ajax({
        type: "POST",
        url: webmethod,
        data: JSON.stringify(dataparam),
        contentType: "application/json; charset=utf-8",
        dataType: 'json',
        async: false,
        success: function (result) {
            //window.location.replace("../Common/DashBoard.aspx");
            navItems = $.parseJSON(result.d);
            //alert(navItems);
        },
        error: OnError
    });

    function OnError(result) {
        alert("error");
    }

    // var CheckWhichLoginType;
    // CheckWhichLoginType = document.getElementById("AD").value;
    //if (roleName == "SA") {
    //    navItems = [{
    //        "parent": "Dashboard",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": []
    //    }, {
    //        "parent": "User Management",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": [{
    //            "title": "Create User",
    //            "url": "../UserManagement/CreateUser.aspx"
    //        }, {
    //            "title": "User Role Mapping",
    //            "url": "../UserManagement/UserMapping.aspx"
    //        }, {
    //            "title": "User Mailbox Mapping",
    //            "url": "../UserManagement/UserMailBoxMapping.aspx"
    //        }, {
    //            "title": "Change Password",
    //            "url": "../UserManagement/ChangePassword.aspx"
    //        }]
    //    }, {
    //        "parent": "Configuration",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": [{
    //            "title": "Mail Template Configuration",
    //            "url": "../UserManagement/Remaindermailboxconfigure.aspx"
    //        }, {
    //            "title": "Category Configuration",
    //            "url": "../UserManagement/CategoryConfiguration.aspx"
    //        }, {
    //            "title": "Field Configuration",
    //            "url": "../UserManagement/FieldConfiguration.aspx"
    //        }, {
    //            "title": "Flag Configuration",
    //            "url": "../UserManagement/ReferenceConfiguration.aspx"
    //        }]
    //    }, {
    //        "parent": "Client Configuration",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": [{
    //            "title": "SubProcess",
    //            "url": "../Configuration/SubProcess.aspx"
    //        }, {
    //            "title": "Mailbox Login Details",
    //            "url": "../UserManagement/EMailBoxLoginDetails.aspx"
    //        }, {
    //            "title": "Mailbox",
    //            "url": "../Configuration/MailBoxCreation.aspx"
    //        }]
    //    },
    //    {
    //        "parent": "Search",
    //        "url": "../Search/Search.aspx",
    //        "child": []
    //    }, {
    //        "parent": "Reports",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": [{
    //            "title": "TAT",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=1"
    //        }, {
    //            "title": "TAT SplitUp",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=2"
    //        }, {
    //            "title": "Ageing",
    //            "url": "../Reports/Ageing.aspx"
    //        }, {
    //            "title": "Productivity",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=3"
    //        }, {
    //            "title": "OverAll",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=4"
    //        }, {
    //            "title": "Clarification Sent",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=5"
    //        }, {
    //            "title": "Clarification with Ageing",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=6"
    //        }
    //        ]
    //    }//, {
    //    //    "parent": "Change Role",
    //    //    "url": "../AuthenticationandAuthorization/ChooseRole.aspx",
    //    //    "child": []
    //    //}
    //    ];
    //}
    //else if (roleName == "A") {
    //    navItems = [{
    //        "parent": "Dashboard",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": []
    //    }, {
    //        "parent": "User Management",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": [{
    //            "title": "Create User",
    //            "url": "../UserManagement/CreateUser.aspx"
    //        }, {
    //            "title": "User Role Mapping",
    //            "url": "../UserManagement/UserMapping.aspx"
    //        }, {
    //            "title": "User Mailbox Mapping",
    //            "url": "../UserManagement/UserMailBoxMapping.aspx"
    //        }, {
    //            "title": "Change Password",
    //            "url": "../UserManagement/ChangePassword.aspx"
    //        }]
    //    }, {
    //        "parent": "Configuration",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": [{
    //            "title": "Mail Template Configuration",
    //            "url": "../UserManagement/Remaindermailboxconfigure.aspx"
    //        }, {
    //            "title": "Category Configuration",
    //            "url": "../UserManagement/CategoryConfiguration.aspx"
    //        }, {
    //            "title": "Field Configuration",
    //            "url": "../UserManagement/FieldConfiguration.aspx"
    //        }, {
    //            "title": "Flag Configuration",
    //            "url": "../UserManagement/ReferenceConfiguration.aspx"
    //        }]
    //    },
    //    {
    //        "parent": "Search",
    //        "url": "../Search/Search.aspx",
    //        "child": []
    //    }, {
    //        "parent": "Reports",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": [{
    //            "title": "TAT",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=1"
    //        }, {
    //            "title": "TAT SplitUp",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=2"
    //        }, {
    //            "title": "Ageing",
    //            "url": "../Reports/Ageing.aspx"
    //        }, {
    //            "title": "Productivity",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=3"
    //        }, {
    //            "title": "OverAll",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=4"
    //        }, {
    //            "title": "Clarification Sent",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=5"
    //        }, {
    //            "title": "Clarification with Ageing",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=6"
    //        }
    //        ]
    //    }
    //        //, {
    //    //    "parent": "Change Role",
    //    //    "url": "../AuthenticationandAuthorization/ChooseRole.aspx",
    //    //    "child": []
    //        //}
    //    ];
    //}
    //else if (roleName == "TL") {
    //    navItems = [{
    //        "parent": "Dashboard",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": []
    //    }, {
    //        "parent": "User Management",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": [{
    //            "title": "Create User",
    //            "url": "../UserManagement/CreateUser.aspx"
    //        }, {
    //            "title": "User Role Mapping",
    //            "url": "../UserManagement/UserMapping.aspx"
    //        }, {
    //            "title": "User Mailbox Mapping",
    //            "url": "../UserManagement/UserMailBoxMapping.aspx"
    //        }, {
    //            "title": "Change Password",
    //            "url": "../UserManagement/ChangePassword.aspx"
    //        }, {
    //            "title": "Change Signature",
    //            "url": "../UserManagement/Signature.aspx"
    //        }]
    //    }, {
    //        "parent": "Manual Case Creation",
    //        "url": "../Common/ManualCaseCreationNewUI.aspx",
    //        "child": []
    //    }, {
    //        "parent": "Quality Check",
    //        "url": "../Common/QCWorkQueue.aspx",
    //        "child": []
    //    },
    //    {
    //        "parent": "Search",
    //        "url": "../Search/Search.aspx",
    //        "child": []
    //    }, {
    //        "parent": "Reports",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": [{
    //            "title": "TAT",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=1"
    //        }, {
    //            "title": "TAT SplitUp",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=2"
    //        }, {
    //            "title": "Ageing",
    //            "url": "../Reports/Ageing.aspx"
    //        }, {
    //            "title": "Productivity",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=3"
    //        }, {
    //            "title": "OverAll",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=4"
    //        }, {
    //            "title": "Clarification Sent",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=5"
    //        }, {
    //            "title": "Clarification with Ageing",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=6"
    //        }
    //        ]
    //    }
    //    //, {
    //    //    "parent": "Change Role",
    //    //    "url": "../AuthenticationandAuthorization/ChooseRole.aspx",
    //    //    "child": []
    //    //}
    //    ];
    //}
    //else if (roleName == "P") {
    //    navItems = [{
    //        "parent": "Dashboard",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": []
    //    }, {
    //        "parent": "Manual Case Creation",
    //        "url": "../Common/ManualCaseCreationNewUI.aspx",
    //        "child": []
    //    }, {
    //        "parent": "Quality Check",
    //        "url": "../Common/QCWorkQueue.aspx",
    //        "child": []
    //    }, {
    //        "parent": "User Management",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": [{
    //            "title": "Change Password",
    //            "url": "../UserManagement/ChangePassword.aspx"
    //        }, {
    //            "title": "Change Signature",
    //            "url": "../UserManagement/Signature.aspx"
    //        }]
    //    },
    //    {
    //        "parent": "Search",
    //        "url": "../Search/Search.aspx",
    //        "child": []
    //    }
    //    //, {
    //    //    "parent": "Change Role",
    //    //    "url": "../AuthenticationandAuthorization/ChooseRole.aspx",
    //    //    "child": []
    //    //}
    //    ];
    //}
    //else if (roleName == "CU") {
    //    navItems = [{
    //        "parent": "Dashboard",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": []
    //    }, {
    //        "parent": "User Management",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": [{
    //            "title": "Change Password",
    //            "url": "../UserManagement/ChangePassword.aspx"
    //        }]
    //    },
    //    {
    //        "parent": "Search",
    //        "url": "../Search/Search.aspx",
    //        "child": []
    //    }, {
    //        "parent": "Reports",
    //        "url": "../Common/DashBoard.aspx",
    //        "child": [{
    //            "title": "TAT",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=1"
    //        }, {
    //            "title": "TAT SplitUp",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=2"
    //        }, {
    //            "title": "Ageing",
    //            "url": "../Reports/Ageing.aspx"
    //        }, {
    //            "title": "Productivity",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=3"
    //        }, {
    //            "title": "OverAll",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=4"
    //        }, {
    //            "title": "Clarification Sent",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=5"
    //        }, {
    //            "title": "Clarification with Ageing",
    //            "url": "../Reports/TATSplitUp.aspx?ReportType=6"
    //        }
    //        ]
    //    }
    //    //, {
    //    //    "parent": "Change Role",
    //    //    "url": "../AuthenticationandAuthorization/ChooseRole.aspx",
    //    //    "child": []
    //    //}
    //    ];
    //}

    var role = null
    if (UID == undefined || UID == null) {
        UID = $('#UID').prop('value');
    }
    var dataparam = {};
    dataparam['UserId'] = UID;
    var webmethod = "../EMTSrv.asmx/RoleNamesList";
    $.ajax({
        type: "POST",
        url: webmethod,
        data: JSON.stringify(dataparam),
        contentType: "application/json; charset=utf-8",
        dataType: 'json',
        async: false,
        success: function (result) {
            role = result.d
        },
        error: OnError
    });

    function OnError(result) {
        alert("error");
    }
    // debugger;
    var ISAD = $('#ISAD').val();
    //alert(fname);

    createTopNavPanel(navItems);

    function createTopNavPanel(navJson) {
        var a = null;
        var parent = null;
        var nav = $("#nav");
        $.each(navJson, function (index, element) {
            if (element.ChildMenu.length > 0) {
                if (element.ParentURL != "") {
                    if (element.PageName == $("#hdnCurrentPage").val()) {
                        nav.append('<li class="pNav ' + element.AccessMode + ' id="p_nav_' + index + '" ><a class="clkpNav selected" id="ap_nav_' + index + '" href = "' + element.ParentURL + '">' + element.PageName + '</a><ul class="pUL" id="p_UL_' + index + '">');
                    }
                    else {
                        nav.append('<li class="pNav ' + element.AccessMode + ' id="p_nav_' + index + '" ><a class="clkpNav" id="ap_nav_' + index + '" href = "' + element.ParentURL + '">' + element.PageName + '</a><ul class="pUL" id="p_UL_' + index + '">');
                    }
                }
                else {
                    if (element.PageName == $("#hdnCurrentPage").val()) {
                        nav.append('<li class="pNav" id="p_nav_' + index + '" ><a class="clkpNav selected" id="ap_nav_' + index + '" href = "javascript:void(0);">' + element.PageName + '</a><ul class="pUL" id="p_UL_' + index + '">');
                    }
                    else {
                        nav.append('<li class="pNav" id="p_nav_' + index + '" ><a class="clkpNav" id="ap_nav_' + index + '" href = "javascript:void(0);">' + element.PageName + '</a><ul class="pUL" id="p_UL_' + index + '">');
                    }
                }
                var parent = $("#p_UL_" + index);
                $.each(element.ChildMenu, function (idx, childEle) {

                    if (ADLogin == "Yes" && childEle.url == "../UserManagement/ChangePassword.aspx") {

                        parent.append('<li class="cNav" id="c_nav_' + index + '_' + idx + '" ><a class="clkcNav" id="ac_nav_' + index + '_' + idx + '"  href="#" onClick="UrlOpen();">' + childEle.ChildPageName + '</a></li>');
                    }
                    else {
                        parent.append('<li class="cNav" id="c_nav_' + index + '_' + idx + '" ><a class="clkcNav" id="ac_nav_' + index + '_' + idx + '"  href="' + childEle.ChildurlURL + '">' + childEle.ChildPageName + '</a></li>');
                    }
                });
                nav.append('</ul></li>');
            } else {
                if (element.ParentURL != "") {
                    if (element.PageName == $("#hdnCurrentPage").val()) {

                        nav.append('<li class="pNav ' + element.AccessMode + '" id="p_nav_' + index + '" ><a class="clkpNav selected" id="ap_nav_' + index + '" href = "' + element.ParentURL + '">' + element.PageName + '</a>');
                    }
                    else {
                        nav.append('<li class="pNav ' + element.AccessMode + '" id="p_nav_' + index + '" ><a class="clkpNav" id="ap_nav_' + index + '" href = "' + element.ParentURL + '">' + element.PageName + '</a>');
                    }
                }
                else {
                    if (element.PageName == $("#hdnCurrentPage").val()) {

                        nav.append('<li class="pNav ' + element.AccessMode + '" id="p_nav_' + index + '" ><a class="clkpNav selected" id="ap_nav_' + index + '">' + element.PageName + '</a>');
                    }
                    else {
                        nav.append('<li class="pNav ' + element.AccessMode + '" id="p_nav_' + index + '" ><a class="clkpNav" id="ap_nav_' + index + '">' + element.PageName + '</a>');
                    }
                }
            }
            a = index;
        });

        a = a + 1;
        nav.append('<li class="pNav" id="p_nav_' + a + '" ><a class="clkpNav" id="ap_nav_' + a + '" href = "javascript:void(0);">' + "Change Role" + '</a><ul class="pUL" id="p_UL_' + a + '">');
        parent = $("#p_UL_" + a);
        if (role.length > 0) {
            $.each(role, function (idx, childEle) {

                parent.append('<li class="cNav" id="c_nav_' + a + '_' + idx + '" ><a class="clkcNav" id="ac_nav_' + a + '_' + idx + '"  href="' + "../Common/DashBoard.aspx" + '">' + childEle.RoleDescription + '</a></li>');

                $('#roleID').val(childEle.RoleId);
                //$('ac_nav_' + a + '_' + idx).addClass(childEle.RoleId);
            })
            nav.append('</ul></li>');
        }

        if (roleName == "[A]") {
            $('#ap_nav_3').css('background', 'url("../img/search_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_4').css('background', 'url("../img/report_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_5').css('background', 'url("../img/change_role_icon.png") no-repeat scroll 10px center transparent');
        }
        else if (roleName == "[P]") {

            $('#ap_nav_1').css('background', 'url("../img/config_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_2').css('background', 'url("../img/client_config.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_3').css('background', 'url("../img/user_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_4').css('background', 'url("../img/search_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_5').css('background', 'url("../img/change_role_icon.png") no-repeat scroll 10px center transparent');
        }
        else if (roleName == "[CU]") {
            $('#ap_nav_2').css('background', 'url("../img/search_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_3').css('background', 'url("../img/report_icon.png") no-repeat scroll 10px center transparent');
            $('#ap_nav_4').css('background', 'url("../img/change_role_icon.png") no-repeat scroll 10px center transparent')
        }
    }

    countryName = $('#c_ap_nav_0').text();
    subProcessName = $('#c_ac_nav_0_0').text();

    //$("#aside").load("./content/piechart.html");
    //$("#aside").load("./content/PieChart.aspx");
    //debugger;
    //breadcrumbs navigation    
    if (leftnavigation_classification == 1) {
        if (sQueryString != '' && sQueryString != undefined && sQueryString != null) {
            if (sQueryString.length == 2 || sQueryString.length == 3) {
                $('#frameMain').attr('src', './content/PieChart.aspx');
            }
            else {
                $('#frameMain').attr('src', './content/Inbox.aspx');
            }
        }
        else {
            $('#frameMain').attr('src', './content/PieChart.aspx');
        }

    }
    else {
        if (sQueryString != '' && sQueryString != undefined && sQueryString != null) {
            if (sQueryString.length != 2) {
                //        $('#frameMain').attr('src', './content/PieChart.aspx');
                //    }
                //    else
                //    {
                $('#frameMain').attr('src', './content/Inbox.aspx');
                //}
            }
            else {
                $('#frameMain').attr('src', './content/PieChart.aspx');
            }
        }
        else {
            $('#frameMain').attr('src', './content/PieChart.aspx');
        }
    }

    $("#ap_nav_0").addClass("selected");

    /*top Nav ele events*/
    $(".clkpNav").click(function () {
        if ($(this).hasClass("selected")) {
            // return false;
        }
        if ($(this).attr("id") === "ap_nav_0") {
            //$("#aside").load("./content/piechart.html");
            //$("#aside").load("./content/PieChart.aspx");
            $('#frameMain').attr('src', './content/PieChart.aspx');
            $("#collapsableNav,#aside").show();
            $("#underConstruction").hide();

        } else {
            $("#collapsableNav,#aside").hide();
            $("#underConstruction").show();
        }

        $(".clkpNav").removeClass("selected");
        $(this).addClass("selected");
    });

    //$("#changeRole").click(function () {
    //    $("#collapsableNav,#aside,#underConstruction").hide();
    //    $("#chooseRole").load("./content/chooseRole.html");
    //    $("#chooseRole").show();
    //});
    /*top Nav ele events*/

    //LeftMenuClicks();


    ///OnUserRoleSelection    
    $(".clkcNav").click(function () {
        var roleName = $(this).text();
        if ($(this).attr('href') == "../Common/DashBoard.aspx") {


            //var roleid = document.getElementById("#roleID").value;
            //var roleid;
            var roleName = $(this).text();

            //var dataparam = {};
            //dataparam['RoleName'] = roleName;
            //var webmethod = "../EMTSrv.asmx/getRoleID";
            //$.ajax({
            //    type: "POST",
            //    url: webmethod,
            //    data: JSON.stringify(dataparam),
            //    contentType: "application/json; charset=utf-8",
            //    dataType: 'json',
            //    async: false,
            //    success: function (result) {
            //        roleid = result.d
            //    },
            //    error: OnError
            //});


            //var RoleNo = [];
            //RoleNo = $(this).attr('class').split(" ");
            //roleid = RoleNo[1];
            //RoleNo = RoleNo[0].split(" ");
            //roleName = $.map(roleName, function (val, index) {
            //    var str = val.charAt(0);
            //    return str;
            //}).join("");

            //if (roleName == 'Super Admin') {
            //    roleid = 1;
            //}
            //else if (roleName == 'Admin') {
            //    roleid = 2;
            //}
            //else if (roleName == 'Team Lead') {
            //    roleid = 3;
            //}
            //else if (roleName == 'Processor') {
            //    roleid = 4;
            //}
            //else if (roleName == 'Client User') {
            //    roleid = 5;
            //}

            var dataparam = {};
            dataparam['roleName'] = roleName;
            var webmethod = "../EMTSrv.asmx/getRoleID";
            $.ajax({
                type: "POST",
                url: webmethod,
                data: JSON.stringify(dataparam),
                contentType: "application/json; charset=utf-8",
                dataType: 'json',
                async: false,
                success: function (result) {
                    //roleid = result.d
                    //roleID = roleid;
                    var array = result.d.split("~");
                    $("#roleID").val(array[0]);
                    $("#role").val(array[1]);
                    roleid = array[0];
                    roleID = array[0];
                },
                error: OnError
            });

            function OnError(result) {
                alert("error");
            }

            var roledes = [];
            roledes = roleName.split(" ");
            roleName = $.map(roledes, function (val, index) {
                var str = val.charAt(0);
                return str;
            }).join("");

            //var dataparam = {};
            ////dataparam['RoleId'] = roleid;
            //dataparam['RoleName'] = roleName;
            //var webmethod = "../EMTSrv.asmx/UpdateUserrole";
            //$.ajax({
            //    type: "POST",
            //    url: webmethod,
            //    data: JSON.stringify(dataparam),
            //    contentType: "application/json; charset=utf-8",
            //    dataType: 'json',
            //    async: false,
            //    success: function (result) {

            //    },
            //    error: OnError
            //});
        }
    });
    function OnError(result) {
        alert("error");
    }

    //subprocess
    $(".secondLevela").click(function () {
        //debugger;
        if (leftnavigation_classification == 1) {
            subProcessName = $(this).text();
            mailBoxName = '';
            statusName = '';
            classificationName = '';
            pgindex = 1;
            pageSize = 20;
            pageCount = 0;
            $('#frameMain').attr('src', './content/PieChart.aspx');
            if ($(this).hasClass("selected")) {
                $(".secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
                $(".thirdLevelul,.fourthLevelul,.fifthLevelul").hide();
                return false;
            }
            $(".secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
            $(this).addClass("selected");
            $(this).parent("li").addClass("selected");
            $(".thirdLevelul,.fourthLevelul,.fifthLevelul").hide();
            $(this).next("ul").show();
        }
        else {
            subProcessName = $(this).text();
            mailBoxName = '';
            statusName = '';
            pgindex = 1;
            pageSize = 20;
            pageCount = 0;
            $('#frameMain').attr('src', './content/PieChart.aspx');
            if ($(this).hasClass("selected")) {
                $(".secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
                $(".thirdLevelul,.fifthLevelul").hide();
                return false;
            }
            $(".secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
            $(this).addClass("selected");
            $(this).parent("li").addClass("selected");
            $(".thirdLevelul,.fifthLevelul").hide();
            $(this).next("ul").show();
        }
    });

    //mailbox
    $(".thirdLevela").click(function () {
        if (leftnavigation_classification == 1) {
            mailBoxName = $(this).text();
            statusName = '';
            classificationName = '';
            pgindex = 1;
            pageSize = 20;
            pageCount = 0;
            $('#frameMain').attr('src', './content/PieChart.aspx');
            if ($(this).hasClass("selected")) {
                $(".thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
                $(".fourthLevelul,.fifthLevelul").hide()
                return false;
            }
            mailBoxName = $(this).text();
            pgindex = 1;
            pageSize = 20;
            pageCount = 0;
            $(".thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
            $(this).addClass("selected");
            $(this).parent("li").addClass("selected");
            $(".fourthLevelul,.fifthLevelul").hide();
            $(this).next("ul").show();
        }
        else {

            delete sessionStorage.Statusid;
            if ($(this).hasClass("selected")) {
                $(".thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
                $(".fifthLevelul").hide()
                return false;
            }
            mailBoxName = $(this).text();
            statusName = 'open';
            pgindex = 1;
            pageSize = 20;
            pageCount = 0;
            $(".thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
            $(this).addClass("selected");
            $(this).parent("li").addClass("selected");
            $(".fifthLevelul").hide();
            $(this).next("ul").show();
        }
    });

    //NLP classification
    $(".fourthLevela").click(function () {
        if (leftnavigation_classification == 1) {
            if ($(this).hasClass("selected")) {
                $(".fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
                $(".fifthLevelul").hide()
                return false;
            }
            classificationName = $(this).text();
            statusName = 'open';
            pgindex = 1;
            pageSize = 20;
            pageCount = 0;
            $(".fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
            $(this).addClass("selected");
            $(this).parent("li").addClass("selected");
            $(".fifthLevelul").hide();
            $(this).next("ul").show();
        }
    });

    //status
    $(".fifthLevela").click(function () {
        //debugger;
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
        if ($(this).hasClass("selected")) {
            $(".fifthLevela,.fifthLevelli").removeClass("selected");
            return false;
        }
        $(".fifthLevela,.fifthLevelli").removeClass("selected");
        $(this).addClass("selected");
        $(this).parent("li").addClass("selected");
        selectedMenuItem = $(this).attr('id');
    });


    /*collapsable ele events*/

    /*tempreedirecting Events*/

    //$("a.firstLevela").click(function () {
    //    pgindex = 1;
    //    pageSize = 20;
    //    pageCount = 0;
    //    $(".dashBoardLabel").show();
    //    $("#underConstruction,.pagelevelLinks").hide();
    //    $("#parentNode").html($(this).text());
    //    resizeTreeScroll($("#collapsableNav"));
    //    statusName = 'open';
    //    selectedMenuItem = $(this).attr('id');
    //});

    $("a.secondLevela").click(function () {
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
        $(".dashBoardLabel").show();
        $("#underConstruction,.pagelevelLinks").hide();
        $("#parentNode").html($(this).text());
        resizeTreeScroll($("#collapsableNav"));
        //statusName = 'open';
        selectedMenuItem = $(this).attr('id');
    });


    $("a.thirdLevela").click(function () {
        if (leftnavigation_classification == 1) {
            pgindex = 1;
            pageSize = 20;
            pageCount = 0;
            $(".dashBoardLabel").show();
            $("#underConstruction,.pagelevelLinks").hide();
            $("#parentNode").html($(this).text());
            resizeTreeScroll($("#collapsableNav"));
            //statusName = 'open';
            selectedMenuItem = $(this).attr('id');
        }
        else {

            pgindex = 1;
            pageSize = 20;
            pageCount = 0;
            $(".pagelevelLinks").show();
            $("#underConstruction,.dashBoardLabel").hide();
            if (typeof document.getElementById('frameMain').contentWindow.OnLeftMenuChange === 'function') {
                document.getElementById('frameMain').contentWindow.OnLeftMenuChange();
            }
            else {
                $('#frameMain').attr('src', './content/Inbox.aspx');
            }
            $("#childNode").html($(this).text());
            resizeTreeScroll($("#collapsableNav"));
            statusName = 'open';
            selectedMenuItem = $(this).attr('id');
        }
    });

    //NLP classification
    $("a.fourthLevela").click(function () {
        if (leftnavigation_classification == 1) {
            pgindex = 1;
            pageSize = 20;
            pageCount = 0;
            $(".pagelevelLinks").show();
            $("#underConstruction,.dashBoardLabel").hide();
            if (typeof document.getElementById('frameMain').contentWindow.OnLeftMenuChange === 'function') {
                document.getElementById('frameMain').contentWindow.OnLeftMenuChange();
            }
            else {
                $('#frameMain').attr('src', './content/Inbox.aspx');
            }
            $("#childNode").html($(this).text());
            resizeTreeScroll($("#collapsableNav"));
            statusName = 'open';
            selectedMenuItem = $(this).attr('id');
        }
    });


    $("a.fifthLevela").click(function () {
        //debugger;
        //$("#underConstruction,.dashBoardLabel").hide();
        //if (typeof document.getElementById('frameMain').contentWindow.OnLeftMenuChange === 'function') {
        //    document.getElementById('frameMain').contentWindow.OnLeftMenuChange();           
        //}
        //else {
        //    $('#frameMain').attr('src', './content/Inbox.aspx');
        //}
        //$("#parentNode").html($(this).text());
        //resizeTreeScroll($("#collapsableNav"));        
        //selectedMenuItem = $(this).attr('id');
        pgindex = 1;
        pageSize = 20;
        pageCount = 0;
        $("#underConstruction,.dashBoardLabel").hide();
        if (typeof document.getElementById('frameMain').contentWindow.OnLeftMenuChange === 'function') {
            document.getElementById('frameMain').contentWindow.OnLeftMenuChange();
        }
        else {
            $('#frameMain').attr('src', './content/Inbox.aspx');
        }
        resizeTreeScroll($("#collapsableNav"));
        selectedMenuItem = $(this).attr('id');
    });


    $("#parentNode").click(function () {
        $("#c_ap_nav_0").removeClass("selected");
    });
    $("#childNode").click(function () {
        $("#c_ac_nav_0_0").removeClass("selected");
    });
    /*tempreedirecting Events*/

    function getstatusName(val_Status) {
        statusName = val_Status;
        selectedMenuItem = $(this).attr('id');
    }

});

function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

function UrlOpen() {
    window.open('https://identity.cognizant.com/itim/self/', '_blank');
}


function AutoRefresh() {
    var selectUserID;
    var webmethod = "../EMTSrv.asmx/EmailboxNames";
    if (UID == undefined || UID == null) {
        UID = $('#UID').prop('value');//$('#fname').prop();
        roleID = $('#roleID').prop('value');
    }

    if (roleID == 4) {
        selectUserID = UID;
    }
    else {
        selectUserID = 0;
    }


    var selectedSubprocessId = 0;


    var dataparam = {};
    var webmethod1 = "../EMTSrv.asmx/Classificationcheck";
    $.ajax({
        type: "POST",
        url: webmethod1,
        data: JSON.stringify(dataparam),
        contentType: "application/json; charset=utf-8",
        dataType: 'json',
        async: false,
        success: function (result) {
            classificationresult = result.d
        },
        error: OnError
    });


    function OnError(result) {
        alert("error");
    }
    leftnavigation_classification = classificationresult;
    //debugger;
    sessionStorage.leftnavigation_classification = leftnavigation_classification;

    if (selectedMenuItem == null) {

        //var params = { CountryId: 1, LoggedInUserId: UID, RoleId: roleID, SelectedAssociateId: selectUserID, SelectedSubProcessId: '0' };
        // var params = { CountryId: 1, LoggedInUserId: UID, RoleId: roleID, SelectedAssociateId: selectUserID, SelectedSubProcessId: selectedSubprocessId };
        //debugger;
        var params = { ClassificationResult: classificationresult, CountryId: 1, LoggedInUserId: UID, RoleId: roleID, SelectedAssociateId: selectUserID, SelectedSubProcessId: selectedSubprocessId };

        $.ajax({
            type: "POST",
            url: webmethod,
            data: JSON.stringify(params),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (resultData) {
                var collapsbleMenu = resultData.d;
                traverseCollapsibleList(jQuery.parseJSON(collapsbleMenu));
            },
            error: function (error) {
                var data = error;
            }
        });
        OpenSelectedMenu(selectedMenuItem);
    }
    else {

        if (selectedMenuItem.split('_').length - 1 >= 4) {
            var params = { ClassificationResult: classificationresult, CountryId: 1, LoggedInUserId: UID, RoleId: roleID, SelectedAssociateId: selectUserID, SelectedSubProcessId: '0' };
            $.ajax({
                type: "POST",
                url: webmethod,
                data: JSON.stringify(params),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                async: false,
                success: function (resultData) {
                    var collapsbleMenu = resultData.d;
                    traverseCollapsibleList(jQuery.parseJSON(collapsbleMenu));
                },
                error: function (error) {
                    var data = error;
                }
            });
            OpenSelectedMenu(selectedMenuItem);
        }
    }
}



function traverseCollapsibleList(collapsbleMenuJson) {
    var colArr = [];
    $.each(collapsbleMenuJson, function (i, item) {
        createCollapsableArray(i, item);
    });

    createHtmlCollapsableList();


    function createCollapsableArray(i, item) {
        if (leftnavigation_classification == 1) {
            var temp0Level = item.Country;
            var temp2level = item.EmailBox;
            var temp4level = item.ClassificationName;
            //var temp3level = ["Open " + item.Open, "Assigned " + item.Assigned, "Clarification Needed " + item["Clarification Needed"], "Clarification Provided " + item["Clarification Provided"], "Pending for QC " + item["Pending for QC"], "QC Accepted " + item["QC Accepted"], "QC Rejected " + item["QC Rejected"], "Completed " + item.Completed];

            var temp3level = "";

            //Varma Code start for Dynamic Status

            var webmethod = "../EMTSrv.asmx/EmailboxDynamicStatuses";

            var params = { ClassificationResult: classificationresult,Country: item.Country, Emailbox: item.EmailBox, SubProcess: item.SubprocessName };
            $.ajax({
                type: "POST",
                url: webmethod,
                data: JSON.stringify(params),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                async: false,
                success: function (resultData) {
                    var DynamicStatuses = resultData.d;
                    //traverseCollapsibleList(jQuery.parseJSON(collapsbleMenu));

                    // debugger
                    DynamicStatuses = jQuery.parseJSON(DynamicStatuses);

                    var arr1 = [];

                    $(DynamicStatuses).each(function (i, val) {
                        $.each(val, function (key, val) {
                            if (val == null)
                                arr1.push(key + " " + 0);
                            else
                                arr1.push(key + " " + val);
                        });
                    });

                    temp3level = arr1;
                    //temp3level = ["Open " + item.Open, "Assigned " + item.Assigned, "Clarification Needed " + item["Clarification Needed"], "Clarification Provided " + item["Clarification Provided"], "Pending for QC " + item["Pending for QC"], "QC Accepted " + item["QC Accepted"], "QC Rejected " + item["QC Rejected"], "Completed " + item.Completed];
                },
                error: function (error) {
                    var data = error;
                }
            });


            //Varma Code end for Dynamic Status


            var colIndex = colArr.length - 1;
            if ($.inArray(item.Country, colArr[colIndex]) < 0) {
                colArr.push([item.Country]);
            }
            colIndex = colArr.length - 1;
            var col2Index = colArr[colIndex].length - 1;
            if ($.inArray(item.SubprocessName, colArr[colIndex][col2Index]) < 0) {
                colArr[colIndex].push([item.SubprocessName, [temp2level], [temp4level], [temp3level]]);
            }
            else {
                if (leftnavigation_classification == 1) {
                    colIndex = colArr.length - 1;
                    var col3Index = colArr[colIndex].length - 1;
                    if ($.inArray(item.EmailBox, colArr[colIndex][col2Index][col3Index]) < 0) {
                        colArr[colIndex][col2Index][1].push(temp2level);
                    }

                    var col4Index = colArr[colIndex].length - 1;
                    if ($.inArray(item.ClassificationName, colArr[colIndex][col2Index][col3Index + 1]) < 0) {
                        colArr[colIndex][col2Index][2].push(temp4level);
                        colArr[colIndex][col2Index][3].push(temp3level);
                    }
                    else {
                        colArr[colIndex][col2Index][3].push(temp3level);
                    }
                }
                else {
                    colArr[colIndex][col2Index][1].push(temp2level);
                    colArr[colIndex][col2Index][2].push(temp3level);
                }
            }
        }
        else {
            var temp0Level = item.Country;
            var temp2level = item.EmailBox;
            //var temp3level = ["Open " + item.Open, "Assigned " + item.Assigned, "Clarification Needed " + item["Clarification Needed"], "Clarification Provided " + item["Clarification Provided"], "Pending for QC " + item["Pending for QC"], "QC Accepted " + item["QC Accepted"], "QC Rejected " + item["QC Rejected"], "Completed " + item.Completed];


            var temp3level = "";

            //Varma Code start for Dynamic Status

            var webmethod = "../EMTSrv.asmx/EmailboxDynamicStatuses";

            var params = { ClassificationResult: classificationresult,Country: item.Country, Emailbox: item.EmailBox, SubProcess: item.SubprocessName };
            $.ajax({
                type: "POST",
                url: webmethod,
                data: JSON.stringify(params),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                async: false,
                success: function (resultData) {
                    var DynamicStatuses = resultData.d;
                    //traverseCollapsibleList(jQuery.parseJSON(collapsbleMenu));

                    // debugger
                    DynamicStatuses = jQuery.parseJSON(DynamicStatuses);

                    var arr1 = [];

                    $(DynamicStatuses).each(function (i, val) {
                        $.each(val, function (key, val) {
                            if (val == null)
                                arr1.push(key + " " + 0);
                            else
                                arr1.push(key + " " + val);
                        });
                    });

                    temp3level = arr1;
                    //temp3level = ["Open " + item.Open, "Assigned " + item.Assigned, "Clarification Needed " + item["Clarification Needed"], "Clarification Provided " + item["Clarification Provided"], "Pending for QC " + item["Pending for QC"], "QC Accepted " + item["QC Accepted"], "QC Rejected " + item["QC Rejected"], "Completed " + item.Completed];
                },
                error: function (error) {
                    var data = error;
                }
            });


            //Varma Code end for Dynamic Status


            var colIndex = colArr.length - 1;
            if ($.inArray(item.Country, colArr[colIndex]) < 0) {
                colArr.push([item.Country]);
            }
            colIndex = colArr.length - 1;
            var col2Index = colArr[colIndex].length - 1;
            if ($.inArray(item.SubprocessName, colArr[colIndex][col2Index]) < 0) {
                colArr[colIndex].push([item.SubprocessName, [temp2level], [temp3level]]);
            } else {
                colArr[colIndex][col2Index][1].push(temp2level);
                colArr[colIndex][col2Index][2].push(temp3level);
            }
        }
    }

    function createHtmlCollapsableList() {
        if (leftnavigation_classification == 1) {
            var l1 = 0;
            var collapsableMenuString = "";
            for (var i = 0; i < colArr.length; i++) {
                collapsableMenuString += '<li id="c_p_nav_' + i + '" class="firstLevelli"><a class="cclkpNav firstLevela" id="c_ap_nav_' + i + '" href="#" >' + colArr[i][0] + '</a>';
                collapsableMenuString += '<ul class="secondLevelul" id="c_p_UL_' + i + '" >';
                for (var j = 1; j < colArr[i].length; j++) {
                    collapsableMenuString += '<li class="cNav secondLevelli" id="c_c_nav_' + i + '_' + (j - 1) + '"><a class="secondLevela" id="c_ac_nav_' + i + '_' + (j - 1) + '" href="#">' + colArr[i][j][0] + '</a>';
                    collapsableMenuString += '<ul class="thirdLevelul" id="c_c_UL_' + i + '_' + (j - 1) + '" >';
                    for (var k = 0; k < colArr[i][j][1].length; k++) {
                        collapsableMenuString += '<li class="thirdLevelli " id="c_c_nav_' + i + '_' + (j - 1) + '_' + k + '"><a class="thirdLevela" id="c_ac_nav_' + i + '_' + (j - 1) + '_' + k + '" href="#">' + colArr[i][j][1][k] + '</a>';
                        collapsableMenuString += '<ul class="fourthLevelul" id="c_c_UL_' + i + '_' + (j - 1) + '_' + k + '" >';
                        //NLP classification                    
                        for (var l = 0; l < colArr[i][j][2].length; l++) {
                            collapsableMenuString += '<li class="fourthLevelli " id="c_c_nav_' + i + '_' + (j - 1) + '_' + k + '_' + (l) + '"><a class="fourthLevela" id="c_ac_nav_' + i + '_' + (j - 1) + '_' + k + '_' + (l) + '" href="#">' + colArr[i][j][2][l] + '</a>';
                            collapsableMenuString += '<ul class="fifthLevelul" id="c_c_UL_' + i + '_' + (j - 1) + '_' + k + '_' + (l) + '" >';
                            var TotalCaseStatus = colArr[i][j][3].length;
                            if (l1 < TotalCaseStatus) {
                                for (var m = 0; m < colArr[i][j][3][l1].length; m++) {
                                    collapsableMenuString += '<li class="fifthLevelli " id="c_c_nav_' + i + '_' + (j - 1) + '_' + k + '_' + (l) + '_' + m + '"><a class="fifthLevela" id="c_ac_nav_' + i + '_' + (j - 1) + '_' + k + '_' + (l) + '_' + m + '" onclick="getstatus(this)" href="#">' + colArr[i][j][3][l1][m] + '</a></li>';
                                }
                                l1 = l1 + 1;
                            }
                            collapsableMenuString += '</ul></li>';
                        }
                        collapsableMenuString += '</ul></li>';
                    }
                    collapsableMenuString += '</ul></li>';
                }
                collapsableMenuString += '</ul></li>';
            }
            $("#collapsableNav ul").html(collapsableMenuString);
        }
        else {
            var collapsableMenuString = "";
            for (var i = 0; i < colArr.length; i++) {
                collapsableMenuString += '<li id="c_p_nav_' + i + '" class="firstLevelli"><a class="cclkpNav firstLevela" id="c_ap_nav_' + i + '" href="#" >' + colArr[i][0] + '</a>';
                collapsableMenuString += '<ul class="secondLevelul" id="c_p_UL_' + i + '" >';
                for (var j = 1; j < colArr[i].length; j++) {
                    collapsableMenuString += '<li class="cNav secondLevelli" id="c_c_nav_' + i + '_' + (j - 1) + '"><a class="secondLevela" id="c_ac_nav_' + i + '_' + (j - 1) + '" href="#">' + colArr[i][j][0] + '</a>';
                    collapsableMenuString += '<ul class="thirdLevelul" id="c_c_UL_' + i + '_' + (j - 1) + '" >';
                    for (var k = 0; k < colArr[i][j][1].length; k++) {
                        //collapsableMenuString += '<li class="thirdLevelli " id="c_c_nav_' + i + '_' + (j - 1) + '_' + k + '"><a class="thirdLevela" id="c_ac_nav_' + i + '_' + (j - 1) + '_' + k + '_' + '0' + '" href="#">' + colArr[i][j][1][k] + '</a>';
                        collapsableMenuString += '<li class="thirdLevelli " id="c_c_nav_' + i + '_' + (j - 1) + '_' + k + '"><a class="thirdLevela" id="c_ac_nav_' + i + '_' + (j - 1) + '_' + k + '" href="#">' + colArr[i][j][1][k] + '</a>';
                        collapsableMenuString += '<ul class="fifthLevelul" id="c_c_UL_' + i + '_' + (j - 1) + '_' + k + '" >';
                        for (var l = 0; l < colArr[i][j][2][k].length; l++) {
                            collapsableMenuString += '<li class="fifthLevelli " id="c_c_nav_' + i + '_' + (j - 1) + '_' + k + '_' + l + '"><a class="fifthLevela" id="c_ac_nav_' + i + '_' + (j - 1) + '_' + k + '_' + l + '" onclick="getstatus(this)" href="#">' + colArr[i][j][2][k][l] + '</a></li>';
                        }
                        collapsableMenuString += '</ul></li>';
                    }
                    collapsableMenuString += '</ul></li>';
                }
                collapsableMenuString += '</ul></li>';
            }
            $("#collapsableNav ul").html(collapsableMenuString);
        }
    }
}

function LeftMenuClicks() {
    /*collapsable ele events*/
    //$(".firstLevela").click(function () {
    //    debugger;
    //    if(leftnavigation_classification==1){
    //        countryName = $(this).text();
    //        mailBoxName = '';
    //        subProcessName = '';
    //        statusName = '';
    //        classificationName = '';
    //        pgindex = 1;
    //        pageSize = 20;
    //        pageCount = 0;       
    //        $('#frameMain').attr('src', './content/PieChart.aspx');
    //        if ($(this).hasClass("selected")) {                                
    //                $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
    //                $(this).next("ul").hide();            
    //                $(".secondLevelul,.thirdLevelul,.fourthLevelul,.fifthLevelul").hide();
    //                return false;               
    //            }           
    //        $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
    //        $($(this)[0].id).addClass("selected");            
    //        $(this).parent("li").addClass("selected");            
    //        $('.firstLevelul').children().find('ul').hide();            
    //    }
    //    else{                               
    //        countryName = $(this).text();
    //        mailBoxName = '';
    //        subProcessName = '';
    //        statusName = '';
    //        pgindex = 1;
    //        pageSize = 20;
    //        pageCount = 0;            
    //        $('#frameMain').attr('src', './content/PieChart.aspx');
    //        if ($(this).hasClass("selected")) {
    //            $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
    //            $(this).next("ul").hide();
    //            $(".secondLevelul,.thirdLevelul,.fifthLevelul").hide();
    //            return false;
    //        }
    //        $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
    //        $($(this)[0].id).addClass("selected");            
    //        $(this).parent("li").addClass("selected");            
    //        $('.firstLevelul').children().find('ul').hide();            
    //    }    
    //});


    //$(".secondLevela").click(function () {
    //    if (leftnavigation_classification == 1) {
    //        subProcessName = $(this).text();
    //        mailBoxName = '';
    //        statusName = '';
    //        classificationName = '';            
    //        $('#frameMain').attr('src', './content/PieChart.aspx');            
    //        if ($(this).hasClass("selected")) {                
    //            $(".secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");                
    //            $(".thirdLevelul,.fourthLevelul,.fifthLevelul").hide();
    //            return false;
    //        }            
    //        $(".secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");            
    //        $($(this)[0].id).addClass("selected");
    //        $(this).parent("li").addClass("selected");            
    //        $('.secondLevelul').find('ul').hide();            
    //    }
    //    else {
    //        subProcessName = $(this).text();
    //        mailBoxName = '';
    //        statusName = '';            
    //        $('#frameMain').attr('src', './content/PieChart.aspx');            
    //        if ($(this).hasClass("selected")) {
    //            $(".secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
    //            $(".thirdLevelul,.fifthLevelul").hide();
    //            return false;
    //        }
    //        $(".secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
    //        $($(this)[0].id).addClass("selected");
    //        $(this).parent("li").addClass("selected");            
    //        $('.secondLevelul').find('ul').hide();
    //    }
    //});


    //$(".thirdLevela").click(function () {        
    //    if (leftnavigation_classification == 1) {
    //        mailBoxName = $(this).text();
    //        statusName = '';
    //        classificationName = '';            
    //            //if (typeof document.getElementById('frameMain').contentWindow.OnLeftMenuChange === 'function') {
    //            //    document.getElementById('frameMain').contentWindow.OnLeftMenuChange();
    //            //}
    //            //else {
    //            //    $('#frameMain').attr('src', './content/PieChart.aspx');
    //            //}                
    //            if ($(this).hasClass("selected")) {                 
    //                $(".thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");                    
    //                $(".fourthLevelul,.fifthLevelul").hide()
    //                return false;
    //            }                            
    //            $(".thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");            
    //        $($(this)[0].id).addClass("selected");
    //        $(this).parent("li").addClass("selected");
    //        $('.thirdLevelul').find('ul').hide();

    //    }
    //    else {
    //        delete sessionStorage.Statusid;
    //        if ($(this).hasClass("selected")) {
    //            $(".thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
    //            $(".fifthLevelul").hide()
    //            return false;
    //        }
    //        mailBoxName = $(this).text();
    //        statusName = 'open';
    //        $(".thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");            
    //        $($(this)[0].id).addClass("selected");
    //        $(this).parent("li").addClass("selected");
    //        $('.thirdLevelul').find('ul').hide();            
    //    }
    //});


    ////Added for NLP classification
    //$(".fourthLevela").click(function () {
    //    if (leftnavigation_classification == 1) {
    //        if ($(this).hasClass("selected")) {
    //            $(".fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");
    //            return false;
    //        }
    //        statusName = 'open';
    //        classificationName = $(this).text();            
    //        $(".fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");            
    //        $($(this)[0].id).addClass("selected");
    //        $(this).parent("li").addClass("selected");            
    //    }
    //});


    //$(".fifthLevela").click(function () {
    //    //debugger;
    //        if ($(this).hasClass("selected")) {
    //            $(".fifthLevela,.fifthLevelli").removeClass("selected");
    //            return false;
    //        }            
    //        $(".fifthLevela,.fifthLevelli").removeClass("selected");
    //        $($(this)[0].id).addClass("selected");
    //        $(this).parent("li").addClass("selected");
    //        selectedMenuItem = $(this).attr('id');                    
    //});


    ///*collapsable ele events*/

    ///*tempreedirecting Events*/
    ////Country
    //$("a.firstLevela").click(function () {        
    //        $(".dashBoardLabel").show();
    //        $("#underConstruction,.pagelevelLinks").hide();
    //        $("#parentNode").html($(this).text());
    //        resizeTreeScroll($("#collapsableNav"));
    //        statusName = 'open';
    //        selectedMenuItem = $(this).attr('id');        
    //});

    ////Subprocess
    //$("a.secondLevela").click(function () {        
    //        $(".dashBoardLabel").show();
    //        $("#underConstruction,.pagelevelLinks").hide();
    //        $("#parentNode").html($(this).text());
    //        resizeTreeScroll($("#collapsableNav"));
    //        //statusName = 'open';
    //        selectedMenuItem = $(this).attr('id');
    //});

    ////Mailbox
    //$("a.thirdLevela").click(function () {
    //    if (leftnavigation_classification == 1) {
    //        $(".dashBoardLabel").show();
    //        $("#underConstruction,.pagelevelLinks").hide();
    //        $("#parentNode").html($(this).text());
    //        resizeTreeScroll($("#collapsableNav"));
    //        //statusName = 'open';
    //        selectedMenuItem = $(this).attr('id');
    //    }
    //    else {
    //        $(".pagelevelLinks").show();
    //        $("#underConstruction,.dashBoardLabel").hide();
    //        if (typeof document.getElementById('frameMain').contentWindow.OnLeftMenuChange === 'function') {
    //            document.getElementById('frameMain').contentWindow.OnLeftMenuChange();
    //        }
    //        else {
    //            $('#frameMain').attr('src', './content/Inbox.aspx');
    //        }
    //        $("#childNode").html($(this).text());
    //        resizeTreeScroll($("#collapsableNav"));
    //        statusName = 'open';
    //        selectedMenuItem = $(this).attr('id');
    //    }        
    //});


    ////NLP classification
    //$("a.fourthLevela").click(function () {
    //    if (leftnavigation_classification == 1) {
    //        $(".pagelevelLinks").show();
    //        $("#underConstruction,.dashBoardLabel").hide();

    //        if (typeof document.getElementById('frameMain').contentWindow.OnLeftMenuChange === 'function') {
    //            document.getElementById('frameMain').contentWindow.OnLeftMenuChange();
    //        }
    //        else {

    //            $('#frameMain').attr('src', './content/Inbox.aspx');
    //        }
    //        $("#childNode").html($(this).text());
    //        resizeTreeScroll($("#collapsableNav"));
    //        statusName = 'open';
    //        selectedMenuItem = $(this).attr('id');
    //    }        
    //});

    ////Status
    //$("a.fifthLevela").click(function () {        
    //        $("#underConstruction,.dashBoardLabel").hide();
    //        if (typeof document.getElementById('frameMain').contentWindow.OnLeftMenuChange === 'function') {
    //            document.getElementById('frameMain').contentWindow.OnLeftMenuChange();
    //        }
    //        else {
    //            $('#frameMain').attr('src', './content/Inbox.aspx');
    //        }
    //        resizeTreeScroll($("#collapsableNav"));
    //        selectedMenuItem = $(this).attr('id');        
    //});


    $("#parentNode").click(function () {
        $("#c_ap_nav_0").removeClass("selected");
    });
    $("#childNode").click(function () {
        $("#c_ac_nav_0_0").removeClass("selected");
    });
    /*tempreedirecting Events*/

    function getstatusName(val_Status) {

        statusName = val_Status;
        selectedMenuItem = $(this).attr('id');
    }
}

function OpenSelectedMenu(selectedMenuItem) {

    if (selectedMenuItem != null) {

        var stringArray = selectedMenuItem.split("_");

        LeftMenuClicks();

        var elementname = '#c_p_nav_';

        //debugger;
        //NLP changes
        if (leftnavigation_classification == 1) {
            if ((stringArray.length - 1) == 7) //Fifth level click
            {
                $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");

                $('#c_p_nav_' + stringArray[3]).parent("ul").show();

                $('#c_p_nav_' + stringArray[3]).addClass("selected");
                $('#c_ap_nav_' + stringArray[3]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6] + '_' + stringArray[7]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6] + '_' + stringArray[7]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6] + '_' + stringArray[7]).addClass("selected");

                $('#' + selectedMenuItem).addClass("selected");
                $('#' + selectedMenuItem).parent("li").addClass("selected");

                $(".pagelevelLinks").show();
                $("#underConstruction,.dashBoardLabel").hide();
                $('#frameMain').attr('src', './content/Inbox.aspx');
                $("#childNode").html(statusName);
            }
            else if ((stringArray.length - 1) == 6) //Fourth level click
            {
                $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");

                $('#c_p_nav_' + stringArray[3]).parent("ul").show();

                $('#c_p_nav_' + stringArray[3]).addClass("selected");
                $('#c_ap_nav_' + stringArray[3]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6]).addClass("selected");

                $(".fifthLevelul").hide();
                $('#' + selectedMenuItem).addClass("selected");
                $('#' + selectedMenuItem).parent("li").addClass("selected");
                $('#' + selectedMenuItem).next("ul").show();

                $(".pagelevelLinks").show();
                $("#underConstruction,.dashBoardLabel").hide();
                $('#frameMain').attr('src', './content/Inbox.aspx');
                $("#childNode").html(classificationName);
            }
            else if ((stringArray.length - 1) == 5) //Third level click
            {
                $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");

                $('#c_p_nav_' + stringArray[3]).parent("ul").show();

                $('#c_p_nav_' + stringArray[3]).addClass("selected");
                $('#c_ap_nav_' + stringArray[3]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");

                $(".fourthLevelul,.fifthlevelul").hide();
                $('#' + selectedMenuItem).addClass("selected");
                $('#' + selectedMenuItem).parent("li").addClass("selected");
                $('#' + selectedMenuItem).next("ul").show();
                $(".dashBoardLabel").show();
                $("#underConstruction,.pagelevelLinks").hide();
                $('#frameMain').attr('src', './content/Inbox.aspx');
                $("#parentNode").html(mailBoxName);
            }
            else if ((stringArray.length - 1) == 4) //Second level click
            {
                $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");

                $('#c_p_nav_' + stringArray[3]).parent("ul").show();

                $('#c_p_nav_' + stringArray[3]).addClass("selected");
                $('#c_ap_nav_' + stringArray[3]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");

                $(".thirdLevelul,.fourthLevelul,.fifthlevelul").hide();

                $('#' + selectedMenuItem).addClass("selected");
                $('#' + selectedMenuItem).parent("li").addClass("selected");
                $('#' + selectedMenuItem).next("ul").show();

                $(".dashBoardLabel").show();
                $("#underConstruction,.pagelevelLinks").hide();
                $('#frameMain').attr('src', './content/PieChart.aspx');
                $("#parentNode").html(subProcessName);
            }
            else if ((stringArray.length - 1) == 3) //First level click
            {
                $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fourthLevela,.fourthLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");

                $('#c_p_nav_' + stringArray[3]).parent("ul").show();

                $('#c_p_nav_' + stringArray[3]).addClass("selected");
                $('#c_ap_nav_' + stringArray[3]).addClass("selected");

                $(".secondLevelul,.thirdLevelul,.fourthLevelul,.fifthlevelul").hide();

                $('#' + selectedMenuItem).addClass("selected");
                $('#' + selectedMenuItem).parent("li").addClass("selected");

                $(".dashBoardLabel").show();
                $("#underConstruction,.pagelevelLinks").hide();
                $('#frameMain').attr('src', './content/PieChart.aspx');
                $("#parentNode").html(countryName);
            }
        }
        else {//without NLP

            if ((stringArray.length - 1) == 6) //Fourth level click
            {
                $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");

                $('#c_p_nav_' + stringArray[3]).parent("ul").show();

                $('#c_p_nav_' + stringArray[3]).addClass("selected");
                $('#c_ap_nav_' + stringArray[3]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5] + '_' + stringArray[6]).addClass("selected");

                $('#' + selectedMenuItem).addClass("selected");
                $('#' + selectedMenuItem).parent("li").addClass("selected");

                $(".pagelevelLinks").show();
                $("#underConstruction,.dashBoardLabel").hide();
                $('#frameMain').attr('src', './content/Inbox.aspx');
                $("#childNode").html(statusName);

            }
            else if ((stringArray.length - 1) == 5) //Third level click
            {
                $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");

                $('#c_p_nav_' + stringArray[3]).parent("ul").show();

                $('#c_p_nav_' + stringArray[3]).addClass("selected");
                $('#c_ap_nav_' + stringArray[3]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4] + '_' + stringArray[5]).addClass("selected");

                //c_ac_nav_0_0_0  c_ac_nav_0_0_0_2   c_ac_nav_0_0  c_ap_nav_0   c_p_nav_0 c_ap_nav_0   c_ac_nav_0_0_0  c_c_nav_0_0_0  c_ac_nav_0_0  c_c_nav_0_0
                $(".fifthLevelul").hide();
                $('#' + selectedMenuItem).addClass("selected");
                $('#' + selectedMenuItem).parent("li").addClass("selected");
                $('#' + selectedMenuItem).next("ul").show();

                $(".pagelevelLinks").show();
                $("#underConstruction,.dashBoardLabel").hide();
                $('#frameMain').attr('src', './content/Inbox.aspx');
                $("#childNode").html(mailBoxName);
            }
            else if ((stringArray.length - 1) == 4) //Second level click
            {
                $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");

                $('#c_p_nav_' + stringArray[3]).parent("ul").show();

                $('#c_p_nav_' + stringArray[3]).addClass("selected");
                $('#c_ap_nav_' + stringArray[3]).addClass("selected");

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).parent("ul").show();

                $('#c_c_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");
                $('#c_ac_nav_' + stringArray[3] + '_' + stringArray[4]).addClass("selected");

                $(".thirdLevelul,.fifthLevelul").hide();
                $('#' + selectedMenuItem).addClass("selected");
                $('#' + selectedMenuItem).parent("li").addClass("selected");
                $('#' + selectedMenuItem).next("ul").show();

                $(".dashBoardLabel").show();
                $("#underConstruction,.pagelevelLinks").hide();
                $('#frameMain').attr('src', './content/PieChart.aspx');
                $("#parentNode").html(subProcessName);

            }
            else if ((stringArray.length - 1) == 3) //First level click
            {

                $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");

                $('#c_p_nav_' + stringArray[3]).parent("ul").show();


                $('#c_p_nav_' + stringArray[3]).addClass("selected");
                $('#c_ap_nav_' + stringArray[3]).addClass("selected");

                $(".secondLevelul,.thirdLevelul,.fifthLevelul").hide();
                $('#' + selectedMenuItem).addClass("selected");
                $('#' + selectedMenuItem).parent("li").addClass("selected");
                $('#' + selectedMenuItem).next("ul").show();

                $(".dashBoardLabel").show();
                $("#underConstruction,.pagelevelLinks").hide();
                $('#frameMain').attr('src', './content/PieChart.aspx');
                $("#parentNode").html(countryName);
            }
        }
    }
    else {
        selectedMenuItem = "c_ap_nav_0"

        var stringArray = selectedMenuItem.split("_");

        LeftMenuClicks();

        $(".firstLevela,.firstLevelli,.secondLevela,.secondLevelli,.thirdLevela,.thirdLevelli,.fifthLevela,.fifthLevelli").removeClass("selected");

        $('#c_p_nav_' + stringArray[3]).parent("ul").show();


        $('#c_p_nav_' + stringArray[3]).addClass("selected");
        $('#c_ap_nav_' + stringArray[3]).addClass("selected");

        $(".secondLevelul,.thirdLevelul,.fifthLevelul").hide();
        $('#' + selectedMenuItem).addClass("selected");
        $('#' + selectedMenuItem).parent("li").addClass("selected");
        $('#' + selectedMenuItem).next("ul").show();

        $(".dashBoardLabel").show();
        $("#underConstruction,.pagelevelLinks").hide();
        $('#frameMain').attr('src', './content/PieChart.aspx');
        $("#parentNode").html(countryName);
    }
}

function getstatus(val) {
    //statusName = val.text.replace(/[ 0-9]/g, '');
    statusName = val.text.replace(/\d+$/, '');
    return false;
}

function resizeTreeScroll(ele) {
    var _ele = ele;
    _ele.customScrollbar({ skin: "default-skin", hScroll: false, "resize": true });
    _ele.children(".viewport").css({ "width": "252px" });
    if (_ele.children(".vertical").is(':visible')) {
        _ele.mousewheel();
    } else {
        _ele.unmousewheel();
    }
}
