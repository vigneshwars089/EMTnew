﻿/// <reference path="angular.js" />
/// <reference path="angular-route.js" />
/// <reference path="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.10/angular-sanitize.js" />

var ProcessingPage = angular.module('ProcessingPage', ['ngSanitize', 'ui.bootstrap', 'ui.grid', 'ngMaterial']);
var CaseId = 0;
var UserId = "";
var EMailBoxId = 0;
var PreviousPage = "";
var lftSelection = "";
var SelectionText = "";
var RoleId = 0;
var StatusId = 0;
var SelectedUserId = "";
var APIURL = "http://localhost:58976/api/processing/";

ProcessingPage.config(['$locationProvider', function ($locationProvider) {
    $locationProvider.html5Mode(true);
}]);

//dateformat
ProcessingPage.filter('stringToDate', function ($filter) {
    return function (ele, dateFormat) {
        return $filter('date')(new Date(ele), dateFormat);
    }
})



//Initial CaseDetails
ProcessingPage.controller("CaseDetailsController", ['$scope', '$location', '$window', '$http', '$sce', '$modal', '$mdDialog', function ($scope, $location, $window, $http, $sce, $modal, $mdDialog) {
    $scope.files = [];
    $scope.selectedcheckboxes = [];
    $scope.dynamicValues = {};
    $scope.ToStatusID = 0;
    $scope.ToStatus = "";
    $scope.ddCategoryID = 0;
    $scope.ddFlagCategoryId = 0;
    $scope.UserId = $('[id$="hdnLoginId"]').val();
    $scope.RoleId = $('[id$="hdnRoleId"]').val();
    $scope.myDate = new Date();
    $scope.queryparameters = $location.search();
    $scope.lstAttachments = [];
    $scope.lstUploadedAttachments = [];
    $scope.lstInlineAttachments = [];
    $scope.fileContent = "";
    $scope.currentdate = new Date();
    $scope.ConversationFrom = '';
    $scope.updatedTo = '';
    $scope.updatedCC = '';
    $scope.updatedBCc = '';
    $scope.updatedSubject = '';
    $scope.CaseId = $scope.queryparameters.CaseId;
    CaseId = $scope.CaseId;
    UserId = $scope.UserId;
    RoleId = $scope.RoleId;
    EMailBoxId = $scope.queryparameters.EMailBox;
    PreviousPage = $scope.queryparameters.PreviousPage;
    lftSelection = $scope.queryparameters.lftSelection;
    SelectionText = $scope.queryparameters.SelectionText;
    StatusId = $scope.queryparameters.Status;
    $scope.StatusId = StatusId;
    SelectedUserId = $scope.queryparameters.SelectedUserId;
    var apiurldata = CaseId + "/" + UserId + "/" + EMailBoxId + "/" + StatusId + "/" + RoleId;
    //var apiurl = "http://localhost:58976/api/processing/GetCaseDetails/" + apiurldata;
    var apiurl = APIURL + "GetCaseDetails/" + apiurldata;
    $http({
        url:
         apiurl,
        xhrFields: {
            withCredentials: false
        },
        dataType: "jsonp",
        method: "GET",
        params: '',
        headers: {
            "Content-Type": "application/json"
        }
    }).then(function (response) {
        $scope.Casedetails = response.data;
        console.log(response);
        $scope.Subject = response.data.objEmailCaseInfo.Subject;
        $scope.Country = response.data.objEmailCaseInfo.Country;
        $scope.EmailBoxName = response.data.objEmailCaseInfo.EmailBoxName;
        $scope.EmailBoxId = response.data.objEmailCaseInfo.EmailBoxId;
        $scope.SubprocessName = response.data.objEmailCaseInfo.SubprocessName;
        $scope.CaseType = response.data.objEmailCaseInfo.CaseType;
        $scope.AssignedTo = response.data.objEmailCaseInfo.AssignedTo;
        $scope.ClassificationDescription = response.data.objEmailCaseInfo.ClassificationDescription;
        $scope.Status = response.data.objEmailCaseInfo.Status;
        $scope.CaseStatus = response.data.objEmailCaseInfo.Status;
        $scope.QCAssignedTo = response.data.objEmailCaseInfo.QCAssignedTo;
        $scope.EmailReceivedDate = response.data.objEmailCaseInfo.EmailReceivedDate;
        $scope.EmailFrom = response.data.objEmailCaseInfo.EmailFrom;
        $scope.EmailTo = response.data.objEmailCaseInfo.EmailTo;
        $scope.EmailCc = response.data.objEmailCaseInfo.EmailCc;
        $scope.EmailBcc = response.data.objEmailCaseInfo.EmailBcc;
        $scope.EmailBody = response.data.objEmailCaseInfo.EmailBody;
        $scope.EmailBoxId = response.data.objEmailCaseInfo.EmailBoxId;
        $scope.EmailBoxAddress = response.data.objEmailCaseInfo.EmailBoxAddress;
        $scope.StatusId = response.data.objEmailCaseInfo.StatusId;
        $scope.CategoryId = response.data.objEmailCaseInfo.CategoryId;
        $scope.Comments = response.data.objEmailCaseInfo.Comments;
        $scope.AssignedToId = response.data.objEmailCaseInfo.AssignedToId;
        $scope.QCUserId = response.data.objEmailCaseInfo.QCUserId;
        $scope.IsUrgent = response.data.objEmailCaseInfo.IsUrgent;
        $scope.IsManual = response.data.objEmailCaseInfo.IsManual;
        $scope.IsVipMail = response.data.objEmailCaseInfo.IsVipMail;
        $scope.SubprocessId = response.data.objEmailCaseInfo.SubprocessId;
        $scope.CountryId = response.data.objEmailCaseInfo.CountryId;
        $scope.IsClassificationActive = response.data.objEmailCaseInfo.IsClassificationActive;
        $scope.ParentCaseId = response.data.objEmailCaseInfo.ParentCaseId;
        $scope.OptionalEMailBoxAddress = response.data.objEmailCaseInfo.OptionalEMailBoxAddress;
        $scope.ForwardedToGmb = response.data.objEmailCaseInfo.ForwardedToGmb;
        $scope.IsMailTriggerRequired = response.data.objEmailCaseInfo.IsMailTriggerRequired;
        $scope.IsQCRequired = response.data.objEmailCaseInfo.IsQCRequired;
        $scope.ErrorMessage = response.data.objEmailCaseInfo.ErrorMessage;
        $scope.ApproverUserId = response.data.objEmailCaseInfo.ApproverUserId;


        //emailbox details
        var mailboxapidata = $scope.EmailBoxId;
        var mailboxapi = APIURL + "GetEmailBoxDetails/" + mailboxapidata;
        $http({
            url: mailboxapi,
            xhrFields: {
                withCredentials: false
            },
            dataType: "jsonp",
            method: "GET",
            data: '',
            headers: {
                "Content-Type": "application/json"
            }
        }).then(function (MailBoxresponse) {

            $scope.MailBoxdetails = MailBoxresponse.data;
            console.log(MailBoxresponse);
        }, function (reason) {
            $scope.error = reason.data;
        });

        $scope.files = [];
       
        $scope.getTheFiles = function ($files) {
            $scope.files = $files;           
           
        };

        //status dropdown
        var statuslistapidata = $scope.SubprocessId + "/" + $scope.RoleId;
        var statuslistapi = APIURL + "GetStatusTransition/" + statuslistapidata;
        $http({
            url: statuslistapi,
            xhrFields: {
                withCredentials: false
            },
            dataType: "jsonp",
            method: "GET",
            data: '',
            headers: {
                "Content-Type": "application/json"
            }
        }).then(function (Statusresponse) {

            $scope.Statusdropdowndetails = Statusresponse.data;
            console.log(Statusresponse);
        }, function (reason) {
            $scope.error = reason.data;
        });

        //approver dropdown

        var approverlistapi = APIURL + "GetApproverList";
        $http({
            url: approverlistapi,
            xhrFields: {
                withCredentials: false
            },
            dataType: "jsonp",
            method: "GET",
            data: '',
            headers: {
                "Content-Type": "application/json"
            }
        }).then(function (Approverresponse) {

            $scope.ApproverList = Approverresponse.data;
            console.log(Approverresponse);
        }, function (reason) {
            $scope.error = reason.data;
        });

        var dynamicstatusapidata = $scope.SubprocessId;
        // var dynamicstatusapi = "http://localhost:58976/api/processing/GetDynamicStatus/" + dynamicstatusapidata;
        var dynamicstatusapi = APIURL + "GetDynamicStatus/" + dynamicstatusapidata;
        $http({
            url: dynamicstatusapi,
            xhrFields: {
                withCredentials: false
            },
            dataType: "jsonp",
            method: "GET",
            data: '',
            headers: {
                "Content-Type": "application/json"
            }
        }).then(function (dynamicstatusresponse) {
            $scope.dynamicstatusedetails = dynamicstatusresponse.data;
            console.log(dynamicstatusresponse);
            angular.forEach($scope.dynamicstatusedetails, function (value, key) {
                if (value.IsClarificationStatus == true) {
                    $scope.ClarificationNeededStatus = value.StatusDescription;
                    console.log($scope.ClarificationNeededStatus);
                }
                if (value.IsOnHold) {
                    $scope.OnHoldStatus = value.StatusDescription;
                }
                if (value.IsQCPending) {
                    $scope.QCPendingStatus = value.StatusDescription;
                }
                if (value.IsQCApprovedorRejected) {
                    $scope.QCApprovedorRejectedStatus = value.StatusDescription;
                }
                if (value.IsFinalStatus) {
                    $scope.FinalStatus = value.StatusDescription;
                }
                if (value.IsApprovalStatus) {
                    $scope.ApprovalStatus = value.StatusDescription;
                }
                if (value.StatusId == $scope.StatusId) {
                    $scope.IsOpen = value.IsInitalStatus;
                    $scope.IsClarificationProvided = value.IsFollowupStatus;
                    $scope.IsClarificationStatus = value.IsClarificationStatus;
                    $scope.IsFinalStatus = value.IsFinalStatus;
                    $scope.IsOnHold = value.IsOnHold;
                    $scope.IsQCPending = value.IsQCPending;
                    $scope.IsQCApprovedorRejected = value.IsQCApprovedorRejected;
                    $scope.IsAssigned = value.IsAssigned;
                    $scope.IsReassignStatus = value.IsReassignStatus;
                    $scope.IsApprovalStatus = value.IsApprovalStatus;
                }
            })

            //Get Dynamic Fields
            var dynamicfieldsapidata = CaseId;
            var dynamicfieldsapi = APIURL + "GetDynamicFieldsInfo/" + dynamicfieldsapidata;
            //var dynamicfieldsapi = " http://localhost:58976/api/processing/GetDynamicFieldsInfo/" + dynamicfieldsapidata;

            $http({
                url: dynamicfieldsapi,
                xhrFields: {
                    withCredentials: false
                },
                dataType: "jsonp",
                method: "GET",
                data: '',
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function (DynamicFieldsresponse) {
                $scope.DynamicFieldsdetails = DynamicFieldsresponse.data;
                angular.forEach($scope.DynamicFieldsdetails, function (value, key) {
                    angular.forEach(value.lstControlValues, function (value1, key1) {
                        if (value1.optionText == value.FieldValue)
                            $scope.dynamicValues[value.FieldMasterID] = { optionText: value1.optionText, optionValue: value1.optionValue };
                    });
                });

                console.log(DynamicFieldsresponse);
            }, function (reason) {
                $scope.error = reason.data;
            });

            if ($scope.Status == $scope.OnHoldStatus || $scope.Status == $scope.QCPendingStatus || $scope.Status == $scope.QCApprovedorRejectedStatus || $scope.Status == $scope.FinalStatus || $scope.UserId != $scope.AssignedToId) {
                document.getElementById("StatusSelect").disabled = true;
                document.getElementById("txtcomments").disabled = true;
                //$("#divdynamicFields :input[type='text']").attr("disabled", true);
                //$("#divdynamicFields :select").attr("disabled", true);
                $('[id$="divdynamicFields"]').find('input,select').attr('disabled', 'disabled');
            }
            if ($scope.RoleId == 3 && $scope.Status == $scope.ApprovalStatus) {
                document.getElementById("StatusSelect").disabled = false;
                document.getElementById("txtcomments").disabled = false;
                //$("#divdynamicFields :input[type='text']").attr("disabled", true);
                //$("#divdynamicFields :select").attr("disabled", true);
                $('[id$="divdynamicFields"]').find('input,select').removeAttr('disabled');
            }
            if (($scope.RoleId == 3 || $scope.RoleId == 4) && $scope.QCPendingStatus == $scope.Status && $scope.QCUserId == $scope.UserId) {
                document.getElementById("StatusSelect").disabled = false;
                document.getElementById("txtcomments").disabled = false;
                //$("#divdynamicFields :input[type='text']").attr("disabled", true);
                //$("#divdynamicFields :select").attr("disabled", true);
                $('[id$="divdynamicFields"]').find('input,select').removeAttr('disabled');
            }

        }, function (reason) {
            $scope.error = reason.data;
        });


    }, function (reason) {
        $scope.error = reason.data;
        console.log(reason);
    });

    $scope.mySplit = function (string) {
        var array = string.split(';');
        return array;
    }
   
    //saranya - to get file details when files are uploaded
  
    // NOW UPLOAD THE FILES.
    $scope.uploadFiles = function () {
       
        
    }

    $scope.ReassignClick = function () {
        if ($scope.UserId == $scope.AssignedToId) {
            if ($scope.IsClarificationStatus != true && $scope.IsQCPending != true && $scope.IsFinalStatus != true) {
                if ($scope.RoleId == 3 || $scope.RoleId == 4) {
                 //   $("#lblAssignedto").css("display", "none");
                    $("#assignedto").css("display", "none");
                    $("#imgreassign").css("display", "none");
                    $("#ReassignUserList").css("display", "block");
                    $("#lnkUpdate").css("display", "block");
                    $("#lnkCancel").css("display", "block");
                    var userlistapidata = $scope.CountryId + "/" + EMailBoxId + "/" + $scope.RoleId;
                    var userlistapi = APIURL + "ReassignUserList/" + userlistapidata;
                    $http({
                        url: userlistapi,
                        xhrFields: {
                            withCredentials: false
                        },
                        dataType: "jsonp",
                        method: "GET",
                        data: '',
                        headers: {
                            "Content-Type": "application/json"
                        }
                    }).then(function (userlistresponse) {
                        $scope.userlistdropdowndetails = userlistresponse.data;
                        console.log(userlistresponse);
                    }, function (reason) {
                        $scope.error = reason.data;
                    });
                }
            }
        }
    }
    //convert content from htmltoplaintext
    $scope.HtmltoText = function (text) {
        $scope.trustedHtml = $sce.trustAsHtml(text);
        //$scope.followupConversationID = ConversationID;
    }

    $scope.UpdateReassignedUser = function () {
        var updateReassigneduserapidata = CaseId + "/" + $scope.selectedUser.UserId + "/" + UserId;
        //var updateReassigneduserapi = "http://localhost:58976/api/processing/Reassign/" + updateReassigneduserapidata;
        var updateReassigneduserapi = APIURL + "Reassign/" + updateReassigneduserapidata;
        $http({
            url: updateReassigneduserapi,
            xhrFields: {
                withCredentials: false
            },
            dataType: "jsonp",
            method: "POST",
            data: '',
            headers: {
                "Content-Type": "application/json"
            }
        }).then(function (UpdateUserresponse) {
            $scope.UpdateUserresponsedetails = UpdateUserresponse.data;
            console.log(UpdateUserresponse);
            $window.location.reload();
        }, function (reason) {
            $scope.error = reason.data;
        });
    }

    //bind Category dropdown
    $scope.displayCategory = function () {
        angular.forEach($scope.dynamicstatusedetails, function (value, key) {
            if (value.StatusId == $scope.selectedStatus.ToStatusID) {
                if (value.IsClarificationStatus == true) {
                    var Categorylistapi = APIURL + "GetCategory/" + EMailBoxId;
                    $http({
                        url: Categorylistapi,
                        xhrFields: {
                            withCredentials: false
                        },
                        dataType: "jsonp",
                        method: "GET",
                        data: '',
                        headers: {
                            "Content-Type": "application/json"
                        }
                    }).then(function (Categoryresponse) {
                        $scope.Categorydropdowndetails = Categoryresponse.data;
                        console.log(Categoryresponse);
                    }, function (reason) {
                        $scope.error = reason.data;
                        console.log(reason);
                    });
                    $("#CategorySelect").show();
                    $("#FlagCatgorySelect").hide();
                }
                else if (value.IsFinalStatus == true) {
                    var Categorylistapi = APIURL + "GetCategory/" + EMailBoxId;
                    $http({
                        url: Categorylistapi,
                        xhrFields: {
                            withCredentials: false
                        },
                        dataType: "jsonp",
                        method: "GET",
                        data: '',
                        headers: {
                            "Content-Type": "application/json"
                        }
                    }).then(function (Categoryresponse) {
                        $scope.Categorydropdowndetails = Categoryresponse.data;
                        console.log(Categoryresponse);
                    }, function (reason) {
                        $scope.error = reason.data;
                        console.log(reason);
                    });

                    var FlagCategorylistapi = APIURL + "GetFlagCategory/" + EMailBoxId;
                    $http({
                        url: FlagCategorylistapi,
                        xhrFields: {
                            withCredentials: false
                        },
                        dataType: "jsonp",
                        method: "GET",
                        data: '',
                        headers: {
                            "Content-Type": "application/json"
                        }
                    }).then(function (FlagCategoryresponse) {
                        $scope.FlagCategorydropdowndetails = FlagCategoryresponse.data;
                        console.log(FlagCategoryresponse);
                    }, function (reason) {
                        $scope.error = reason.data;
                        console.log(reason);
                    });
                    $("#CategorySelect").show();
                    $("#FlagCatgorySelect").show();
                }
                else if (value.IsApprovalStatus == true) {
                    $("#ApproverSelect").show();
                }
                else {
                    $("#CategorySelect").hide();
                    $("#FlagCatgorySelect").hide();
                    $("#ApproverSelect").hide();
                }
            }
        })
        $scope.ToStatusID = $scope.selectedStatus.ToStatusID;
        $scope.ToStatus = $scope.selectedStatus.ToStatus;
    }

    $scope.category = function () {
        $scope.ddCategoryID = $scope.selectedCategory.CategoryId;
    }

    $scope.FlagCategory = function () {
        $scope.ddFlagCategoryId = $scope.selectedFlagCatgory.FlagCategoryId
    }

    $scope.CancelClick = function () {
        if (PreviousPage == "DashBoard" && (lftSelection == null || lftSelection == "")) {
            $window.location.href = "DashBoard.aspx";
        }
        else {
            $window.location.href = "DashBoard.aspx?selectedMenu=" + lftSelection + "&SelectionText=" + SelectionText;
        }
        if (PreviousPage == "Search") {
            $window.location.href = "../Search/search.aspx?View=PreSearch"
        }
        if (PreviousPage == "QCWorkQueue") {
            $window.location.href = "QCWorkQueue.aspx"
        }
        if (PreviousPage == "WorkQueue") {
            var SelectedUserId = !(SelectedUserId == null && SelectedUserId == "") ? SelectedUserId.ToString() : "";
            $window.location.href = "WorkQueue.aspx?MailBoxId=" + EMailBoxId + "&StatusId=" + StatusId + "&SelectedUserId=" + SelectedUserId;
        }
    }

    //AuditPopup click
    $scope.customFullscreen = false
    $scope.AuditLogopen = function () {
        $mdDialog.show({
            controller: 'AuditPopupcontroller',
            templateUrl: 'AuditLog.html',
            clickOutsideToClose: false,
            fullscreen: $scope.customFullscreen
        })
    }

    //CommentsPopup click
    $scope.CommentsHistoryopen = function () {
        $mdDialog.show({
            controller: 'CommentsPopupcontroller',
            templateUrl: 'CommentsHistory.html',
            clickOutsideToClose: false,
            fullscreen: $scope.customFullscreen
        })
    }

    $scope.isChecked = function (item) {
        angular.forEach($scope.DynamicFieldsdetails, function (value, key) {
            if (value.FieldType == "CheckBoxList") {
                if (value.FieldValue.indexOf(item) >= 0) {
                    return true;
                }
                else {
                    return true;
                }
            }
        });

    }

    if (window.DOMParser) {
        parseXml = function (xmlStr) {
            return (new window.DOMParser()).parseFromString(xmlStr, "text/xml");
        };
    } else if (typeof window.ActiveXObject != "undefined" && new window.ActiveXObject("Microsoft.XMLDOM")) {
        parseXml = function (xmlStr) {
            var xmlDoc = new window.ActiveXObject("Microsoft.XMLDOM");
            xmlDoc.async = "false";
            xmlDoc.loadXML(xmlStr);
            return xmlDoc;
        };
    } else {
        parseXml = function () { return null; }
    }
    //}

    $scope.DynamicFieldsUpdate = function () {
        var sqlXMLValue = "";
        var XMLValue = "";
        try {
            XMLValue = "<root>";
            angular.forEach($scope.DynamicFieldsdetails, function (value, key) {
                if (value.FieldType == "RadioButtonList") {
                    if (value.FieldPrevilegeName == "Mandatory") {
                        if ($scope.dynamicValues[value.FieldMasterID] == "" || $scope.dynamicValues[value.FieldMasterID] == null || $scope.dynamicValues[value.FieldMasterID] == 'undefined') {
                            alert("Please fill all the mandatory fields");
                            throw "exit";
                        }
                        else {
                            var radioval = angular.fromJson($scope.dynamicValues[value.FieldMasterID]);
                            XMLValue = XMLValue + "<row  FieldMasterID = '" + value.FieldMasterID + "'  FieldValue ='" + radioval.optionText + "'    IsListValue = '" + "0" + "' />";
                        }
                    }
                    else {
                        if ($scope.dynamicValues[value.FieldMasterID] == "" || $scope.dynamicValues[value.FieldMasterID] == null || $scope.dynamicValues[value.FieldMasterID] == 'undefined') {
                            XMLValue = XMLValue + "<row  FieldMasterID = '" + value.FieldMasterID + "'  FieldValue ='" + "" + "'    IsListValue = '" + "0" + "' />";
                        }
                        else {
                            var radioval = angular.fromJson($scope.dynamicValues[value.FieldMasterID]);
                            XMLValue = XMLValue + "<row  FieldMasterID = '" + value.FieldMasterID + "'  FieldValue ='" + radioval.optionText + "'    IsListValue = '" + "0" + "' />";
                        }

                    }
                }
                else if (value.FieldType == "Date") {
                    if (value.FieldPrevilegeName == "Mandatory") {
                        if (value.FieldValue == "" || value.FieldValue == null || value.FieldValue == 'undefined') {
                            alert("Please fill all the mandatory fields");
                            throw "exit";
                        }
                        else {
                            XMLValue = XMLValue + "<row  FieldMasterID = '" + value.FieldMasterID + "'  FieldValue ='" + value.FieldValue + "'    IsListValue = '" + "0" + "' />";
                        }
                    }
                    else {
                        if (value.FieldValue == "" || value.FieldValue == null || value.FieldValue == 'undefined') {
                            XMLValue = XMLValue + "<row  FieldMasterID = '" + value.FieldMasterID + "'  FieldValue ='" + "" + "'    IsListValue = '" + "0" + "' />";
                        }
                        else {
                            XMLValue = XMLValue + "<row  FieldMasterID = '" + value.FieldMasterID + "'  FieldValue ='" + value.FieldValue + "'    IsListValue = '" + "0" + "' />";
                        }
                    }
                }
                else if (value.FieldType == "TextBox") {
                    if (value.FieldPrevilegeName == "Mandatory") {
                        if (document.getElementById(value.FieldMasterID).value == "" || document.getElementById(value.FieldMasterID).value == null || document.getElementById(value.FieldMasterID).value == 'undefined') {
                            alert("Please fill all the mandatory fields");
                            throw "exit";
                        }
                        else {
                            XMLValue = XMLValue + "<row  FieldMasterID = '" + value.FieldMasterID + "'  FieldValue ='" + document.getElementById(value.FieldMasterID).value + "'    IsListValue = '" + "0" + "' />";
                        }
                    }
                    else {
                        if (document.getElementById(value.FieldMasterID).value == "" || document.getElementById(value.FieldMasterID).value == null || document.getElementById(value.FieldMasterID).value == 'undefined') {
                            XMLValue = XMLValue + "<row  FieldMasterID = '" + value.FieldMasterID + "'  FieldValue ='" + "" + "'    IsListValue = '" + "0" + "' />";
                        }
                        else {
                            XMLValue = XMLValue + "<row  FieldMasterID = '" + value.FieldMasterID + "'  FieldValue ='" + document.getElementById(value.FieldMasterID).value + "'    IsListValue = '" + "0" + "' />";
                        }
                    }
                }
                else if (value.FieldType == "DropDownList") {
                    if (value.FieldPrevilegeName == "Mandatory") {
                        if (($scope.dynamicValues[value.FieldMasterID] == "" || $scope.dynamicValues[value.FieldMasterID] == null || $scope.dynamicValues[value.FieldMasterID] == 'undefined') && value.FieldValue == "") {
                            alert("Please fill all the mandatory fields");
                            throw "exit";
                        }
                        else {
                            XMLValue = XMLValue + "<row  FieldMasterID = '" + value.FieldMasterID + "'  FieldValue ='" + value.FieldValue + "'    IsListValue = '" + "0" + "' />";
                        }
                    }
                    else {
                        if ($scope.dynamicValues[value.FieldMasterID] == "" || $scope.dynamicValues[value.FieldMasterID] == null || $scope.dynamicValues[value.FieldMasterID] == 'undefined') {
                            XMLValue = XMLValue + "<row  FieldMasterID = '" + value.FieldMasterID + "'  FieldValue ='" + value.FieldValue + "'    IsListValue = '" + "0" + "' />";
                        }
                        else {
                            var ddlval = $scope.dynamicValues[value.FieldMasterID].optionText;
                            XMLValue = XMLValue + "<row  FieldMasterID = '" + value.FieldMasterID + "'  FieldValue ='" + ddlval + "'    IsListValue = '" + "0" + "' />";
                        }
                    }
                }
                else if (value.FieldType == "CheckBoxList") {
                    $scope.checkboxText = "";
                    $scope.checkboxval = "";
                    value.lstControlValues.filter(function (lstControlValues) {
                        if (lstControlValues.selected) {
                            if ($scope.checkboxText == "") {
                                $scope.checkboxText = lstControlValues.optionText
                            }
                            else {
                                $scope.checkboxText += ',' + lstControlValues.optionText;
                            }
                            if ($scope.checkboxval == "") {
                                $scope.checkboxval = lstControlValues.optionValue;
                            }
                            else {
                                $scope.checkboxval += ',' + lstControlValues.optionValue;
                            }
                        }
                        else if (lstControlValues.optionText != "") {
                            $scope.checkboxText = lstControlValues.optionText;
                            $scope.checkboxval = lstControlValues.optionValue;
                        }
                    });
                    if (value.FieldPrevilegeName == "Mandatory" && $scope.checkboxText == "" && $scope.checkboxval == "") {
                        alert("Please fill all the mandatory fields");
                        throw "exit";
                    }
                    else {
                        XMLValue = XMLValue + "<row  FieldMasterID = '" + value.FieldMasterID + "'  FieldValue ='" + $scope.checkboxval + "'   FieldText ='" + $scope.checkboxText + "'    IsListValue = '" + "1" + "' />";
                    }
                }
            })
            XMLValue = XMLValue + "</root>";

            var xmlsqlvalue = parseXml(XMLValue);
            if (xmlsqlvalue) {
                sqlXMLValue = new XMLSerializer().serializeToString(xmlsqlvalue.documentElement);
                console.log(sqlXMLValue);
            }

            updatedynamicfieldsapidata = CaseId + "/" + sqlXMLValue + "/" + UserId;
            var updatedynamicfieldsapi = APIURL + "UpdateDynamicFields";
            $http({
                url: updatedynamicfieldsapi,
                xhrFields: {
                    withCredentials: false
                },
                dataType: "application/json",
                method: "POST",
                params: {
                    "CaseId": CaseId,
                    "sqlXMLValue": sqlXMLValue,
                    "UserId": UserId
                }
            }).then(function (response) {
                $scope.updatedynamicfiels = response.data;
                console.log(response);
            }, function (reason) {
                $scope.error = reason.data;
                console.log(reason);
            });
            return true;
        }
        catch (err) {
            return false;
        }
    }

    //submit without mailcontent
    $scope.CaseSubmit = function () {
        if ($scope.IsClarificationStatus != true) {
            //if ($scope.Status != $scope.OnHoldStatus && $scope.Status != $scope.QCPendingStatus && $scope.Status != $scope.QCApprovedorRejectedStatus && $scope.Status != $scope.FinalStatus) {
            if (
                ($scope.UserId == $scope.AssignedToId && $scope.RoleId == 4)
                || ($scope.UserId == $scope.QCUserId && ($scope.RoleId == 3 || $scope.RoleId == 4))
                || ($scope.UserId == $scope.ApproverUserId && $scope.RoleId == 3)
                ) {

                if ($scope.ToStatus != "") {
                    if ($scope.ToStatus == $scope.ClarificationNeededStatus) {
                        $("#diveditableContent").css("display", "none");
                        $("#divMaileditor").css("display", "block");
                        loadEditor();
                        $scope.ConversationFrom = $scope.EmailBoxAddress;
                        $scope.updatedTo = $scope.EmailFrom;
                        $scope.updatedCC = '';
                        $scope.updatedBCc = '';
                        $scope.updatedSubject = $scope.Subject;
                    }
                    else if ($scope.Comments != null) {
                        var dynamicfieldresult = $scope.DynamicFieldsUpdate();
                        if (dynamicfieldresult) {
                            var UpdateCaseInfo = {};
                            UpdateCaseInfo['CaseId'] = $scope.CaseId;
                            UpdateCaseInfo['EmailReceivedDate'] = $scope.EmailReceivedDate;
                            UpdateCaseInfo['EmailFrom'] = $scope.EmailFrom;
                            UpdateCaseInfo['EmailTo'] = $scope.EmailTo;
                            UpdateCaseInfo['EmailCc'] = $scope.EmailCc;
                            UpdateCaseInfo['EmailBcc'] = $scope.EmailBcc;
                            UpdateCaseInfo['Subject'] = $scope.Subject;
                            UpdateCaseInfo['EmailBody'] = $scope.EmailBody;
                            UpdateCaseInfo['EmailBoxId'] = $scope.EmailBoxId;
                            UpdateCaseInfo['EmailBoxAddress'] = $scope.EmailBoxAddress;
                            UpdateCaseInfo['EmailBoxName'] = $scope.EmailBoxName;
                            UpdateCaseInfo['StatusId'] = $scope.selectedStatus.ToStatusID;
                            UpdateCaseInfo['Status'] = $scope.selectedStatus.ToStatus;
                            UpdateCaseInfo['CategoryId'] = $scope.ddCategoryID;
                            UpdateCaseInfo['CaseType'] = $scope.CaseType;
                            UpdateCaseInfo['Comments'] = $scope.Comments;
                            UpdateCaseInfo['AssignedToId'] = $scope.AssignedToId;
                            UpdateCaseInfo['QCUserId'] = $scope.QCUserId;
                            UpdateCaseInfo['QCAssignedTo'] = $scope.QCAssignedTo;
                            if ($scope.selectedApprover != undefined)
                                UpdateCaseInfo['ApproverUserId'] = $scope.selectedApprover.ApproverID;
                            UpdateCaseInfo['IsUrgent'] = $scope.IsUrgent;
                            UpdateCaseInfo['IsManual'] = $scope.IsManual;
                            UpdateCaseInfo['IsVipMail'] = $scope.IsVipMail;
                            UpdateCaseInfo['SubprocessId'] = $scope.SubprocessId;
                            UpdateCaseInfo['SubprocessName'] = $scope.SubprocessName;
                            UpdateCaseInfo['CountryId'] = $scope.CountryId;
                            UpdateCaseInfo['Country'] = $scope.Country;
                            UpdateCaseInfo['IsClassificationActive'] = $scope.IsClassificationActive;
                            UpdateCaseInfo['ClassificationDescription'] = $scope.ClassificationDescription;
                            UpdateCaseInfo['ParentCaseId'] = $scope.ParentCaseId;
                            UpdateCaseInfo['OptionalEMailBoxAddress'] = $scope.OptionalEMailBoxAddress;
                            UpdateCaseInfo['ForwardedToGmb'] = $scope.ForwardedToGmb;
                            UpdateCaseInfo['IsMailTriggerRequired'] = $scope.IsMailTriggerRequired;
                            UpdateCaseInfo['IsQCRequired'] = $scope.IsQCRequired;
                            UpdateCaseInfo['ErrorMessage'] = $scope.ErrorMessage;
                            UpdateCaseInfo['ModifiedBy'] = $scope.UserId;
                            UpdateCaseInfo['ModifiedDate'] = $scope.currentdate;

                            var updateCase = APIURL + "UpdateCaseDetails";
                            //var updateCase = "http://localhost:58976/api/processing/UpdateCaseDetails";
                            $http({
                                url: updateCase,
                                xhrFields: {
                                    withCredentials: false
                                },
                                dataType: "application/json",
                                method: "POST",
                                data: UpdateCaseInfo
                            }).then(function (response) {
                                $scope.updatedetails = response.data;
                                console.log(response);
                                $window.location.reload();
                            }, function (reason) {
                                $scope.error = reason.data;
                                console.log(reason);
                            });
                        }
                    }
                    else {
                        alert("Please Enter Comments");
                    }
                }
                else {
                    alert("Please select Status");
                }

            }
        }
    }

    $scope.ReplyAllClick = function () {
        if ($scope.IsOpen == true || $scope.IsAssigned == true || $scope.IsClarificationStatus == true || $scope.IsClarificationProvided == true) {
            if ($scope.UserId == $scope.AssignedToId) {
                if ($scope.RoleId == 1 || $scope.RoleId == 2) {
                }
                else {
                    $("#diveditableContent").css("display", "none");
                    $("#divMaileditor").css("display", "block");
                    loadEditor();
                    $scope.ConversationFrom = $scope.EmailBoxAddress;
                    $scope.updatedTo = $scope.EmailFrom;;
                    $scope.updatedCC = $scope.EmailCc;
                    $scope.updatedBCc = $scope.EmailBcc;
                    $scope.updatedSubject = $scope.Subject;
                }
            }
        }
    }

    $scope.ReplyClick = function () {
        if ($scope.IsOpen == true || $scope.IsAssigned == true || $scope.IsClarificationStatus == true || $scope.IsClarificationProvided == true) {
            if ($scope.UserId == $scope.AssignedToId) {
                if ($scope.RoleId == 1 || $scope.RoleId == 2) {
                }
                else {
                    $("#diveditableContent").css("display", "none");
                    $("#divMaileditor").css("display", "block");
                    loadEditor();
                    $scope.ConversationFrom = $scope.EmailBoxAddress;
                    $scope.updatedTo = $scope.EmailFrom;
                    $scope.updatedCC = '';
                    $scope.updatedBCc = '';
                    $scope.updatedSubject = $scope.Subject;
                }
            }
        }
    }

    $scope.ForwardClick = function () {
        if ($scope.IsOpen == true || $scope.IsAssigned == true || $scope.IsClarificationStatus == true || $scope.IsClarificationProvided == true) {
            if ($scope.UserId == $scope.AssignedToId) {
                if ($scope.RoleId == 1 || $scope.RoleId == 2) {
                }
                else {
                    $("#diveditableContent").css("display", "none");
                    $("#divMaileditor").css("display", "block");
                    loadEditor();
                    $scope.ConversationFrom = $scope.EmailBoxAddress;
                    $scope.updatedSubject = $scope.Subject;
                    $scope.updatedTo = '';
                    $scope.updatedCC = '';
                    $scope.updatedBCc = '';
                }
            }
        }
    }

    //$scope.SendMail = function () {
    //    $scope.uploadFiles();
    //};

    //submit with mailcontent
    $scope.SendMail = function () {

       // $scope.uploadFiles();
        if (($scope.IsOpen == true || $scope.IsAssigned == true || $scope.IsClarificationStatus == true || $scope.IsClarificationProvided == true) && $scope.ToStatus == "") {

            $scope.IsFollowUp = true;
            $scope.Comments = "";
            $scope.CategoryId = 0;
            $scope.ConversationFrom = $("#txtFrom").val();
            $scope.updatedTo = $("#txtTo").val();
            $scope.updatedCC = $("#txtCC").val();
            $scope.updatedBCc = $("#txtBCC").val();
            $scope.updatedSubject = $("#lblMailSubjectCaseId").text() + $("#txtsubject").val();
            $scope.followupConversationID = document.getElementById("conversationid").value;
            if ($("#divMaileditor").length) {
                $("#hdnEditorMailBodyContent").val($("#htmlEditorMailBody").val());
            }
            $scope.updatedContent = $("#hdnEditorMailBodyContent").val();
            //alert($("#hdnEditorMailBodyContent").val());        
            var objEmailCaseInfodetails = {};
            objEmailCaseInfodetails['CaseId'] = $scope.CaseId;
            objEmailCaseInfodetails['EmailReceivedDate'] = $scope.EmailReceivedDate;
            objEmailCaseInfodetails['EmailFrom'] = $scope.EmailFrom;
            objEmailCaseInfodetails['EmailTo'] = $scope.EmailTo;
            objEmailCaseInfodetails['EmailCc'] = $scope.EmailCc;
            objEmailCaseInfodetails['EmailBcc'] = $scope.EmailBcc;
            objEmailCaseInfodetails['Subject'] = $scope.Subject;
            objEmailCaseInfodetails['EmailBody'] = $scope.EmailBody;
            objEmailCaseInfodetails['EmailBoxId'] = $scope.EmailBoxId;
            objEmailCaseInfodetails['EmailBoxAddress'] = $scope.EmailBoxAddress;
            objEmailCaseInfodetails['EmailBoxName'] = $scope.EmailBoxName;
            objEmailCaseInfodetails['StatusId'] = $scope.ToStatusID;
            objEmailCaseInfodetails['Status'] = $scope.ToStatus;
            objEmailCaseInfodetails['CategoryId'] = $scope.ddCategoryID;
            objEmailCaseInfodetails['CaseType'] = $scope.CaseType;
            objEmailCaseInfodetails['Comments'] = $scope.Comments;
            objEmailCaseInfodetails['AssignedToId'] = $scope.AssignedToId;
            objEmailCaseInfodetails['QCUserId'] = $scope.QCUserId;
            objEmailCaseInfodetails['QCAssignedTo'] = $scope.QCAssignedTo;
            objEmailCaseInfodetails['ApproverUserId'] = $scope.ApproverUserId;
            objEmailCaseInfodetails['IsUrgent'] = $scope.IsUrgent;
            objEmailCaseInfodetails['IsManual'] = $scope.IsManual;
            objEmailCaseInfodetails['IsVipMail'] = $scope.IsVipMail;
            objEmailCaseInfodetails['SubprocessId'] = $scope.SubprocessId;
            objEmailCaseInfodetails['SubprocessName'] = $scope.SubprocessName;
            objEmailCaseInfodetails['CountryId'] = $scope.CountryId;
            objEmailCaseInfodetails['Country'] = $scope.Country;
            objEmailCaseInfodetails['IsClassificationActive'] = $scope.IsClassificationActive;
            objEmailCaseInfodetails['ClassificationDescription'] = $scope.ClassificationDescription;
            objEmailCaseInfodetails['ParentCaseId'] = $scope.ParentCaseId;
            objEmailCaseInfodetails['OptionalEMailBoxAddress'] = $scope.OptionalEMailBoxAddress;
            objEmailCaseInfodetails['ForwardedToGmb'] = $scope.ForwardedToGmb;
            objEmailCaseInfodetails['IsMailTriggerRequired'] = $scope.IsMailTriggerRequired;
            objEmailCaseInfodetails['IsQCRequired'] = $scope.IsQCRequired;
            objEmailCaseInfodetails['ErrorMessage'] = $scope.ErrorMessage;

            //var lstAttachmentsdetails = values;
            var lstInlineAttachments = {};
            var lstAttachments = {};
            //public Int32 Id;
            //public string FileName;
            //public string ContentType;
            //public byte[] FileContent;
            //public string CreatedDate;
            //public string AttachmentType;
            //public Int32 AttachmentTypeId;

            var objEmailConversationInfodetails = {};
            objEmailConversationInfodetails['Id'] = 0;
            objEmailConversationInfodetails['EmailDate'] = $scope.currentdate;
            objEmailConversationInfodetails['EmailFrom'] = $("#ddlFrom")[0].options[$("#ddlFrom")[0].selectedIndex].text;
            objEmailConversationInfodetails['EmailTo'] = $scope.updatedTo;
            objEmailConversationInfodetails['EmailCc'] = $scope.updatedCC;
            objEmailConversationInfodetails['EmailBcc'] = $scope.updatedBCc;
            objEmailConversationInfodetails['Subject'] = $scope.updatedSubject;
            objEmailConversationInfodetails['Content'] = $scope.updatedContent;
            objEmailConversationInfodetails['ConversationType'] = null;
            objEmailConversationInfodetails['IsHighImportance'] = false;
            objEmailConversationInfodetails['IsShowQuotedText'] = false;
            objEmailConversationInfodetails['CreatedBy'] = $scope.UserId;
            objEmailConversationInfodetails['CreatedDate'] = $scope.currentdate;

            //var lstNewFileAttachments = [];
            //var objFileAttachment = {};
            //objFileAttachment['Id'] = $scope.lstUploadedAttachments[0].Id;
            //objFileAttachment['FileName'] = $scope.lstUploadedAttachments[0].FileName;
            //objFileAttachment['ContentType'] = $scope.lstUploadedAttachments[0].ContentType;
            //objFileAttachment['FileContentString'] = $scope.lstUploadedAttachments[0].FileContentString;// new Int8Array(1);//
            //objFileAttachment['FileContentBytes'] = $scope.lstUploadedAttachments[0].FileContentBytes;
            //objFileAttachment['CreatedDate'] = $scope.lstUploadedAttachments[0].CreatedDate;
            //objFileAttachment['AttachmentType'] = $scope.lstUploadedAttachments[0].AttachmentType;
            //objFileAttachment['AttachmentTypeId'] = $scope.lstUploadedAttachments[0].AttachmentTypeId;

            //lstNewFileAttachments.push(objFileAttachment);

            objEmailConversationInfodetails['lstAttachments'] = $scope.lstAttachments;
            objEmailConversationInfodetails['lstInlineAttachments'] = $scope.lstInlineAttachments;
            objEmailConversationInfodetails['ErrorMessage'] = null;


            var objMailBoxInfodetails = {};
            objMailBoxInfodetails = $scope.MailBoxdetails;
            //objMailBoxInfodetails['ServiceExchangeUrl'] = 'https://mail.cognizant.com/ews/Exchange.asmx';
            //objMailBoxInfodetails['LoginEMailId'] = 'CEmtDev2';
            //objMailBoxInfodetails['ClientExVersion'] = 'Exchange2010_SP1';
            //objMailBoxInfodetails['Domain'] = 'cts';
            //objMailBoxInfodetails['Password'] = 'RTExMTExMSM=';
            //objMailBoxInfodetails['EMailId'] = 'emtdev2@cognizant.com';
            //objMailBoxInfodetails['IsLocked'] = false;


            var processInputdetails = {};
            processInputdetails['objEmailCaseInfo'] = objEmailCaseInfodetails;
            processInputdetails['objEmailConversationInfo'] = objEmailConversationInfodetails;
            processInputdetails['objMailBoxInfo'] = objMailBoxInfodetails;
            processInputdetails['FollowupConversationId'] = $scope.followupConversationID;
            processInputdetails['IsForwardToGMB'] = false;
            processInputdetails['IsFollowUp'] = $scope.IsFollowUp;
            processInputdetails['UserId'] = $scope.UserId;
            processInputdetails['ActionDate'] = $scope.currentdate;

            processInput = {};
            processInput['processInput'] = processInputdetails;
            console.log(processInput);
            //var processcaseapi = "http://localhost:58976/api/processing/ProcessCase"
            var processcaseapi = APIURL + "ProcessCase/"

            //file upload chnages

            var formdata = new FormData();
            angular.forEach($scope.files, function (value, key) {
                formdata.append(key, value);
            });

            //var request = {
            //    method: 'POST',
            //    url: APIURL + 'FileUpload',
            //    data: formdata,
            //    headers: {
            //        'Content-Type': undefined
            //    },
            //    transformRequest: angular.identity,

            //};

            formdata.append('processInput', JSON.stringify(processInputdetails));

            $http({
                url: processcaseapi,                
               
                method: "POST",
                data: formdata,
                headers: {
                            'Content-Type': undefined
                        },
                        transformRequest: angular.identity

            }).then(function (response) {
                $scope.Casedetails = response.data;
                alert("Mail sent successfully");
                console.log(response);
                $window.location.reload();
            }, function (reason) {
                $scope.error = reason.data;
                alert("Unable to send mail. Please contact EMT IT team for assistance");
                console.log(reason);
            });
        }
        else if ($scope.ToStatus == $scope.ClarificationNeededStatus) {
            var dynamicfieldresult = $scope.DynamicFieldsUpdate();
            if (dynamicfieldresult) {
                if ($scope.ddCategoryID == 0) {
                    alert("Kindly select Category")
                }
                else {
                    if ($scope.Comments != null) {
                        if ($scope.updatedTo != "" || $scope.updatedTo != null) {
                            $scope.IsFollowUp = false;
                            $scope.ConversationFrom = $("#txtFrom").val();
                            $scope.updatedTo = $("#txtTo").val();
                            $scope.updatedCC = $("#txtCC").val();
                            $scope.updatedBCc = $("#txtBCC").val();
                            $scope.updatedSubject = $("#lblMailSubjectCaseId").text() + $("#txtsubject").val();
                            $scope.followupConversationID = document.getElementById("conversationid").value;
                            if ($("#divMaileditor").length) {
                                $("#hdnEditorMailBodyContent").val($("#htmlEditorMailBody").val());
                            }
                            $scope.updatedContent = $("#hdnEditorMailBodyContent").val();
                            //alert($("#hdnEditorMailBodyContent").val());        
                            var objEmailCaseInfodetails = {};
                            objEmailCaseInfodetails['CaseId'] = $scope.CaseId;
                            objEmailCaseInfodetails['EmailReceivedDate'] = $scope.EmailReceivedDate;
                            objEmailCaseInfodetails['EmailFrom'] = $scope.EmailFrom;
                            objEmailCaseInfodetails['EmailTo'] = $scope.EmailTo;
                            objEmailCaseInfodetails['EmailCc'] = $scope.EmailCc;
                            objEmailCaseInfodetails['EmailBcc'] = $scope.EmailBcc;
                            objEmailCaseInfodetails['Subject'] = $scope.Subject;
                            objEmailCaseInfodetails['EmailBody'] = $scope.EmailBody;
                            objEmailCaseInfodetails['EmailBoxId'] = $scope.EmailBoxId;
                            objEmailCaseInfodetails['EmailBoxAddress'] = $scope.EmailBoxAddress;
                            objEmailCaseInfodetails['EmailBoxName'] = $scope.EmailBoxName;
                            objEmailCaseInfodetails['StatusId'] = $scope.ToStatusID;
                            objEmailCaseInfodetails['Status'] = $scope.ToStatus;
                            objEmailCaseInfodetails['CategoryId'] = $scope.selectedCategory.CategoryId;
                            objEmailCaseInfodetails['CaseType'] = $scope.CaseType;
                            objEmailCaseInfodetails['Comments'] = $scope.Comments;
                            objEmailCaseInfodetails['AssignedToId'] = $scope.AssignedToId;
                            objEmailCaseInfodetails['QCUserId'] = $scope.QCUserId;
                            objEmailCaseInfodetails['QCAssignedTo'] = $scope.QCAssignedTo;
                            objEmailCaseInfodetails['IsUrgent'] = $scope.IsUrgent;
                            objEmailCaseInfodetails['IsManual'] = $scope.IsManual;
                            objEmailCaseInfodetails['IsVipMail'] = $scope.IsVipMail;
                            objEmailCaseInfodetails['SubprocessId'] = $scope.SubprocessId;
                            objEmailCaseInfodetails['SubprocessName'] = $scope.SubprocessName;
                            objEmailCaseInfodetails['CountryId'] = $scope.CountryId;
                            objEmailCaseInfodetails['Country'] = $scope.Country;
                            objEmailCaseInfodetails['IsClassificationActive'] = $scope.IsClassificationActive;
                            objEmailCaseInfodetails['ClassificationDescription'] = $scope.ClassificationDescription;
                            objEmailCaseInfodetails['ParentCaseId'] = $scope.ParentCaseId;
                            objEmailCaseInfodetails['OptionalEMailBoxAddress'] = $scope.OptionalEMailBoxAddress;
                            objEmailCaseInfodetails['ForwardedToGmb'] = $scope.ForwardedToGmb;
                            objEmailCaseInfodetails['IsMailTriggerRequired'] = $scope.IsMailTriggerRequired;
                            objEmailCaseInfodetails['IsQCRequired'] = $scope.IsQCRequired;
                            objEmailCaseInfodetails['ErrorMessage'] = $scope.ErrorMessage;

                            //var lstAttachmentsdetails = values;
                            var lstInlineAttachments = {};

                            var objEmailConversationInfodetails = {};
                            objEmailConversationInfodetails['Id'] = 0;
                            objEmailConversationInfodetails['EmailDate'] = $scope.currentdate;
                            objEmailConversationInfodetails['EmailFrom'] = $("#ddlFrom")[0].options[$("#ddlFrom")[0].selectedIndex].text;
                            objEmailConversationInfodetails['EmailTo'] = $scope.updatedTo;
                            objEmailConversationInfodetails['EmailCc'] = $scope.updatedCC;
                            objEmailConversationInfodetails['EmailBcc'] = $scope.updatedBCc;
                            objEmailConversationInfodetails['Subject'] = $scope.updatedSubject;
                            objEmailConversationInfodetails['Content'] = $scope.updatedContent;
                            objEmailConversationInfodetails['ConversationType'] = null;
                            objEmailConversationInfodetails['IsHighImportance'] = false;
                            objEmailConversationInfodetails['IsShowQuotedText'] = false;
                            objEmailConversationInfodetails['CreatedBy'] = $scope.UserId;
                            objEmailConversationInfodetails['CreatedDate'] = $scope.currentdate;

                            objEmailConversationInfodetails['lstAttachments'] = $scope.lstAttachments;
                            objEmailConversationInfodetails['lstInlineAttachments'] = $scope.lstInlineAttachments;
                            objEmailConversationInfodetails['ErrorMessage'] = null;


                            var objMailBoxInfodetails = {};
                            objMailBoxInfodetails = $scope.MailBoxdetails;
                            //objMailBoxInfodetails['ServiceExchangeUrl'] = 'https://mail.cognizant.com/ews/Exchange.asmx';
                            //objMailBoxInfodetails['LoginEMailId'] = 'CEmtDev1';
                            //objMailBoxInfodetails['ClientExVersion'] = 'Exchange2010_SP1';
                            //objMailBoxInfodetails['Domain'] = 'cts';
                            //objMailBoxInfodetails['Password'] = 'RTExMTExMSM=';
                            //objMailBoxInfodetails['EMailId'] = 'emtdev1@cognizant.com';
                            //objMailBoxInfodetails['IsLocked'] = false;



                            var processInputdetails = {};
                            processInputdetails['objEmailCaseInfo'] = objEmailCaseInfodetails;
                            processInputdetails['objEmailConversationInfo'] = objEmailConversationInfodetails;
                            processInputdetails['objMailBoxInfo'] = objMailBoxInfodetails;
                            processInputdetails['FollowupConversationId'] = $scope.followupConversationID;
                            processInputdetails['IsForwardToGMB'] = false;
                            processInputdetails['IsFollowUp'] = $scope.IsFollowUp;
                            processInputdetails['UserId'] = $scope.UserId;
                            processInputdetails['ActionDate'] = $scope.currentdate;

                            processInput = {};
                            processInput['processInput'] = processInputdetails;
                            console.log(processInput);
                            //var processcaseapi = "http://localhost:58976/api/processing/ProcessCase"
                            var processcaseapi = APIURL + "ProcessCase/"

                            //file upload chnages

                            var formdata = new FormData();
                            angular.forEach($scope.files, function (value, key) {
                                formdata.append(key, value);
                            });

                          

                            formdata.append('processInput', JSON.stringify(processInputdetails));

                            $http({
                                url: processcaseapi,

                                method: "POST",
                                data: formdata,
                                headers: {
                                    'Content-Type': undefined
                                },
                                transformRequest: angular.identity

                            }).then(function (response) {
                                $scope.Casedetails = response.data;
                                alert("Mail sent successfully");
                                console.log(response);
                                $window.location.reload();
                            }, function (reason) {
                                $scope.error = reason.data;
                                alert("Unable to send mail. Please contact EMT IT team for assistance");
                                console.log(reason);
                            });                         
                                                       
                        }
                        else {
                            alert("Please Enter To Address");
                        }
                    }
                    else {
                        alert("Please Enter Comments");
                    }
                }
            }
        }
    }

    //filedownload
    $scope.download = function (filename, filecontent) {
        var sliceSize = 512;
        var byteCharacters = atob(filecontent);
        var byteArrays = [];
        for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);
            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }
            var byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
        }
        var blob = new Blob(byteArrays, { type: 'image/jpg' });
        var ie = navigator.userAgent.match(/MSIE\s([\d.]+)/),
        ie11 = navigator.userAgent.match(/Trident\/7.0/) && navigator.userAgent.match(/rv:11/),
        ieEDGE = navigator.userAgent.match(/Edge/g),
        ieVer = (ie ? ie[1] : (ie11 ? 11 : (ieEDGE ? 12 : -1)));

        if (ie && ieVer < 10) {
            console.log("No blobs on IE ver<10");
            return;
        }
        if (ieVer > -1) {
            console.log(blob);
            console.log(filename);
            window.navigator.msSaveOrOpenBlob(blob, filename);
        }
            //if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            //    window.navigator.msSaveBlob(blob, 'aa.jpg');
            //}
        else {
            var blobURL = (window.URL || window.webkitURL).createObjectURL(blob);
            var anchor = document.createElement("a");
            anchor.download = filename;
            anchor.href = blobURL;
            anchor.click();
        }
    }


}])
//ProcessingPage.directive('fileread', ['$parse', function ($parse) {
//    return {
//        restrict: 'A',
//        scope: { model: '=' },
//        link: function (scope, element, attrs) {
//            var model = $parse(attrs.ngFileModel);
//            var isMultiple = attrs.multiple;
//            var modelSetter = model.assign;
//            element.bind('change', function () {
//                var values = [];
//                var currentdate = new Date();               
//                angular.forEach(element[0].files, function (item) {
//                    var array1 = [];
//                    var arraystring = '';
//                    var reader = new FileReader();
//                    reader.readAsDataURL(item);
//                    var BASE64_MARKER = ';base64,';
//                    var base64Index = reader.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
//                    var base64 = reader.result.substring(base64Index);
//                    var raw = window.btoa(base64);
//                    var rawLength = raw.length;                        
//                    array1 = new Uint8Array(new ArrayBuffer(rawLength));
//                    for (j = 0; j < rawLength; j++) {
//                         array1[j] = raw.charCodeAt(j);
//                    }
//                    arraystring = array1.toString();
//                    var value = {
//                        // File Name 
//                        name: item.name,
//                        //File Size 
//                        size: item.size,
//                        //File URL to view 
//                        url: URL.createObjectURL(item),
//                        // File Input Value 
//                        //_file: item,
//                        FileContent: arraystring
//                    };
//                    values.push(value);
//                });


//                scope.model[i] = "New value";
//                scope.$apply();
//            });
//        }
//    };
//}]);



//ProcessingPage.directive('fileread', function ($parse) {
//    return {
//        restrict: 'EA',
//        scope: {
//            fileread: "="
//        },
//        link: function (scope, element, attrs) {
//            var model = $parse(attrs.ngFileModel);
//            var isMultiple = attrs.multiple;
//            var modelSetter = model.assign;
//            element.bind('change', function () {
//                var currentdate = new Date();
//                var array = [];
//                for (var i = 0; i < element[0].files.length; i++) {
//                    var reader = new FileReader();
//                    reader.readAsDataURL(element[0].files[i]);
//                    var array1 = [];
//                    var arraystring = '';

//                    var BASE64_MARKER = ';base64,';
//                    var base64Index = reader.result.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
//                    var base64 = reader.result.substring(base64Index);
//                    var raw = window.atob(base64);
//                    var rawLength = raw.length;
//                    array1 = new Int8Array(new ArrayBuffer(rawLength));
//                    for (j = 0; j < rawLength; j++) {
//                        array1[j] = raw.charCodeAt(j);
//                    }
//                    console.log(array1);
//                    arraystring = array1.toString();
//                    console.log(arraystring);
//                    scope.$apply(function () {
//                        scope.filecontent = arraystring;
//                    });

//                    var value = {
//                        Id: 0,
//                        FileName: element[0].files[i].name,
//                        ContentType: element[0].files[i].type,
//                        FileContentString: scope.filecontent,
//                        FileContentBytes:array1,
//                        CreatedDate: currentdate,
//                        AttachmentType: 'File Sent',
//                        AttachmentTypeId: 3,
//                    };
//                    scope.fileread[i] = value;
//                }
//                scope.$apply(function () {
//                    if (isMultiple) {
//                        modelSetter(scope, fileread);
//                    } else {
//                        modelSetter(scope, fileread[0]);
//                    }
//                });
//            });
//        }
//    };
//});

ProcessingPage.directive('ngFiles', ['$parse', function ($parse) {

    function fn_link(scope, element, attrs) {
        var onChange = $parse(attrs.ngFiles);
        element.on('change', function (event) {
            onChange(scope, { $files: event.target.files });
           // $scope.lstUploadedAttachments = $files;
        });
    };

    return {
        link: fn_link
    }
} ])

        
    

//fetch AuditPopup data and design
ProcessingPage.controller('AuditPopupcontroller', function ($scope, $http, uiGridConstants, $mdDialog) {
    $scope.myData = [];
    var Auditapidata = CaseId + "/" + UserId;
    //var Auditapi = "http://localhost:58976/api/processing/GetAuditLog/" + Auditapidata;
    var Auditapi = APIURL + "GetAuditLog/" + Auditapidata;
    $http({
        url: Auditapi,
        xhrFields: {
            withCredentials: false
        },
        dataType: "jsonp",
        method: "GET",
        data: '',
        headers: {
            "Content-Type": "application/json"
        }
    }).then(function (Auditresponse) {
        console.log(Auditresponse);
        $scope.auditLogOptions.data = Auditresponse;
        if (Auditresponse.data.length <= 7) {
            $scope.auditLogOptions.minRowsToShow = Auditresponse.data.length;
        }
        else {
            $scope.auditLogOptions.minRowsToShow = 7;
        }
    }, function (reason) {
        $scope.error = reason.data;
        console.log(error);
    });

    $scope.cancel = function () {
        $mdDialog.cancel();
    };
    $scope.auditLogOptions = {
        enableSorting: false,
        enableColumnMenus: false,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.NEVER,
        columnDefs: [{
            name: 'From Status',
            width: '20%',
            cellClass: 'grid-first-row',
            field: 'FromStatus',
            cellTooltip: true
        }, {
            name: 'To Status',
            width: '20%',
            field: 'ToStatus',
            cellTooltip: true
        }, {
            name: 'User Name',
            width: '20%',
            field: 'ActionBy',
            cellTooltip: true
        }, {
            name: 'Start date',
            width: '20%',
            field: 'FromDate',
            cellTooltip: true
        }, {
            name: 'End date',
            width: '20%',
            field: 'ToDate',
            cellTooltip: true
        }],
        onRegisterApi: function (gridApi) {
            $scope.gridTestModelApi = gridApi;
        }
    };
});



//fetch CommentsPopup data and design
ProcessingPage.controller('CommentsPopupcontroller', function ($scope, $http, $mdDialog, uiGridConstants) {
    var Commentsapidata = CaseId + "/" + UserId;
    var Commentsapi = APIURL + "GetComments/" + Commentsapidata;
    $http({
        url: Commentsapi,
        xhrFields: {
            withCredentials: false
        },
        dataType: "jsonp",
        method: "GET",
        data: '',
        headers: {
            "Content-Type": "application/json"
        }
    }).then(function (Commentsresponse) {
        $scope.CommentsHistory = Commentsresponse.data;
        console.log(Commentsresponse);
        $scope.CommentOptions.data = Commentsresponse.data;
        console.log($scope.CommentOptions.data);
        if (Commentsresponse.data.length <= 7) {
            $scope.CommentOptions.minRowsToShow = Commentsresponse.data.length;
        }
        else {
            $scope.CommentOptions.minRowsToShow = 7;
        }
    }, function (reason) {
        $scope.error = reason.data;
    });

    $scope.cancel = function () {
        $mdDialog.cancel();
    };
    $scope.CommentOptions = {
        enableSorting: false,
        enableColumnMenus: false,
        enableHorizontalScrollbar: uiGridConstants.scrollbars.NEVER,
        columnDefs: [{
            name: 'Comments',
            width: '33%',
            cellClass: 'grid-first-row',
            field: 'CommentDescription',
            cellTooltip: true
        }, {
            name: 'User',
            width: '33%',
            field: 'CommentedBy',
            cellTooltip: true
        }, {
            name: 'Date',
            width: '33%',
            field: 'CommentedDate',
            cellTooltip: true
        }],
        onRegisterApi: function (gridApi) {
            $scope.gridTestModelApi = gridApi;
        }
    };
});


