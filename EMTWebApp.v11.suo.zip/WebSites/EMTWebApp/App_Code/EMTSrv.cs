﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;
using EMTWebApp.Common.Views;
using Microsoft.Practices.EnterpriseLibrary.Data;
using EMTWebApp.UserManagement.Common;
using EMTWebApp.Common;
using System.Text.RegularExpressions;
using System.Net;
using EMTWebApp.Constants;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using DigiOPS.TechFoundation.Security;
using DigiOPS.TechFoundation.EMTAccessControl;
using DigiOPS.TechFoundation.Entities;
using System.Web.Script.Serialization;
using System.Web.Script.Services;


/// <summary>
/// Summary description for EMTSrv
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class EMTSrv : System.Web.Services.WebService, IWorkQueueView
{
    private WorkQueuePresenter _presenter;
    UserSession userData = new UserSession();
    CommonController objCon = new CommonController();
    CryptInfo cryptInfo = new CryptInfo();
    SecurityFactory securityFactory = new SecurityFactory();
    

    string cipher = System.Configuration.ConfigurationManager.AppSettings["ENCRYPTIONKEY"].ToString();
   
    public EMTSrv()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld()
    {
        return "Hello World";
    }

    [WebMethod(EnableSession = true)]
    public List<Dictionary<string, object>> GetWorkQueueList(string subProcessName,string mailBoxName,string classificationName, string statusName, string selectedUserId, int PageIndex, int Pagesize, string SortExpName, string SortExpOrder)
     {
        UserSession objUser = (UserSession)Session["userdetails"];
        //int MailBoxId, StatusId;
        if (SortExpName == "ReceivedDate")
        {
            SortExpName = "EmailReceivedDate";
        }
        else if (SortExpName == "Sender")
        {
            SortExpName = "EMailFrom";
        }
        else if (SortExpName == "AssignedTo")
        {
            SortExpName = "FirstName";
        }
        else if (SortExpName == "Priority")
        {
            SortExpName = "IsUrgent";
        }
        string UserId;
        UserId = string.Empty;
        userData = (UserSession)HttpContext.Current.Session["userdetails"];
        UserId = selectedUserId;

        DataSet dsWorkQueueList = new DataSet();
        Hashtable ht = new Hashtable();
        ht.Add("@SubProcessName", subProcessName);

        string StatusName = Regex.Replace(statusName, @"\d+$", string.Empty);
        ht.Add("@Status", StatusName);
        ht.Add("@LoggedInUserId", UserId);

        ht.Add("@PageIndex", PageIndex);
        ht.Add("@PageSize", Pagesize);

        ht.Add("@SortExpName", SortExpName);
        ht.Add("@SortExpOrder", SortExpOrder);

        if (classificationName != "" && classificationName != null)
        {
            ht.Add("@EMailboxName", mailBoxName);
            ht.Add("@ClassificationName", classificationName);
            dsWorkQueueList = objCon.GetWorkQueueList_mailboxlevel(ht);
        }
        else
        {
            ht.Add("@EMailboxName", mailBoxName);
            dsWorkQueueList = objCon.GetWorkQueueList(ht);
        }
        

        string[] strResult = new string[2];

        System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> row;
        foreach (DataRow dr in dsWorkQueueList.Tables[1].Rows)
        {
            row = new Dictionary<string, object>();
            foreach (DataColumn col in dsWorkQueueList.Tables[1].Columns)
            {
                if (col.ColumnName == "ReceivedDate")
                {
                    //Varma - Timezone Feature On&OFF functionality 
                    if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                    {
                        // DateTime dateRecieved = Convert.ToDateTime(dr[col].ToString());
                        DateTime dateRecieved = DateTime.ParseExact(dr[col].ToString(), "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
                        String zonedDateTime = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(dateRecieved.ToString("dd/MM/yyyy HH:mm:ss"), true, objUser.TimeZone, false) + "(" + objUser.TimeZone + ")";
                        row.Add(col.ColumnName, zonedDateTime);
                    }
                    else 
                    {
                        DateTime dateRecieved = Convert.ToDateTime(dr[col].ToString());
                        row.Add(col.ColumnName, dateRecieved.ToString("dd/MM/yyyy HH:mm:ss"));
                    }
                }
                else if (col.ColumnName == "Subject" && col.ColumnName !=null)
                {
                    //Decryption
                     string decryptedValue = HelperMethods.DecryptString(dr[col].ToString());                        
                     //cryptInfo.CryptKey = cipherpassword;
                     //cryptInfo.ValueToCrypt = dr[col].ToString();
                     //string decryptedValue = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
                     row.Add(col.ColumnName, decryptedValue);                    
                }
                else
                {
                    row.Add(col.ColumnName, dr[col]);
                }
            }
            rows.Add(row);
        }
        return rows;

    }

    [WebMethod(EnableSession = true)]
    public List<Dictionary<string, object>> GetWorkQueueList1(string statusName, string selectedUserId, int PageIndex, int Pagesize, string SortExpName, string SortExpOrder)
    {
        UserSession objUser = (UserSession)Session["userdetails"];
        //int MailBoxId, StatusId;
        if (SortExpName == "ReceivedDate")
        {
            SortExpName = "EmailReceivedDate";
        }
        else if (SortExpName == "Sender")
        {
            SortExpName = "EMailFrom";
        }
        else if (SortExpName == "AssignedTo")
        {
            SortExpName = "FirstName";
        }
        else if (SortExpName == "Priority")
        {
            SortExpName = "IsUrgent";
        }
        string UserId;
        UserId = string.Empty;
        userData = (UserSession)HttpContext.Current.Session["userdetails"];
        UserId = selectedUserId;
        DataSet dsWorkQueueList = new DataSet();

        Hashtable ht = new Hashtable();

        ht.Add("@Status", statusName);
        ht.Add("@LoggedInUserId", UserId);

        ht.Add("@PageIndex", PageIndex);
        ht.Add("@PageSize", Pagesize);


        ht.Add("@SortExpName", SortExpName);
        ht.Add("@SortExpOrder", SortExpOrder);

        dsWorkQueueList = objCon.GetWorkQueueList(ht);
        string[] strResult = new string[2];

        System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> row;
        foreach (DataRow dr in dsWorkQueueList.Tables[1].Rows)
        {
            row = new Dictionary<string, object>();
            foreach (DataColumn col in dsWorkQueueList.Tables[1].Columns)
            {
                if (col.ColumnName == "ReceivedDate")
                {
                    //Varma - Timezone Feature On&OFF functionality 
                    if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                    {

                        DateTime dateRecieved = DateTime.ParseExact(dr[col].ToString(), "dd/MM/yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
                        String zonedDateTime = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(dateRecieved.ToString("dd/MM/yyyy HH:mm:ss"), true, objUser.TimeZone, false) + "(" + objUser.TimeZone + ")";
                        row.Add(col.ColumnName, zonedDateTime);
                    }
                    else 
                    {
                        DateTime dateRecieved = Convert.ToDateTime(dr[col].ToString());
                        row.Add(col.ColumnName, dateRecieved.ToString("dd/MM/yyyy HH:mm:ss"));
                    }
                }
                else
                {
                    row.Add(col.ColumnName, dr[col]);
                }
            }
            rows.Add(row);
        }
        return rows;

    }

    public string ConvertDataTabletoString(DataTable dt)
    {
        System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> row;
        foreach (DataRow dr in dt.Rows)
        {
            row = new Dictionary<string, object>();
            foreach (DataColumn col in dt.Columns)
            {
                row.Add(col.ColumnName, dr[col]);
            }
            rows.Add(row);
        }
        return serializer.Serialize(rows);
        
    }

    [WebMethod]
    public int Classificationcheck()
    {
        //DataTable dt = new DataTable();
        int dt= objCon.Classificationcheck(ConfigurationManager.ConnectionStrings["ConnStr"].ToString());        
        return dt;
    }

    [WebMethod]
    public string EmailboxNames(string ClassificationResult,string CountryId, string LoggedInUserId, string RoleId, string SelectedAssociateId, string SelectedSubProcessId)
    {       
        try
        {
            string strResult="";
            Regex regex = new Regex(@"^[0-9]{0,10}$");
            Match match = regex.Match(SelectedSubProcessId);
            Match matchSelectedAssociateId =regex.Match(SelectedAssociateId);
            Match matchRoleId =regex.Match(RoleId);
            Match matchLoggedInUserId = regex.Match(LoggedInUserId);
            Match matchCountryId = regex.Match(CountryId);
            if (match.Success&&matchSelectedAssociateId.Success&&matchRoleId.Success&&matchLoggedInUserId.Success&&matchCountryId.Success)
            {
                DataTable dt = new DataTable();
                if (ClassificationResult == "1")
                {
                    dt = objCon.EmailboxNameswithclassification(CountryId, LoggedInUserId, RoleId, SelectedAssociateId, SelectedSubProcessId,
                    ConfigurationManager.ConnectionStrings["ConnStr"].ToString());
                    //string strResult = ConvertDataTabletoString(dt);
                    strResult = ConvertDataTabletoString(dt);
                    return strResult;
                }
                else
                {
                    dt = objCon.EmailboxNames(CountryId, LoggedInUserId, RoleId, SelectedAssociateId, SelectedSubProcessId,
                    ConfigurationManager.ConnectionStrings["ConnStr"].ToString());
                    //string strResult = ConvertDataTabletoString(dt);
                    strResult = ConvertDataTabletoString(dt);
                    return strResult;
                }
            }
            else
            {
                return strResult;
            }
            
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
        finally
        {
            
        }
    }

    
    [WebMethod(EnableSession=true)]
    public string EmailboxDynamicStatuses(string ClassificationResult, string Country, string Emailbox, string SubProcess)
    {        
        try
        {
            UserSession objUser = (UserSession)Session["userdetails"];
            String UserId;
            if (objUser.RoleId == 4)
            {
                UserId = objUser.UserId;
            }
            else
            {
                UserId = "0";
            }
            DataTable dt = new DataTable();
            if (ClassificationResult == "1")
            {                
               // dt = objCon.EmailboxStatuseswithclassification(Country, Emailbox, SubProcess, UserId, ConfigurationManager.ConnectionStrings["ConnStr"].ToString());
            }
            else
            {                
                dt = objCon.EmailboxStatuses(Country, Emailbox, SubProcess, UserId, ConfigurationManager.ConnectionStrings["ConnStr"].ToString());
            }
            string strResult = ConvertDataTabletoString(dt);
            return strResult;
        }
        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            throw ex;
        }
        finally
        {
            //connection.Close();
        }
    }

    [WebMethod(EnableSession = true)]
    public void UpdateUserrole(string RoleId, string RoleName)
    {
        Session["UserID"] = null;
        //Regex regex = new Regex("^[a-zA-Z0-9 ]+$");
        Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
        Regex regexNumeric = new Regex(@"^[0-9]{0,10}$");

        Match matchRoleName = regex.Match(RoleName);
        Match matchRoleId = regexNumeric.Match(RoleId);
        if (matchRoleId.Success && matchRoleName.Success)
        {
            bool session = IsSessionValid();
            if (session == true && (Convert.ToInt32(RoleId) >= 1 && Convert.ToInt32(RoleId) <= 5))
            {
                userData.RoleName = RoleName;
                userData.RoleId = Convert.ToInt32(RoleId);
            }
            Session["UserID"] = userData.UserId;
        }
    }

    private bool IsSessionValid()
    {
        userData = (UserSession)Session["UserDetails"];
        if (userData == null)
            return false;
        else
            return true;

    }
    public class RoleList
    {
        public int RoleId { get; set; }
        public string RoleDescription { get; set; }
    }
    [WebMethod(EnableSession=true)]
    public List<RoleList> RoleNamesList(string UserId)
    {
        Session["RoleIDForUser"] = null;
        Session["RoleNameForUser"] = null;
        //Regex regex = new Regex("^[a-zA-Z0-9 ]+$");
        Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
        Match matchUserId = regex.Match(UserId);
        if (matchUserId.Success)
        {
            List<RoleList> objRole = new List<RoleList>();
            //Pranay Added 
            List<String> listroleid = new List<String>();
            List<String> listrolename = new List<String>();
            string spName = "GetUserRoleList";
            DataTable dt = new DataTable();
            string connString = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand(spName, conn);
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.AddWithValue("@UserId", UserId);

                        da.Fill(dt);
                    }
                }

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    listroleid.Add(dt.Rows[i]["RoleId"].ToString());
                    listrolename.Add(dt.Rows[i]["RoleDescription"].ToString());
                    objRole.Add(new RoleList
                    {
                        RoleId = Convert.ToInt32(dt.Rows[i]["RoleId"]),
                        RoleDescription = dt.Rows[i]["RoleDescription"].ToString()
                    });
                }
                
                    Session["RoleIDForUser"] = listroleid;
                    Session["RoleNameForUser"] = listrolename;
                
            }

            catch (Exception e)
            {
                throw e;
            }
            return objRole;
        }
        else
            return null;
    }//}

    [WebMethod]

    public string EncryptCredentials(string LoginValue)
    {
        string EncryptedValue = HelperMethods.DecryptValue(LoginValue);
        EncryptedValue = HelperMethods.EncryptCredentials(EncryptedValue);
        return EncryptedValue;
    }

    [WebMethod(EnableSession = true)]

    public void Draft_calling(string CaseId, string LoggedInUserId, string Content,string RadioButton, string ToAddress, string CcAddress, int IsHighImportance, int IsShowQuotedText, string SelectedCheckbox)
    {

        Hashtable hsDraft = new Hashtable();
        hsDraft.Add("@CASEID", Convert.ToInt32(CaseId));
        hsDraft.Add("@AssignedId", LoggedInUserId);
        hsDraft.Add("@ToAddress", ToAddress);
        hsDraft.Add("@CcAddress", CcAddress);
        hsDraft.Add("@RadioButtonSelected", RadioButton);
        hsDraft.Add("@IsHighImportance", IsHighImportance);
        hsDraft.Add("@ShowQuotedText", IsShowQuotedText);
        hsDraft.Add("@SelectedAttachments", SelectedCheckbox);
        string Source = Content;
        DateTime now = DateTime.UtcNow;
        hsDraft.Add("@currentdate", now);
        var imgSrcMatches_Draft = System.Text.RegularExpressions.Regex.Matches(Source,
            //string.Format("<img.+?src=[\"'](.+?)[\"'].*?>"),  
                           string.Format("<img.*src=[\"'](.+?)[\"'].*>"),
                                       RegexOptions.CultureInvariant | RegexOptions.IgnoreCase |
                                       RegexOptions.Multiline);
        List<string> imgSrcs_Draft = new List<string>();

        foreach (Match match in imgSrcMatches_Draft)
        {
            string srcvalue = match.Groups[1].Value;
            try
            {
                if (srcvalue.Contains("data:image/png;base64"))
                {
                    imgSrcs_Draft.Add(srcvalue.Replace("data:image/png;base64,", ""));

                    byte[] imgArray = Convert.FromBase64String(srcvalue.Replace("data:image/png;base64,", "").Replace(' ', '+'));
                    
                }
                else if (srcvalue.Contains("data:image/jpeg;base64,"))
                {
                    imgSrcs_Draft.Add(srcvalue.Replace("data:image/jpeg;base64,", ""));

                    byte[] imgArray = Convert.FromBase64String(srcvalue.Replace("data:image/jpeg;base64,", "").Replace(' ', '+'));
                  
                }
                else
                {
                    byte[] imageArray;
                    
                    using (var webClient = new WebClient())
                    {
                        imageArray = webClient.DownloadData(srcvalue);
                    }

                    string base64ImageRepresentation = Convert.ToBase64String(imageArray);

                    if (base64ImageRepresentation.Contains("data:image/png;base64,"))
                        imgSrcs_Draft.Add(base64ImageRepresentation.Replace("data:image/png;base64,", ""));

                    else if (base64ImageRepresentation.Contains("data:image/jpeg;base64,"))
                        imgSrcs_Draft.Add(base64ImageRepresentation.Replace("data:image/jpeg;base64,", ""));
                    else
                        imgSrcs_Draft.Add(base64ImageRepresentation);
                }

                Source = Source.Replace(srcvalue, "cid:image000" + ".png");
              
            }
            catch
            {

            }
        }

        if (imgSrcs_Draft.Count > 0)
        {
            IList InlineAttachments;
            List<EMTWebApp.Constants.Attachment> lstInline = new List<EMTWebApp.Constants.Attachment>();

            int aa = 0;


            foreach (string imgcontent in imgSrcs_Draft)
            {
                EMTWebApp.Constants.Attachment at = new EMTWebApp.Constants.Attachment();

                string Name = "";



                if (aa > 99)
                    Name = "cid:image0" + aa + ".png";
                else if (aa >= 10 && aa <= 99)
                    Name = "cid:image00" + aa + ".png";
                else
                    Name = "cid:image000" + aa + ".png";

                at.FileName = Name;
                at.FileType = ".png";
                //string actualInlineimg = imgcontent.Replace(" ", "+");
                
                //cryptInfo.CryptKey = cipherpassword;
                //cryptInfo.ValueToCrypt = actualInlineimg;
                //string encryptedInlineimg = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
                //at.FileContent = Convert.FromBase64String(encryptedInlineimg);
                at.FileContent = HelperMethods.EncryptAttachments(Convert.FromBase64String(imgcontent.Replace(" ", "+").ToString()));                    
                //at.FileContent = Convert.FromBase64String(imgcontent.Replace(" ", "+").ToString());
                at.AttachmentTypeId = 3;

                lstInline.Add(at);
                aa = aa + 1;

            }
            if (lstInline.Count > 0)
            {
                InlineAttachments = lstInline;

                objCon.DeleteLastDraft(Convert.ToInt64(CaseId));
                objCon.UploadAttachment_Draft(Convert.ToInt64(CaseId), InlineAttachments, LoggedInUserId); //Upload followup file to DB
            }

        }
        else
        {
            objCon.DeleteLastDraft(Convert.ToInt64(CaseId));
        }
        string plainbody = Source;
        
        //cryptInfo.CryptKey = cipherpassword;
        //cryptInfo.ValueToCrypt = plainbody;
        //string encryptedPlainBody = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
        string encryptedPlainBody = HelperMethods.EncryptString(plainbody);
        byte[] bt = Encoding.ASCII.GetBytes(encryptedPlainBody);
       
        hsDraft.Add("@Content", bt);
        int count = objCon.draft_save(hsDraft);

    }


    [WebMethod]
    public List<DonutchartCount> GetDonutChartData(string countryName, string subprocessName, string mailboxName, string UID, string roleID)
    {
        List<DonutchartCount> lChartdtls = new List<DonutchartCount>();
        try
        {
            if (String.IsNullOrEmpty(countryName))
            {
                countryName = string.Empty;
            }
            if (String.IsNullOrEmpty(subprocessName))
            {
                subprocessName = string.Empty;
            }
            if (String.IsNullOrEmpty(mailboxName))
            {
                mailboxName = string.Empty;
            }
            if (String.IsNullOrEmpty(UID))
            {
                UID = string.Empty;
            }
            if (String.IsNullOrEmpty(roleID))
            {
                roleID = string.Empty;
            }

            string spName = "SP_GetDonutChartDtls_new";
            DataTable dt = new DataTable();
            dt = ExecuteSP(spName, countryName, subprocessName, mailboxName, UID, roleID);
            int sWithcognCount = 0;
            int sInworkCount = 0;
            List<ChartModel> lstchart = new List<ChartModel>();
            DonutchartCount lstcount = new DonutchartCount();
            foreach (DataRow dr in dt.Rows)
            {
                //statusid 1 - Open, 2 - Assigned, 3- clarification Needed, 4 - Clarification Provided
                //if (dr["Statusid"].ToString() == "1" || dr["Statusid"].ToString() == "2" ||
                //    dr["Statusid"].ToString() == "3" || dr["Statusid"].ToString() == "4")
                //{
                    lstchart.Add(new ChartModel
                    {
                        Name = dr["STATUSDESCRIPTION"].ToString(),
                        Count = dr["StatusCount"].ToString()
                    });
                    //if (dr["Statusid"].ToString() != "3")
                    //{
                    //    sWithcognCount += (Convert.ToInt32(dr["StatusCount"]));
                    //}
                    //else
                    //{
                    //    sInworkCount += (Convert.ToInt32(dr["StatusCount"]));
                    //}

                //}

            }
            lstcount.chartdtls = lstchart;
            lstcount.Incogncount = sWithcognCount.ToString();
            lstcount.WithoutcognCount = sInworkCount.ToString();
            lChartdtls.Add(lstcount);

            return lChartdtls;
        }
        catch (Exception e)
        {

        }
        return lChartdtls;
    }


    public DataTable ExecuteSP(string roleName)
    {

        string connString = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();

        DataTable dt = new DataTable();
        try
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    da.SelectCommand = new SqlCommand("USP_GET_RoleID", conn);
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.AddWithValue("@RoleName", roleName);
                    DataSet ds = new DataSet();
                    da.Fill(dt);
                }
            }
            return dt;
        }

        catch (Exception e)
        {
            throw e;
        }
    }



    public DataTable ExecuteSP(string spName, string country, string subprocessName, string mailboxName, string UserID, string RoleID)
    {

        string connString = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();

        DataTable dt = new DataTable();
        try
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    da.SelectCommand = new SqlCommand(spName, conn);
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.AddWithValue("@Country", country);
                    da.SelectCommand.Parameters.AddWithValue("@SubprocessName", subprocessName);
                    da.SelectCommand.Parameters.AddWithValue("@MailBoxName", mailboxName);
                    da.SelectCommand.Parameters.AddWithValue("@UserID", UserID);
                    da.SelectCommand.Parameters.AddWithValue("@RoleID", RoleID);
                    DataSet ds = new DataSet();
                    da.Fill(dt);
                }
            }
            return dt;
        }

        catch (Exception e)
        {
            throw e;
        }
    }


    public DataTable ExecuteSPName(string spName)
    {

        string connString = ConfigurationManager.ConnectionStrings["ConnStr"].ToString();

        DataTable dt = new DataTable();
        try
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter())
                {
                    da.SelectCommand = new SqlCommand(spName, conn);
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;

                    DataSet ds = new DataSet();
                    da.Fill(dt);
                }
            }
            return dt;
        }

        catch (Exception e)
        {
            throw e;
        }
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)] 
    public string GetACLMenu(string UserID, int RoleID)
    {
        ACLMenu objACL = new ACLMenu();
        List<ACL> lstACL = new List<ACL>();
        //var jsonSerialiser = new JavaScriptSeralizer();
        lstACL = objACL.GetACLMenuList(UserID, RoleID);
        //string strjson = jsonSerialiser.Serialize(lstACL);
        return new JavaScriptSerializer().Serialize(lstACL); 
    }

    [WebMethod(EnableSession = true)]

    public string getRoleID(string roleName)
    {
        DataTable dt = new DataTable();
        dt=ExecuteSP(roleName);
        string strRoleID=string.Empty;
        Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
        Regex regexNumeric = new Regex(@"^[0-9]{0,10}$");
        if (dt.Rows.Count > 0)
        {
            strRoleID = Convert.ToString(dt.Rows[0]["UserRoleId"]);

            Match matchRoleName = regex.Match(roleName);
            Match matchRoleId = regexNumeric.Match(strRoleID);

            userData = (UserSession)HttpContext.Current.Session["userdetails"];
            if (matchRoleId.Success && matchRoleName.Success)
            {
                //bool session = IsSessionValid();
                if (Convert.ToInt32(strRoleID) >= 1)
                {
                    userData.RoleName = Convert.ToString(dt.Rows[0]["RoleDescription"]);
                    userData.RoleId = Convert.ToInt32(strRoleID);
                }

            }
            Session["UserDetails"] = userData;
            strRoleID = Convert.ToString(dt.Rows[0]["UserRoleId"]) + "~" + Convert.ToString(dt.Rows[0]["RoleDescription"]);
        }
        return strRoleID;
    }

    [WebMethod]
    public List<StackedbarChartModel> GetStackedbarChartData(string countryName, string subprocessName, string mailboxName, string UID, string roleID)
    {
        
        List<StackedbarChartModel> lstkedchart = new List<StackedbarChartModel>();
        try
        {
            string spName = "SP_GetStakedBarChartData_new";
            DataTable dt = new DataTable();            
            Regex regex = new Regex(@"^[a-zA-Z0-9_ ]*$");
            Regex regexNumeric = new Regex(@"^[0-9]{0,10}$");
            
            Match matchCountry = regex.Match(countryName);
             Match matchsubprocessName= regex.Match(subprocessName);
             Match matchmailboxName = regex.Match(mailboxName);
             Match matchUID = regexNumeric.Match(UID);
             Match matchRoleID = regexNumeric.Match(roleID);
             if (matchCountry.Success && matchsubprocessName.Success && matchmailboxName.Success&&matchUID.Success&&matchRoleID.Success)
            {
                dt = ExecuteSP(spName, countryName, subprocessName, mailboxName, UID, roleID);

                DataTable dtStatus = new DataTable();

                dtStatus.Columns.Add("StatusCount", typeof(int));
                dtStatus.Columns.Add("StatusID", typeof(int));
                dtStatus.Columns.Add("StatusName", typeof(string));
                dtStatus.Columns.Add("SubProcessGroupId", typeof(int));
                dtStatus.Columns.Add("SubprocessName", typeof(string));

                DataView view = new DataView(dt);

                //DataTable distinctValues = view.ToTable(true, new string[2] { "SubProcessGroupId", "SubprocessName" });
                string SP_fetchdynamicstatus = "SP_GetStackBarChartDefaultDynamicStatus";
                 DataTable distinctValues = ExecuteSP(SP_fetchdynamicstatus, countryName, subprocessName, mailboxName, UID, roleID);
                foreach (DataRow item in distinctValues.Rows)
                {
                    //dtStatus.Rows.Add(0, 1, "Open", item["SubProcessGroupId"].ToString(), item["SubprocessName"].ToString());
                    //dtStatus.Rows.Add(0, 2, "Assigned", item["SubProcessGroupId"].ToString(), item["SubprocessName"].ToString());
                    //dtStatus.Rows.Add(0, 3, "Clarification Needed", item["SubProcessGroupId"].ToString(), item["SubprocessName"].ToString());
                    //dtStatus.Rows.Add(0, 4, "Clarification Provided", item["SubProcessGroupId"].ToString(), item["SubprocessName"].ToString());
                    //dtStatus.Rows.Add(0, 5, "Pending for QC", item["SubProcessGroupId"].ToString(), item["SubprocessName"].ToString());
                    //dtStatus.Rows.Add(0, 7, "QC Accepted", item["SubProcessGroupId"].ToString(), item["SubprocessName"].ToString());
                    //dtStatus.Rows.Add(0, 8, "QC Rejected", item["SubProcessGroupId"].ToString(), item["SubprocessName"].ToString());
                    //dtStatus.Rows.Add(0, 10, "Completed", item["SubProcessGroupId"].ToString(), item["SubprocessName"].ToString());
                    dtStatus.Rows.Add(0, item["StatusID"], item["StatusName"], item["SubProcessGroupId"].ToString(), item["SubprocessName"].ToString());
                }
                foreach (DataRow item in dtStatus.Rows)
                {
                    foreach (DataRow rw in dt.Rows)
                    {
                        if (Convert.ToInt32(item["StatusID"]) == Convert.ToInt32(rw["StatusID"])
                            && Convert.ToInt32(item["SubProcessGroupId"]) == Convert.ToInt32(rw["SubProcessGroupId"]))
                        {

                            item["StatusCount"] = rw["StatusCount"];
                        }
                    }
                }

                dtStatus.AcceptChanges();

                StackedbarChartModel objstak = new StackedbarChartModel();
                int SubGroupid = 0;
                bool bset = false;

                var drs1 = (from DataRow dRow in dtStatus.Rows
                            select dRow["SubProcessGroupId"]).Distinct();
                var drs2 = (from row in dtStatus.AsEnumerable()
                            select row.Field<string>("SubProcessGroupId")).Distinct();

                DataRow[] dR;
                foreach (DataRow dr in dtStatus.Rows)
                {
                    if (SubGroupid != Convert.ToInt32(dr["SubProcessGroupId"]))
                    {
                        //objstak.key = dr["SubprocessName"].ToString();
                        //SAST fix for "Data Filter Injection" - varma
                        string SProceename = dr["SubprocessName"].ToString().Replace("'", "");
                        dR = dtStatus.Select("SubprocessName = '" + SProceename + "'");
                        SubGroupid = Convert.ToInt32(dr["SubProcessGroupId"]);
                        List<ChartModel> lstchart = new List<ChartModel>();
                        foreach (var item in dR)
                        {
                            lstchart.Add(new ChartModel
                            {
                                Name = item["StatusName"].ToString(),
                                Count = item["StatusCount"].ToString()
                            });
                        }
                        //objstak.chartdtls = lstchart;
                        lstkedchart.Add(new StackedbarChartModel
                        {
                            key = dr["SubprocessName"].ToString(),
                            values = lstchart
                        });

                    }
                }
                return lstkedchart;
            }
            else
            {                
                return lstkedchart;
            }
        }
        catch (Exception e)
        {
            throw e;
        }

    }

    public static DataTable JoinTwoDataTablesOnOneColumn(DataTable dtblLeft, DataTable dtblRight, string colToJoinOn, int joinType)
    {
        //Change column name to a temp name so the LINQ for getting row data will work properly.
        string strTempColName = colToJoinOn + "_2";
        if (dtblRight.Columns.Contains(colToJoinOn))
            dtblRight.Columns[colToJoinOn].ColumnName = strTempColName;

        //Get columns from dtblLeft
        DataTable dtblResult = dtblLeft.Clone();

        //Get columns from dtblRight
        var dt2Columns = dtblRight.Columns.OfType<DataColumn>().Select(dc => new DataColumn(dc.ColumnName, dc.DataType, dc.Expression, dc.ColumnMapping));

        //Get columns from dtblRight that are not in dtblLeft
        var dt2FinalColumns = from dc in dt2Columns.AsEnumerable()
                              where !dtblResult.Columns.Contains(dc.ColumnName)
                              select dc;

        //Add the rest of the columns to dtblResult
        dtblResult.Columns.AddRange(dt2FinalColumns.ToArray());

        //No reason to continue if the colToJoinOn does not exist in both DataTables.
        if (!dtblLeft.Columns.Contains(colToJoinOn) || (!dtblRight.Columns.Contains(colToJoinOn) && !dtblRight.Columns.Contains(strTempColName)))
        {
            if (!dtblResult.Columns.Contains(colToJoinOn))
                dtblResult.Columns.Add(colToJoinOn);
            return dtblResult;
        }

        switch (joinType)
        {

            default:
            case 0:
                #region Inner
                //get row data
                //To use the DataTable.AsEnumerable() extension method you need to add a reference to the System.Data.DataSetExtension assembly in your project. 
                var rowDataLeftInner = from rowLeft in dtblLeft.AsEnumerable()
                                       join rowRight in dtblRight.AsEnumerable() on rowLeft[colToJoinOn] equals rowRight[strTempColName]
                                       select rowLeft.ItemArray.Concat(rowRight.ItemArray).ToArray();


                //Add row data to dtblResult
                foreach (object[] values in rowDataLeftInner)
                    dtblResult.Rows.Add(values);

                #endregion
                break;
            case 1:
                #region Left
                var rowDataLeftOuter = from rowLeft in dtblLeft.AsEnumerable()
                                       join rowRight in dtblRight.AsEnumerable() on rowLeft[colToJoinOn] equals rowRight[strTempColName] into gj
                                       from subRight in gj.DefaultIfEmpty()
                                       select rowLeft.ItemArray.Concat((subRight == null) ? (dtblRight.NewRow().ItemArray) : subRight.ItemArray).ToArray();


                //Add row data to dtblResult
                foreach (object[] values in rowDataLeftOuter)
                    dtblResult.Rows.Add(values);

                #endregion
                break;
        }

        //Change column name back to original
        dtblRight.Columns[strTempColName].ColumnName = colToJoinOn;

        //Remove extra column from result
        dtblResult.Columns.Remove(strTempColName);

        return dtblResult;
    }


    public DataTable CompareRows(DataTable dtStatus, DataTable dt)
    {

        DataTable dtNew = new DataTable();
       

        return null;
    }

    public class ChartModel
    {
        public string Name { get; set; }
        public string Count { get; set; }
    }

    public class DonutchartCount
    {
        public List<ChartModel> chartdtls { get; set; }
        public string Incogncount { get; set; }
        public string WithoutcognCount { get; set; }
    }

    public class StackedbarChartModel
    {
        public string key { get; set; }
        public List<ChartModel> values { get; set; }

    }

    public static class Utils
    {
        public static string GenerateToken()
        {
            var token = Guid.NewGuid().ToString();
            HttpContext.Current.Session["RequestVerificationToken"] = token;
            return token;
        }
    }
        
}



