﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DirectoryBrowsing
/// </summary>
public class DirectoryBrowsing : IHttpHandler
{
    public void ProcessRequest(HttpContext context)
    {
        context.Response.StatusCode = 404;
    }

    public bool IsReusable
    {
        get
        {
            return false;
        }
    }


}