﻿using System;
using Microsoft.Practices.ObjectBuilder;
using System.Data;
using System.Collections;
using EMTWebApp.ExceptionHandler;
using EMTWebApp.UserManagement.Common;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Data.SqlTypes;
using EMTWebApp.Constants;
using System.IO;
using System.Threading;
using System.Text;
using DigiOPS.TechFoundation.Logging;
using System.Globalization;

namespace EMTWebApp.Reports.Views
{
    public partial class Reports_TATSplitup : Microsoft.Practices.CompositeWeb.Web.UI.Page, ITATSplitupView
    {
        #region DECLARATION
        private TATSplitupPresenter _presenter;
        UserSession objUser = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            lblNoRecord.Text = "";
            lblNoRecord.Style.Add("display", "none");
            if (Session["userdetails"] != null)
            {
                Session["CurrentPage"] = "Reports";
                objUser = (UserSession)Session["userdetails"];
                IsValidRoleToAccessThisPage(objUser);
                if (!this.IsPostBack)
                {
                    //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                    string PKeyword = (Session["PasswordExpiration"]).ToString();
                    if (PKeyword == "yes")
                    {
                        Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                    }
                    try
                    {
                        Page.Form.DefaultButton = btnExportExcel.UniqueID;
                        txtFromDate.Attributes.Add("OnFocusOut", "javascript:return FormatFromDate()");
                        txtToDate.Attributes.Add("OnFocusOut", "javascript:return FormatToDate()");
                        if (Request.QueryString["CaseId"] != null)
                        {
                            hdnReportType.Value=Server.HtmlEncode(Request.QueryString["ReportType"]);
                            //hdnReportType.Value = Session["ReportType"].ToString();
                        }
                      //  hdnReportType.Value = Request.QueryString["ReportType"];
                        // btnSearch.Attributes.Add("OnClientClick", "return isNumber();");
                        IsSessionValid();
                        
                        BindCountry();
                        //BindSubProcess();
                        ReportNameBinding();

                        this._presenter.OnViewInitialized();
                    }
                    catch (Exception ex)
                    {
                        new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | Page_Load()");  
                        //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | Page_Load()");
                        Response.Redirect("~/Errors/Error.aspx",false);
                    }
                }
            }
            else
            {
                Response.Redirect("~/Errors/SessionExpired.aspx", false);
            }
            this._presenter.OnViewLoaded();
        }
               
        #region PROPERTIES
        [CreateNew]
        public TATSplitupPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion

        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserDetails)
        {
            try
            {
                if ((UserDetails.RoleId == (int)Constant.UserRole.SuperAdmin) || (UserDetails.RoleId == (int)Constant.UserRole.Admin) || (UserDetails.RoleId == (int)Constant.UserRole.TeamLead) || (UserDetails.RoleId == (int)Constant.UserRole.ClientUser))
                {
                    return true;
                }
                else
                {
                    Response.Redirect(@"~\Errors\AccessDenied.aspx", false);
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | TatSplitup.aspx.cs | IsValidRoleToAccessThisPage()");  
                //errorlog.HandleError(Ex, UserDetails.UserId, " | TatSplitup.aspx.cs | IsValidRoleToAccessThisPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
            return false;
        }


        private void IsSessionValid()
        {
            try
            {
                objUser = (UserSession)Session["userdetails"];
                if (objUser == null)
                    Response.Redirect(@"~\Errors\SessionExpired.aspx", false);
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | IsSessionValid()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | IsSessionValid()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

        }

        /// <summary>
        /// Function to Bind the Country Details to the dropdown
        /// </summary>
        private void BindCountry()
        {
            try
            {
                ddlCountry.Items.Clear();
                //ddlCountry.Enabled = false;
                ddlEMailbox.Enabled = false;
                DataSet dsCountry = new DataSet();
                Hashtable htUserData = new Hashtable();
                htUserData.Add("@AssociateId", !string.IsNullOrEmpty(objUser.UserId) ? objUser.UserId : "");
                htUserData.Add("@roleid", (objUser.RoleId > 0) ? Convert.ToString(objUser.RoleId) : "");
                dsCountry = _presenter.GetCountryByUserIdForDashboard(htUserData);

                if (dsCountry.Tables[0].Rows.Count > 0)
                {
                    ddlCountry.DataSource = dsCountry;
                    ddlCountry.DataTextField = "COUNTRY";
                    ddlCountry.DataValueField = "COUNTRYID";
                    ddlCountry.DataBind();
                    if (dsCountry.Tables[0].Rows.Count == 1)
                    {
                        ddlCountry.SelectedIndex = -1;
                        ddlCountry.Enabled = false;
                    }
                    else
                    {
                        ddlCountry.Items.Insert(0, new ListItem("-Select-", "0", true));
                    }

                }
                
                //ddlCountry.Enabled = true;
                dsCountry.Dispose();

                if (ddlCountry.Items.Count > 0)
                    //BindEmailboxByCountryId();
                    BindEmailboxByCountryIdandUserId();
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | BindCountry()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | BindCountry()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }
        private void ReportNameBinding()
        {
            try
            {
                int ReportheaderName;
                ReportheaderName = (Convert.ToInt32(Request.QueryString["ReportType"]));
                if (ReportheaderName == 1)
                {
                    lblReportHeader.Text = "<h2>TAT Report</h2>";
                }
                else if (ReportheaderName == 2)
                {
                    lblReportHeader.Text = "<h2>TAT SplitUp Report</h2>";
                }
                else if (ReportheaderName == 3)
                {
                    lblReportHeader.Text = "<h2>Productivity Report</h2>";
                } if (ReportheaderName == 4)
                {
                    lblReportHeader.Text = "<h2>Overall Report</h2>";
                } if (ReportheaderName == 5)
                {
                    lblSubProcess.Visible = false;
                    ddlSubProcess.Visible = false;
                    lblReportHeader.Text = "<h2>Clarification Sent Report</h2>";
                } if (ReportheaderName == 6)
                {
                    lblSubProcess.Visible = false;
                    ddlSubProcess.Visible = false;
                    lblReportHeader.Text = "<h2>Clarification with Ageing Report</h2>";
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | ReportNameBinding()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | ReportNameBinding()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        private void BindEmailboxByCountryId()
        {
            try
            {
                ddlEMailbox.Items.Clear();
                DataSet ds = new DataSet();
                Hashtable ht = new Hashtable();
                ht.Add("@CountryId", ddlCountry.SelectedValue);
                ds = _presenter.GetMailboxByCountryId(ht);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    ddlEMailbox.DataSource = ds;
                    ddlEMailbox.DataTextField = "EMAILBOXNAME";
                    ddlEMailbox.DataValueField = "EMAILBOXID";
                    ddlEMailbox.DataBind();
                }
                ddlEMailbox.Items.Insert(0, new ListItem("-Select-", "0"));
                ddlEMailbox.Enabled = true;
                ds.Dispose();
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | BindEmailboxByCountryId()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | BindEmailboxByCountryId()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }

        /// <summary>
        /// Function to Bind the Emailbox Names based on the Country Selection and the User Id
        /// </summary>
        private void BindEmailboxByCountryIdandUserId()
        {
            try
            {
                ddlEMailbox.Items.Clear();
                DataSet ds = new DataSet();
                Hashtable ht = new Hashtable();
                ht.Add("@CountryId", ddlCountry.SelectedValue);
                ht.Add("@Roleid", !string.IsNullOrEmpty(Convert.ToString(objUser.RoleId))  ? objUser.RoleId : 0) ;
                ht.Add("@Userid", !string.IsNullOrEmpty(objUser.UserId) ? objUser.UserId : "");
                ds = _presenter.GetMailboxByCountryIdandUserId(ht);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    ddlEMailbox.DataSource = ds;
                    ddlEMailbox.DataTextField = "EMAILBOXNAME";
                    ddlEMailbox.DataValueField = "EMAILBOXID";
                    ddlEMailbox.DataBind();
                }
                if (ds.Tables.Count > 0 && ds.Tables[1].Rows.Count > 0)
                {
                    ddlSubProcess.Items.Clear();
                    ddlSubProcess.DataSource = ds.Tables[1];
                    ddlSubProcess.DataTextField = "SubProcessName";
                    ddlSubProcess.DataValueField = "SubProcessGroupID";
                    ddlSubProcess.DataBind();
                    ddlSubProcess.Items.Insert(0, new ListItem("ALL", "0"));
                    //lblSubProcess.Visible = ddlSubProcess.Visible = true;
                }
                //BindSubProcess();
                ddlEMailbox.Items.Insert(0, new ListItem("-Select-", "0"));
                ddlEMailbox.SelectedIndex = 0;
                ddlEMailbox.Enabled = true;
                ds.Dispose();
                Bindcategory(ddlEMailbox.SelectedIndex);
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | BindEmailboxByCountryIdandUserId()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | BindEmailboxByCountryIdandUserId()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }

        private void BindSubProcess()
        {
            try
            {
                ddlSubProcess.Items.Clear();
                DataSet dsSubProcessId = new DataSet();
                Hashtable ht = new Hashtable();
                ht.Add("@CountryId", ddlCountry.SelectedValue);
                //ht.Add("@MailBox", ddlEMailbox.SelectedValue);
                dsSubProcessId = _presenter.GetSubProcessGroup(ht);

                if (dsSubProcessId.Tables[0].Rows.Count > 0)
                {
                    ddlSubProcess.DataSource = dsSubProcessId;
                    ddlSubProcess.DataTextField = "SubProcessName";
                    ddlSubProcess.DataValueField = "SubProcessGroupID";
                    ddlSubProcess.DataBind();
                    //ddlSubProcess.Items.Insert(0, new ListItem("ALL", "0"));
                    //lblSubProcess.Visible = ddlSubProcess.Visible = true;
                }
                ddlSubProcess.Items.Insert(0, new ListItem("ALL", "0"));
                dsSubProcessId.Dispose();
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | BindSubProcess()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | BindSubProcess()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }

        private void ClearFields()
        {
            try
            {
                if (!(ddlCountry.Items.Count == 0))
                    ddlCountry.SelectedIndex = 0;
                //BindEmailboxByCountryId();
                BindEmailboxByCountryIdandUserId();

                //ddlSubProcess.Items.Clear();
                //ddlSubProcess.Items.Insert(0, new ListItem("ALL", "0"));
                ddlEMailbox.SelectedIndex = 0;
                ddlSubProcess.SelectedIndex = 0;
                Bindcategory(ddlEMailbox.SelectedIndex);
                txtFromDate.Text = "";
                txtToDate.Text = "";
                lblNoRecord.Text = "";
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | ClearFields()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | ClearFields()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }


        /// <summary>
        /// Bind category
        /// </summary>
        /// <param></param>
        ///<returns> void </returns>
        void Bindcategory(int emailboxid)
        {
            try
            {
                DataSet ds = new DataSet();
                Hashtable ht = new Hashtable();
                ht.Add("@Emailboxid", ddlEMailbox.SelectedValue);
                ds = _presenter.GetCategory(ht);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {                    
                    lstCategory.DataSource = ds;
                    lstCategory.DataTextField = "Category";
                    lstCategory.DataValueField = "EmailboxCategoryId";
                    lstCategory.DataBind();

                }
                else
                {                 
                    lstCategory.Items.Clear();

                    lstCategory.DataSource = null;
                    lstCategory.DataBind();
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " |TATSplitup.aspx.cs| Bindcategory()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }


        protected void btnExportExcel_Click(object sender, EventArgs e)
        {
           
                lblNoRecord.Text = "";
                lblNoRecord.Style.Add("display", "none");

                BindSearchDetails();
                DataTable ds = new DataTable();
                ds = (DataTable)ViewState["CaseListData"];
                if (ds.Rows.Count > 0)
                {
                    lblNoRecord.Text = "";
                    lblNoRecord.Style.Add("display", "none");
                    ExportToExcel(ds);
                }
                else
                {
                    lblNoRecord.Style.Add("display", "inline");
                    lblNoRecord.Text = "No Records Found";
                }
           
        }

        private void ExportToExcel(DataTable ds)
        {
            try
            {
               
                HttpResponse Response = HttpContext.Current.Response;
                Response.Clear();
                Response.ClearContent();
                Response.ClearHeaders();
                Response.Buffer = true;
                string reportname = lblReportHeader.Text.Replace("<h2>", "");
                reportname = reportname.Replace("</h2>", "");
                string strFilename = "EMT-SearchDetails_" + DateTime.Now.ToString() +"_" +reportname + ".xls";                
                Response.AddHeader("content-disposition", "attachment;filename=" + strFilename);
                Response.ContentType = "application/vnd.ms-excel";
                Response.ContentEncoding = Encoding.UTF8;
                Response.Cache.SetCacheability(HttpCacheability.NoCache);

                System.IO.StringWriter StringWriter = new System.IO.StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(StringWriter);
                
                GridView gv = new GridView();
                gv.DataSource = ds;
                gv.DataBind();
                gv.AllowSorting = false;
                gv.AllowPaging = false;
                gv.HeaderStyle.ForeColor = System.Drawing.Color.Black;

                for (int i = 0; i < gv.Rows.Count; i++)
                {
                    //Apply text style to each Row
                    gv.Rows[i].Attributes.Add("class", "textmode");
                    if(Convert.ToInt32(Server.HtmlEncode(Request.QueryString["ReportType"]))==1)
                    {
                        gv.Rows[i].Cells[5].Attributes.Add("class", "date");
                        gv.Rows[i].Cells[6].Attributes.Add("class", "date");                       

                    }
                    else if (Convert.ToInt32(Server.HtmlEncode(Request.QueryString["ReportType"])) == 2)
                    {
                        gv.Rows[i].Cells[4].Attributes.Add("class", "date");
                        gv.Rows[i].Cells[13].Attributes.Add("class", "date");
                    }
                    else if (Convert.ToInt32(Request.QueryString["ReportType"]) == 3)
                    {
                        gv.Rows[i].Cells[1].Attributes.Add("class", "date");
                        gv.Rows[i].Cells[5].Attributes.Add("class", "date");
                    }
                    else if (Convert.ToInt32(Request.QueryString["ReportType"]) == 4)
                    {
                        gv.Rows[i].Cells[6].Attributes.Add("class", "date");
                        gv.Rows[i].Cells[9].Attributes.Add("class", "date");
                    }
                    else if (Convert.ToInt32(Request.QueryString["ReportType"]) == 5)
                    {
                        gv.Rows[i].Cells[1].Attributes.Add("class", "date");
                        gv.Rows[i].Cells[2].Attributes.Add("class", "date");
                        gv.Rows[i].Cells[5].Attributes.Add("class", "date");
                    }
                    else if (Convert.ToInt32(Request.QueryString["ReportType"]) == 6)
                    {
                        gv.Rows[i].Cells[1].Attributes.Add("class", "date");
                        gv.Rows[i].Cells[2].Attributes.Add("class", "date");
                    }

                }
                //gv.Columns[5].
                gv.RenderControl(htw);

                //string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                // mso-number-format:short date
                //string style = @"<style>.date { mso-number-format:'mm/dd/yyyy h:mm:ss'; }</style>";
               // string style = @"<style>.date { mso-number-format:'mm\\/dd\\/yyyy hh:mm:ss'; }</style>";
                string style = @"<style> td { mso-number-format:\@; } </style>";
                Response.Write(style);

                // Style is added dynamically
                Response.Write(StringWriter.ToString());
                StringWriter.Close();
                htw.Close();
                Response.End();
                //HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
            catch (ThreadAbortException ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | ExportToExcel()");  
                //errorlog.HandleError(ex, objUser.UserId, " | TATSplitup.aspx.cs | ExportToExcel()");
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | ExportToExcel()");  
                //errorlog.HandleError(ex, objUser.UserId, " | TATSplitup.aspx.cs | ExportToExcel()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                IsSessionValid();
                ClearFields();
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | btnReset_Click()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | btnReset_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

        }

        protected void ddlEMailbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //BindCaseList();
                BindSubProcess();
                Bindcategory(ddlEMailbox.SelectedIndex);
                lblNoRecord.Text = "";
                lblNoRecord.Style.Add("display", "none");
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | ddlEMailbox_SelectedIndexChanged()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | ddlEMailbox_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                BindEmailboxByCountryIdandUserId();
                lblNoRecord.Text = "";
                lblNoRecord.Style.Add("display", "none");
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | ddlCountry_SelectedIndexChanged()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | ddlCountry_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        //private TATSplitupPresenter _presenter;

        //[CreateNew]
        //public TATSplitupPresenter Presenter
        //{
        //    get
        //    {
        //        return this._presenter;
        //    }
        //    set
        //    {
        //        if (value == null)
        //            throw new ArgumentNullException("value");

        //        this._presenter = value;
        //        this._presenter.View = this;
        //    }
        //}

        // TODO: Forward events to the presenter and show state to the user.
        // For examples of this, see the View-Presenter (with Application Controller) QuickStart:
        //	

        private DataTable BindSearchDetails()
        {
            DataTable dt = null;
            try
            {
                Hashtable hs = new Hashtable();
                //DateTime RecDateFrom = !string.IsNullOrEmpty(txtFromDate.Text.Trim()) ? Convert.ToDateTime(txtFromDate.Text) : DateTime.MinValue;
                //DateTime RecDateTo = !string.IsNullOrEmpty(txtToDate.Text.Trim()) ? Convert.ToDateTime(txtToDate.Text) : DateTime.MinValue;
                //DateTime.ParseExact(dateString, @"d/M/yyyy", 	System.Globalization.CultureInfo.InvariantCulture)

                //CultureInfo currentCulture = Thread.CurrentThread.CurrentCulture;
                //IFormatProvider frmprovider=

                var dtFrom = txtFromDate.Text;
                var dtTo = txtToDate.Text;
                DateTime RecDateFrom = !string.IsNullOrEmpty(txtFromDate.Text.Trim()) ? DateTime.ParseExact(dtFrom,"dd/MM/yyyy", CultureInfo.InvariantCulture,DateTimeStyles.AssumeLocal) : DateTime.MinValue;
                DateTime RecDateTo = !string.IsNullOrEmpty(txtToDate.Text.Trim()) ? DateTime.ParseExact(dtTo, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal) : DateTime.MinValue;
                hs.Add("@COUNTRYID", ddlCountry.SelectedValue);
                hs.Add("@EMAILBOXID", ddlEMailbox.SelectedValue);
                if (ddlSubProcess.SelectedValue != "0")
                {
                    hs.Add("@SUBPROCESSGROUPID", ddlSubProcess.SelectedValue);
                }
                else
                {
                    hs.Add("@SUBPROCESSGROUPID", DBNull.Value);
                }


                if (lstCategory.SelectedValue != "0")
                {
                    string strCategoryIds = "";

                    for (int i = 0; i < lstCategory.Items.Count; i++)
                    {
                        if (lstCategory.Items[i].Selected)
                        {
                            if (strCategoryIds == "")
                                strCategoryIds = lstCategory.Items[i].Value.ToString();
                            else
                                strCategoryIds = strCategoryIds + "," + lstCategory.Items[i].Value.ToString();
                        }
                    }

                    hs.Add("@CategoryID", strCategoryIds);
                }                
                else
                {
                    hs.Add("@CategoryID", DBNull.Value);
                }

                hs.Add("@FROMDATE", RecDateFrom.ToString("MM-dd-yyyy"));
                hs.Add("@TODATE", RecDateTo.ToString("MM-dd-yyyy"));
                //Pranay 18 janauary 2017 -- adding offset for User Session fo Report purpose
                hs.Add("@OFFSET", objUser.OffSet);
                int Report = Convert.ToInt32(Request.QueryString["ReportType"]);


                DataSet ds = _presenter.GetSearchCaseList(hs, Report);
                //gvCaseList.HeaderRow.Cells[6].Visible = false;
                if (ds != null && ds.Tables.Count != 0)
                {
                    dt = ds.Tables[0];
                }
                ds.Dispose();
                ViewState["CaseListData"] = ds.Tables[0];
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | BindSearchDetails()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | BindSearchDetails()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }

            return dt;
        }

        protected void ddlSubProcess_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                lblNoRecord.Text = "";
                lblNoRecord.Style.Add("display", "none");
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | ddlSubProcess_SelectedIndexChanged()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | ddlSubProcess_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        protected void txtFromDate_TextChanged(object sender, EventArgs e)
        {
            try
            {
                lblNoRecord.Text = "";
                lblNoRecord.Style.Add("display", "none");
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | txtFromDate_TextChanged()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | txtFromDate_TextChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        protected void txtToDate_TextChanged(object sender, EventArgs e)
        {
            try
            {

                lblNoRecord.Text = "";
                lblNoRecord.Style.Add("display", "none");
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | TATSplitup.aspx.cs | txtToDate_TextChanged()");  
                //errorlog.HandleError(ex, objUser.UserId , " | TATSplitup.aspx.cs | txtToDate_TextChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
}
}