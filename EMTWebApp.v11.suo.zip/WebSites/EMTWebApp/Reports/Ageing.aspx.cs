﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Web.UI.WebControls.WebParts;
using EMTWebApp.Constants;
using DigiOPS.TechFoundation.Logging;
using System.Text;
using System.Text.RegularExpressions;

namespace EMTWebApp.Reports.Views
{
    public partial class Reports_Ageing : Microsoft.Practices.CompositeWeb.Web.UI.Page, IAgeingView
    {
        #region DECLARATION
        private AgeingPresenter _presenter;
        UserSession UserDetails = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        string LoginId;
        public DataTable dtBaseData;
        #endregion
        /// <summary>
        /// To bind the Country details, Email Login Details and 
        /// EmailBox Details Grid and initialize other controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Session["CurrentPage"] = "Reports";
                UserDetails = (UserSession)Session["UserDetails"];
                IsValidRoleToAccessThisPage(UserDetails);
                RedirectToErrorPage(UserDetails);
                if (!this.IsPostBack)
                {
                    this._presenter.OnViewInitialized();
                    ddlCntryName.Focus();
                    //OnClientClick="return compare();return ValidateRanges(); "
                    Page.Form.DefaultButton = btnSubmit.UniqueID;
                    if (Session["UserDetails"] != null)
                    {
                        ddlEmailBox.Items.Insert(0, "- Select -");
                        LoginId = UserDetails.UserId.ToString();
                        BindCountry();
                        BindSubProcessNames();
                    }
                    else
                    {
                        Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    }

                    this._presenter.OnViewLoaded();
                    //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                    string PKeyword = (Session["PasswordExpiration"]).ToString();
                    if (PKeyword == "yes")
                    {
                        Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                    }
                }
            }

            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | Ageing.aspx.cs | Page_Load()");  
                //errorlog.HandleError(ex, UserDetails.UserId , " | Ageing.aspx.cs | Page_Load()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }

        #region PROPERTIES
        [CreateNew]
        public AgeingPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion

        #region PRIVATE METHODS
        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserDetails)
        {
            try
            {
                if (UserDetails != null)
                {
                    if ((UserDetails.RoleId == (int)Constant.UserRole.SuperAdmin) || (UserDetails.RoleId == (int)Constant.UserRole.Admin) || (UserDetails.RoleId == (int)Constant.UserRole.TeamLead) || (UserDetails.RoleId == (int)Constant.UserRole.ClientUser))
                    {
                        return true;
                    }
                    else
                    {
                        Response.Redirect(@"~\Errors\AccessDenied.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    }
                }
                else
                {
                    Response.Redirect(@"~\Errors\AccessDenied.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | IsValidRoleToAccessThisPage()");  
                //errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | IsValidRoleToAccessThisPage()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
            return false;
        }

        /// <summary>
        /// Method to redirect to Error page if userdetails are null
        /// </summary>
        private void RedirectToErrorPage(UserSession UserDetails)
        {
            try
            {
                if (UserDetails == null)
                {
                    Response.Redirect(@"~\Errors\AccessDenied.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | RedirectToErrorPage()");  
                //errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | RedirectToErrorPage()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }

        /// <summary>
        /// Function to bind the country names to the dropdown
        /// </summary>
        public void BindCountry()
        {
            try
            {
                Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
                Match matchUserId = regex.Match(UserDetails.UserId);
                Match matchRoleId = regex.Match(UserDetails.RoleId.ToString());
                if (matchUserId.Success && matchRoleId.Success)
                {
                    Hashtable htUserData = new Hashtable();
                    htUserData.Add("@AssociateId", !string.IsNullOrEmpty(UserDetails.UserId) ? UserDetails.UserId : "");
                    htUserData.Add("@roleid", (UserDetails.RoleId != null) ? Convert.ToString(UserDetails.RoleId) : "");
                    DataSet dsCountryNames = _presenter.BindCountry(htUserData);
                    if (dsCountryNames.Tables[0].Rows.Count > 0)
                    {
                        ddlCntryName.DataSource = dsCountryNames;
                        ddlCntryName.DataValueField = "CountryID";
                        ddlCntryName.DataTextField = "Country";
                        ddlCntryName.DataBind();
                        if (dsCountryNames.Tables[0].Rows.Count == 1)
                        {
                            ddlCntryName.SelectedIndex = -1;
                            ddlCntryName.Enabled = false;
                        }
                        else
                        {
                            ddlCntryName.Items.Insert(0, new ListItem("-Select-", "0", true));
                        }
                    }
                    //ListItem select = new ListItem();
                    //select.Text = "- Select -";
                    //select.Value = "0";
                    //ddlCntryName.Items.Insert(0, select);
                }
                else
                {
                    Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | BindCountry()");  
               // errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | BindCountry()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }

        /// <summary>
        /// Function to clear the fields 
        /// </summary>
        public void Clearfields()
        {
            try
            {
                ddlEmailBox.Items.Clear();
                ddlEmailBox.Items.Insert(0, "- Select -");
                ddlCntryName.SelectedIndex = 0;
                //ddlSubProcessName.Items.Clear();
                //ddlSubProcessName.Items.Insert(0, "- Select -");
                ddlSubProcessName.SelectedIndex = 0;
                //ddlCntryName_SelectedIndexChanged(null, null);
                grdAgeing.Visible = false;
                GVBaseData.Visible = false;
                btnOnScreenData.Visible = false;
                btnBaseData.Visible = false;
                txtRange1.Text = "";
                txtRange2.Text = "";
                txtRange3.Text = "";
                txtRange4.Text = "";
                btnSubmit.Text = "Submit";
                lblErrorMsg.Text = "";
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | Clearfields()");  
                //errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | Clearfields()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }

        /// <summary>
        /// Function to bind the SubProcess Names to the dropdown
        /// </summary>
        public void BindSubProcessNames()
        {
            try
            {
                Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
                Match matchddlCntryName = regex.Match(ddlCntryName.SelectedValue);
                if (matchddlCntryName.Success)
                {
                    Hashtable ht = new Hashtable();
                    ht.Add("@CountryId", ddlCntryName.SelectedValue);
                    //ht.Add("@MailBox", ddlEmailBox.SelectedValue);
                    DataSet dsSubProcessName = _presenter.BindSubProcessNames(ht);
                    if (dsSubProcessName.Tables[0].Rows.Count > 0)
                    {
                        ddlSubProcessName.DataSource = dsSubProcessName;
                        ddlSubProcessName.DataValueField = "SUBPROCESSGROUPID";
                        ddlSubProcessName.DataTextField = "SUBPROCESSNAME";
                        ddlSubProcessName.DataBind();
                    }
                    ListItem select = new ListItem();
                    select.Text = "- Select -";
                    select.Value = "0";
                    ddlSubProcessName.Items.Insert(0, select);
                }
                else
                {
                    Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | BindSubProcessNames()");  
               // errorlog.HandleError(Ex, UserDetails.UserId, " | Ageing.aspx.cs | BindSubProcessNames()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        /// <summary>
        /// To disable the link for the count that is zero or null
        /// </summary>
        /// <param name="e"></param>
        private void disableLink(object sender, GridViewRowEventArgs e)
        {
            try
            {
                for (int RowIndex = 7; RowIndex <= e.Row.Cells.Count - 1; RowIndex++)
                {
                    LinkButton lnk = (LinkButton)e.Row.Cells[RowIndex].Controls[1];
                    if (lnk != null)
                    {
                        if (lnk.Text == string.Empty || lnk.Text == "0")
                        {
                            lnk.Enabled = false;
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | disableLink()");  
                //errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | disableLink()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }

        /// <summary>
        /// To pass the Command Argument
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        private string redirection(GridViewCommandEventArgs e)
        {
            return e.CommandArgument.ToString();
        }

        /// <summary>
        /// To get the range details for binding the values to the Grid
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        private string redirectionRange(GridViewCommandEventArgs e)
        {
            string Url = string.Empty;
            string Range = string.Empty;

            if (e.CommandName == "Range1")
            {
                Url = txtRange1.Text.ToString().Trim();
            }
            else if (e.CommandName == "Range1&2")
            {
                Url = txtRange1.Text.ToString().Trim() + "," + txtRange2.Text.ToString().Trim();
            }
            else if (e.CommandName == "Range2&3")
            {
                Url = txtRange2.Text.ToString().Trim() + "," + txtRange3.Text.ToString().Trim();
            }
            else if (e.CommandName == "Range3&4")
            {
                Url = txtRange3.Text.ToString().Trim() + "," + txtRange4.Text.ToString().Trim();
            }
            else if (e.CommandName == "Range>4")
            {
                Url = txtRange4.Text.ToString().Trim();
            }
            return Url;

        }

        #region Paging and Sorting
        /// <summary>
        /// To sort the Page
        /// </summary>
        protected DataView SortDataTable(DataTable dataTable, bool isPageIndexChanging)
        {
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (GridViewSortExpression != string.Empty)
                {
                    if (isPageIndexChanging)
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GridViewSortDirection);
                    }
                    else
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GetSortDirection());
                    }
                }
                return dataView;
            }
            else
            {
                return new DataView();
            }
        }

        private string GetSortDirection()
        {
            switch (GridViewSortDirection)
            {
                case "ASC":
                    GridViewSortDirection = "DESC";
                    break;
                case "DESC":
                    GridViewSortDirection = "ASC";
                    break;
            }
            return GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }

        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }


        #endregion

        /// <summary>
        /// Function to bind the Emailbox names to the dropdown 
        /// based on the Country and Sub-Process Names Selected
        /// </summary>
        public void BindEmailboxNames()
        {
            try
            {
                ddlEmailBox.Items.Clear();
                Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
                Match matchCntryName = regex.Match(ddlCntryName.SelectedValue);
                Match matchSubProcessName = regex.Match(ddlSubProcessName.SelectedValue);
                if (matchCntryName.Success && matchSubProcessName.Success)
                {
                    int CountryId = Convert.ToInt16(ddlCntryName.SelectedValue);
                    int SubProcessId = Convert.ToInt16(ddlSubProcessName.SelectedValue);
                    DataSet dsEmailboxNames = _presenter.BindEmailboxNames(CountryId, SubProcessId);
                    ddlEmailBox.DataSource = dsEmailboxNames;
                    ddlEmailBox.DataValueField = "EMAILBOXID";
                    ddlEmailBox.DataTextField = "EMAILBOXNAME";
                    ddlEmailBox.DataBind();
                    ListItem select = new ListItem();
                    select.Text = "- Select -";
                    select.Value = "0";
                    ddlEmailBox.Items.Insert(0, select);
                }
                else
                {
                    Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | BindEmailboxNames()");  
                //errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | BindEmailboxNames()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }
        #endregion

        #region  EVENTS
        /// <summary>
        /// Button event to bind the Ageing Details to the Grid
        /// by getting the Country, Sub-Process, EmailBox, and Ranges (1, 2, 3 & 4)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                try
                {
                    Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
                    Match matchCntryName = regex.Match(ddlCntryName.SelectedValue.ToString().Trim());
                    Match matchSubProcessName = regex.Match(ddlSubProcessName.SelectedValue.ToString().Trim());
                    Match matchEmailBox = regex.Match(ddlEmailBox.SelectedValue.ToString().Trim());
                    string CountryId = ddlCntryName.SelectedValue.ToString().Trim();
                    string SubProcessId = ddlSubProcessName.SelectedValue.ToString().Trim();
                    string EmailBoxId = ddlEmailBox.SelectedValue.ToString().Trim();
                    if (ddlEmailBox.SelectedIndex != 0)
                    {
                        EmailBoxId = ddlEmailBox.SelectedValue.ToString().Trim();
                    }
                    else
                    {
                        EmailBoxId = "0";
                    }
                    Regex regexNumeric = new Regex(@"^[0-9]{0,10}$");
                    Match matchtxtRange1 = regexNumeric.Match(txtRange1.Text.ToString().Trim());
                    Match matchtxtRange2 = regexNumeric.Match(txtRange2.Text.ToString().Trim());
                    Match matchtxtRange3 = regexNumeric.Match(txtRange3.Text.ToString().Trim());
                    Match matchtxtRange4 = regexNumeric.Match(txtRange4.Text.ToString().Trim());
                    if (matchCntryName.Success && matchSubProcessName.Success && matchEmailBox.Success && matchtxtRange1.Success && matchtxtRange2.Success && matchtxtRange3.Success && matchtxtRange4.Success)
                    {
                        int Range1 = Convert.ToInt16(txtRange1.Text.ToString().Trim());
                        int Range2 = Convert.ToInt16(txtRange2.Text.ToString().Trim());
                        int Range3 = Convert.ToInt16(txtRange3.Text.ToString().Trim());
                        int Range4 = Convert.ToInt16(txtRange4.Text.ToString().Trim());
                        string offset = UserDetails.OffSet;
                        grdAgeing.Visible = true;
                        DataSet dsAgeingData = this._presenter.GridAgeingDetBind(CountryId, SubProcessId, EmailBoxId, Range1, Range2, Range3, Range4, offset);
                        if (dsAgeingData != null && dsAgeingData.Tables.Count > 0 && dsAgeingData.Tables[0].Rows.Count > 0)
                        {
                            grdAgeing.Columns[7].HeaderText = " < " + System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(txtRange1.Text.ToString().Trim(), true);
                            grdAgeing.Columns[8].HeaderText = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(txtRange1.Text.ToString().Trim(), true) + " - " + System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(txtRange2.Text.ToString().Trim(), true);
                            grdAgeing.Columns[9].HeaderText = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(txtRange2.Text.ToString().Trim(), true) + " - " + System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(txtRange3.Text.ToString().Trim(), true);
                            grdAgeing.Columns[10].HeaderText = System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(txtRange3.Text.ToString().Trim(), true) + " - " + System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(txtRange4.Text.ToString().Trim(), true);
                            grdAgeing.Columns[11].HeaderText = " > " + System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(txtRange4.Text.ToString().Trim(), true);
                            grdAgeing.DataSource = dsAgeingData;
                            grdAgeing.DataBind();
                            ViewState["AgeingCount"] = grdAgeing.DataSource;
                            grdAgeing.Visible = true;
                            btnOnScreenData.Visible = true;
                            lblErrorMsg.Visible = false;
                            GVBaseData.DataSource = null;
                            GVBaseData.Visible = false;
                            btnBaseData.Visible = false;
                            //}
                        }
                        else
                        {
                            btnOnScreenData.Visible = false;
                            lblErrorMsg.Visible = true;
                            lblErrorMsg.Text = "No Records to Display";
                            grdAgeing.Visible = false;
                            //grdAgeing.EmptyDataText = "No Records to Display";
                        }
                    }
                    else
                    {
                        Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                    }

                }
                catch (Exception Ex)
                {
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | btnSubmit_Click()");
                    //errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | btnSubmit_Click()");
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                }
            }
        }

        /// <summary>
        /// Button Event to Clear the Field
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClear_Click(object sender, EventArgs e)
        {
            Clearfields();
        }

        /// <summary>
        /// To bind the EmailBox names to the dropdown by getting the selected values of Country and Sub-Process
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlCntryName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlCntryName.SelectedValue.ToString() != "0" && ddlCntryName.SelectedValue.ToString() != "0")
                {
                    BindEmailboxNames();
                    BindSubProcessNames();
                    grdAgeing.DataSource = null;
                    grdAgeing.Visible = false;
                    GVBaseData.DataSource = null;
                    GVBaseData.Visible = false;
                    btnOnScreenData.Visible = false;
                    btnBaseData.Visible = false;
                    lblErrorMsg.Visible = false;
                }
                else
                {
                    BindEmailboxNames();
                    ddlSubProcessName.SelectedIndex = 0;
                    lblErrorMsg.Visible = false;
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | ddlCntryName_SelectedIndexChanged()");  
                //errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | ddlCntryName_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }

        /// <summary>
        /// To bind the EmailBox names to the dropdown by getting the selected values of Country and Sub-Process
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlSubProcessName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlCntryName.SelectedValue.ToString() != "0" && ddlCntryName.SelectedValue.ToString() != "0")
                {
                    BindEmailboxNames();
                    grdAgeing.DataSource = null;
                    grdAgeing.Visible = false;
                    GVBaseData.DataSource = null;
                    GVBaseData.Visible = false;
                    btnOnScreenData.Visible = false;
                    btnBaseData.Visible = false;
                    lblErrorMsg.Visible = false;
                }
                else
                {
                    ddlEmailBox.Items.Insert(0, "- Select -");
                    lblErrorMsg.Visible = false;
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | ddlSubProcessName_SelectedIndexChanged()");  
                //errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | ddlSubProcessName_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }

        }
        /// <summary>
        /// To bind the EmailBox names to the dropdown by getting the selected values of Country and Sub-Process
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlEmailBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                grdAgeing.DataSource = null;
                grdAgeing.Visible = false;
                GVBaseData.DataSource = null;
                GVBaseData.Visible = false;
                btnOnScreenData.Visible = false;
                btnBaseData.Visible = false;
                lblErrorMsg.Visible = false;
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | ddlEmailBox_SelectedIndexChanged()");  
                //errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | ddlEmailBox_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        public override void VerifyRenderingInServerForm(Control control)
        {

        }
        /// <summary>
        /// Event to bind the numeric values without link that are zeros
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdAgeing_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                // check for row to be bound if it contains data
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    disableLink(sender, e);
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | grdAgeing_RowDataBound()");  
               // errorlog.HandleError(Ex, UserDetails.UserId, " | Ageing.aspx.cs | grdAgeing_RowDataBound()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// Event to bind the Base Data grid based on the count of the selected status
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdAgeing_RowCommand(object sender, GridViewCommandEventArgs e)                   
        {
            try
            {
                GridViewRow row = (GridViewRow)(((Control)e.CommandSource).NamingContainer);
                {
                    Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
                    Regex regexNumeric = new Regex(@"^[0-9]{0,10}$");
                    Hashtable ht = new Hashtable();
                    string Range = redirectionRange(e);
                    string Status = redirection(e);
                    Label CntryId = row.FindControl("lblCountryID") as Label;
                    Label SubProcId = row.FindControl("lblSubProcessGroupId") as Label;
                    Label MailBoxId = row.FindControl("lblEmailBoxId") as Label;
                    string CountryId = Convert.ToString(CntryId.Text);
                    string SubProcessId = Convert.ToString(SubProcId.Text);
                    string EmailBoxId = Convert.ToString(MailBoxId.Text);
                    Match matchCountryId = regex.Match(CountryId);
                    Match matchSubProcessId = regex.Match(SubProcessId);
                    Match matchEmailBoxId = regex.Match(EmailBoxId);
                    Match matchStatus = regex.Match(Status);
                    if (matchCountryId.Success && matchSubProcessId.Success && matchEmailBoxId.Success && matchStatus.Success)
                    {
                        ht.Add("@Country", CountryId);
                        ht.Add("@SubProcess", SubProcessId);
                        ht.Add("@MailBoxId", EmailBoxId);
                        ht.Add("@StatusID", Status);
                        if (Range.ToString() != string.Empty && Status.ToString() != string.Empty)
                        {
                            GVBaseData.DataSource = null;
                            GVBaseData.DataBind();
                            string[] RangeStatus = Range.ToString().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                            if (RangeStatus.Length == 1)
                            {
                                Match matchRANGEBOUNDARY = regexNumeric.Match(RangeStatus[0].ToString().Trim());
                                if (matchRANGEBOUNDARY.Success)
                                {
                                    if (e.CommandName == "Range1")
                                    {
                                        ht.Add("@RANGEBOUNDARY1", RangeStatus[0].ToString().Trim());
                                        ht.Add("@RANGEBOUNDARY2", string.Empty);
                                    }
                                    else if (e.CommandName == "Range>4")
                                    {
                                        ht.Add("@RANGEBOUNDARY1", string.Empty);
                                        ht.Add("@RANGEBOUNDARY2", RangeStatus[0].ToString().Trim());
                                    }
                                }
                                else
                                {
                                    Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                                }
                            }
                            else if (RangeStatus.Length == 2)
                            {
                                Match matchRANGEBOUNDARY1 = regexNumeric.Match(RangeStatus[0].ToString().Trim());
                                Match matchRANGEBOUNDARY2 = regexNumeric.Match(RangeStatus[1].ToString().Trim());
                                if (matchRANGEBOUNDARY1.Success && matchRANGEBOUNDARY2.Success)
                                {
                                    ht.Add("@RANGEBOUNDARY1", RangeStatus[0].ToString().Trim());
                                    ht.Add("@RANGEBOUNDARY2", RangeStatus[1].ToString().Trim());
                                }
                                else
                                {
                                    Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                                }
                            }
                            string StatusID = Status.ToString();
                            DataSet dsBaseData = this._presenter.BindBaseData(ht);
                            GVBaseData.DataSource = dsBaseData;

                            if (dsBaseData != null && dsBaseData.Tables.Count > 0 && dsBaseData.Tables[0].Rows.Count > 0)
                            {
                                GVBaseData.Visible = true;
                                GVBaseData.DataSource = dsBaseData;
                                GVBaseData.DataBind();
                                ViewState["BaseData"] = dsBaseData;
                                ViewState["BaseDataSort"] = dsBaseData.Tables[0];
                                btnBaseData.Visible = true;
                            }
                            else
                            {
                                GVBaseData.DataSource = null;
                                GVBaseData.DataBind();
                                GVBaseData.Visible = false;
                                btnBaseData.Visible = false;
                            }
                        }
                    }
                    else
                    {
                        Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                    }
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | grdAgeing_RowCommand()");  
               // errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | grdAgeing_RowCommand()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

        }

        /// <summary>
        /// Button event to export the On-Screen data to Excel format
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnOnScreenData_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet dsOnscreenExcel = new DataSet();
                dsOnscreenExcel = ((DataSet)ViewState["AgeingCount"]);
                dsOnscreenExcel.Tables[0].Columns.Remove("CountryID");
                dsOnscreenExcel.Tables[0].Columns.Remove("SubProcessGroupId");
                dsOnscreenExcel.Tables[0].Columns.Remove("EmailboxId");
                dsOnscreenExcel.Tables[0].Columns.Remove("StatusId");
                dsOnscreenExcel.Tables[0].Columns["Range1"].ColumnName = " < " + txtRange1.Text.ToString().Trim();
                dsOnscreenExcel.Tables[0].Columns["Range1 & Range2"].ColumnName = txtRange1.Text.ToString().Trim() + " to " + txtRange2.Text.ToString().Trim();
                dsOnscreenExcel.Tables[0].Columns["Range2 & Range3"].ColumnName = txtRange2.Text.ToString().Trim() + " to " + txtRange3.Text.ToString().Trim();
                dsOnscreenExcel.Tables[0].Columns["Range3 & Range4"].ColumnName = txtRange3.Text.ToString().Trim() + " to " + txtRange4.Text.ToString().Trim();
                dsOnscreenExcel.Tables[0].Columns["Range > 4"].ColumnName = " > " + txtRange4.Text.ToString().Trim();


                if (dsOnscreenExcel.Tables[0].Rows.Count > 0)
                {
                    string strFilename = "Ageing_OnScreen_Details_" + DateTime.Now.ToString() + ".xls";
                    Response.Clear();
                    Response.AddHeader("content-disposition", "attachment;filename=" + strFilename);
                    Response.Charset = "UTF-8";
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.ContentType = "application/vnd.ms-excel";
                    System.IO.StringWriter stringWrite = new System.IO.StringWriter();
                    System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
                    GridView gv = new GridView();
                    gv.DataSource = dsOnscreenExcel;
                    gv.DataBind();
                    gv.AllowSorting = false;
                    gv.AllowPaging = false;
                    gv.HeaderStyle.ForeColor = System.Drawing.Color.Black;
                    // Loop through the rows and hide the cell in the first column
                    for (int i = 0; i < grdAgeing.Rows.Count; i++)
                    {
                        GridViewRow row = grdAgeing.Rows[i];
                        row.Cells[0].Visible = false;
                    }

                    string style = @"<style> td { mso-number-format:""0""; } </style> ";
                    gv.RenderControl(htmlWrite);
                    Response.Write(style);
                    Response.Write(stringWrite.ToString());
                    stringWrite.Close();
                    htmlWrite.Close();
                    Response.Flush();
                    Response.End();
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | btnOnScreenData_Click()");  
              //  errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | btnOnScreenData_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// Button event to export the Base data to Excel format
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBaseData_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet dsBaseDataExcel = new DataSet();
                dsBaseDataExcel = ((DataSet)ViewState["BaseData"]);

                if (dsBaseDataExcel.Tables[0].Rows.Count > 0)
                {
                    string strFilename = "Ageing_BaseData_Details_" + DateTime.Now.ToString() + ".xls";
                    Response.Clear();
                    Response.AddHeader("content-disposition", "attachment;filename=" + strFilename);
                    Response.Charset = "UTF-8";
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.ContentType = "application/vnd.ms-excel";
                    System.IO.StringWriter stringWrite = new System.IO.StringWriter();
                    System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
                    GridView gv = new GridView();
                    gv.DataSource = dsBaseDataExcel;
                    gv.DataBind();
                    gv.AllowSorting = false;
                    gv.AllowPaging = false;
                    gv.HeaderStyle.ForeColor = System.Drawing.Color.Black;
                    gv.RenderControl(htmlWrite);
                    Response.Write(stringWrite.ToString());
                    stringWrite.Close();
                    htmlWrite.Close();
                    Response.Flush();
                    Response.End();

                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | btnBaseData_Click()");  
                //errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | btnBaseData_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        /// <summary>
        /// Event to change the page in the grid (GVBASEDATA)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GVBaseData_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                dtBaseData = (DataTable)ViewState["BaseDataSort"];
                GVBaseData.DataSource = SortDataTable(dtBaseData as DataTable, true);
                GVBaseData.PageIndex = e.NewPageIndex;
                GVBaseData.DataBind();
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | Ageing.aspx.cs | GVBaseData_PageIndexChanging()");  
                //errorlog.HandleError(ex, UserDetails.UserId , " | Ageing.aspx.cs | GVBaseData_PageIndexChanging()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }
        /// <summary>
        /// Event to change the page in the grid (GVBASEDATA)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdAgeing_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdAgeing.PageIndex = e.NewPageIndex;
                grdAgeing.EditIndex = -1;
                grdAgeing.DataSource = ViewState["AgeingCount"];
                grdAgeing.DataBind();
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | grdAgeing_PageIndexChanging()");  
              //  errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | grdAgeing_PageIndexChanging()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        /// <summary>
        /// Row Data bound event to align the particular columns to center
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GVBaseData_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    //    if (e.Row.Cells[6].Text == "&nbsp;")
                    //    {
                    //        e.Row.Cells[6].Text = "-";
                    //        e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Center;
                    //    }
                    e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Center;
                    e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                    e.Row.Cells[6].HorizontalAlign = HorizontalAlign.Center;
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | Ageing.aspx.cs | GVBaseData_RowDataBound()");  
                //errorlog.HandleError(Ex, UserDetails.UserId , " | Ageing.aspx.cs | GVBaseData_RowDataBound()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// To Sort the Grid Ascending and Descending (GVBASEDATA)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GVBaseData_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                GridViewSortExpression = e.SortExpression;
                int pageIndex = GVBaseData.PageIndex;
                dtBaseData = (DataTable)ViewState["BaseDataSort"];
                GVBaseData.DataSource = SortDataTable(dtBaseData, false);
                GVBaseData.DataBind();
                GVBaseData.PageIndex = pageIndex;
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | Ageing.aspx.cs | GVBaseData_Sorting()");  
               // errorlog.HandleError(ex, UserDetails.UserId , " | Ageing.aspx.cs | GVBaseData_Sorting()");
                Response.Redirect("~/Errors/Error.aspx",false);
            }
        }

        #endregion


    }
}