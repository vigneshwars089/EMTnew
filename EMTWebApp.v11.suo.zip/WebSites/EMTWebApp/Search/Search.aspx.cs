﻿using System;
using Microsoft.Practices.ObjectBuilder;
using System.Data;
using System.Collections;
using EMTWebApp.ExceptionHandler;
using EMTWebApp.UserManagement.Common;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Data.SqlTypes;
using EMTWebApp.Constants;
using System.IO;
using System.Threading;
using System.Text;
using System.Globalization;
using EMTWebApp.Common.Views;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Security;
using System.Linq;
using DigiOPS.TechFoundation.ExceptionHandling;
namespace EMTWebApp.Search.Views
{
    public partial class Search : Microsoft.Practices.CompositeWeb.Web.UI.Page, ISearchView
    {
        #region DECLARATION
        private SearchPresenter _presenter;
        //Pranay 3rd Oct 2016
        // private  EMTWebApp.Common.Views.ProcessingPresenter _processingpresenter;
        UserSession objUser = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        DataTable dtGrid = new DataTable();
        DataSet dsGrid = new DataSet();

        #endregion
        /// <summary>
        /// To initialize the Controls and to bind the Country Details and Available Status to the Dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["userdetails"] != null)
            {
                objUser = (UserSession)Session["userdetails"];

                Session["CurrentPage"] = "Search";
                if (!this.IsPostBack)
                {
                    //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                    string PKeyword = (Session["PasswordExpiration"]).ToString();
                    if (PKeyword == "yes")
                    {
                        Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                    }
                    try
                    {

                        txtFromDate_CalendarExtende.EndDate = DateTime.Now;
                        Page.Form.DefaultButton = btnSearch.UniqueID;
                        txtFromDate.Attributes.Add("OnFocusOut", "javascript:return FormatFromDate()");
                        txtToDate.Attributes.Add("OnFocusOut", "javascript:return FormatToDate()");
                        btnSearch.Attributes.Add("OnClientClick", "return isNumber();");
                        IsSessionValid();
                        BindCountry();
                        //  BindStatus();
                        Hashtable htUserData = new Hashtable();
                        htUserData.Add("@ASSOCIATEID", !string.IsNullOrEmpty(objUser.UserId) ? objUser.UserId : "");
                        htUserData.Add("@Roleid", (objUser.RoleId != null) ? Convert.ToString(objUser.RoleId) : "");
                        _presenter.GetCountryByUserIdForDashboard(htUserData); //Bind the Country dropdown
                        //Pranay 21 October 2016 


                        this._presenter.OnViewInitialized();

                        if (Session["SearchCriteria"] != null && Request.QueryString["View"] == "PreSearch")
                        {
                            Hashtable hs = (Hashtable)Session["SearchCriteria"];

                            ddlCountry.SelectedValue = hs["@CountryId"].ToString();
                            ddlCountry_SelectedIndexChanged(this, null);

                            ddlEMailbox.SelectedValue = hs["@EMailboxId"].ToString();

                            txtCaseId.Text = hs["@CaseId"].ToString();

                            if (hs["@StatusId"].ToString() != "")
                                ddlStatus.SelectedValue = hs["@StatusId"].ToString();

                            if (Convert.ToDateTime(hs["@ReceivedFrom"].ToString()) != DateTime.MinValue)
                                txtFromDate.Text = Convert.ToDateTime(hs["@ReceivedFrom"].ToString()).ToString("MM/dd/yyyy");
                            if (Convert.ToDateTime(hs["@ReceivedTo"].ToString()) != DateTime.MinValue)
                                txtToDate.Text = Convert.ToDateTime(hs["@ReceivedTo"].ToString()).ToString("MM/dd/yyyy");

                            if (hs["@CaseSubject"].ToString() != "")
                                txtCaseSubject.Text = ReplaceSpaces(hs["@CaseSubject"].ToString());
                            if (hs["@FromEmail"].ToString() != "")
                                txtFromEmail.Text = hs["@FromEmail"].ToString();

                            btnSearch_Click(this, null);


                        }
                    }
                    catch (Exception ex)
                    {
                        //ExceptionHelper.HandleException(ex);
                        new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | Page_Load()");
                        // errorlog.HandleError(ex, objUser.UserId , " | Search.cs | Page_Load()");
                        Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    }

                }


            }
            else
            {
                Response.Redirect("~/Errors/SessionExpired.aspx", false);
            }
            this._presenter.OnViewLoaded();
        }

        #region PROPERTIES
        [CreateNew]
        public SearchPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion

        #region METHODS
        /// <summary>
        /// Method to redirect to login or session expired page
        /// </summary>
        private void IsSessionValid()
        {
            try
            {
                objUser = (UserSession)Session["userdetails"];
                if (objUser == null)
                    Response.Redirect(@"~\Errors\SessionExpired.aspx", false);
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | IsSessionValid()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | IsSessionValid()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// Function to Bind the Country Details to the dropdown
        /// </summary>
        private void BindCountry()
        {
            try
            {
                ddlCountry.Items.Clear();

                ddlEMailbox.Enabled = false;
                DataSet dsCountry = new DataSet();
                Hashtable htUserData = new Hashtable();
                htUserData.Add("@ASSOCIATEID", !string.IsNullOrEmpty(objUser.UserId) ? objUser.UserId : "");
                htUserData.Add("@Roleid", (objUser.RoleId != null) ? Convert.ToString(objUser.RoleId) : "");
                dsCountry = _presenter.GetCountryByUserIdForDashboard(htUserData);

                if (dsCountry.Tables[0].Rows.Count > 0)
                {
                    ddlCountry.DataSource = dsCountry;
                    ddlCountry.DataTextField = "Country";
                    ddlCountry.DataValueField = "CountryId";
                    ddlCountry.DataBind();

                    if (dsCountry.Tables[0].Rows.Count == 1)
                    {
                        ddlCountry.SelectedIndex = -1;
                        ddlCountry.Enabled = false;
                    }
                    else
                    {
                        ddlCountry.Items.Insert(0, new ListItem("-Select-", "0", true));
                        ddlCountry.Enabled = true;
                    }
                }


                //ddlCountry.Enabled = true;
                dsCountry.Dispose();

                if (ddlCountry.Items.Count > 0)
                    BindEmailboxByCountryId();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | BindCountry()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | BindCountry()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// Function to Bind the Emailbox Names based on the Country Selection
        /// </summary>
        private void BindEmailboxByCountryId()
        {
            try
            {
                ddlEMailbox.Items.Clear();
                DataSet ds = new DataSet();
                Hashtable ht = new Hashtable();
                ht.Add("@CountryId", ddlCountry.SelectedValue);
                ht.Add("@Userid", !string.IsNullOrEmpty(objUser.UserId) ? objUser.UserId : "");
                ht.Add("@Roleid", !string.IsNullOrEmpty(Convert.ToString(objUser.RoleId)) ? objUser.RoleId : 0);
                ds = _presenter.GetMailboxByCountryIdandUserId(ht);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    ddlEMailbox.DataSource = ds;
                    ddlEMailbox.DataTextField = "EMAILBOXNAME";
                    ddlEMailbox.DataValueField = "EMAILBOXID";
                    ddlEMailbox.DataBind();
                }
                ddlEMailbox.Items.Insert(0, new ListItem("-Select-", "0"));
                ddlEMailbox.Enabled = true;
                ds.Dispose();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | BindEmailboxByCountryId()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | BindEmailboxByCountryId()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// Function to Bind the Emailbox Names based on the Country Selection and the User Id
        /// </summary>
        private void BindEmailboxByCountryIdandUserId()
        {
            try
            {
                ddlEMailbox.Items.Clear();
                DataSet ds = new DataSet();
                Hashtable ht = new Hashtable();
                ht.Add("@CountryId", ddlCountry.SelectedValue);
                ht.Add("@Userid", !string.IsNullOrEmpty(objUser.UserId) ? objUser.UserId : "");
                ht.Add("@Roleid", !string.IsNullOrEmpty(Convert.ToString(objUser.RoleId)) ? objUser.RoleId : 0);
                ds = _presenter.GetMailboxByCountryIdandUserId(ht);

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    ddlEMailbox.DataSource = ds;
                    ddlEMailbox.DataTextField = "EMAILBOXNAME";
                    ddlEMailbox.DataValueField = "EMAILBOXID";
                    ddlEMailbox.DataBind();
                }
                ddlEMailbox.Items.Insert(0, new ListItem("-Select-", "0"));
                ddlEMailbox.Enabled = true;
                ds.Dispose();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | BindEmailboxByCountryIdandUserId()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | BindEmailboxByCountryIdandUserId()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        ///// <summary>
        ///// Get EMailBox list based on the selected country from the datatbase and bind it in a dropdown
        ///// </summary>
        ///// <param></param>
        /////<returns>void </returns>
        //DataSet ISearchView.BindEMailBox
        //{
        //    set
        //    {
        //        if (value != null && value.Tables.Count > 0 && value.Tables[0].Rows.Count > 0)
        //        {
        //            ddlEMailbox.DataSource = value;
        //            ddlEMailbox.DataTextField = "EMailBoxName";
        //            ddlEMailbox.DataValueField = "EMailBoxId";
        //            ddlEMailbox.DataBind();
        //            ddlEMailbox.Items.Insert(0, new ListItem("--Select--", "0"));
        //        }
        //        else
        //        {
        //            ddlEMailbox.DataSource = null;
        //            ddlEMailbox.Items.Clear();
        //            ddlEMailbox.Items.Insert(0, new ListItem("--Select--", "0"));
        //        }
        //    }
        //}

        /// <summary>
        /// Function to Bind the Status available to the Status Dropdown
        /// </summary>
        private void BindStatus(int MailBoxId)
        {
            //dynamic status change
            try
            {
                ddlStatus.Items.Clear();
                DataSet ds = new DataSet();
                Hashtable ht = new Hashtable();
                ht.Add("@MailBoxId", MailBoxId);
                ds = _presenter.GetAllStatus(ht);
                Session["StatusMasterData"] = ds;
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    ddlStatus.DataSource = ds;
                    ddlStatus.DataTextField = "StatusDescription";
                    ddlStatus.DataValueField = "StatusId";
                }
                ddlStatus.DataBind();
                ddlStatus.Items.Insert(0, new ListItem("All", "0"));
                ds.Dispose();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | BindStatus()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | BindStatus()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// Function to Bind the Available User Names & Ids to the UserID Dropdown to reassign the CAses
        /// </summary>
        private void BindUserIds(bool IsSkillBasedAllocation)
        {
            try
            {
                ddlUserIds.Items.Clear();
                if (ddlSkillSet.SelectedValue != "0")
                {
                    DataSet ds = new DataSet();
                    Hashtable ht = new Hashtable();
                    ht.Add("@CountryId", ddlCountry.SelectedValue);
                    ht.Add("@EMailbocId", ddlEMailbox.SelectedValue);
                    ht.Add("@Roleid", Constant.UserRole.Processor);
                    if (IsSkillBasedAllocation)
                        ht.Add("@SkillId", ddlSkillSet.SelectedValue);
                    else
                        ht.Add("@SkillId", "0");
                    ds = _presenter.GetUserIdsByCountryEmailboxRole(ht);
                    if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                    {
                        ddlUserIds.DataSource = ds;
                        ddlUserIds.DataTextField = "UserName";
                        ddlUserIds.DataValueField = "UserId";

                    }
                    ddlUserIds.DataBind();
                    ds.Dispose();
                }
                ddlUserIds.Items.Insert(0, new ListItem("-Select-", "0"));
                
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | BindUserIds()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | BindUserIds()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

       
   private void BindSkillSet()
        {
            try
            {
                ddlSkillSet.Items.Clear();
                DataSet dsSkillSet = _presenter.GetSkillSet();
                foreach (DataRow dr in dsSkillSet.Tables[0].Rows)
                {

                    ddlSkillSet.Items.Add(new ListItem(dr["SkillDescription"].ToString(), dr["SkillId"].ToString()));
                }
                ListItem select = new ListItem();
                select.Text = "--Select--";
                select.Value = "0";
                ddlSkillSet.Items.Insert(0, select);

            }
            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, "", " | Search.aspx.cs | BindSkillSet()");
                //errorlog.HandleError(ex, UserData.UserId, " | CreateUser.cs | BindTimeZone()");
            }
            catch (Exception Ex)
            {
                ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserDetails.UserId + " | MailBoxCreation.cs | BindTimeZone()");
                //Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        

        /// <summary>
        /// Function to Bind the Flag Criteria based on Mailbox selected
        /// Pranay 24 October 2016 
        /// </summary>
        private void BindFlagonMailboxSelected()
        {
            try
            {
                ddlflagCriteria.Items.Clear();
                DataSet ds = new DataSet();
                Hashtable ht = new Hashtable();

                ht.Add("@EMailboxId", ddlEMailbox.SelectedValue);

                ds = _presenter.GetFlagCriteriaByEmailboxSelected(ht);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    ddlflagCriteria.DataSource = ds;
                    ddlflagCriteria.DataTextField = "Reference";
                    ddlflagCriteria.DataValueField = "EmailboxReferenceId";

                }
                ddlflagCriteria.DataBind();
                ddlflagCriteria.Items.Insert(0, new ListItem("-Select-", "0"));
                ds.Dispose();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | BindFlagonMailboxSelected()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | BindFlagonMailboxSelected()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// Function to Clear the Output Fields
        /// </summary>
        //private void ClearOutputFields()
        //{
        //    btnAssign.Visible = lblUserIds.Visible = ddlUserIds.Visible = btnReAssign.Visible = false;
        //    gvCaseList.DataSource = null;
        //    gvCaseList.Visible = btnExportExcel.Visible = btnMoveToClarifProvided.Visible = false;
        //}


        /// <summary>
        /// Function to Clear the Fields
        /// </summary>
        private void ClearFields()
        {
            try
            {
                if (!(ddlCountry.Items.Count == 0))
                    ddlCountry.SelectedIndex = 0;
                BindEmailboxByCountryId();
                txtCaseId.Text = txtFromDate.Text = txtToDate.Text = txtCaseSubject.Text = txtFromEmail.Text = "";
                if (!(ddlStatus.Items.Count == 0))
                    ddlStatus.SelectedIndex = 0;

                if (!(ddlflagCriteria.Items.Count == 0))
                    ddlflagCriteria.SelectedIndex = 0;
                btnAssign.Visible = lblUserIds.Visible = ddlUserIds.Visible = btnReAssign.Visible =lblSkillSet.Visible=ddlSkillSet.Visible= false;

                gvCaseList.DataSource = null;
                gvCaseList.Visible = btnExportExcel.Visible = btnMoveToClarifProvided.Visible = false;
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | ClearFields()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | ClearFields()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// Function to Bind the Search data to the Grid
        /// </summary>
        private void BindCaseList()
        {
            try
            {
                ViewState.Clear();
                DataTable dtSearch;
                //DataTable dtSearch = this.BindSearchDetails();
                dsGrid = this.BindSearchDetails(1, 10, "", "");
                if (dsGrid == null)
                {

                    dtSearch = null;
                }
                else
                {
                    dtSearch = dsGrid.Tables[0];
                }
                if (dtSearch != null && dtSearch.Rows.Count > 0)
                {

                    gvCaseList.DataSource = dtSearch;
                    gvCaseList.VirtualItemCount = Convert.ToInt32(dsGrid.Tables[1].Rows[0][0]);
                    gvCaseList.DataBind();
                    btnExportExcel.Visible = true;
                    gvCaseList.Visible = true;

                }
                else
                {
                    gvCaseList.DataSource = null;
                    gvCaseList.DataBind();
                    btnExportExcel.Visible = false;
                    gvCaseList.Visible = true;
                    gvCaseList.EmptyDataText = "No Records Found";


                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | BindCaseList()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | BindCaseList()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }




        /// <summary>
        /// Method to get the Search Details from the Fields
        /// </summary>
        /// <returns></returns>
        private DataSet BindSearchDetails(int pgIndex, int pgSize, string srtExp, string strOrder)
        {
            DataTable dt = null;
            DataSet dsSearch = new DataSet();
            try
            {
                if (srtExp.ToLower() == "receiveddate")
                    srtExp = "EmailReceivedDate";
                else if (srtExp.ToLower() == "sender")
                    srtExp = "EMailFrom";
                else if (srtExp.ToLower() == "assignedto")
                    srtExp = "um.FirstName";
                else if (srtExp.ToLower() == "priority")
                    srtExp = "IsUrgent";
                else if (srtExp.ToLower() == "caseid")
                    srtExp = "CaseId";
                else if (srtExp.ToLower() == "status")
                    srtExp = "StatusDescription";
                string NewSubject = ReplaceSpecialCharacters(txtCaseSubject.Text);


                Hashtable hs = new Hashtable();
                var dtFrom = txtFromDate.Text;
                var dtTo = txtToDate.Text;
                DateTime RecDateFrom = !string.IsNullOrEmpty(txtFromDate.Text.Trim()) ? DateTime.ParseExact(dtFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal) : DateTime.MinValue;
                DateTime RecDateTo = !string.IsNullOrEmpty(txtToDate.Text.Trim()) ? DateTime.ParseExact(dtTo, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal) : DateTime.MinValue;
                hs.Add("@CountryId", !(ddlCountry.SelectedValue == "0") ? ddlCountry.SelectedValue : "");
                hs.Add("@EMailboxId", !(ddlEMailbox.SelectedValue == "0") ? ddlEMailbox.SelectedValue : "");
                hs.Add("@ReceivedFrom", RecDateFrom.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                hs.Add("@ReceivedTo", RecDateTo.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                hs.Add("@CaseId", !string.IsNullOrEmpty(txtCaseId.Text.Trim()) ? txtCaseId.Text : "");
                hs.Add("@StatusId", !(ddlStatus.SelectedValue == "0") ? ddlStatus.SelectedValue : "");
                //new search fields
                hs.Add("@CaseSubject", !string.IsNullOrEmpty(NewSubject) ? NewSubject : "");
                hs.Add("@FromEmail", !string.IsNullOrEmpty(txtFromEmail.Text.Trim()) ? txtFromEmail.Text : "");

                //Pranay 3rd August 2016 ---Adding  Role and Associate ID for user who login
                hs.Add("@LoginUserId", !string.IsNullOrEmpty(objUser.UserId) ? objUser.UserId : "");
                hs.Add("@Roleid", !string.IsNullOrEmpty(Convert.ToString(objUser.RoleId)) ? objUser.RoleId : 0);

                //Pranay 25 August 2016 -- Adding Flag Criteria to Search
                hs.Add("@flagCriteria", !(ddlflagCriteria.SelectedValue == "0") ? ddlflagCriteria.SelectedValue : "");
                hs.Add("@PageIndex", pgIndex);
                hs.Add("@PageSize", pgSize);
                hs.Add("@SortExpName", srtExp);
                hs.Add("@SortExpOrder", strOrder);
                string value = Session["Searchmodifiedvalue"].ToString();
                if (Session["Searchmodifiedvalue"] != "Search")
                {
                    // Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    dsSearch = null;
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Error Ocurred in this page')", true);
                    //Session.Remove("Searchmodifiedvalue");                

                }
                else
                {
                    Session["SearchCriteria"] = hs;

                    dsSearch = _presenter.GetSearchCaseList(hs);
                    //gvCaseList.HeaderRow.Cells[6].Visible = false;
                    if (dsSearch != null && dsSearch.Tables.Count != 0)
                    {
                        dt = dsSearch.Tables[0];
                        //for (int i = 0; i <= dt.Rows.Count; i++) 
                        //{
                        //    string Subdecrpt = string.Empty;
                        //    Subdecrpt = dsSearch.Tables[0].Rows[];
                        //}
                    }
                }
                // ds.Dispose();
                // ViewState["CaseListData"] = dsSearch.Tables[0];
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | BindSearchDetails()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | BindSearchDetails()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

            return dsSearch;
        }
        /// <summary>
        /// To get the Grid details to the Excel during Export
        /// </summary>
        /// <param name="ds"></param>
        private void ExportToExcel(DataTable ds)
        {
            try
            {
                using (System.IO.StringWriter StringWriter = new System.IO.StringWriter())
                using (HtmlTextWriter htw = new HtmlTextWriter(StringWriter))
                {
                    HttpResponse Response = HttpContext.Current.Response;
                    Response.Clear();
                    Response.ClearContent();
                    Response.ClearHeaders();
                    Response.Buffer = true;
                    string strFilename = "EMT-SearchDetails_" + DateTime.Now.ToString() + ".xls";
                    Response.AddHeader("content-disposition", "attachment;filename=" + strFilename);
                    Response.ContentType = "application/vnd.ms-excel";
                    Response.ContentEncoding = Encoding.UTF8;
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);

                    //System.IO.StringWriter StringWriter = new System.IO.StringWriter();
                    // HtmlTextWriter htw = new HtmlTextWriter(StringWriter);
                    GridView gv = new GridView();
                    gv.DataSource = ds;
                    gv.DataBind();
                    gv.AllowSorting = false;
                    gv.AllowPaging = false;
                    gv.HeaderStyle.ForeColor = System.Drawing.Color.Black;
                    gv.HeaderRow.Cells[10].Visible = false;
                    for (int i = 0; i < gv.Rows.Count; i++)
                    {
                        gv.Rows[i].Attributes.Add("class", "textmode");
                        gv.Rows[i].Cells[1].Attributes.Add("class", "date");

                        GridViewRow row = gv.Rows[i];
                        row.Cells[10].Visible = false;
                    }
                    gv.RenderControl(htw);
                    //string style = @"<style>.date { mso-number-format:'mm/dd/yyyy h:mm:ss'; }</style>";
                    string style = @"<style>.date { mso-number-format:'mm\\/dd\\/yyyy hh:mm:ss'; }</style>";
                    Response.Write(style);
                    // Style is added dynamically
                    Response.Write(StringWriter.ToString());
                    //  StringWriter.Close();
                    htw.Close();
                    Response.End();
                    //HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
            }
            catch (ThreadAbortException ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | ExportToExcel()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | ExportToExcel()");

            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | ExportToExcel()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | ExportToExcel()");
                //Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        #region Paging and Sorting
        /// <summary>
        /// To sort the Page
        /// </summary>
        protected DataView SortDataTable(DataTable dataTable, bool isPageIndexChanging)
        {
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (GridViewSortExpression != string.Empty)
                {
                    if (isPageIndexChanging)
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GridViewSortDirection);
                    }
                    else
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GetSortDirection());
                    }
                }
                return dataView;
            }
            else
            {
                return new DataView();
            }
        }

        private string GetSortDirection()
        {
            switch (GridViewSortDirection)
            {
                case "ASC":
                    GridViewSortDirection = "DESC";
                    break;
                case "DESC":
                    GridViewSortDirection = "ASC";
                    break;
            }
            return GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }

        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }


        #endregion

        /// <summary>
        /// Function to Bind the search details to the grid based on the below mentioned Status selected from the dropdown (If Data Exists)
        /// </summary>
        private void CheckReassignSatus()
        {
            try
            {
                //dynamic workflow change

                int StatusId = Convert.ToInt32(ddlStatus.SelectedValue);
                DataSet dsStatus = (DataSet)Session["StatusMasterData"];
                if (gvCaseList.Rows.Count > 0)
                {
                    if (objUser.RoleId == (int)Constant.UserRole.TeamLead)
                    {
                        if (dsStatus.Tables[0].AsEnumerable().Any(row => StatusId == row.Field<int>("StatusId") && true == row.Field<bool>("IsReassignStatus")))
                        {
                            gvCaseList.Columns[0].Visible = false;
                            btnAssign.Visible = true;
                            lblUserIds.Visible = ddlUserIds.Visible = btnReAssign.Visible = false;
                        }
                        if (dsStatus.Tables[0].AsEnumerable().Any(row => StatusId == row.Field<int>("StatusId") && true == row.Field<bool>("IsReminderStatus")))//check if current status is reminder status
                            if (dsStatus.Tables[0].AsEnumerable().Any(row => true == row.Field<bool>("IsFollowupStatus")))//check if followup status exists for the subprocess, else hide move to clarification provided button
                                btnMoveToClarifProvided.Visible = true;
                    }
                    else if ((objUser.RoleId == (int)Constant.UserRole.Processor))
                    {
                        if (dsStatus.Tables[0].AsEnumerable().Any(row => (StatusId == row.Field<int>("StatusId") && (true == row.Field<bool>("IsReassignStatus") || (true == row.Field<bool>("IsAssignedStatus") || true == row.Field<bool>("IsFollowupStatus"))))))
                        {
                            gvCaseList.Columns[0].Visible = false;
                            btnAssign.Visible = true;
                            lblUserIds.Visible = ddlUserIds.Visible = btnReAssign.Visible = false;
                        }
                    }
                    else
                    {
                        btnAssign.Visible = false;
                    }
                }

                else
                {
                    btnAssign.Visible = false;
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | CheckReassignSatus()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | CheckReassignSatus()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }


        /// <summary>
        /// Function to check whether the selected status is "Completed" or not
        /// Pranay --30 September 2016
        /// </summary>
        private void CheckIsCompleted()
        {
            //dynamic workflow change
            DataSet dsStatus = (DataSet)(Session["StatusMasterData"]);
            var dsStatusTransition = from myRow in dsStatus.Tables[0].AsEnumerable()
                                     where myRow.Field<bool>("IsFinalStatus") == true
                                     select myRow;

            try
            {
                int StatusId = Convert.ToInt32(ddlStatus.SelectedValue);
                bool isFinal = dsStatusTransition.CopyToDataTable().AsEnumerable().Any(row => StatusId == row.Field<int>("StatusId"));
                if (isFinal && objUser.RoleId == (int)Constant.UserRole.TeamLead)
                {
                    gvCaseList.Columns[0].Visible = true;

                    btnReOpen.Visible = true;
                    btnUnflag.Visible = true;
                }
                else if (isFinal && objUser.RoleId == (int)Constant.UserRole.Processor)
                {
                    gvCaseList.Columns[0].Visible = true;
                    btnUnflag.Visible = true;
                }
                else
                {
                    btnReOpen.Visible = false;
                    btnUnflag.Visible = false;
                    gvCaseList.Columns[7].Visible = true;
                    gvCaseList.Columns[8].Visible = true;
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | CheckIsCompleted()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | CheckIsCompleted()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }


        /// <summary>
        /// Function to check Role in order to disable flag Criteria drop downlist
        /// Pranay --21 October 2016
        /// </summary>
        private void CheckRoleToDisableFlagdropdown()
        {
            //dynamic workflow change
            DataSet dsStatus = (DataSet)(Session["StatusMasterData"]);
            var dsStatusTransition = from myRow in dsStatus.Tables[0].AsEnumerable()
                                     where myRow.Field<bool>("IsFinalStatus") == true
                                     select myRow;

            bool isFinal = dsStatusTransition.CopyToDataTable().AsEnumerable().Any(row => Convert.ToInt32(ddlStatus.SelectedValue) == row.Field<int>("StatusId"));

            try
            {
                BindFlagonMailboxSelected();
                if (((objUser.RoleId == (int)Constant.UserRole.Processor) || objUser.RoleId == (int)Constant.UserRole.TeamLead) && isFinal)
                {
                    ddlflagCriteria.Enabled = true;
                }
                else
                {
                    ddlflagCriteria.Enabled = false;

                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | CheckRoleToDisableFlagdropdown()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | CheckRoleToDisableFlagdropdown()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

        }

        private bool CheckSkillBasedAllocation()
        {
            bool IsSkillBasedAllocation = false;
            if ((objUser.RoleId == (int)Constant.UserRole.TeamLead))
            {
                Hashtable ht = new Hashtable();
                ht.Add("@EmailBoxId", ddlEMailbox.SelectedValue);
                DataSet ds=_presenter.IsSkillBasedAllocation(ht);
                IsSkillBasedAllocation = (ds.Tables[0].Rows[0]["IsSkillBasedAllocation"] != null) ? Convert.ToBoolean(ds.Tables[0].Rows[0]["IsSkillBasedAllocation"]) : false;
            }

            return IsSkillBasedAllocation;
        }

        #endregion

        #region EVENTS
        /// <summary>
        /// Button event to check the Session and to bd the Search values to the Grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                IsSessionValid();

                ResetFields();
                //CheckIsCompleted();

                BindCaseList();

                CheckReassignSatus();
                // CheckIsClarificationRequired();
                CheckIsCompleted();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | btnSearch_Click()");
                //errorlog.HandleError(ex, objUser.UserId, " | Search.cs | btnSearch_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// Reset the fields
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResetFields()
        {
            try
            {
                gvCaseList.DataSource = null;
                btnAssign.Visible = lblUserIds.Visible = ddlUserIds.Visible=lblSkillSet.Visible=ddlSkillSet.Visible = btnReAssign.Visible = btnMoveToClarifProvided.Visible = btnExportExcel.Visible = false;
                ddlSkillSet.Items.Clear();
                ddlUserIds.Items.Clear();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | ResetFields()");
                //errorlog.HandleError(ex, objUser.UserId, " | Search.cs | ResetFields()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// Event to change the page in the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvCaseList_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
        {
            try
            {


                IsSessionValid();
                Session["pgSearchIndex"] = e.NewPageIndex + 1;

                DataSet dsSearch = BindSearchDetails(e.NewPageIndex + 1, 10, "", "");
                dtGrid = dsSearch.Tables[0];

                gvCaseList.DataSource = dtGrid;
                gvCaseList.PageIndex = e.NewPageIndex;
                // gvCaseList.EditIndex = -1;
                //DataTable dtSearch = (DataTable)ViewState["CaseListData"];
                //gvCaseList.DataSource = SortDataTable(dtSearch, true);
                gvCaseList.VirtualItemCount = Convert.ToInt32(dsSearch.Tables[1].Rows[0][0]);
                //  DataBind();
                gvCaseList.DataBind();
                //include a check for processor
                if (objUser.RoleId == Convert.ToInt32(Constant.UserRole.Processor) && btnReAssign.Visible == true)
                {
                    (gvCaseList.DataSource as DataView).RowFilter = string.Format("AssignedTo Like '%(" + objUser.UserId.Trim() + ")'");// "NewsDate2 Like '%" + yearID + "'";
                    gvCaseList.DataBind();
                }

                gvCaseList.PageIndex = 0;

                if (btnReAssign.Visible == true || btnMoveToClarifProvided.Visible == true)
                {
                    gvCaseList.Columns[0].Visible = true;
                }


                if (btnReOpen.Visible == true || btnUnflag.Visible == true)
                {
                    gvCaseList.Columns[0].Visible = true;
                }


                //Pranay 27 October -- for showing message if user select a header checbox and navigate to next page
                CheckBox headerChkBox = ((CheckBox)gvCaseList.HeaderRow.FindControl("chkCheckAll"));
                if ((objUser.RoleId == Convert.ToInt32(Constant.UserRole.TeamLead) || objUser.RoleId == Convert.ToInt32(Constant.UserRole.Processor)) && headerChkBox.Checked == false && gvCaseList.Columns[0].Visible == true)
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Values from previous page will be Unchecked!!!');", true);
                    //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "confirm", "CallConfirmBox();", true);
                    //ScriptManager.RegisterStartupScript(this, typeof(string), "ConfirmMessage", "confirm('Values from previous page will be Unchecked!!!!')", true);

                }


            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | gvCaseList_PageIndexChanging()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | gvCaseList_PageIndexChanging()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// Event to Sort the Grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvCaseList_Sorting(object sender, System.Web.UI.WebControls.GridViewSortEventArgs e)
        {
            try
            {
                //GridViewSortExpression = e.SortExpression;
                //int pageIndex = gvCaseList.PageIndex;
                //gvCaseList.DataSource = SortDataTable(BindSearchDetails() as DataTable, false);
                //gvCaseList.DataBind();
                string srtExp = string.Empty;
                string srtOrder = string.Empty;
                Session["srtSearchExp"] = e.SortExpression.ToString();
                //Session["srtOrder"] = e.SortDirection.ToString();

                srtOrder = "Ascending";
                if (Session["srtSearchExp"] != null)
                {
                    if (Session["srtSearchExp"].ToString() == e.SortExpression)
                    {
                        Session["srtSearchExp"] = null;
                        if (Session["srtSearchOrder"] == null)
                            srtOrder = "Desending";
                        else if (Session["srtSearchOrder"].ToString().ToLower() == "desending")
                            srtOrder = "Ascending";
                        else if (Session["srtSearchOrder"].ToString().ToLower() == "ascending")
                            srtOrder = "Desending";

                        Session["srtSearchOrder"] = srtOrder;
                    }
                    else
                    {
                        Session["srtSearchExp"] = e.SortExpression;
                    }
                }
                else
                {
                    Session["srtSearchExp"] = e.SortExpression;
                }


                //srtExp=e.SortExpression.ToString();

                if (e.SortExpression.ToString().ToLower() == "receiveddate")
                    srtExp = "EmailReceivedDate";
                else if (e.SortExpression.ToString().ToLower() == "emailfrom")
                    srtExp = "EMailFrom";
                else if (e.SortExpression.ToString().ToLower() == "assignedto")
                {
                    if (Convert.ToInt32(ddlStatus.SelectedValue) != 1)
                        srtExp = "um.FirstName";
                    else
                        srtExp = "";
                }
                else if (e.SortExpression.ToString().ToLower() == "priority")
                    srtExp = "IsUrgent";
                else if (e.SortExpression.ToString().ToLower() == "caseid")
                    srtExp = "CaseId";
                else if (e.SortExpression.ToString().ToLower() == "status")
                    srtExp = "StatusDescription";
                else if (e.SortExpression.ToString().ToLower() == "flaggedby")
                    srtExp = "FCM.CreatedbyId";
                else if (e.SortExpression.ToString().ToLower() == "isflagged")
                    srtExp = "FCM.IsActive";
                else if (e.SortExpression.ToString().ToLower() == "subject")
                    srtExp = "subject";

                //  e.NewPageIndex + 1;
                // int pageIndex = gvCaseList.PageIndex + 1;
                int pageIndex = gvCaseList.PageIndex + 1;


                dsGrid = BindSearchDetails(pageIndex, 10, srtExp, srtOrder);
                dtGrid = dsGrid.Tables[0];
                //dtGrid = dsSearch.Tables[1];
                gvCaseList.DataSource = dtGrid;
                gvCaseList.VirtualItemCount = Convert.ToInt32(dsGrid.Tables[1].Rows[0][0]);
                gvCaseList.DataBind();
                //include a check for processor
                if (objUser.RoleId == Convert.ToInt32(Constant.UserRole.Processor) && btnReAssign.Visible == true)
                {
                    (gvCaseList.DataSource as DataView).RowFilter = string.Format("AssignedTo Like '%(" + objUser.UserId.Trim() + ")'");
                    gvCaseList.DataBind();
                }
                // gvCaseList.PageIndex = pageIndex;
                if (btnReAssign.Visible == true || btnMoveToClarifProvided.Visible == true)
                {
                    gvCaseList.Columns[0].Visible = true;
                }

                //Pranay 14 November 2016
                if (btnReOpen.Visible == true || btnUnflag.Visible == true)
                {
                    gvCaseList.Columns[0].Visible = true;
                }

            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | gvCaseList_Sorting()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | gvCaseList_Sorting()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        protected void gvCaseList_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            try
            {
                //e.Row.Cells[0].Visible = false;
                //gvCaseList.TopPagerRow.Visible = true;
                gvCaseList.Columns[0].Visible = false;


                if (e.Row.RowType == DataControlRowType.DataRow || e.Row.RowType == DataControlRowType.Header)
                {
                    for (int count = 0; count < e.Row.Cells.Count; count++)
                    {
                        e.Row.Cells[count].HorizontalAlign = HorizontalAlign.Center;

                        if (e.Row.RowType == DataControlRowType.DataRow && count == 2)
                        {
                            e.Row.Cells[count].HorizontalAlign = HorizontalAlign.Left;
                            //Varma - Timezone Feature On&OFF functionality 
                            if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                            {
                                String rcvddate = e.Row.Cells[count].Text;
                                DateTime ReceivedDate = DateTime.ParseExact(rcvddate, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                                e.Row.Cells[count].Text = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(ReceivedDate.ToString("dd/MM/yyyy HH:mm:ss"), true, objUser.TimeZone, false);
                            }
                        }
                        else if (e.Row.RowType == DataControlRowType.DataRow && count == 3)
                        {
                            e.Row.Cells[count].HorizontalAlign = HorizontalAlign.Left;
                            String encryptsubject = e.Row.Cells[count].Text;
                            //Decrption
                            //cryptInfo.CryptKey = cipherpassword;
                            //cryptInfo.ValueToCrypt = encryptsubject;
                            //string decryptsubject = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
                            string decryptsubject = Constants.HelperMethods.DecryptString(encryptsubject);
                            e.Row.Cells[count].Text = decryptsubject;
                        }

                    }
                }

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    CheckBox headerchk = (CheckBox)gvCaseList.HeaderRow.FindControl("chkCheckAll");
                    CheckBox childchk = (CheckBox)e.Row.FindControl("ChkboxReassign");
                    childchk.Attributes.Add("onclick", "javascript:rCheckChange(this);");
                    headerchk.Attributes.Add("onclick", "javascript:hCheckChange(this);");


                }
                //if (e.Row.RowType == DataControlRowType.DataRow)
                //{
                //    CheckBox headerchk = (CheckBox)grdAllocation.HeaderRow.FindControl("chkHead");
                //    CheckBox childchk = (CheckBox)e.Row.FindControl("chkRow");
                //    childchk.Attributes.Add("onclick", "javascript:rCheckChange(this);");
                //    headerchk.Attributes.Add("onclick", "javascript:hCheckChange(this);");
                //}
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | gvCaseList_RowDataBound()");
                //errorlog.HandleError(ex, objUser.UserId, " | Search.cs | gvCaseList_RowDataBound()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

        }

        protected void gvCaseList_Command(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.ToUpper() == "SORT")
                {
                }
                else if (e.CommandName.ToUpper() == "PAGE")
                {
                }
                else
                {
                    int index = Convert.ToInt32(e.CommandArgument);
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | gvCaseList_Command()");
                //errorlog.HandleError(ex, objUser.UserId, " | Search.cs | gvCaseList_Command()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                BindEmailboxByCountryIdandUserId();
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | ddlCountry_SelectedIndexChanged()");
                //errorlog.HandleError(ex, objUser.UserId, " | Search.cs | ddlCountry_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        protected void ddlEMailbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //Pranay  24 October changing Flag Criteria Drop down on Emailbox Selection
                BindFlagonMailboxSelected();
                BindStatus(Convert.ToInt32(ddlEMailbox.SelectedValue));
                CheckRoleToDisableFlagdropdown();
                
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | ddlEMailbox_SelectedIndexChanged()");
                //errorlog.HandleError(ex, objUser.UserId, " | Search.cs | ddlEMailbox_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        protected void ddlSkillSet_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindUserIds(true);
        }

        protected void ddlStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            CheckRoleToDisableFlagdropdown();

        }


        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                IsSessionValid();
                ClearFields();
                Session["SearchCriteria"] = null;
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | btnReset_Click()");
                //errorlog.HandleError(ex, objUser.UserId, " | Search.cs | btnReset_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        protected void btnAssign_Click(object sender, EventArgs e)
        {
            try
            {
                ViewState.Clear();
                IsSessionValid();
                if (objUser.RoleId == (int)Constant.UserRole.Processor)
                {
                    BindCaseList();
                    (gvCaseList.DataSource as DataTable).DefaultView.RowFilter = string.Format("AssignedTo Like '%(" + objUser.UserId.Trim() + ")'");// "NewsDate2 Like '%" + yearID + "'";
                    gvCaseList.DataBind();

                }
                //Pranay 11 November 2016-- Binding details for Team Lead
                else if (objUser.RoleId == (int)Constant.UserRole.TeamLead)
                {
                    BindCaseList();
                    gvCaseList.DataBind();
                }
                if (CheckSkillBasedAllocation())//skill based allocation
                {
                    if (!(gvCaseList.Rows.Count == 0) )
                    {
                        BindSkillSet();
                        ddlUserIds.Items.Clear();
                        //BindUserIds();
                        lblUserIds.Visible = ddlUserIds.Visible = lblSkillSet.Visible = ddlSkillSet.Visible = btnReAssign.Visible = true;
                        btnReAssign.Text = "Re-Assign";
                        gvCaseList.Columns[0].Visible = true;
                    }
                    else 
                    {
                        BindSkillSet();
                        ddlUserIds.Items.Clear();
                        // BindUserIds();
                        lblUserIds.Visible = ddlUserIds.Visible = lblSkillSet.Visible = ddlSkillSet.Visible = btnReAssign.Visible = false;
                        //btnReAssign.Text = "Assign";
                        gvCaseList.Columns[0].Visible = false;
                    }
                }
                else//skill based allocation is off
                {
                    if (!(gvCaseList.Rows.Count == 0) )
                    {

                        BindUserIds(false);
                        lblUserIds.Visible = ddlUserIds.Visible =  btnReAssign.Visible = true;
                        btnReAssign.Text = "Re-Assign";
                        gvCaseList.Columns[0].Visible = true;
                    }
                    else
                    {
                        BindUserIds(false);
                        lblUserIds.Visible = ddlUserIds.Visible  = btnReAssign.Visible = false;
                        //btnReAssign.Text = "Assign";
                        gvCaseList.Columns[0].Visible = false;
                    }

                }
                // bind data again as data is not 
                //check whether the user is TL or Processor and filter the data accordingly.

                if (objUser.RoleId == (int)Constant.UserRole.Processor)
                {

                    ListItem removeItem = ddlUserIds.Items.FindByText(objUser.FirstName + " " + objUser.LastName + " ( " + objUser.UserId + " ) ");
                    ddlUserIds.Items.Remove(removeItem);
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | btnAssign_Click()");
                //errorlog.HandleError(ex, objUser.UserId, " | Search.cs | btnAssign_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        protected void btnMoveToClarifProvided_Click(object sender, EventArgs e)
        {
            try
            {
                IsSessionValid();

                string strUserId, strCaseIDs;
                strUserId = objUser.UserId;
                strCaseIDs = string.Empty;

                foreach (GridViewRow gvRow in gvCaseList.Rows)
                {
                    CheckBox chk = (CheckBox)gvRow.FindControl("ChkboxReassign");
                    LinkButton LnkBtnCaseId = (LinkButton)gvRow.FindControl("lnkbtnCaseId");

                    if (chk.Checked == true && strCaseIDs != string.Empty)
                    {
                        strCaseIDs = strCaseIDs + "," + LnkBtnCaseId.Text.Trim();
                    }
                    if (strCaseIDs == string.Empty && chk.Checked == true)
                    {
                        strCaseIDs = LnkBtnCaseId.Text.Trim();
                    }
                }

                //if (strCaseIDs != string.Empty)
                //{

                Hashtable ht = new Hashtable();
                ht.Add("@CaseIds", strCaseIDs);
                ht.Add("@LoggedInUserId", objUser.UserId);

                int Returnvalue = _presenter.UpdateCaseFromClarifNeededToClarifReceived(ht);

                if (Returnvalue != 0)
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Selected case(s) moved to clarification provided queue successfully!');", true);
                    BindCaseList();
                    gvCaseList.Columns[0].Visible = true;
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Transaction is UnSuccessful!');", true);
                }
                //}
                //else
                //{
                //    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select case(s) to move to clarification received queue!);", true);
                //}
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | btnMoveToClarifProvided_Click()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | btnMoveToClarifProvided_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        protected void btnReAssign_Click(object sender, EventArgs e)
        {
            try
            {
                IsSessionValid();

                string strUserId = objUser.UserId;
                int intNoOfRecordsAssigned = 0;
                string strCaseIDs = string.Empty;
                int intNotUnFlagged = 0;

                foreach (GridViewRow gvRow in gvCaseList.Rows)
                {
                    CheckBox chk = (CheckBox)gvRow.FindControl("ChkboxReassign");
                    LinkButton LnkBtnCaseId = (LinkButton)gvRow.FindControl("lnkbtnCaseId");

                    if (chk.Checked == true && strCaseIDs != string.Empty)
                    {
                        strCaseIDs = strCaseIDs + "," + LnkBtnCaseId.Text.Trim();
                        intNoOfRecordsAssigned = intNoOfRecordsAssigned + 1;
                    }
                    if (strCaseIDs == string.Empty && chk.Checked == true)
                    {
                        strCaseIDs = LnkBtnCaseId.Text.Trim();
                        intNoOfRecordsAssigned = intNoOfRecordsAssigned + 1;
                    }
                }

                Hashtable hsReAssign = new Hashtable();
                if (ddlUserIds.SelectedIndex != 0)
                {
                    hsReAssign.Add("@AllocatedToId", ddlUserIds.SelectedValue.Trim());

                    hsReAssign.Add("@CaseIds", strCaseIDs);
                    hsReAssign.Add("@LoggedInUserId", objUser.UserId);

                    if (strCaseIDs != string.Empty)
                    {
                        int res = this._presenter.UpdateOnReassign(hsReAssign);
                        if (res != 0)
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Case(s) Assigned to the Selected User!');", true);
                        }
                        else
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Transaction is UnSuccessful!');", true);
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select atleast one Case to Reassign!');", true);
                    }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select atleast one User to Reassign!');", true);
                }
                BindCaseList();

                if (objUser.RoleId == (int)Constant.UserRole.Processor)
                {
                    (gvCaseList.DataSource as DataTable).DefaultView.RowFilter = string.Format("AssignedTo Like '%(" + objUser.UserId.Trim() + ")'");// "NewsDate2 Like '%" + yearID + "'";
                    gvCaseList.DataBind();
                }
                gvCaseList.Columns[0].Visible = true;

            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | btnReAssign_Click()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | btnReAssign_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        protected void lnkbtnCaseId_Click(object sender, EventArgs e)
        {
            try
            {
                LinkButton lnkbtn = (LinkButton)sender;
                int Index = ((GridViewRow)((sender as LinkButton)).NamingContainer).RowIndex;
                Label lblStatusId = (Label)gvCaseList.Rows[Index].FindControl("lblStatusId");
                Label lblEMailboxId = (Label)gvCaseList.Rows[Index].FindControl("lblEMailboxId");
                // Response.Redirect(Server.UrlEncode("Processing.aspx?CaseId=" + lnkbtn.Text.Trim() + "&PreviousPage=Search.aspx" + "&EMailBox" + lblEMailboxId.Text.Trim() + "&Status=" + lblStatusId.Text.Trim()), false);
               Response.Redirect("~/Common/NewProcessingPage.aspx?CaseId=" + lnkbtn.Text.Trim() + "&PreviousPage=Search" + "&EMailBox=" + lblEMailboxId.Text.Trim() + "&Status=" + lblStatusId.Text.Trim(), false);
               // Response.Redirect("~/Common/NewProcessingPage.aspx?CaseId=" + lnkbtn.Text.Trim() + "&PreviousPage=Search" + "&EMailBox=" + lblEMailboxId.Text.Trim() + "&Status=" + lblStatusId.Text.Trim(), false);
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);CheckIsClarificationRequired 
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | lnkbtnCaseId_Click()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | lnkbtnCaseId_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

        }

        protected void btnExportExcel_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet dsSearch = new DataSet();
                DataTable dt = new DataTable();
                //DataTable ds = new DataTable();
                //ds = (DataTable)ViewState["CaseListData"];
                string NewSubject = ReplaceSpecialCharacters(txtCaseSubject.Text);


                Hashtable hs = new Hashtable();
                var dtFrom = txtFromDate.Text;
                var dtTo = txtToDate.Text;
                DateTime RecDateFrom = !string.IsNullOrEmpty(txtFromDate.Text.Trim()) ? DateTime.ParseExact(dtFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal) : DateTime.MinValue;
                DateTime RecDateTo = !string.IsNullOrEmpty(txtToDate.Text.Trim()) ? DateTime.ParseExact(dtTo, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal) : DateTime.MinValue;
                hs.Add("@CountryId", !(ddlCountry.SelectedValue == "0") ? ddlCountry.SelectedValue : "");
                hs.Add("@EMailboxId", !(ddlEMailbox.SelectedValue == "0") ? ddlEMailbox.SelectedValue : "");
                hs.Add("@ReceivedFrom", RecDateFrom.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                hs.Add("@ReceivedTo", RecDateTo.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                hs.Add("@CaseId", !string.IsNullOrEmpty(txtCaseId.Text.Trim()) ? txtCaseId.Text : "");
                hs.Add("@StatusId", !(ddlStatus.SelectedValue == "0") ? ddlStatus.SelectedValue : "");
                //new search fields
                hs.Add("@CaseSubject", !string.IsNullOrEmpty(NewSubject) ? NewSubject : "");
                hs.Add("@FromEmail", !string.IsNullOrEmpty(txtFromEmail.Text.Trim()) ? txtFromEmail.Text : "");

                //Pranay 3rd August 2016 ---Adding  Role and Associate ID for user who login
                hs.Add("@LoginUserId", !string.IsNullOrEmpty(objUser.UserId) ? objUser.UserId : "");
                hs.Add("@Roleid", !string.IsNullOrEmpty(Convert.ToString(objUser.RoleId)) ? objUser.RoleId : 0);

                dsSearch = _presenter.GetSearchExportList(hs);
                //gvCaseList.HeaderRow.Cells[6].Visible = false;
                if (dsSearch != null && dsSearch.Tables.Count != 0)
                {
                    dt = dsSearch.Tables[0];
                }
                if (dt != null)
                {
                    dt.Columns.Remove("StatusId");
                    dt.Columns.Remove("EmailboxId");
                    dt.Columns.Remove("ISACTIVE");
                    if (dt.Rows.Count > 0)
                    {
                        ExportToExcel(dt);
                    }
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | btnExportExcel_Click()");
                //errorlog.HandleError(ex, objUser.UserId, " | Search.cs | btnExportExcel_Click()");
                //Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {

        }



        private static string ReplaceSpecialCharacters(string FileName)
        {
            //return FileName.Replace("\"", "%").Replace("*", "%").Replace(@"/", "%").Replace(":", "%").Replace("<", "%").Replace(">", "%").Replace("?", "%").Replace(@"\", "%").Replace("|", "%").Replace("\t", "%").Replace("\r", "%").Replace("\n", "%").Replace(" ", "%");
            return FileName.Replace(" ", "%");
        }

        private static string ReplaceSpaces(string FileName)
        {
            //return FileName.Replace("\"", "%").Replace("*", "%").Replace(@"/", "%").Replace(":", "%").Replace("<", "%").Replace(">", "%").Replace("?", "%").Replace(@"\", "%").Replace("|", "%").Replace("\t", "%").Replace("\r", "%").Replace("\n", "%").Replace(" ", "%");
            return FileName.Replace("%", " ");
        }
        #endregion

       
        /// <summary>
        /// Pranay --30 September 2016--- functionality to be performed on Reopen button click 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnReOpen_Click(object sender, EventArgs e)
        {
            try
            {
                IsSessionValid();

                string NewCases = string.Empty;
                string truncatedCaseIds = string.Empty;
                int intNoOfRecordsInserted = 0;

                foreach (GridViewRow gvRow in gvCaseList.Rows)
                {
                    string strcaseid = string.Empty;

                    CheckBox chk = (CheckBox)gvRow.FindControl("ChkboxReassign");
                    LinkButton LnkBtnCaseId = (LinkButton)gvRow.FindControl("lnkbtnCaseId");
                    strcaseid = LnkBtnCaseId.Text.Trim();
                    if (chk.Checked == true && strcaseid != string.Empty)
                    {

                        //string subject = gvRow.FindControl("Subject").ToString();
                        string subject = gvCaseList.Rows[gvRow.RowIndex].Cells[3].Text;

                        int mailboxid = Convert.ToInt32(ddlEMailbox.SelectedItem.Value);
                        DataSet ds = _presenter.LoadCaseDetails(Convert.ToInt32(strcaseid), mailboxid, objUser.UserId, 10, Convert.ToInt32(objUser.RoleId));

                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            string fromEmailId = string.Empty;
                            string toEmailId = string.Empty;
                            string ccEmailId = string.Empty;
                            string bccEmailId = string.Empty;

                            bool isManual = Convert.ToBoolean(ds.Tables[0].Rows[0]["ISMANUAL"]);
                            if (isManual)
                            {
                                fromEmailId = ds.Tables[0].Rows[0]["EMAILBOXADDRESS"].ToString();
                                toEmailId = ds.Tables[0].Rows[0]["EMAILFROM"].ToString();
                            }
                            else
                            {
                                fromEmailId = ds.Tables[0].Rows[0]["EMAILFROM"].ToString();
                                toEmailId = ds.Tables[0].Rows[0]["EMAILBOXADDRESS"].ToString();
                            }
                            ccEmailId = ds.Tables[0].Rows[0]["EmailCC"].ToString();

                            bool isUrgent = Convert.ToBoolean(ds.Tables[0].Rows[0]["ISURGENT"]);
                            string emailbody = ds.Tables[0].Rows[0]["EMailBody"].ToString();

                            Hashtable ht = new Hashtable();
                            ht.Add("@Received_date", DateTime.Now);
                            ht.Add("@MailFolder_Id", mailboxid);
                            ht.Add("@Status_Id", "1");
                            ht.Add("@Subject", subject);
                            ht.Add("@Message", emailbody);
                            ht.Add("@From_Add", fromEmailId);
                            ht.Add("@Toaddress", toEmailId);
                            ht.Add("@CCaddress", ccEmailId);
                            ht.Add("@BCCaddress", bccEmailId.ToString());
                            ht.Add("@Priority", isUrgent);
                            ht.Add("@IsManual", isManual);

                            int newcaseid = _presenter.InsertMailForReopenCases(ht);
                            NewCases = NewCases + newcaseid.ToString();
                            if (newcaseid != -99)
                            {
                                Hashtable htcaseid = new Hashtable();
                                htcaseid.Add("@OLDCASEID", strcaseid);
                                htcaseid.Add("@NEWCASEID", newcaseid);
                                int insertattachment = this._presenter.InsertAttachmentForReopenCases(htcaseid);
                                intNoOfRecordsInserted = intNoOfRecordsInserted + 1;
                                NewCases = NewCases + ',';

                            }

                        }
                    }


                    //else 
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select atleast one Case to ReOpen!');", true);
                    //}


                }

                if (intNoOfRecordsInserted > 0)
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Total " + intNoOfRecordsInserted + " case(s) has been Reopened. New CaseIds are (" + NewCases.Remove(NewCases.Length - 1) + ")');", true);
                }
                else if (intNoOfRecordsInserted == 0)
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select atleast one Case to ReOpen!');", true);
                }

                BindCaseList();
                gvCaseList.Columns[0].Visible = true;
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Search.cs | btnReOpen_Click()");
                //errorlog.HandleError(ex, objUser.UserId , " | Search.cs | btnReOpen_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }


        /// <summary>
        ///  Pranay --24 October 2016--- functionality to be performed on Flag button click (Patheon CR(Marking cases with flag))
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        //protected void btnFlag_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        IsSessionValid();

        //        int intNoofRecordsFlagged = 0;

        //        foreach (GridViewRow gvRow in gvCaseList.Rows)
        //        {
        //            string strcaseid = string.Empty;

        //            CheckBox chk = (CheckBox)gvRow.FindControl("ChkboxReassign");
        //            LinkButton LnkBtnCaseId = (LinkButton)gvRow.FindControl("lnkbtnCaseId");
        //            strcaseid = LnkBtnCaseId.Text.Trim();

        //            if (chk.Checked == true && strcaseid != string.Empty)
        //            {
        //                int countryid = Convert.ToInt32(ddlCountry.SelectedItem.Value);
        //                int mailboxid = Convert.ToInt32(ddlEMailbox.SelectedItem.Value);
        //                int referenceid = Convert.ToInt32(ddlflagCriteria.SelectedItem.Value);
        //                string flaggedby = objUser.UserId;

        //                Hashtable ht = new Hashtable();
        //                ht.Add("@CaseId", strcaseid);
        //                ht.Add("@CountryId", countryid);
        //                ht.Add("@EmailBoxId",mailboxid);
        //                ht.Add("@ReferenceId",referenceid);
        //                ht.Add("@ReferencedBy",flaggedby);
        //                ht.Add("@CreatedDate", DateTime.Now);

        //                int newcaseid = _presenter.InsertDetailsForFlaggedCases(ht);
        //                if (newcaseid != -99)
        //                {

        //                    intNoofRecordsFlagged = intNoofRecordsFlagged + 1;
        //                }

        //            }
        //        }
        //        if (intNoofRecordsFlagged > 0)
        //        {
        //            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Total " + intNoofRecordsFlagged + " case(s) has been Flagged to refer in future');", true);
        //        }
        //        else if (intNoofRecordsFlagged == 0)
        //        {
        //            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select atleast one Case to Flagged!');", true);
        //        }


        //    }
        //    catch (Exception ex)
        //    {
        //        errorlog.HandleError(ex, objUser.UserId + "| Search.cs | btnFlag_Click()");
        //        Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
        //    }
        //}


        /// <summary>
        ///  Pranay --24 October 2016--- functionality to be performed on UnFlag button click (Patheon CR(Marking cases with flag))
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUnflag_Click(object sender, EventArgs e)
        {
            try
            {
                IsSessionValid();

                int intNoofRecordsUnFlagged = 0;
                string unFlaggedIds = string.Empty;
                string NotUnFlaggedIds = string.Empty;
                foreach (GridViewRow gvRow in gvCaseList.Rows)
                {
                    string strcaseid = string.Empty;
                    string flaggedbyUserId = string.Empty;
                    string IsFlagged = string.Empty;


                    string Unflaggedby = objUser.UserId;

                    CheckBox chk = (CheckBox)gvRow.FindControl("ChkboxReassign");
                    LinkButton LnkBtnCaseId = (LinkButton)gvRow.FindControl("lnkbtnCaseId");
                    strcaseid = LnkBtnCaseId.Text.Trim();


                    Label LabelFlaggedByUserId = (Label)gvRow.FindControl("FlaggedByUserId");
                    flaggedbyUserId = LabelFlaggedByUserId.Text.Trim();


                    //Label LabelIsFlagged = (Label)gvRow.FindControl("IsFlagged");
                    //IsFlagged = LabelIsFlagged.Text.Trim();
                    IsFlagged = gvCaseList.Rows[gvRow.RowIndex].Cells[7].Text;

                    if (chk.Checked == true && strcaseid != string.Empty)
                    {
                        if ((flaggedbyUserId == objUser.UserId && (objUser.RoleId == (int)Constant.UserRole.Processor) && IsFlagged == "Yes"))
                        {
                            int countryid = Convert.ToInt32(ddlCountry.SelectedItem.Value);
                            int mailboxid = Convert.ToInt32(ddlEMailbox.SelectedItem.Value);
                            int referenceid = Convert.ToInt32(ddlflagCriteria.SelectedItem.Value);
                            //string Unflaggedby = objUser.UserId;

                            Hashtable ht = new Hashtable();
                            ht.Add("@CaseId", strcaseid);
                            ht.Add("@UnFlaggedBy", Unflaggedby);
                            ht.Add("@ModifiedDate", DateTime.Now);

                            int totalUpdate = _presenter.UpdateDetailsForUnFlaggedCases(ht);
                            if (totalUpdate != -99)
                            {
                                unFlaggedIds = unFlaggedIds + strcaseid + ',';
                                intNoofRecordsUnFlagged = intNoofRecordsUnFlagged + 1;
                            }

                        }
                        else if ((objUser.RoleId == (int)Constant.UserRole.TeamLead) && IsFlagged == "Yes")
                        {
                            Hashtable ht = new Hashtable();
                            ht.Add("@CaseId", strcaseid);
                            ht.Add("@UnFlaggedBy", Unflaggedby);
                            ht.Add("@ModifiedDate", DateTime.Now);

                            int totalUpdate = _presenter.UpdateDetailsForUnFlaggedCases(ht);
                            if (totalUpdate != -99)
                            {
                                unFlaggedIds = unFlaggedIds + strcaseid + ',';
                                intNoofRecordsUnFlagged = intNoofRecordsUnFlagged + 1;
                            }
                        }
                        else
                        {
                            NotUnFlaggedIds = NotUnFlaggedIds + strcaseid + ',';
                        }
                    }
                }
                if ((intNoofRecordsUnFlagged > 0) && !String.IsNullOrEmpty(NotUnFlaggedIds))
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Ids Unflagged are( " + unFlaggedIds.Remove(unFlaggedIds.Length - 1) + "). Case(s) which are not unflagged are (" + NotUnFlaggedIds.Remove(NotUnFlaggedIds.Length - 1) + "). \\n Note:- Processor can only Unflag cases which are flagged by him.');", true);
                }
                else if ((intNoofRecordsUnFlagged > 0) && String.IsNullOrEmpty(NotUnFlaggedIds))
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Ids Unflagged are( " + unFlaggedIds.Remove(unFlaggedIds.Length - 1) + ").\\n  \\nNote:-  Processor can only Unflag cases which are flagged by him.');", true);
                }
                else if (intNoofRecordsUnFlagged == 0 && (objUser.RoleId == (int)Constant.UserRole.Processor))
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select atleast one case Flagged by you to proceed further!.\\n  \\nNote:-  Processor can only Unflag cases which are flagged by him.');", true);
                }
                else if (intNoofRecordsUnFlagged == 0 && (objUser.RoleId == (int)Constant.UserRole.TeamLead))
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select atleast one case Flagged to proceed further!.');", true);
                }
                BindCaseList();
                if (gvCaseList.Rows.Count > 0)
                {
                    gvCaseList.Columns[0].Visible = true;
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, "| Search.cs | btnFlag_Click()");
                //errorlog.HandleError(ex, objUser.UserId , "| Search.cs | btnFlag_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

    }
}

