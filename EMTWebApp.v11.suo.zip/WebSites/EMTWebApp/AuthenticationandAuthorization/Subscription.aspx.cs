﻿using EMTWebApp.AuthenticationandAuthorization.Views;
using Microsoft.Practices.ObjectBuilder;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security;
using System.Runtime.InteropServices;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.DirectoryServices.AccountManagement;
using DigiOPS.TechFoundation.Logging;

namespace EMTWebApp.AuthenticationandAuthorization.Views
{
    public partial class Subscription : Microsoft.Practices.CompositeWeb.Web.UI.Page, ILoginView
    {
        UserErrorLog errorlog = new UserErrorLog();

        private LoginPresenter objPresenter;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    string uname = "";// Environment.UserName;

                    char[] sep = { '\\' };
                    string[] a = Request.LogonUserIdentity.Name.Split(sep);
                    if (a.Length == 1)
                        uname = a.GetValue(0).ToString();
                    else
                        uname = a.GetValue(1).ToString();

                    using (var context = new PrincipalContext(ContextType.Domain, "cts"))
                    {
                        using (var domainContext = new PrincipalContext(ContextType.Domain, "cts"))
                        {
                            using (var foundUser = UserPrincipal.FindByIdentity(domainContext, IdentityType.SamAccountName, uname))
                            {
                                if (foundUser != null)
                                {
                                    lblUnameID.Text = foundUser.Name + "(" + uname + ")";
                                    lblEmailId.Text = foundUser.EmailAddress;

                                    hdnUserid.Value = uname;

                                    if (Request.QueryString["Subject"] != null)
                                    {
                                        lblSubject.Text = Request.QueryString["Subject"].ToString();
                                    }
                                }
                            }
                        }
                    }

                    this.objPresenter.OnViewInitialized();
                }
            }
            catch (Exception ex) {

                errorlog.HandleError(ex, "", "Login.aspx.cs|Page_Load");
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, "", "Login.aspx.cs|Page_Load");
            }

        }
        protected void btnOptin_Click(object sender, EventArgs e)
        {
            try
            {
                Hashtable hs = new Hashtable();
                hs.Add("@UserID", hdnUserid.Value);
                hs.Add("@Subject", lblSubject.Text);
                hs.Add("@SubscriptionStatus", "Subscribe");

                int status = objPresenter.InsertSubscription(hs);
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "complete('Opt-in');", true);
               // ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "$(function() {complete('in');}", true);
            }
            catch
            {

            }
        }
        protected void btnOptout_Click(object sender, EventArgs e)
        {
            try
            {
                Hashtable hs = new Hashtable();
                hs.Add("@UserID", hdnUserid.Value);
                hs.Add("@Subject", lblSubject.Text);
                hs.Add("@SubscriptionStatus", "UnSubscribe");

                int status = objPresenter.InsertSubscription(hs);

                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "complete('Opt-out');", true);
               // ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "$(function() {complete('out');}", true);
            }
            catch
            {

            }
        }

        #region PROPERTIES
        [CreateNew]
        public LoginPresenter Presenter
        {
            get
            {
                return this.objPresenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this.objPresenter = value;
                this.objPresenter.View = this;
            }
        }
        #endregion

    }
}