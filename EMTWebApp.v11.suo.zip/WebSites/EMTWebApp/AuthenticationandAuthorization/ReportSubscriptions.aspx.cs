﻿using EMTWebApp.AuthenticationandAuthorization.Views;
using Microsoft.Practices.ObjectBuilder;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security;
using System.Runtime.InteropServices;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.DirectoryServices.AccountManagement;
using DigiOPS.TechFoundation.Logging;
using System.Data.SqlClient;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using EMTWebApp.UserManagement.Common;
using EMTWebApp.Constants;

namespace EMTWebApp.AuthenticationandAuthorization.Views
{
    public partial class ReportSubscriptions : Microsoft.Practices.CompositeWeb.Web.UI.Page, ILoginView
    {

        public SqlConnection connection = new SqlConnection(@"Data Source=CTSC00617635601; Initial Catalog=EMT_SV_RT;User Id=emtuser;Password=password-1;");
        //public SqlConnection connection = new SqlConnection(@"Data Source=CTSINPUNVPTRA02; Initial Catalog=EMTDemo;User Id=EMTUser;Password=EMTUser;");

        UserErrorLog errorlog = new UserErrorLog();

        private LoginPresenter objPresenter;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    string uname = "";// Environment.UserName;

                    char[] sep = { '\\' };
                    string[] a = Request.LogonUserIdentity.Name.Split(sep);
                    if (a.Length == 1)
                        uname = a.GetValue(0).ToString();
                    else
                        uname = a.GetValue(1).ToString();

                    using (var context = new PrincipalContext(ContextType.Domain, "cts"))
                    {
                        using (var domainContext = new PrincipalContext(ContextType.Domain, "cts"))
                        {
                            using (var foundUser = UserPrincipal.FindByIdentity(domainContext, IdentityType.SamAccountName, uname))
                            {
                                if (foundUser != null)
                                {
                                    //DataTable UserDetails = CreateUserSession(uname);

                                    //if (UserDetails.Rows.Count > 0)
                                    //{
                                    //    string RoleId = UserDetails.Rows[0]["RoleId"].ToString();

                                    //    if ((RoleId == Constant.UserRole.SuperAdmin.ToString()) || (RoleId == Constant.UserRole.Admin.ToString()) || (RoleId == Constant.UserRole.TeamLead.ToString()) || (RoleId == Constant.UserRole.ClientUser.ToString()))
                                    //    {
                                            pageContainer.Style.Add("display", "block");
                                            pageUnAuthorizedContainer.Style.Add("display", "none");
                                    //      }
                                    //     else
                                    //      {
                                          //  pageContainer.Style.Add("display", "none");
                                          //  pageUnAuthorizedContainer.Style.Add("display", "block");
                                    //       }
                                    //}
                                    //else
                                    //{
                                    //    pageContainer.Style.Add("display", "none");
                                    //    pageUnAuthorizedContainer.Style.Add("display", "block");
                                    //}
                                    lblUnameID.Text = foundUser.Name + "(" + uname + ")";
                                    lblEmailId.Text = foundUser.EmailAddress;

                                    lblUserID.Text = "User " + uname;
                                    hdnUserid.Value = uname;

                                    //lblUnameID.Text = "Guest";
                                    //lblEmailId.Text = foundUser.EmailAddress;

                                    //lblUserID.Text = "User Guest";

                                    //txtEmailId.Visible = true;
                                    //lblEmailId.Visible = false;
                                    //if (Request.QueryString["Subject"] != null)
                                    //{
                                    //    lblSubject.Text = Request.QueryString["Subject"].ToString();
                                    //}
                                }
                                else
                                {
                                    lblUnameID.Text = "Guest";
                                    //lblEmailId.Text = foundUser.EmailAddress;

                                    lblUserID.Text = "User Guest";
                                    lblEmailId.Visible = false;
                                    txtEmailId.Visible = true;
                                    //txtEmailId.Focus();

                                    hdnUserid.Value = txtEmailId.Text;
                                }
                            }
                        }
                    }

                    this.objPresenter.OnViewInitialized();
                }
            }
            catch (Exception ex)
            {

                errorlog.HandleError(ex, "", "ReportSubscriptions.aspx.cs|Page_Load");
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, "", "ReportSubscriptions.aspx.cs|Page_Load");
            }

        }

        //private DataTable CreateUserSession(string UserId)
        //{
        //    DataTable dtUserdetails = null;
            
        //    try
        //    {
        //        connection.Open();
        //        SqlCommand sqlCommand = new SqlCommand("USP_USERSESSION", connection);
        //        sqlCommand.CommandType = CommandType.StoredProcedure;
        //        sqlCommand.Parameters.AddWithValue("@UserId", UserId);

        //        IDataReader UserDetails = sqlCommand.ExecuteReader();
              
        //        bool singleround = false;
        //        while (UserDetails.Read())
        //        {
        //            if (!singleround)
        //            {
        //                DataRow dr = new DataRow();

        //                dr["UserID"] =  UserDetails["UserID"].ToString();
        //                dr["FirstName"] = UserDetails["First Name"].ToString();
        //                dr["LastName"] = UserDetails["Last Name"].ToString();
        //                dr["RoleId"] = Convert.ToInt16(UserDetails["RoleID"]);
        //                dr["RoleName"] = UserDetails["RoleName"].ToString();

        //                dtUserdetails.Rows.Add(dr);
        //            }

        //            singleround = true;
        //        }
        //        return dtUserdetails;
                
        //        UserDetails.Close();
        //        connection.Close();
 
        //    }
        //    catch (Exception ex)
        //    {
        //        connection.Close();
 
        //        errorlog.HandleError(ex, "", "ReportSubscriptions.aspx.cs|Page_Load");
        //        new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, "", "ReportSubscriptions.aspx.cs|Page_Load");
        //    }
        //}

         

        protected void btnSubmitChanges_Click(object sender, EventArgs e)
        {
            try
            {
                if (hdnUserid.Value != "")
                {

                    // Over all weekly subscription
                    string OverallweeklyStatus = hdnOverallWeekly.Value;
                     
                    Hashtable hsOverallweekly = new Hashtable();
                    hsOverallweekly.Add("@UserID", hdnUserid.Value);

                    hsOverallweekly.Add("@Subject", lblOverallWeekly.Text);
                    if (OverallweeklyStatus == "Opt-Out")
                        hsOverallweekly.Add("@SubscriptionStatus", "UnSubscribe");
                    else
                        hsOverallweekly.Add("@SubscriptionStatus", "Subscribe");
                    hsOverallweekly.Add("@Interval", "Weekly");
                    int OAWkstatus = InsertSubscription(hsOverallweekly);

                    // TAT weekly subscription
                    string TATweeklyStatus = hdnTATWeekly.Value;

                    Hashtable hsTATweekly = new Hashtable();
                    hsTATweekly.Add("@UserID", hdnUserid.Value);

                    hsTATweekly.Add("@Subject", lblTATWeekly.Text);
                    if (TATweeklyStatus == "Opt-Out")
                        hsTATweekly.Add("@SubscriptionStatus", "UnSubscribe");
                    else
                        hsTATweekly.Add("@SubscriptionStatus", "Subscribe");

                    hsTATweekly.Add("@Interval", "Weekly");

                    int TATWkstatus = InsertSubscription(hsTATweekly);

                    // Over all monthly subscription
                    string OverallmonthlyStatus = hdnOverallMonthly.Value;

                    Hashtable hsOverallmonthly = new Hashtable();
                    hsOverallmonthly.Add("@UserID", hdnUserid.Value);

                    hsOverallmonthly.Add("@Subject", lblOverallMonthly.Text);
                    if (OverallmonthlyStatus == "Opt-Out")
                        hsOverallmonthly.Add("@SubscriptionStatus", "UnSubscribe");
                    else
                        hsOverallmonthly.Add("@SubscriptionStatus", "Subscribe");
                    hsOverallmonthly.Add("@Interval", "Monthly");

                    int OAMNstatus = InsertSubscription(hsOverallmonthly);

                    // TAT monthly subscription
                    string TATmonthlyStatus = hdnTATMonthly.Value;

                    Hashtable hsTATmonthly = new Hashtable();
                    hsTATmonthly.Add("@UserID", hdnUserid.Value);

                    hsTATmonthly.Add("@Subject", lblTATMonthly.Text);
                    if (TATmonthlyStatus == "Opt-Out")
                        hsTATmonthly.Add("@SubscriptionStatus", "UnSubscribe");
                    else
                        hsTATmonthly.Add("@SubscriptionStatus", "Subscribe");
                    hsTATmonthly.Add("@Interval", "Monthly");

                    int TATMNstatus = InsertSubscription(hsTATmonthly);


                    hdnOverallWeekly.Value = "";
                    hdnTATWeekly.Value = "";
                    hdnOverallMonthly.Value = "";
                    hdnTATMonthly.Value = "";

                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "complete('Opt-out');", true);
                    // ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "$(function() {complete('out');}", true);
                }
                else
                {
                    txtEmailId.Visible = true;
                    //txtEmailId.setFocus();
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "alert('Please enter email address and try again!!!')", true);
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "alert('Unable to process your request, please try again!!!')", true);
            }
        }

        protected int InsertSubscription(Hashtable hs)
        {
            int InsCount = 0;
            try
            {
                string commandText_Tab_1 = "InsertReportSubscriberContact";
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand(commandText_Tab_1, connection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                AddParameter(ref sqlCommand, hs);

                InsCount = Convert.ToInt32(sqlCommand.ExecuteScalar());
                connection.Close();
            }
            catch (Exception ex)
            {
                connection.Close();
            }
            return InsCount;
        }

        private void AddParameter(ref SqlCommand command, Hashtable values)
        {
            try
            {
                foreach (string key in values.Keys)
                {
                    object obj = DBNull.Value;
                    if (values[key].ToString() == "" || values[key].ToString() == "0001-01-01 00:00:00.000")
                        obj = DBNull.Value;
                    else
                        obj = values[key];
                    command.Parameters.Add(new SqlParameter(key.ToString(), obj));
                }
            }
            catch (Exception ex)
            {

            }
        }


        //#region PROPERTIES
        //[CreateNew]
        //public LoginPresenter Presenter
        //{
        //    get
        //    {
        //        return this.objPresenter;
        //    }
        //    set
        //    {
        //        if (value == null)
        //            throw new ArgumentNullException("value");

        //        this.objPresenter = value;
        //        this.objPresenter.View = this;
        //    }
        //}
        //#endregion

    }
}