﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//using Outlook = Microsoft.Office.Interop.Outlook;

using Microsoft.Exchange.WebServices;
//using Microsoft.Office.Interop.Outlook;
//using System.Net.Mail;
using Microsoft.Exchange.WebServices.Data;
using System.Net;
using System.Web.Services.Description;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices.ActiveDirectory;
using System.Text;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data;
using System.Data.SqlClient;


namespace EMTWebApp.AuthenticationandAuthorization.Views
{
    public partial class CreateDL : Microsoft.Practices.CompositeWeb.Web.UI.Page, ILoginView
    {

        ExchangeService service;
        Mailbox EMailBox;

        //public SqlConnection connection = new SqlConnection(@"Data Source=CTSINTBMVBFS\SQL_SERVER12; Initial Catalog=EMT_SV_RT;User Id=sa2;Password=password-1;");
        public SqlConnection connection = new SqlConnection(@"Data Source=CTSINPUNVPTRA02; Initial Catalog=EMTDemo;User Id=EMTUser;Password=EMTUser;");


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void CreateMailboxConnection()
        {
            service = new ExchangeService(ExchangeVersion.Exchange2010_SP1);
            service.Url = new Uri("https://mail.cognizant.com/EWS/exchange.asmx");
            service.Credentials = new WebCredentials("cemtdev5", "E111111#", "cts");
            service.TraceEnabled = false;

            EMailBox = new Mailbox("EMTDev5@cognizant.com");
        }

        protected void btnCreateDL_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    //Outlook._Application obj;
            //    //CreateNewDistributionList(obj);

            //    CreateMailboxConnection();

            //    FolderView cfv = new FolderView(1000);
            //    cfv.Traversal = FolderTraversal.Shallow;
            //    SearchFilter cfFilter = new SearchFilter.IsEqualTo(FolderSchema.DisplayName, "Others");
            //    FolderId cntfld = new FolderId(WellKnownFolderName.Contacts, EMailBox);
            //    FindFoldersResults ffcResult = service.FindFolders(cntfld, cfFilter, cfv);
            //    if (ffcResult.Folders.Count == 1)
            //    {
            //        ContactGroup cg = new ContactGroup(service);
            //        cg.DisplayName = txtDLName.Text;
            //        cg.Save(ffcResult.Folders[0].Id);

            //        //cg.Members.Add(new GroupMember("bramharajavarma.rk@cognizant.com"));
            //        //cg.Members.Add(new GroupMember("karthikeyan.alagar@cognizant.com"));
            //        //cg.Update(0);

            //        //Contact newContact = new Contact(service);
            //        //newContact.GivenName = "John";
            //        //newContact.Surname = "Smith";
            //        //newContact.FileAsMapping = FileAsMapping.GivenNameSpaceSurname;
            //        //newContact.CompanyName = "Smith & Smith Inc.";
            //        //newContact.JobTitle = "CEO";
            //        //newContact.AssistantName = "Pocahontas";
            //        //newContact.Body = @"Captain John Smith (c. January 1580 – 21 June 1631) Admiral " +
            //        //"of New England was an English soldier, explorer, and author. He was knighted " +
            //        //"for his services to Sigismund Bathory, Prince of Transylvania and friend Mozes Szekely.";
            //        //// Add E-mail Addresses
            //        //EmailAddress contactEmail1 = new EmailAddress("Work", "bramharajavarma.rk@cognizant.com");
            //        //newContact.EmailAddresses[EmailAddressKey.EmailAddress1] = contactEmail1;

            //        //Guid propertySetId = new Guid("{F4FD924D-5489-4AE1-BD43-25491342529B}");
            //        //ExtendedPropertyDefinition clientIdPropertyDefinition =
            //        //    new ExtendedPropertyDefinition(propertySetId, "ClientId", MapiPropertyType.String);
            //        //newContact.SetExtendedProperty(clientIdPropertyDefinition, "SMITHINC");

            //        //newContact.Save();

            //        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Contact Group created sucessfully in Mailbox!!');", true);
            //    }

            //    //CreateDistributionList();}
            //}
            //catch (Exception ex)
            //{
            //    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('" + ex.Message + "');", true);
            //}
        }

        protected void btnAddMemmbers_Click(object sender, EventArgs e)
        {
            try
            {
                //    CreateMailboxConnection();

                //    ItemView ItemView = new ItemView(1);
                //    SearchFilter cntGroup = new SearchFilter.IsEqualTo(ItemSchema.ItemClass, "Others");
                //    SearchFilter cntGroupName = new SearchFilter.IsEqualTo(ContactGroupSchema.DisplayName, "Test CG");
                //    SearchFilter sfCol = new SearchFilter.SearchFilterCollection(LogicalOperator.And) { cntGroup, cntGroupName };

                //    FolderId ContactFolder = new FolderId(WellKnownFolderName.Contacts, EMailBox);
                //    FindItemsResults<Item> fiCntResults = service.FindItems(ContactFolder, sfCol, ItemView);
                //    if (fiCntResults.Items.Count == 1)
                //    {
                //        ContactGroup contactGroup = (ContactGroup)fiCntResults.Items[0];

                //        GroupMember gm1 = new GroupMember(txtMember1.Text);
                //        GroupMember gm2 = new GroupMember(txtMember2.Text);

                //        contactGroup.Members.Add(gm1);
                //        contactGroup.Members.Add(gm2);

                //        contactGroup.Update(ConflictResolutionMode.AlwaysOverwrite);
                //    }

            }
            catch (Exception ex)
            {
                //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('" + ex.Message + "');", true);
            }
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            string commandText_Tab_1 = "GetSubscriberContact";
            connection.Open();

            using (SqlCommand sqlCommand = new SqlCommand(commandText_Tab_1, connection))
            {
                SqlDataAdapter da = new SqlDataAdapter(sqlCommand);

                DataSet ds = new DataSet();
                da.Fill(ds);

                try
                {
                    if (ds != null)
                    {
                        if (ds.Tables[0] != null)
                        {
                            List<string> strSubscribeUsers = new List<string>();
                            List<string> strUnSubscribeUsers = new List<string>();
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                if (dr["SubscriptionStatus"].ToString() == "Subscribe")
                                {

                                    using (var context = new PrincipalContext(ContextType.Domain, "cts"))
                                    {
                                        using (var domainContext = new PrincipalContext(ContextType.Domain, "cts"))
                                        {
                                            using (var foundUser = UserPrincipal.FindByIdentity(domainContext, IdentityType.SamAccountName, dr["UserID"].ToString()))
                                            {
                                                if (foundUser != null)
                                                {
                                                    strSubscribeUsers.Add(foundUser.EmailAddress);
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    using (var context = new PrincipalContext(ContextType.Domain, "cts"))
                                    {
                                        using (var domainContext = new PrincipalContext(ContextType.Domain, "cts"))
                                        {
                                            using (var foundUser = UserPrincipal.FindByIdentity(domainContext, IdentityType.SamAccountName, dr["UserID"].ToString()))
                                            {
                                                if (foundUser != null)
                                                {
                                                    strUnSubscribeUsers.Add(foundUser.EmailAddress);
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            AddRemoveGroupMember("Others", "HCDO|| IMPACT News Bulletin", "Add", strSubscribeUsers);
                            AddRemoveGroupMember("Others", "HCDO|| IMPACT News Bulletin", "Remove", strUnSubscribeUsers);
                        }
                    }

                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Contact Groups updated sucessfully in Mailbox!!');", true);
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('" + ex.Message + "');", true);
                }
                finally
                {
                    connection.Close();
                }
            }
        }
        protected void AddRemoveGroupMember(string Contactsfolder, string GroupName, string AddOrRemove, List<string> lstUsrs)
        {
            try
            {
                CreateMailboxConnection();


                FolderView cfv = new FolderView(1000);
                cfv.Traversal = FolderTraversal.Shallow;
                SearchFilter cfFilter = new SearchFilter.IsEqualTo(FolderSchema.DisplayName, "Others");
                FolderId cntfld = new FolderId(WellKnownFolderName.Contacts, EMailBox);
                FindFoldersResults ffcResult = service.FindFolders(cntfld, cfFilter, cfv);

                if (ffcResult.Folders.Count == 1)
                {
                    ItemView ItemView = new ItemView(9999);
                    SearchFilter cntGroup = new SearchFilter.IsEqualTo(ItemSchema.ItemClass, Contactsfolder);
                    SearchFilter cntGroupName = new SearchFilter.IsEqualTo(ContactGroupSchema.DisplayName, GroupName);

                    FindItemsResults<Item> fiCntResults = service.FindItems(ffcResult.Folders[0].Id, cntGroupName, ItemView);

                    if (fiCntResults.Items.Count == 1)
                    {
                        ContactGroup contactGroup = (ContactGroup)fiCntResults.Items[0];

                        if (AddOrRemove == "Add")
                        {
                            foreach (string newusr in lstUsrs)
                            {
                                GroupMember gm1 = new GroupMember(newusr);
                                contactGroup.Members.Add(gm1);
                            }
                        }
                        else
                        {
                            foreach (string newusr1 in lstUsrs)
                            {
                                GroupMember gm2 = new GroupMember(newusr1);
                                bool test = contactGroup.Members.Remove(gm2);
                            }
                        }
                        contactGroup.Update(ConflictResolutionMode.AlwaysOverwrite);
                    }
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('" + ex.Message + "');", true);
            }
        }

    }



    public static class DomainManager
    {
        static DomainManager()
        {
            Domain domain = null;
            DomainController domainController = null;
            try
            {
                domain = Domain.GetCurrentDomain();
                DomainName = domain.Name;
                domainController = domain.PdcRoleOwner;
                DomainControllerName = domainController.Name.Split('.')[0];
                ComputerName = Environment.MachineName;
            }
            finally
            {
                if (domain != null)
                    domain.Dispose();
                if (domainController != null)
                    domainController.Dispose();
            }
        }

        public static string DomainControllerName { get; private set; }

        public static string ComputerName { get; private set; }

        public static string DomainName { get; private set; }

        public static string DomainPath
        {
            get
            {
                bool bFirst = true;
                StringBuilder sbReturn = new StringBuilder(200);
                string[] strlstDc = DomainName.Split('.');
                foreach (string strDc in strlstDc)
                {
                    if (bFirst)
                    {
                        sbReturn.Append("DC=");
                        bFirst = false;
                    }
                    else
                        sbReturn.Append(",DC=");

                    sbReturn.Append(strDc);
                }
                return sbReturn.ToString();
            }
        }

        public static string RootPath
        {
            get
            {
                return string.Format("LDAP://{0}/{1}", DomainName, DomainPath);
            }
        }
    }
}