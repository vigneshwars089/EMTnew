﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;

using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.SessionState;
using System.Reflection;
using System.Configuration;
//SSO login 
//using QuartSecurity;
using DigiOPS.TechFoundation.Security;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using DigiOPS.TechFoundation.Logging;
using EMTWebApp.UserManagement;
using EMTWebApp.Constants;
using System.Text;
using EMTWebApp.UserManagement.Views;
using DigiOPS.TechFoundation.ExceptionHandling;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using System.Web.Security;
using System.Security;
using System.Runtime.InteropServices;

namespace EMTWebApp.AuthenticationandAuthorization.Views
{
    public partial class Login : Microsoft.Practices.CompositeWeb.Web.UI.Page, ILoginView, IForgotPasswordView
    {
        #region DECLARATION

        private LoginPresenter objPresenter;
        UserSession objUser = new UserSession();
        public string LoginID;
        string UserName;
        public string Pkeyword;
        UserErrorLog errorlog = new UserErrorLog();
        //SSO login 
        //UserAuthentication ADCheck = new UserAuthentication();
        //UserAuthentication
        UserContextInfo userContextInfo = new UserContextInfo();
        //Authentication ADCheck = new Authentication();
        string CheckWhichLoginType = ConfigurationManager.AppSettings["ADLogin"].ToString();
        //SSO login 
        CryptInfo cryptInfo = new CryptInfo();
        AccountLockInfo objacclockinfo = new AccountLockInfo();
        SecurityFactory securityFactory = new SecurityFactory();
        string cipher = ConfigurationManager.AppSettings["ENCRYPTIONKEY"].ToString();
        string encryptionmode = ConfigurationManager.AppSettings["ENCRYPT/DECRYPT"].ToString();
        double TokenExpiration = Convert.ToDouble(ConfigurationManager.AppSettings["TokenExpirationTimeInMinutes"].ToString());
        string TokenKey = ConfigurationManager.AppSettings["TokenKey"].ToString();
        Random rand = new Random();
        private ForgotPasswordPresenter _presenter;
        public static int logincount = 0;
        string AccountLockMailID = ConfigurationManager.AppSettings["AccountLockMailID"].ToString();
        EMTUserRepository objusrep = new EMTUserRepository();

        private const string AntiXsrfTokenKey = "__AntiXsrfToken";
        private const string AntiXsrfUserNameKey = "__AntiXsrfUserName";
        private string _antiXsrfTokenValue;

        #endregion


        /// <summary>
        /// To Initiate the controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 

        //    if (!this.Page.EnableViewStateMac)
        //    {
        //        throw new InvalidOperationException(
        //            "MAC is not enabled for the page and the view state is therefore vulnerable to tampering.");
        //    }
        //    ViewStateUserKey = Session.SessionID;
        //    ViewStateUserKey = LoginID;
        //    //base.OnInit(e);
        //}
        //protected void Page_Init(object sender, EventArgs e)
        //{
        //    // The below code helps to protect from XSRF attacks  
        //    var requestCookie = Request.Cookies[AntiXsrfToenKey];
        //    Guid requestCookieGuidValue;
        //    if (requestCookie != null && Guid.TryParse(requestCookie.Value, out requestCookieGuidValue))
        //    {
        //        // Use the Anti-XSRF token from the cookie  
        //        _antiXsrfToenValue = requestCookie.Value;
        //        Page.ViewStateUserKey = _antiXsrfToenValue;
        //    }
        //    else
        //    {
        //        // Create new Anti-XSRF token and assign to the cookie  
        //        _antiXsrfToenValue = Guid.NewGuid()
        //            .ToString("N");
        //        Page.ViewStateUserKey = _antiXsrfToenValue;
        //        var responseCookie = new HttpCookie(AntiXsrfToenKey)
        //        {
        //            HttpOnly = true,
        //            Value = _antiXsrfToenValue
        //        };
        //        Response.Cookies.Set(responseCookie);
        //    }
        //} 


        protected void Page_Init(object sender, EventArgs e)
        {
            //if (Session.IsNewSession)
            //{
            //    Session["UserDetails"] = DateTime.Now;
            //}
            Page.ViewStateUserKey = Session.SessionID;
            if (Page.EnableViewState)
            {

                if (!string.IsNullOrEmpty(Request.Params["__VIEWSTATE"]) && string.IsNullOrEmpty(Request.Form["__VIEWSTATE"]))
                {
                    throw new Exception("Cross Site History Manipulation happened...");
                }
            }

            // The code below helps to protect against XSRF attacks
            var requestCookie = Request.Cookies[AntiXsrfTokenKey];
            Guid requestCookieGuidValue;
            if (requestCookie != null && Guid.TryParse(requestCookie.Value, out requestCookieGuidValue))
            {
                // Use the Anti-XSRF token from the cookie
                _antiXsrfTokenValue = requestCookie.Value;
                Page.ViewStateUserKey = _antiXsrfTokenValue;
            }
            else
            {
                // Generate a new Anti-XSRF token and save to the cookie
                _antiXsrfTokenValue = Guid.NewGuid().ToString("N");
                Page.ViewStateUserKey = _antiXsrfTokenValue;
                Session["_antiXsrfTokenValue"] = _antiXsrfTokenValue;

                var responseCookie = new HttpCookie(AntiXsrfTokenKey)
                {
                    HttpOnly = true,
                    Value = _antiXsrfTokenValue
                };
                if (FormsAuthentication.RequireSSL && Request.IsSecureConnection)
                {
                    responseCookie.Secure = true;
                }
                Response.Cookies.Set(responseCookie);
            }

            Page.PreLoad += Page_PreLoad;

           

        }

        protected void Page_PreLoad(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Set Anti-XSRF token
                ViewState[AntiXsrfTokenKey] = Page.ViewStateUserKey;
                ViewState[AntiXsrfUserNameKey] = Context.User.Identity.Name ?? String.Empty;
            }
            else
            {
                // Validate the Anti-XSRF token
                if ((string)ViewState[AntiXsrfTokenKey] != _antiXsrfTokenValue
                    || (string)ViewState[AntiXsrfUserNameKey] != (Context.User.Identity.Name ?? String.Empty))
                {
                    //throw new InvalidOperationException("Validation of Anti-XSRF token failed.");
                    Server.Transfer(@"~/Errors/BadRequest.aspx?r=" + HelperMethods.GenerateSecureRandom());
                }
            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            //(select+,)
            //iterate through all the params and check for sql injection - saranya

            Regex regex = new Regex(System.Configuration.ConfigurationManager.AppSettings["SQLInjectionRegex"]);
                      
            foreach (string key in HttpContext.Current.Request.Form.Keys)
            {
                // if(key!="txtLoginId"&&key!="txtPKeyword")
                if (!String.IsNullOrEmpty(Request.Form[key]) && regex.Match(Request.Form[key]).Success)
                {
                    Server.Transfer(@"~/Errors/BadRequest.aspx?r=" + HelperMethods.GenerateSecureRandom());
                }
            }
            if (
               ( this.Request.UrlReferrer == null
                && this.Request.Headers["Referer"] == null)
                || 
                ((this.Request.UrlReferrer != null && this.Request.UrlReferrer.Host.Equals(this.Request.Url.Host))
                && (this.Request.Headers["Referer"] != null && this.Request.Headers["Referer"].Contains(this.Request.Url.Host))
                ))
            {
                regenerateId();
            if (!this.IsPostBack)
            {
                    //Pranay  3 March 2017 Uncommenting for Security Fix(Session Identifier Not Updated)
                //txtLoginId.Attributes.Add("autocomplete", "off");
                //txtPassword.Attributes.Add("autocomplete", "off");
                logincount = 0;
                try
                {
                    Response.Expires = 0;
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.Cache.SetNoServerCaching();
                    Response.Cache.SetNoStore();
                    Response.Cache.SetMaxAge(TimeSpan.Zero);
                    Response.AppendHeader("Pragma", "no-cache");
                    Page.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    if (Session["userdetails"] != null)
                    {
                        Session["userdetails"] = null;
			Session["UserID"] = null;
                    }
                    ///commented out for SSO login
                    //Session.Clear();
                    //Session.Abandon();
                    //LockAccount.Visible=false;
                    txtLoginId.Focus();
                    //Page.Form.DefaultButton = btnLogin.UniqueID;
                }
                catch (EMTException ex)
                {
                   // errorlog.HandleError(ex, objUser.UserId, " |  Login.aspx.cs|Page_Load");
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " |  Login.aspx.cs|Page_Load");
                }
                catch (Exception ex)
                {
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, LoginID, "Login.aspx.cs|Page_Load");
                    //errorlog.HandleError(ex, LoginID, "Login.aspx.cs|Page_Load");
                    //ExceptionHelper.HandleException(ex);
                }
                this.objPresenter.OnViewInitialized();
                this._presenter.OnViewInitialized();
                //SSO login
                    //if (Request.QueryString["t"] != null)
                    //{
                    //    SSOLogin();
                    //    return;
                    //}
                    //end
                }
                else
                {
                    if (Session.SessionID != Request.Cookies["ASP.NET_SessionId"].Value)
                {
                    Response.Redirect(@"~/Errors/SessionExpired.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                }
            }
            this.objPresenter.OnViewLoaded();
            this._presenter.OnViewLoaded();
        }
            else
            {
               // Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                Server.Transfer(@"~/Errors/BadRequest.aspx?r=" + HelperMethods.GenerateSecureRandom());
            }
        }
        #region PROPERTIES
        [CreateNew]
        public LoginPresenter Presenter
        {
            get
            {
                return this.objPresenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this.objPresenter = value;
                this.objPresenter.View = this;
            }
        }
        [CreateNew]
        public ForgotPasswordPresenter ForgotPresenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion
        #region PRIVATE METHODS
        /// <summary>
        /// TO CREATE THE SESSION WITH THE USERID
        /// </summary>
        /// <param name="userid"></param>
        private void CreateUserSession(string UserId)
        {
            try
            {
                UserSession UserData = new UserSession();
                IDataReader UserDetails = objPresenter.UserDetails(UserId);
                bool singleround = false;
                while (UserDetails.Read())
                {
                    if (!singleround)
                    {
                        UserData.UserId = UserDetails["UserID"].ToString();
                        UserData.FirstName = UserDetails["First Name"].ToString();
                        UserData.LastName = UserDetails["Last Name"].ToString();
                        UserData.RoleId = Convert.ToInt16(UserDetails["RoleID"]);
                        UserData.RoleName = UserDetails["RoleName"].ToString();

                        //Varma - Timezone Feature On&OFF functionality 
                        if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                        {
                            //Pranay 5th january 2017 --adding timeZone of user to UserSession
                            UserData.TimeZone = UserDetails["TimeZone"].ToString();
                            UserData.OffSet = UserDetails["Offset"].ToString();
                        }
                    }
                    singleround = true;
                }
                UserDetails.Close();
                Session["UserDetails"] = UserData;
            }
            catch (EMTException ex)
            {
               // errorlog.HandleError(ex, LoginID, " | CreateUser.aspx.cs | CreateUserSession()");
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, LoginID, " | CreateUser.aspx.cs | CreateUserSession()");

            }
            catch (Exception ex)
            {
               // errorlog.HandleError(ex, LoginID, "Login.aspx.cs|CreateUserSession");
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, LoginID, "Login.aspx.cs|CreateUserSession");
                //ExceptionHelper.HandleException(ex);
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        #endregion
        #region EVENTS

        private void SSOLogin()
        {
            var securityHandler = securityFactory.GetUserSecurityHandler("AD");
            string jsonWebToken = ConfigurationManager.AppSettings["jsonWebToken"].ToString();
            string secretKey = ConfigurationManager.AppSettings["secretKey"].ToString();
            securityHandler.UserTimeStampCheck(jsonWebToken, secretKey, userContextInfo);

            string userID = userContextInfo.UserID;
            string copyOfUserID = userID;
            DateTime createdOn = userContextInfo.CreatedOn;
            DateTime copyOfCreatedOn = createdOn;
            bool resultStatus = userContextInfo.ResultStatus;
            bool copyOfResultStatus = resultStatus;

            if (copyOfCreatedOn.AddMinutes(1) < DateTime.Now)
            {
                lblErrorMsg.Text = "TOKEN EXPIRED. CANNOT LOGON!...";
                txtLoginId.Focus();
                return;
            }

            //LoginID = txtLoginId.Text.Trim();          

            int UserID = objPresenter.ValidateLogin(LoginID);

            if (UserID == 0)
            {
                lblErrorMsg.Text = "YOU DO NOT HAVE ACCESS PERMISSION. KINDLY CONTACT ADMIN";
                lblErrorMsg.Text = "GIVEN USERID DOES NOT EXISTS IN EMT !!!. KINDLY CONTACT EMT ADMIN";
                txtLoginId.Focus();
            }
            else
            {
                int returnvalue = objPresenter.ValidateADLogin(LoginID);

                if (returnvalue == 1)//SUCCESS SCENARIO
                {
                    CreateUserSession(LoginID);
                    Response.Redirect("~/Common/DashBoard.aspx", false);
                    Response.Redirect("~/AuthenticationandAuthorization/ChooseRole.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                }
                if (returnvalue == 2)// WHEN THE USER IS NOT MAPPED TO ANY ROLES 
                {
                    lblErrorMsg.Text = "YOU ARE NOT MAPPED TO ANY ROLES. KINDLY CONTACT ADMIN";
                }
            }
        }

        //protected void myLogin_Authenticate(object sender, AuthenticateEventArgs e)
        //{

        //}

        /// <summary>
        /// EVENT TO LOGIN THE USER TO THE APPLICATION
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            
            int AccountLock = Convert.ToInt16(ConfigurationManager.AppSettings["AccountLock"].ToString());
            try
            {
                //UserName = txtLoginId.Value.Trim();
                //securityfix for encryption instead of encoding
                //byte[] encodedLoginIdBytes = Convert.FromBase64String(txtLoginId.Value.Trim());
                //UserName = Encoding.UTF8.GetString(encodedLoginIdBytes);
                UserName = HelperMethods.DecryptCredentials(txtLoginId.Value.Trim());
                int IsLocked = objusrep.IsAccountLocked(UserName);

                if (Request.Form["__VIEWSTATEENCRYPTED"] != null && Request.Form["__VIEWSTATEENCRYPTED"] != "")
                {

                  //  Response.Redirect("~/Errors/BadRequest.aspx", false);
                    Server.Transfer(@"~/Errors/BadRequest.aspx?r=" + HelperMethods.GenerateSecureRandom());
                }
                else
                {
                    if (CheckWhichLoginType == "Yes")// AD Login type
                    {
                        //UserName = txtLoginId.Value.Trim();
                        //securityfix for encryption instead of encoding
                        //encodedLoginIdBytes = Convert.FromBase64String(txtLoginId.Value.Trim());
                        //UserName = Encoding.UTF8.GetString(encodedLoginIdBytes);
                        UserName = HelperMethods.DecryptCredentials(txtLoginId.Value.Trim());
                        //Pkeyword = txtPKeyword.Value.Trim();
                        Regex myRegex = new Regex("[\\\'\\\"]", RegexOptions.Compiled | RegexOptions.IgnoreCase);
                        //securityfix for encryption instead of encoding
                        //var encodedTextBytes = Convert.FromBase64String(txtPKeyword.Value.Trim());
                        //string plainText = Encoding.UTF8.GetString(encodedTextBytes);
                        string plainText = HelperMethods.DecryptCredentials(txtPKeyword.Value.Trim());
                        string encodedString = myRegex.Replace(plainText, "");
                        if (encryptionmode == "ON")
                        {
                        Pkeyword = Constants.HelperMethods.EncryptString(encodedString);
                        }
                        else
                        {
                            Pkeyword = Constants.HelperMethods.EncryptValue(encodedString);
                        }
                        
                        //SSO login                    
                        //bool CheckLoginType = ADCheck.AuthenticateUserAgainstAD(UserName, Password, "cts");
                        userContextInfo.UserID = UserName;
                        userContextInfo.Password = encodedString; 
                        userContextInfo.Domain = ConfigurationManager.AppSettings["Domain"].ToString();
                        var securityFactory = new SecurityFactory();
                        bool isAuthenticated = securityFactory.GetUserSecurityHandler("AD").Authenticate(userContextInfo);

                        bool copyOfIsAuthenticated = isAuthenticated;

                        Session["CheckLoginType"] = copyOfIsAuthenticated;

                        if (copyOfIsAuthenticated == false)
                        {
                            lblErrorMsg.Text = "UserId / Password is Incorrect!!!";
                            txtLoginId.Focus();
                            logincount++;
                            //Pranay 27 March 2017--for making username and password field empty
                            txtLoginId.Value = String.Empty;
                            txtPKeyword.Value = String.Empty;
                        }
                        else
                        {
                            Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
                            string loginidvalue = HelperMethods.DecryptCredentials(txtLoginId.Value.Trim());
                            Match matchtxtLoginId = regex.Match(loginidvalue);
                            if (matchtxtLoginId.Success)
                            {
                                //securityfix for encryption instead of encoding
                                //encodedLoginIdBytes = Convert.FromBase64String(txtLoginId.Value.Trim());
                                //LoginID = Encoding.UTF8.GetString(encodedLoginIdBytes);
                                LoginID = HelperMethods.DecryptCredentials(txtLoginId.Value.Trim());
                                //LoginID = txtLoginId.Value.Trim();
                                int UserID = objPresenter.ValidateLogin(LoginID);
                                logincount = 0;
                                if (UserID == 0)
                                {
                                    // lblErrorMsg.Text = "YOU DO NOT HAVE ACCESS PERMISSION. KINDLY CONTACT ADMIN";
                                    lblErrorMsg.Text = "UserId / Password is Incorrect!!!";
                                    txtLoginId.Focus();
                                    objUser.PKeywordExpiration = "no";
                                    Session["PasswordExpiration"] = objUser.PKeywordExpiration;
                                    //Pranay 27 March 2017--for making username and password field empty
                                    txtLoginId.Value = String.Empty;
                                    txtPKeyword.Value = String.Empty;
                                }
                                else
                                {
                                    //int returnvalue = objPresenter.ValidateADLogin(txtLoginId.Value.Trim());
                                    int returnvalue = objPresenter.ValidateADLogin(LoginID);
                                    if (returnvalue == 4)//SUCCESS SCENARIO
                                    {
                                        //objUser.PasswordExpiration = 0;
                                        //CreateUserSession(txtLoginId.Value);
                                        CreateUserSession(LoginID);
                                        objUser.PKeywordExpiration = "no";
                                        Session["PasswordExpiration"] = objUser.PKeywordExpiration;
                                        regenerateId();//to regenerate session id after login - saranya
                                        Response.Redirect("~/Common/DashBoard.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                                        //Response.Redirect("~/AuthenticationandAuthorization/ChooseRole.aspx", false);
                                    }
                                    if (returnvalue == 2)// WHEN THE USER IS NOT MAPPED TO ANY ROLES 
                                    {
                                        logincount++;
                                        lblErrorMsg.Text = "YOU ARE NOT MAPPED TO ANY ROLES. KINDLY CONTACT ADMIN";
                                        //Pranay 27 March 2017
                                        txtLoginId.Value = UserName;
                                    }                                   

                                }
                            }
                            else
                            {
                                Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                            }
                        }
                    }

                    else if (CheckWhichLoginType == "No") /// Forms  Login Type
                    {
                        if (IsLocked == 0)
                        {
                            //logincount =(int)Session["logincount"];

                            if (logincount < AccountLock)
                            {
                                //LoginID = txtLoginId.Value.Trim();
                                //commented since encryption used instead of encoding
                                //encodedLoginIdBytes = Convert.FromBase64String(txtLoginId.Value.Trim());
                                //string plainLoginId = Encoding.UTF8.GetString(encodedLoginIdBytes);
                                string plainLoginId = HelperMethods.DecryptCredentials(txtLoginId.Value.Trim());
                                //int UserID = objPresenter.ValidateLogin(LoginID);
                                int UserID = objPresenter.ValidateLogin(plainLoginId);
                                if (UserID == 0)
                                {
                                    //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Given UserId does not exists!!');", true);
                                    lblErrorMsg.Text = "UserId / Password is Incorrect!!!";
                                    objUser.PKeywordExpiration= "no";
                                    Session["PasswordExpiration"] = objUser.PKeywordExpiration;
                                    //Pranay 27 March 2017
                                    txtLoginId.Value = String.Empty;
                                    txtPKeyword.Value = String.Empty;
                                    txtLoginId.Focus();
                                  //  throw new Exception("adgbawhdgasjkdn:");
                                }
                                else
                                {

                                    Regex myRegex = new Regex("[\\\'\\\"]", RegexOptions.Compiled | RegexOptions.IgnoreCase);
                                    //commented since encryption used instead of encoding
                                    //var encodedTextBytes = Convert.FromBase64String(txtPKeyword.Value.Trim());
                                    //string plainText = Encoding.UTF8.GetString(encodedTextBytes);
                                    string plainText = HelperMethods.DecryptCredentials(txtPKeyword.Value.Trim());
                                    string encodedString = myRegex.Replace(plainText, "");
                                    string result;
                                    if (encryptionmode == "ON")
                                    {
                                        result = Constants.HelperMethods.EncryptString(plainText);
                                    }
                                    else
                                    {
                                        result = Constants.HelperMethods.EncryptValue(plainText);
                                    }
                                    
                                    //string result = Constants.HelperMethods.EncryptString(txtPKeyword.Value.Trim());

                                    Regex regex = new Regex("\"|'");
                                    //Match match = regex.Match(txtPKeyword.Value.Trim());
                                    Match match = regex.Match(Constants.HelperMethods.EncryptValue(encodedString));
                                    if (match.Success)
                                    {
                                        Response.Redirect(@"~/Errors/BadRequest.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                                    }
                                    else
                                    {
                                        // string result = Constants.HelperMethods.EncryptString(txtPKeyword.Value.Trim());

                                        //string EncryptPassword = Constants.HelperMethods.EncryptValue(txtPassword.Text.Trim());
                                        //int returnvalue = objPresenter.ValidateLogin(txtLoginId.Value.Trim(), result);
                                        //securityfix for encryption instead of encoding
                                        //encodedLoginIdBytes = Convert.FromBase64String(txtLoginId.Value.Trim());                                        
                                        //plainLoginId = Encoding.UTF8.GetString(encodedLoginIdBytes);
                                        plainLoginId = HelperMethods.DecryptCredentials(txtLoginId.Value.Trim());
                                        //int returnvalue = objPresenter.ValidateLogin(Encoding.UTF8.GetString(Convert.FromBase64String(txtLoginId.Value.Trim())), result);
                                        int returnvalue = objPresenter.ValidateLogin(plainLoginId, result);
                                        //string EncryptPassword = Constants.HelperMethods.EncryptValue(txtPassword.Text.Trim());

                                        if (returnvalue == 0)//WHEN THE USER ID AND PASSWORD DOES NOT MATCHES
                                        {
                                            lblErrorMsg.Text = "UserId / Password is Incorrect!!!";
                                            //txtPKeyword.Focus();
                                            objUser.PKeywordExpiration = "no";
                                            Session["PasswordExpiration"] = objUser.PKeywordExpiration;
                                            logincount++;
                                            //Pranay 27 March 2017--for making username and password field empty
                                            txtLoginId.Value = String.Empty;
                                            txtPKeyword.Value = String.Empty;
                                            txtLoginId.Focus();
                                            // Session["logincount"] = logincount++.ToString();
                                            //logincount= logincount + 1;

                                        }
                                        if (returnvalue == 3)
                                        {
                                            objUser.PKeywordExpiration = "yes";
                                            Session["PasswordExpiration"] = objUser.PKeywordExpiration;
                                            //Session["CurrentPage"] = "Login";
                                            //CreateUserSession(txtLoginId.Value);
                                            CreateUserSession(plainLoginId);
                                            //objUser.PasswordExpiration = 1;
                                            String redirectURL = HttpContext.Current.Request.Url.ToString().Replace("Login", "ChangePassword");
                                            redirectURL = redirectURL.Replace("AuthenticationandAuthorization", "UserManagement");
                                            ScriptManager.RegisterStartupScript(this, this.GetType(), "PASSWORDEXPIRED", "alert('YOUR PASSWORD HAS EXPIRED. YOU WILL BE REDIRECTED TO CHANGE PASSWORD PAGE');window.location ='" + redirectURL + "';", true);                                                                                        
                                        }
                                        if (returnvalue == 4)//SUCCESS SCENARIO
                                        {
                                            //objUser.PasswordExpiration = 0;
                                            logincount = 0;
                                            objUser.PKeywordExpiration= "no";
                                            Session["PasswordExpiration"] = objUser.PKeywordExpiration;
                                            //CreateUserSession(txtLoginId.Value);
                                            CreateUserSession(plainLoginId);
                                           // Response.Redirect("~/Common/DashBoard.aspx", false);
                                            Response.Redirect("~/Common/DashBoard.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                                            //Response.Redirect("~/AuthenticationandAuthorization/ChooseRole.aspx", false);
                                        }
                                        if (returnvalue == 2)// WHEN THE USER IS NOT MAPPED TO ANY ROLES 
                                        {
                                            logincount++;
                                            objUser.PKeywordExpiration= "no";
                                            Session["PasswordExpiration"] = objUser.PKeywordExpiration;
                                            lblErrorMsg.Text = "YOU ARE NOT MAPPED TO ANY ROLES. KINDLY CONTACT ADMIN";
                                            //Pranay 27 March 2017
                                            txtLoginId.Value = plainLoginId;
                                        }
                                    }
                                }
                            }
                            else if (logincount >= AccountLock)
                            {
                                if (CheckWhichLoginType == "Yes")
                                {
                                    string IdentityPortal = ConfigurationManager.AppSettings["IdentityPortal"].ToString();
                                    Response.Redirect(IdentityPortal + HelperMethods.GenerateSecureRandom(), false);
                                }
                                else if (CheckWhichLoginType == "No")
                                {
                                    //securityfix for encryption instead of encoding
                                    //byte[] encodedLoginId= Convert.FromBase64String(txtLoginId.Value.Trim());
                                    //string plainLoginId = Encoding.UTF8.GetString(encodedLoginId);
                                    string plainLoginId = HelperMethods.DecryptCredentials(txtLoginId.Value.Trim());
                                    objacclockinfo.LoginID = plainLoginId;
                                    objacclockinfo.Lock = true;
                                    objacclockinfo.TokenExpirationTime = System.DateTime.Now;
                                    objacclockinfo.TokenExpiration = TokenExpiration;
                                    objacclockinfo.Size = 6;
                                    objacclockinfo.TokenKey = TokenKey;
                                    objacclockinfo.cipherpassword = cipher;
                                    DateTime date = objacclockinfo.TokenExpirationTime.AddMinutes(objacclockinfo.TokenExpiration);
                                    //lblErrorMsg.Text = "Your Account is Locked";
                                    cryptInfo.CryptKey = cipher;
                                    cryptInfo.ValueToCrypt = objacclockinfo.Token;
                                    string GeneratedToken = securityFactory.GetUserSecurityHandler("AD").TokenGeneration(objacclockinfo);
                                    sendMail_AccountLock(GeneratedToken);
                                }
                            }
                        }

                        else
                        {
                            if (CheckWhichLoginType == "No")
                            {
                                String redirectURL = HttpContext.Current.Request.Url.ToString().Replace("Login", "UnLockAccount");
                                ScriptManager.RegisterStartupScript(this, this.GetType(), "ACCOUNTLOCKED", "alert('YOUR ACCOUNT IS LOCKED. YOU WILL BE REDIRECTED TO ACCOUNT UNLOCK PAGE');window.location ='" + redirectURL + "';", true);                                
                            }
                        }
                    }
                }
            }
            catch (EMTException ex)
            {
               // errorlog.HandleError(ex, LoginID, "Login.aspx.cs|btnLogin_Click");
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex,System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(LoginID,true), "Login.aspx.cs|btnLogin_Click");

            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(LoginID,true), "Login.aspx.cs|btnLogin_Click");
                //errorlog.HandleError(ex, LoginID, "Login.aspx.cs|btnLogin_Click");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
      protected void sendMail_AccountLock(string encryptedToken)
        {
            SecureString sec_strPassword = new SecureString();
            try
            {
                string Subject = "Email Management Tool - Your Password ";
                Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
                Match matchtxtLoginId = regex.Match(HelperMethods.DecryptCredentials(txtLoginId.Value.Trim()));
                if (matchtxtLoginId.Success)
                {
                    //LoginID = txtLoginId.Value.Trim();
                    //securityfix for encryption instead of encoding
                    //byte[] encodedLoginId = Convert.FromBase64String(txtLoginId.Value.Trim());
                    //string LoginID = Encoding.UTF8.GetString(encodedLoginId);
                    string LoginID = HelperMethods.DecryptCredentials(txtLoginId.Value.Trim());
                    DataSet ds = _presenter.ForgotPassword(LoginID);
                    if (ds.Tables.Count > 0 && (ds.Tables[0].Rows.Count > 0 && ds.Tables[1].Rows.Count > 0))
                    {
                        string FirstName, LastName, To, MailBoxLoginId, EmailBoxId;
                        FirstName = ds.Tables[0].Rows[0]["FirstName"].ToString();
                        LastName = ds.Tables[0].Rows[0]["LastName"].ToString();
                        //Password = encryptedToken;
                        To = ds.Tables[0].Rows[0]["Email"].ToString();
                        EmailBoxId = ds.Tables[0].Rows[0]["EMailBoxAddress"].ToString();
                        MailBoxLoginId = ds.Tables[1].Rows[0]["EMailId"].ToString();
                        // MailBoxPassword = Constants.HelperMethods.DecryptString(ds.Tables[1].Rows[0]["Password"].ToString());


                        ///
                        /// mailBoxPassword converted to SecureString
                        /// modifiedBy:Natarajan(577343)
                        ///

                        Login miscObj = new Login();
                        if (encryptionmode == "ON")
                        {
                        sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.DecryptString(ds.Tables[1].Rows[0]["Password"].ToString()));
                        }
                        else
                        {
                            sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.DecryptValue(ds.Tables[1].Rows[0]["Password"].ToString()));
                        }
                        

                        if (To != string.Empty)
                        {
                            string ServiceURL = ConfigurationManager.AppSettings.Get("ClientServiceURL");
                            string strHeader = string.Empty;
                            string strBody = string.Empty;
                            string strFooter = string.Empty;
                            strHeader += "<table width='60%' border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse; border-color: #333333;'>";
                            strHeader += "<tr><td style='height:200px;' valign='top'><table width='100%' border='0' cellpadding='0' cellspacing='0'>";
                            strHeader += "<tr><td style='height: 3px; background-color: #05A4B7;'></td></tr>";
                            strBody += "<tr><td style='font-family:Verdana; font-size:12px; color:#333333; height:200px; padding-left:10px; padding-Right:10px;' valign='middle'>";
                            strBody += "Hi " + FirstName + " " + LastName + ",<br/><br/>" + " Please click on this link to UnLock your Account :"
                                + "<br/><a href=" + AccountLockMailID + "> Click here to Navigate to UnLock Account </a> <br/><br/>"
                                + "Please find your details below for Patheon EMT Login. <br/><br/> Login Id: " + LoginID +
                                "<br/> Token: " + encryptedToken + "<br><br><b>Note: This is a System Generated Mail. We request you not to reply to this message.</b><br><br><br><br>";
                            strBody += "Regards<br>Patheon EMT Helpdesk<br></td>";
                            strFooter += "<tr><td style='height: 3px; background-color: #05A4B7;'></td></tr></table></table>";

                            strBody = strHeader + strBody + strFooter;

                            if (HelperMethods.TokenSendMail(MailBoxLoginId, EmailBoxId, miscObj.convertToUNSecureString(sec_strPassword), ServiceURL, To, Subject, strBody))
                            {
                                //emailClient.Send(message);
                                lblErrorMsg.Text = "Your token has been sent to your MailID (" + To + "). Please check your mail.</br>OR</br>Please click here to UnLock your Account :"
                             + "<a href=" + AccountLockMailID + "> Click here</a>";     
                                // txtLoginId.Visible = false;
                            }
                        }
                        else
                        {
                            //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Hi, Email Id has not been configured to your Login Id.<br/> Please contact Admin);", true);
                            lblErrorMsg.Text = "Email Id has not been configured to your Login Id.<br/> Please contact Admin.";
                        }
                    }
                    else
                    {
                        //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Hi, Your account had been locked or Loginid may be invalid.<br/> Please contact Admin);", true);
                        lblErrorMsg.Text = "Your account had been locked or Loginid may be invalid.<br/> Please contact Admin";
                    }
                }
                else
                {
                    Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                }
            }
            catch (EMTException ex)
            {
                //errorlog.HandleError(ex, LoginID, " | CreateUser.aspx.cs | btnSubmit_Click()");
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(LoginID, true), " | CreateUser.aspx.cs | btnSubmit_Click()");
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex);
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }


        /// <summary>
        /// TO CLEAR THE FIELDS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        //protected void btnclr_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        txtLoginId.Value = "";
        //        txtPassword.Value = "";
        //        rfvtxtLoginId.Text = "";
        //        rfvtxtpwd.Text = "";
        //        lblErrorMsg.Text = "";
        //    }
        //    catch (Exception ex)
        //    {
        //        //ExceptionHelper.HandleException(ex);
        //        errorlog.HandleError(ex, objUser.UserId, "Login.aspx.cs|btnclr_Click");
        //        Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
        //    }
        //}
        ///// <summary>
        /// LINK TO ALLOW THE USER TO NAVIGATE TO THE FORGOT PASSWORD PAGE
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void LnkForgotPwd_Click(object sender, EventArgs e)
        {
            try
            {
                if (CheckWhichLoginType == "Yes")// AD Login type
                {
                    string ForgotPasswordPortal = ConfigurationManager.AppSettings["ForgotPasswordPortal"].ToString();
                    ScriptManager.RegisterStartupScript(this, typeof(string), "OPEN_WINDOW", "var Mleft = (screen.width/2)-(760/2);var Mtop = (screen.height/2)-(700/2);window.open( ForgotPasswordPortal,'_newtab'  );", true);                    
                }
                else if (CheckWhichLoginType == "No")// Normal Login type
                {

                    Response.Redirect("~/UserManagement/ForgotPassword.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                }
            }
            catch (EMTException ex)
            {
                //errorlog.HandleError(ex, LoginID, " | CreateUser.aspx.cs | LnkForgotPwd_Click()");
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, LoginID, " | CreateUser.aspx.cs | LnkForgotPwd_Click()");     
            }
            catch (Exception ex)
            {
               // errorlog.HandleError(ex, objUser.UserId, "Login.aspx.cs|LnkForgotPwd_Click");
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, "Login.aspx.cs|LnkForgotPwd_Click");     
                //ExceptionHelper.HandleException(ex);
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        #endregion

        void regenerateId()
        {
            try
            {
                System.Web.SessionState.SessionIDManager manager = new System.Web.SessionState.SessionIDManager();
                string oldId = manager.GetSessionID(Context);
                string newId = manager.CreateSessionID(Context);
                bool isAdd = false, isRedir = false;
                manager.SaveSessionID(Context, newId, out isRedir, out isAdd);
                HttpApplication ctx = (HttpApplication)HttpContext.Current.ApplicationInstance;
                HttpModuleCollection mods = ctx.Modules;
                System.Web.SessionState.SessionStateModule ssm = (SessionStateModule)mods.Get("Session");
                System.Reflection.FieldInfo[] fields = ssm.GetType().GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
                SessionStateStoreProviderBase store = null;
                System.Reflection.FieldInfo rqIdField = null, rqLockIdField = null, rqStateNotFoundField = null;
                foreach (System.Reflection.FieldInfo field in fields)
                {
                    if (field.Name.Equals("_store")) store = (SessionStateStoreProviderBase)field.GetValue(ssm);
                    if (field.Name.Equals("_rqId")) rqIdField = field;
                    if (field.Name.Equals("_rqLockId")) rqLockIdField = field;
                    if (field.Name.Equals("_rqSessionStateNotFound")) rqStateNotFoundField = field;
                }
                object lockId = rqLockIdField.GetValue(ssm);
                if ((lockId != null) && (oldId != null)) store.ReleaseItemExclusive(Context, oldId, lockId);
                rqStateNotFoundField.SetValue(ssm, true);
                rqIdField.SetValue(ssm, newId);
            }
            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, LoginID, " | Login.aspx.cs|regenerateId");     
               // errorlog.HandleError(ex, LoginID, " | Login.aspx.cs|regenerateId");
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, LoginID, "Login.aspx.cs|regenerateId");     
               // errorlog.HandleError(ex, LoginID, "Login.aspx.cs|regenerateId");
                //ExceptionHelper.HandleException(ex);
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

        }


        /// <summary>
        /// SecureString Method to retrieve Sensitive Data
        /// </summary>
        /// <param name="strPassword"></param>
        /// <returns></returns>

        public SecureString convertToSecureString(string strPassword)
        {
            var secureStr = new SecureString();
            if (strPassword.Length > 0)
            {
                foreach (var c in strPassword.ToCharArray()) secureStr.AppendChar(c);
            }
            return secureStr;
        }

        public string convertToUNSecureString(SecureString secstrPassword)
        {
            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(secstrPassword);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

    }
}