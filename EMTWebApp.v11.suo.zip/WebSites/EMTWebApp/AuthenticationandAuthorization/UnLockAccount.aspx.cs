﻿using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.ExceptionHandling;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Security;
using EMTWebApp.AuthenticationandAuthorization.Views;
using EMTWebApp.Constants;
using EMTWebApp.UserManagement;
using EMTWebApp.UserManagement.Common;
using EMTWebApp.UserManagement.Views;
using Microsoft.Practices.ObjectBuilder;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security;
using System.Runtime.InteropServices;
using System.Web.Security;
using System.Text.RegularExpressions;

public partial class AuthenticationandAuthorization_UnLockAccount : Microsoft.Practices.CompositeWeb.Web.UI.Page, ILoginView, IForgotPasswordView
{
    #region Declaration
    CryptInfo cryptInfo = new CryptInfo();
    SecurityFactory securityFactory = new SecurityFactory();
    UserSession objUser = new UserSession();
    string encryptionmode = ConfigurationManager.AppSettings["ENCRYPT/DECRYPT"].ToString();    
    string cipher = ConfigurationManager.AppSettings["ENCRYPTIONKEY"].ToString();
    private UserManagementController _controller;
    UserErrorLog errorlog = new UserErrorLog();
    double TokenExpiration = Convert.ToDouble(ConfigurationManager.AppSettings["TokenExpirationTimeInMinutes"].ToString());
    private LoginPresenter objPresenter;
    string TokenKey = ConfigurationManager.AppSettings["TokenKey"].ToString();
    Random rand = new Random();
    public string LoginID;
    private ForgotPasswordPresenter _presenter;
    string AccountLockMailID = ConfigurationManager.AppSettings["AccountLockMailID"].ToString();
    AccountLockInfo objacclockinfo = new AccountLockInfo();
    UserRepository objusrep = new EMTUserRepository();

    private const string AntiXsrfTokenKey = "__AntiXsrfToken";
    private const string AntiXsrfUserNameKey = "__AntiXsrfUserName";
    private string _antiXsrfTokenValue; 
    #endregion
  
  
    protected void Page_Load(object sender, EventArgs e)
    {
        //iterate through all the params and check for sql injection - saranya
        Regex regex = new Regex(System.Configuration.ConfigurationManager.AppSettings["SQLInjectionRegex"]);
                      
        foreach (string key in HttpContext.Current.Request.Form.Keys)
        {
            if (!String.IsNullOrEmpty(Request.Form[key]) && regex.Match(Request.Form[key]).Success)
            {
                Server.Transfer(@"~/Errors/BadRequest.aspx");
            }
        }

        if (!this.IsPostBack)
        {  
            this.objPresenter.OnViewInitialized();

            this._presenter.OnViewInitialized();
        }
    }

    void Page_Init(object sender, EventArgs e)
    {
        //if (Session.IsNewSession)
        //{
        //    Session["UserDetails"] = DateTime.Now;
        //}
        this.ViewStateUserKey = Session.SessionID;
        if (Page.EnableViewState)
        {
            if (!string.IsNullOrEmpty(Request.Params["__VIEWSTATE"]) && string.IsNullOrEmpty(Request.Form["__VIEWSTATE"]))
            {
                throw new Exception("Cross Site History Manipulation happened...");
            }
        }

        // The code below helps to protect against XSRF attacks
        var requestCookie = Request.Cookies[AntiXsrfTokenKey];
        Guid requestCookieGuidValue;
        if (requestCookie != null && Guid.TryParse(requestCookie.Value, out requestCookieGuidValue))
        {
            // Use the Anti-XSRF token from the cookie
            _antiXsrfTokenValue = requestCookie.Value;
            Page.ViewStateUserKey = _antiXsrfTokenValue;
        }
        else
        {
            // Generate a new Anti-XSRF token and save to the cookie
            _antiXsrfTokenValue = Guid.NewGuid().ToString("N");
            Page.ViewStateUserKey = _antiXsrfTokenValue;
            Session["_antiXsrfTokenValue"] = _antiXsrfTokenValue;

            var responseCookie = new HttpCookie(AntiXsrfTokenKey)
            {
                HttpOnly = true,
                Value = _antiXsrfTokenValue
            };
            if (FormsAuthentication.RequireSSL && Request.IsSecureConnection)
            {
                responseCookie.Secure = true;
            }
            Response.Cookies.Set(responseCookie);
        }

        Page.PreLoad += Page_PreLoad;
    }

    protected void Page_PreLoad(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Set Anti-XSRF token
            ViewState[AntiXsrfTokenKey] = Page.ViewStateUserKey;
            ViewState[AntiXsrfUserNameKey] = Context.User.Identity.Name ?? String.Empty;
        }
        else
        {
            // Validate the Anti-XSRF token
            if ((string)ViewState[AntiXsrfTokenKey] != _antiXsrfTokenValue
                || (string)ViewState[AntiXsrfUserNameKey] != (Context.User.Identity.Name ?? String.Empty))
            {
                //throw new InvalidOperationException("Validation of Anti-XSRF token failed.");
                Server.Transfer(@"~/Errors/BadRequest.aspx");
            }
        }
    }

    [CreateNew]
    public ForgotPasswordPresenter ForgotPresenter
    {
        get
        {
            return this._presenter;
        }
        set
        {
            if (value == null)
                throw new ArgumentNullException("value");

            this._presenter = value;
            this._presenter.View = this;
        }
    }
    [CreateNew]
    public LoginPresenter Presenter
    {
        get
        {
            return this.objPresenter;
        }
        set
        {
            if (value == null)
                throw new ArgumentNullException("value");

            this.objPresenter = value;
            this.objPresenter.View = this;
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string LoginID = txtLoginId.Value.Trim();
        objacclockinfo.LoginID = LoginID;
        objacclockinfo.Token = txtPKeyword.Value.Trim();

        //string tokn = txtPassword.Value.Trim();
        //= Token;
        objacclockinfo.Lock = true;
        cryptInfo.CryptKey = cipher;
        cryptInfo.ValueToCrypt = objacclockinfo.Token;
       // string decryptedValue = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
        int result = objusrep.ValidateAccountLock(objacclockinfo.LoginID, objacclockinfo.Lock, objacclockinfo.Token);
        //cryptInfo.CryptKey = cipherpassword;
        //cryptInfo.ValueToCrypt = objacclockinfo.Token;
        //string GeneratedToken = securityFactory.GetUserSecurityHandler("AD").TokenGeneration(objacclockinfo);        
        // objUser = (UserSession)Session["userdetails"];
        // objUser.UserId = LoginID;         
        //result = objPresenter.ValidateAccountLock(LoginID, true, objacclockinfo.Token);
        // result = 1;

        if (result == 1)
        {
            String redirectURL = HttpContext.Current.Request.Url.ToString().Replace("UnLockAccount", "Login");         
            ScriptManager.RegisterStartupScript(this, this.GetType(), "ACCOUNTUNLOCKED", "alert('YOUR ACCOUNT IS UNLOCKED. YOU WILL BE REDIRECTED TO LOGIN PAGE');window.location ='" + redirectURL + "';", true);            
        }
        else if (result == 2)
        {
            lblErrorMsg.Text = "Please Regenerate Token.";
        }
        else if (result == 0)
        {
            String redirectURL = HttpContext.Current.Request.Url.ToString().Replace("UnLockAccount", "Error");
            redirectURL = redirectURL.Replace("AuthenticationandAuthorization", "Errors");
            ScriptManager.RegisterStartupScript(this, this.GetType(), "ERROR", "alert('User does not exists');window.location ='" + redirectURL + "';", true);                        
        }

    }


    protected void btnnewtoken_Click(object sender, EventArgs e)
    {
        string LoginID = txtLoginId.Value.Trim();
        objacclockinfo.LoginID = LoginID;
        objacclockinfo.Token = txtPKeyword.Value.Trim();
        objacclockinfo.cipherpassword = cipher;
        objacclockinfo.Lock = true;
        //objacclockinfo.TokenExpirationTime = System.DateTime.Now;
        //Pranay  30 March 2017--changing date to UTC Date
        objacclockinfo.TokenExpirationTime = System.DateTime.UtcNow;
        objacclockinfo.TokenExpiration = TokenExpiration;
        objacclockinfo.Size = 6;
        objacclockinfo.TokenKey = TokenKey;
        DateTime date = objacclockinfo.TokenExpirationTime.AddMinutes(objacclockinfo.TokenExpiration);

        cryptInfo.CryptKey = cipher;
        cryptInfo.ValueToCrypt = objacclockinfo.Token;
        string GeneratedToken = securityFactory.GetUserSecurityHandler("AD").TokenGeneration(objacclockinfo);

        //string GeneratedToken=TokenGeneration(true);
        sendMail_AccountLock(GeneratedToken, LoginID);
       // webtoken.Visible = false;

    }


    //private string TokenGeneration(bool Lock)
    //{
    //    string Token = null;
    //    if (Lock)
    //    {

    //        Token = RandomString(6);
    //    }
    //    DateTime TokenExpirationTime = Convert.ToDateTime(DateTime.Now.ToString("yyyyMMddHHmmss"));
    //    cryptInfo.CryptKey = cipherpassword;
    //    cryptInfo.ValueToCrypt = Token;
    //    string encryptedValue = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
    //    objPresenter.LockAccount(LoginID, Lock, encryptedValue, TokenExpirationTime.AddMinutes(TokenExpiration));
    //    return encryptedValue;
    //}

    //private string RandomString(int Size)
    //{
    //    string input = TokenKey;
    //    StringBuilder builder = new StringBuilder();
    //    char ch;
    //    for (int i = 0; i < Size; i++)
    //    {
    //        ch = input[rand.Next(0, input.Length)];
    //        builder.Append(ch);
    //    }
    //    return builder.ToString();
    //}


    /// <summary>
    /// mailboxPassword stored as a secureString
    /// modifiedBy: Natarajan
    /// </summary>
    /// <param name="encryptedToken"></param>
    /// <param name="LoginID"></param>

    protected void sendMail_AccountLock(string encryptedToken, string LoginID)
    {
        SecureString sec_strPassword = new SecureString();
        try
        {
            if (!String.IsNullOrEmpty(LoginID))
            {

                string Subject = "Email Management Tool - Your Password ";
                //LoginID = objUser.UserId;
                DataSet ds = _presenter.ForgotPassword(LoginID);
                if (ds.Tables.Count > 0 && (ds.Tables[0].Rows.Count > 0 && ds.Tables[1].Rows.Count > 0))
                {
                    string FirstName, LastName, To, MailBoxLoginId, EmailBoxId;
                    FirstName = ds.Tables[0].Rows[0]["FirstName"].ToString();
                    LastName = ds.Tables[0].Rows[0]["LastName"].ToString();
                    //Password = encryptedToken;
                    To = ds.Tables[0].Rows[0]["Email"].ToString();
                    EmailBoxId = ds.Tables[0].Rows[0]["EMailBoxAddress"].ToString();
                    MailBoxLoginId = ds.Tables[1].Rows[0]["EMailId"].ToString();
                   // MailBoxPassword = EMTWebApp.Constants.HelperMethods.DecryptString(ds.Tables[1].Rows[0]["Password"].ToString());

                    AuthenticationandAuthorization_UnLockAccount miscObj = new AuthenticationandAuthorization_UnLockAccount();
                    //encrypt/encode
                    if (encryptionmode == "ON")
                    {
                    sec_strPassword = miscObj.convertToSecureString(EMTWebApp.Constants.HelperMethods.DecryptString(ds.Tables[1].Rows[0]["Password"].ToString()));
                    }
                    else
                    {
                        sec_strPassword = miscObj.convertToSecureString(EMTWebApp.Constants.HelperMethods.DecryptValue(ds.Tables[1].Rows[0]["Password"].ToString()));
                    }
                    

                    if (To != string.Empty)
                    {
                        string ServiceURL = ConfigurationManager.AppSettings.Get("ClientServiceURL");
                        string strHeader = string.Empty;
                        string strBody = string.Empty;
                        string strFooter = string.Empty;
                        strHeader += "<table width='60%' border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse; border-color: #333333;'>";
                        strHeader += "<tr><td style='height:200px;' valign='top'><table width='100%' border='0' cellpadding='0' cellspacing='0'>";
                        strHeader += "<tr><td style='height: 3px; background-color: #05A4B7;'></td></tr>";
                        strBody += "<tr><td style='font-family:Verdana; font-size:12px; color:#333333; height:200px; padding-left:10px; padding-Right:10px;' valign='middle'>";
                        strBody += "Hi " + FirstName + " " + LastName + ",<br/><br/>" + " Please click on this link to UnLock Account Page"
                                + "<br/><a href=" + AccountLockMailID + " > Click here to Navigate to UnLock Account Page </a> <br/><br/>" + "Please find your details below for EMT Login. <br/><br/> Login Id: " + LoginID +
                            "<br/> Token: " + encryptedToken + "<br><br><b>Note: This is a System Generated Mail. We request you not to reply to this message.</b><br><br><br><br>";
                        strBody += "Regards<br>EMT Helpdesk<br></td>";
                        strFooter += "<tr><td style='height: 3px; background-color: #05A4B7;'></td></tr></table></table>";

                        strBody = strHeader + strBody + strFooter;

                        if (HelperMethods.TokenSendMail(MailBoxLoginId, EmailBoxId, miscObj.convertToUNSecureString(sec_strPassword), ServiceURL, To, Subject, strBody))
                        {
                            //emailClient.Send(message);
                            lblErrorMsg.Text = "Your token has been sent to your MailID (" + To + "). Please check your mail.";
                            //txtLoginId.Visible = false;
                        }
                    }
                    else
                    {
                        //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Hi, Email Id has not been configured to your Login Id.<br/> Please contact Admin);", true);
                        lblErrorMsg.Text = "Email Id has not been configured to your Login Id.<br/> Please contact Admin.";
                    }
                }
                else
                {
                    //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Hi, Your account had been locked or Loginid may be invalid.<br/> Please contact Admin);", true);
                    lblErrorMsg.Text = "Your account had been locked or LoginId may be invalid.<br/> Please contact Admin";
                }
            }
            else
                lblErrorMsg.Text = "Please enter User ID ";
        }
        catch (EMTException ex)
        {
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, LoginID, " | LockAccount.aspx.cs|sendMail_AccountLock");  
            //errorlog.HandleError(ex, LoginID, " | LockAccount.aspx.cs|sendMail_AccountLock");
        }

        catch (Exception ex)
        {
            //ExceptionHelper.HandleException(ex);
            new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex);
            //errorlog.HandleError(ex, LoginID, " | ForgotPassword.aspx.cs | btnSubmit_Click()");
            Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
        }
    }


    /// <summary>
    /// SecureString Method to secure the sensitiveData
    /// modifiedBy:Natarajan(577343)
    /// </summary>
    /// <param name="strPassword"></param>
    /// <returns></returns>

    public SecureString convertToSecureString(string strPassword)
    {
        var secureStr = new SecureString();
        if (strPassword.Length > 0)
        {
            foreach (var c in strPassword.ToCharArray()) secureStr.AppendChar(c);
        }
        return secureStr;
    }


    public string convertToUNSecureString(SecureString secstrPassword)
    {
        IntPtr unmanagedString = IntPtr.Zero;
        try
        {
            unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(secstrPassword);
            return Marshal.PtrToStringUni(unmanagedString);
        }
        finally
        {
            Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
        }
    }

}