﻿using EMTWebApp.AuthenticationandAuthorization.Views;
using Microsoft.Practices.ObjectBuilder;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security;
using System.Runtime.InteropServices;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.DirectoryServices.AccountManagement;
using DigiOPS.TechFoundation.Logging;
using System.Data.SqlClient;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace EMTWebApp.AuthenticationandAuthorization.Views
{
    public partial class SubscriptionManagement : Microsoft.Practices.CompositeWeb.Web.UI.Page, ILoginView
    {

        public SqlConnection connection = new SqlConnection(@"Data Source=CTSINTBMVBFS\SQL_SERVER12; Initial Catalog=EMT_SV_RT;User Id=sa2;Password=password-1;");
        //public SqlConnection connection = new SqlConnection(@"Data Source=CTSINPUNVPTRA02; Initial Catalog=EMTDemo;User Id=EMTUser;Password=EMTUser;");

        UserErrorLog errorlog = new UserErrorLog();

        private LoginPresenter objPresenter;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    string uname = "";// Environment.UserName;

                    char[] sep = { '\\' };
                    string[] a = Request.LogonUserIdentity.Name.Split(sep);
                    if (a.Length == 1)
                        uname = a.GetValue(0).ToString();
                    else
                        uname = a.GetValue(1).ToString();

                    using (var context = new PrincipalContext(ContextType.Domain, "cts"))
                    {
                        using (var domainContext = new PrincipalContext(ContextType.Domain, "cts"))
                        {
                            using (var foundUser = UserPrincipal.FindByIdentity(domainContext, IdentityType.SamAccountName, uname))
                            {
                                if (foundUser != null)
                                {
                                    lblUnameID.Text = foundUser.Name + "(" + uname + ")";
                                    lblEmailId.Text = foundUser.EmailAddress;

                                    lblUserID.Text = "User " + uname;

                                    hdnUserid.Value = uname;

                                    //lblUnameID.Text = "Guest";
                                    //lblEmailId.Text = foundUser.EmailAddress;

                                    //lblUserID.Text = "User Guest";

                                    //txtEmailId.Visible = true;
                                    //lblEmailId.Visible = false;
                                    if (Request.QueryString["Subject"] != null)
                                    {
                                        lblSubject.Text = Request.QueryString["Subject"].ToString();
                                    }
                                }
                                else
                                {
                                    lblUnameID.Text = "Guest";
                                    //lblEmailId.Text = foundUser.EmailAddress;

                                    lblUserID.Text = "User Guest";
                                    lblEmailId.Visible = false;
                                    txtEmailId.Visible = true;
                                    //txtEmailId.Focus();

                                    hdnUserid.Value = txtEmailId.Text;
                                }
                            }
                        }
                    }

                    this.objPresenter.OnViewInitialized();
                }
            }
            catch (Exception ex)
            {

                errorlog.HandleError(ex, "", "Login.aspx.cs|Page_Load");
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, "", "Login.aspx.cs|Page_Load");
            }

        }
        //protected void btnOptin_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        Hashtable hs = new Hashtable();
        //        hs.Add("@UserID", hdnUserid.Value);
        //        hs.Add("@Subject", lblSubject.Text);
        //        hs.Add("@SubscriptionStatus", "Subscribe");

        //        int status = objPresenter.InsertSubscription(hs);
        //        ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "complete('Opt-in');", true);
        //        // ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "$(function() {complete('in');}", true);
        //    }
        //    catch
        //    {

        //    }
        //}
        //protected void btnOptout_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        Hashtable hs = new Hashtable();
        //        hs.Add("@UserID", hdnUserid.Value);
        //        hs.Add("@Subject", lblSubject.Text);
        //        hs.Add("@SubscriptionStatus", "UnSubscribe");

        //        int status = objPresenter.InsertSubscription(hs);

        //        ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "complete('Opt-out');", true);
        //        // ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "$(function() {complete('out');}", true);
        //    }
        //    catch
        //    {

        //    }
        //}

        protected void btnSubmitChanges_Click(object sender, EventArgs e)
        {
            try
            {
                if (hdnUserid.Value != "")
                {
                    string bulletinStatus = hdnBulletinStatus.Value;
                    //string promoStatus = hdnPromoStatus.Value;

                    Hashtable hs = new Hashtable();
                    hs.Add("@UserID", hdnUserid.Value);

                    hs.Add("@Subject", lblSubject1.Text);
                    if (bulletinStatus == "Opt-Out")
                        hs.Add("@SubscriptionStatus", "UnSubscribe");
                    else
                        hs.Add("@SubscriptionStatus", "Subscribe");

                    int status = InsertSubscription(hs);

                    //Hashtable Promohs = new Hashtable();
                    //Promohs.Add("@UserID", hdnUserid.Value);

                    //Promohs.Add("@Subject", lblSubject2.Text);
                    //if (promoStatus == "Opt-Out")
                    //    Promohs.Add("@SubscriptionStatus", "UnSubscribe");
                    //else
                    //    Promohs.Add("@SubscriptionStatus", "Subscribe");

                    //int newstatus = InsertSubscription(Promohs);

                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "complete('Opt-out');", true);
                    // ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "$(function() {complete('out');}", true);
                }
                else
                {
                    txtEmailId.Visible = true;
                    //txtEmailId.setFocus();
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "alert('Please enter email address and try again!!!')", true);
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "alert('Unable to process your request, please try again!!!')", true);
            }
        }

        protected int InsertSubscription(Hashtable hs)
        {
            int InsCount = 0;
            try
            {
                string commandText_Tab_1 = "InsertSubscriberContact";
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand(commandText_Tab_1, connection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                AddParameter(ref sqlCommand, hs);

                InsCount = Convert.ToInt32(sqlCommand.ExecuteScalar());
                connection.Close();
            }
            catch (Exception ex)
            {
                connection.Close();
            }
            return InsCount;

        }

        private void AddParameter(ref SqlCommand command, Hashtable values)
        {
            try
            {
                foreach (string key in values.Keys)
                {
                    object obj = DBNull.Value;
                    if (values[key].ToString() == "" || values[key].ToString() == "0001-01-01 00:00:00.000")
                        obj = DBNull.Value;
                    else
                        obj = values[key];
                    command.Parameters.Add(new SqlParameter(key.ToString(), obj));
                }
            }
            catch (Exception ex)
            {

            }
        }


        //#region PROPERTIES
        //[CreateNew]
        //public LoginPresenter Presenter
        //{
        //    get
        //    {
        //        return this.objPresenter;
        //    }
        //    set
        //    {
        //        if (value == null)
        //            throw new ArgumentNullException("value");

        //        this.objPresenter = value;
        //        this.objPresenter.View = this;
        //    }
        //}
        //#endregion

    }
}