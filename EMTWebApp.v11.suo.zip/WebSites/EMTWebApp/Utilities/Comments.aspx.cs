﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.Common;
using EMTWebApp.Common.Views;
using EMTWebApp.ExceptionHandler;
using System.Text.RegularExpressions;
using System.Text.RegularExpressions;
using EMTWebApp.Constants;
using DigiOPS.TechFoundation.Logging;
using EMTWebApp.UserManagement.Common;


namespace EMTWebApp.Utilities.Views
{
	public partial class Comments : Microsoft.Practices.CompositeWeb.Web.UI.Page, ICommentsView
    {
        #region DECLARATION
        private CommentsPresenter _presenter;
        UserSession objUser = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        #endregion

        #region PROPERTIES
        [CreateNew]
        public CommentsPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
		{
            try
            {
                if (!this.IsPostBack)
                {
                    this._presenter.OnViewInitialized();
                }
                this._presenter.OnViewLoaded();
                int CaseID = Convert.ToInt32(Request.QueryString["CaseID"]);
                this._presenter.BindComments(CaseID);
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, objUser.UserId, " | Comments.aspx.cs | Page_Load()");  
                //errorlog.HandleError(ex, objUser.UserId , " | Comments.aspx.cs | Page_Load()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
		}

        #region BINDMETHODS
        /// <summary>
        /// Bind Comments for Cases
        /// </summary>
        public DataSet BindComments
        {
            set
            {
                DataView dview = value.Tables[0].DefaultView;
                grdComments.DataSource = dview;
                grdComments.DataBind();
            }
        }
        #endregion

    }
}

