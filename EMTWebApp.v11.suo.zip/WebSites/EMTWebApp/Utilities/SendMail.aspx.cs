﻿using System;
using Microsoft.Practices.ObjectBuilder;
using DigiOPS.TechFoundation.Logging;
using EMTWebApp.UserManagement.Common;
using EMTWebApp.Constants;

namespace EMTWebApp.Utilities.Views
{
	public partial class SendMail : Microsoft.Practices.CompositeWeb.Web.UI.Page, ISendMailView
	{
		
        #region DECLARATION
        UserSession userData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        private SendMailPresenter _presenter;
        #endregion
		protected void Page_Load(object sender, EventArgs e)
		{
            try
            {
                if (!this.IsPostBack)
                {
                    this._presenter.OnViewInitialized();
                }
                this._presenter.OnViewLoaded();
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, userData.UserId, " | SendMail.cs | Page_Load()");  
                //errorlog.HandleError(ex, userData.UserId, " | SendMail.cs | Page_Load()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
		}

		[CreateNew]
		public SendMailPresenter Presenter
		{
			get
			{
				return this._presenter;
			}
			set
			{
				if(value == null)
					throw new ArgumentNullException("value");

				this._presenter = value;
				this._presenter.View = this;
			}
		}

		// TODO: Forward events to the presenter and show state to the user.
		// For examples of this, see the View-Presenter (with Application Controller) QuickStart:
		//	

	}
}

