﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using EMTWebApp.Constants;
using DigiOPS.TechFoundation.Logging;
using System.Text.RegularExpressions;

namespace EMTWebApp.UserManagement.Views
{
    public partial class UserManagement_FieldConfiguration : Microsoft.Practices.CompositeWeb.Web.UI.Page, IUserMailBoxMappingView
    {
        #region DECLARATIONS
        private UserMailBoxMappingPresenter _presenter;
        private string LoginId = string.Empty;
        private string UserId = string.Empty;
        private string ddlCountryId = string.Empty;
        UserSession UserData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
      
        public string hddnMBMapId;
        #endregion
        /// <summary>
        /// TO BIND THE USERS, COUNTRY NAMES TO THE DROPDOWN AND MAILBOX DETAILS TO THE GRID
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["UserDetails"] != null)
                {

                    UserData = (UserSession)Session["UserDetails"];
                    RedirectToErrorPage(UserData);
                    IsValidRoleToAccessThisPage(UserData);
                    if (!this.IsPostBack)
                    {
                        this._presenter.OnViewInitialized();
                        // BindMailBoxcateMapgrid();
                        Page.Form.DefaultButton = btnMap.UniqueID;
                        BindCountry(); BindMailBoxcateMapgrid();
                        BindDefaultValueforDropDown(); BindFieldType();
                        //chkescalation.Attributes.Add("onchange", "return Validation(" + txtnot.ClientID + ")");
                        //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                        string PKeyword = (Session["PasswordExpiration"]).ToString();
                        if (PKeyword == "yes")
                        {
                            Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                    }
                }
                }
                else
                {
                    Response.Clear();
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
                this._presenter.OnViewLoaded();
            }
            catch (Exception ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | Page_Load()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | Page_Load()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        #region PROPERTIES
        [CreateNew]
        public UserMailBoxMappingPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion
        #region METHODS
        /// <summary>
        /// Method to redirect to login or session expired page
        /// </summary>
        private void RedirectToErrorPage(UserSession UserDetail)
        {
            try
            {
                if (UserDetail == null)
                {
                    Response.Clear(); Response.Redirect(@"~\Errors\Error.aspx"); Response.End();
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | FieldConfiguration.cs | RedirectToErrorPage()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | FieldConfiguration.cs | RedirectToErrorPage()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserData)
        {
            try
            {
                if ((UserData.RoleId == (int)Constant.UserRole.Admin) || (UserData.RoleId == (int)Constant.UserRole.SuperAdmin))
                {
                    return true;
                }
                else
                {
                    Response.Clear(); Response.Redirect("~/Errors/AccessDenied.aspx", false); Response.End();
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | FieldConfiguration.cs | IsValidRoleToAccessThisPage()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | FieldConfiguration.cs | IsValidRoleToAccessThisPage()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            return false;
        }

        /// <summary>
        /// FUNCTION TO BIND THE ACTIVE USERS TO THE DROPDOWN
        /// </summary>

        /// <summary>
        /// FUNCTION TO CLEAR THE FIELDS
        /// </summary>
        public void Clearfields()
        {
            try
            {
                //ddlMailBox.Items.Clear();
                // ddlMailBox.Items.Insert(0, "- Select -");
                //  ddlCountry.SelectedIndex = 0;
                ddlCountry.SelectedIndex = 0; ddlMailBox.SelectedIndex = 0; txtDefault.Text = ""; txtFieldName.Text = ""; txtMaxLength.Text = "";
                ddlValidationType.SelectedIndex = 0; ddlFieldType.SelectedIndex = 0; ddlFieldDataType.SelectedIndex = 0;
                ddlMailBox.Items.Clear();
                btnMap.Text = "Configure";
                BindMailBoxcateMapgrid(); BindDefaultValueforDropDown();
                lblmsg.Visible = false;
                lblmsg.Text = "";
                ddlCountry.Enabled = true;
                ListItem select = new ListItem();
                select.Text = "- Select -";
                select.Value = "0";
                ddlMailBox.Items.Insert(0, select);
                chkActive.Checked = true;
                chkMandatory.Checked = true;
                lblShwItmmsg.Visible = false;
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | Clearfields()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | Clearfields()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        /// <summary>
        /// FUNCTION TO BIND THE COUNTRY NAMES TO THE DROPDOWN
        /// </summary>
        public void BindCountry()
        {
            try
            {
                DataSet dsCountryNames = _presenter.BindCountry();
                ddlCountry.DataSource = dsCountryNames;
                ddlCountry.DataValueField = "CountryID";
                ddlCountry.DataTextField = "Country";
                ddlCountry.DataBind();
                ListItem select = new ListItem();
                select.Text = "- Select -";
                select.Value = "0";
                ddlCountry.Items.Insert(0, select);
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | FieldConfiguration.cs | BindCountry()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | FieldConfiguration.cs | BindCountry()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// FUNCTION TO BIND THE COUNTRY NAMES TO THE DROPDOWN
        /// </summary>
        public void BindFieldType()
        {
            try
            {
                DataSet dsCountryNames = _presenter.BindFieldType();
                ddlFieldType.DataSource = dsCountryNames;
                ddlFieldType.DataValueField = "FieldTypeId";
                ddlFieldType.DataTextField = "FieldType";
                ddlFieldType.DataBind();
                ListItem select = new ListItem();
                select.Text = "- Select -";
                select.Value = "0";
                ddlFieldType.Items.Insert(0, select);
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | FieldConfiguration.cs | BindFieldType()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | FieldConfiguration.cs | BindFieldType()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        private void BindDefaultValueforDropDown()
        {
            try
            {
                ddlFieldDataType.Items.Clear();
                ddlValidationType.Items.Clear();
                //ddlFieldDataType.DataSource = null;
                //ddlFieldDataType.DataBind();
                //ddlValidationType.DataSource = null;
                //ddlValidationType.DataBind();
                ddlFieldDataType.Items.Insert(0, new ListItem("-- Select --", "0"));
                ddlValidationType.Items.Insert(0, new ListItem("-- Select --", "0"));
                ddlDateFormat.Items.Insert(0, new ListItem("-- Select --", "0"));
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | BindDefaultValueforDropDown()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | BindDefaultValueforDropDown()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        /// <summary>
        /// FUNCTION TO BIND THE MAILOX MAP DETAILS TO THE GRID
        /// </summary>
        public DataTable BindMailBoxcateMapgrid()
        {
            DataTable dt = null;
            try
            {
                Hashtable htUserDatagrid = new Hashtable();
                htUserDatagrid.Add("@Country", (ddlCountry.SelectedValue != string.Empty && Convert.ToInt16(ddlCountry.SelectedValue) != 0) ? Convert.ToInt16(ddlCountry.SelectedValue) : 0);
                htUserDatagrid.Add("@Mailboxid", (ddlMailBox.SelectedValue != string.Empty && Convert.ToInt16(ddlMailBox.SelectedValue) != 0) ? Convert.ToInt16(ddlMailBox.SelectedValue) : 0);
                DataSet dsGridMailBoxMapBind = this._presenter.GridMailBoxFieldBind(htUserDatagrid);
                gvConfigureFields.DataSource = dsGridMailBoxMapBind;
                gvConfigureFields.DataBind();
                ViewState["UserRoleMapGrid"] = gvConfigureFields.DataSource;
                dt = dsGridMailBoxMapBind.Tables[0];
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | BindMailBoxcateMapgrid()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | BindMailBoxcateMapgrid()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            return dt;
        }



        /// <summary>
        /// Function to Bind the grid userwise
        /// </summary>
        public DataTable BindUserMailBoxgridUserWise()
        {
            DataTable dt = null;
            //try
            //{

            //    lblmsg.Text = "";
            //    lblmsg.Visible = false;
            //    DataSet dsUserWiseMailBoxMapGridBind = this._presenter.UserWiseMailBoxMapGridBind(UserId, ddlCountryId);
            //    grdCategoryConfiguration.DataSource = dsUserWiseMailBoxMapGridBind;
            //    grdCategoryConfiguration.Visible = true;
            //    grdCategoryConfiguration.DataBind();
            //    ViewState["UserRoleMapGrid"] = grdCategoryConfiguration.DataSource;
            //    dt = dsUserWiseMailBoxMapGridBind.Tables[0];
            //}
            //catch (Exception Ex)
            //{
            //    ExceptionHelper.HandleException(Ex);
            //}
            return dt;
        }

        protected void sort(string strParam)
        {
            try
            {
                if (ViewState["SortDirection"] == null)
                {
                    ViewState["SortDirection"] = "asc";
                }
                else if (ViewState["SortDirection"].ToString() == "asc")
                {
                    ViewState["SortDirection"] = "desc";
                }
                else
                {
                    ViewState["SortDirection"] = "asc";
                }
                BindGrid(strParam);
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | FieldConfiguration.cs | sort()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | FieldConfiguration.cs | sort()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        private void BindGrid(string strparameter)
        {
            try
            {
                string Sortexpression = "";
                string sortdirection = "";
                if (ViewState["Sort"] == null)
                {
                    Sortexpression = strparameter;
                }
                else
                {
                    Sortexpression = ViewState["Sort"].ToString();
                }
                if (ViewState["SortDirection"] == null)
                {
                    sortdirection = "asc";
                }
                else
                {
                    sortdirection = ViewState["SortDirection"].ToString();
                }
                DataTable dtWorkList = new DataTable();
                GetWorkList(Sortexpression, sortdirection);
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | FieldConfiguration.cs | BindGrid()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | FieldConfiguration.cs | BindGrid()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        protected void GetWorkList(string SortExpression, string SortDirection)
        {
            try
            {
                DataSet ds = new DataSet();
                ds = (DataSet)ViewState["UserRoleMapGrid"];
                DataView dv = new DataView();
                dv = ds.Tables[0].DefaultView;
                dv.Sort = SortExpression + " " + SortDirection;
                //grdCategoryConfiguration.DataSource = dv;
                //grdCategoryConfiguration.DataBind();
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | FieldConfiguration.cs | GetWorkList()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | FieldConfiguration.cs | GetWorkList()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        #endregion
        #region EVENTS
        /// <summary>
        /// EVENT TO MAP THE MAILBOX TO THE USERS BASED ON THE COUNTRY SELECTION
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnMap_Click(object sender, EventArgs e)
        {
            string strdefaultValue = string.Empty;
            int chkactive;
            try
            {
                string UserID= Session["UserID"].ToString();
                if (UserData.UserId == UserID)
                {
                if (ddlCountry.SelectedIndex > 0 && Int32.Parse(ddlMailBox.SelectedValue) > 0)
                {
                    int CountryID = Int32.Parse(ddlCountry.SelectedValue.ToString());
                    int MailBoxID = Int32.Parse(ddlMailBox.SelectedValue.ToString());

                    //Pranay 3 March 2017 --Security Fix for FieldName
                    Regex regex = new Regex(@"^[a-zA-Z0-9_ ]+$");
                    Match match = regex.Match(txtFieldName.Text);
                    if (!string.IsNullOrEmpty(txtFieldName.Text) && (match.Success) && txtFieldName.Text.Length<=15)
                    {
                        LoginId = UserData.UserId;
                        Hashtable hs = new Hashtable();
                        hs.Add("@CountryID", CountryID);
                        hs.Add("@MailboxID", MailBoxID);
                        if (!string.IsNullOrEmpty(txtDefault.Text))
                            strdefaultValue = txtDefault.Text;
                        else
                            strdefaultValue = "";
                        hs.Add("@defaultValue", strdefaultValue);

                        string fldname = txtFieldName.Text.Trim().ToString();

                        if (fldname.Contains(" ")) 
                        {
                            fldname = fldname.Replace(" ", "");
                        }
                       

                        hs.Add("@FieldName", fldname);
                        hs.Add("@FieldAliasName", txtFieldName.Text.ToString());

                        hs.Add("@FieldTypeId", Convert.ToInt32(ddlFieldType.SelectedValue.ToString()));
                        hs.Add("@FieldDataTypeID", Convert.ToInt32(ddlFieldDataType.SelectedValue.ToString()));
                        hs.Add("@ValidationTypeID", Convert.ToInt32(ddlValidationType.SelectedValue.ToString()));
                        if (ddlFieldType.SelectedValue.Trim().ToLower() == Constant.TextBox || ddlFieldType.SelectedValue.Trim().ToLower() == Constant.TextArea)
                        {
                            if (!string.IsNullOrWhiteSpace(txtMaxLength.Text.ToString()))
                                hs.Add("@TextLength", Convert.ToInt32(txtMaxLength.Text.ToString()));

                            else
                                hs.Add("@TextLength", 0);
                        }
                        if (chkActive.Checked == true)
                        {
                            chkactive = 1;
                        }
                        else
                        {
                            chkactive = 0;
                        }

                        if (chkMandatory.Checked == true)
                            hs.Add("@Mandatory", 1);
                        else
                            hs.Add("@Mandatory", 2);

                        hs.Add("@Active", chkactive);
                        hs.Add("@CreatedBy", LoginId);
                        if (btnMap.Text == "Configure")
                        {
                            int returnvalue = _presenter.ConfigureFieldtoMailbox(hs);
                            if (returnvalue == 1)//MAPPING SUCCESS
                            {

                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Field name configuration is successful');", true);
                            }
                            else if (returnvalue == 3)//MAPPING FAILURE
                            {
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Field name already exists to the mailbox');", true);
                            }
                            else
                            {
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Field name already exists as a master,Please enter any other field name');", true);

                            }
                            Clearfields();
                            BindMailBoxcateMapgrid();
                        }
                        else // update section
                        {
                            hs.Add("@FieldMasterId", hddnMBoxMapID.Value);
                            int returnvalue = _presenter.UpdateConfigureFieldstoMailbox(hs);
                            if (returnvalue == 0)//UPDATE FAILS
                            {
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update Falied!');", true);
                                BindMailBoxcateMapgrid();
                                btnMap.Text = "Configure";
                            }
                            if (returnvalue == 1)//UPDATE SUCCESS
                            {
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update is successful!');", true);
                                Clearfields();
                                BindMailBoxcateMapgrid();
                                btnMap.Text = "Configure";
                            }
                            else if (returnvalue == 3 || returnvalue == 4)//Already Mapped
                            {
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Field name is already available to the Selected MailBox or as a master value');", true);
                                btnMap.Text = "Update";
                                BindMailBoxcateMapgrid();
                                Clearfields();
                            }
                        }

                    }
                    else
                    {
                        if (string.IsNullOrEmpty(txtFieldName.Text))
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Enter Field name');", true);
                        }
                        else if(!(match.Success))
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Special Characters not allowed!!!');", true);
                        }
                        else if (txtFieldName.Text.Length > 15)
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Length of FieldName should be less than 15 characters');", true);
                        }
                    }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select country and mailbox');", true);
                }
                }
                else
                {
                    
                    Server.Transfer(@"~/Errors/BadRequest.aspx");
                
                }
            }
            catch(Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | FieldConfiguration.cs | btnMap_Click()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | FieldConfiguration.cs | btnMap_Click()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        /// <summary>
        /// EVENT TO CLEAR ALL THE FIELDS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClr_Click(object sender, EventArgs e)
        {
            Clearfields();
        }


        /// <summary>
        /// TO BIND THE LIST OF MAILBOX TO THE MAILBOX DROPDOWN BASED ON THE COUNTRY SELECTTON
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (!(UserData == null))
                {
                    if (ddlCountry.SelectedIndex > 0)
                    {
                        int CountryId = Convert.ToInt32(ddlCountry.SelectedValue);
                        DataSet dsBindActiveMailBox = _presenter.BindActiveMailBox(CountryId, UserData.UserId, UserData.RoleId);
                        if (dsBindActiveMailBox.Tables[0].Rows.Count > 0)
                        {
                            ddlMailBox.DataSource = dsBindActiveMailBox;
                            ddlMailBox.DataValueField = "EMAILBOXID";
                            ddlMailBox.DataTextField = "EMAILBOXNAME";
                            ddlMailBox.DataBind();
                            ListItem select = new ListItem();
                            select.Text = "- Select -";
                            select.Value = "0";
                            ddlMailBox.Items.Insert(0, select);
                            ddlCountryId = ddlCountry.SelectedValue;
                            BindMailBoxcateMapgrid();
                            lblmsg.Text = "";
                        }
                        else
                        {
                            lblmsg.Visible = true;
                            ddlMailBox.Items.Clear();
                            ListItem select = new ListItem();
                            select.Text = "- Select -";
                            select.Value = "0";
                            ddlMailBox.Items.Insert(0, select);
                            lblmsg.Text = "No Mailbox available for the selected country!!!";
                            BindMailBoxcateMapgrid();
                        }
                    }
                    else
                    {
                        ddlMailBox.Items.Clear();
                        ListItem select = new ListItem();
                        select.Text = "- Select -";
                        select.Value = "0";
                        ddlMailBox.Items.Insert(0, select);
                    }
                    ddlCountry.Focus();
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | ddlCountry_SelectedIndexChanged()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | ddlCountry_SelectedIndexChanged()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        #endregion
        protected void ddlFieldType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlFieldType.SelectedIndex > 0)
                {
                    txtDefault.ReadOnly = true;
                    BindFieldDataandValidationType(Int32.Parse(ddlFieldType.SelectedValue.Trim()));
                    trMaxLength.Visible = false;
                    if (ddlFieldType.SelectedValue.Trim().ToLower() == Constant.DropDownList)
                        txtDefault.ReadOnly = true;
                    else if (ddlFieldType.SelectedValue.Trim().ToLower() == Constant.TextBox)
                    {
                        trMaxLength.Visible = true;
                        txtDefault.ReadOnly = false;
                    }

                    //To show message for Add Items
                    if (ddlFieldType.SelectedIndex == 2 || ddlFieldType.SelectedIndex == 3 || ddlFieldType.SelectedIndex == 5)
                    {
                        lblShwItmmsg.Visible = true;
                    }
                    else
                    {
                        lblShwItmmsg.Visible = false;
                    }
                }
                else
                {
                    lblShwItmmsg.Visible = false;
                }
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | ddlFieldType_SelectedIndexChanged()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | ddlFieldType_SelectedIndexChanged()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            
            }
        }
        private void BindFieldDataandValidationType(Int32 FieldTypeID)
        {
            using (DataSet dsRes = _presenter.Getfieldname(FieldTypeID))
            {
                try
                {
                    if (dsRes != null && dsRes.Tables.Count > 0 && dsRes.Tables[0].Rows.Count > 0)
                    {
                        ddlFieldDataType.Items.Clear();
                        ddlValidationType.Items.Clear();
                        ddlFieldDataType.DataSource = null;
                        ddlFieldDataType.DataBind();
                        ddlValidationType.DataSource = null;
                        ddlValidationType.DataBind();

                        ddlFieldDataType.DataValueField = "FieldDataTypeID";
                        ddlFieldDataType.DataTextField = "FieldDataTypeAlias";
                        ddlFieldDataType.DataSource = dsRes.Tables[0];
                        ddlFieldDataType.DataBind();
                        if (dsRes.Tables[0].Rows.Count > 1)
                            ddlFieldDataType.Items.Insert(0, new ListItem("-- Select --", "0"));

                        if (dsRes.Tables[1].Rows.Count > 0)
                        {
                            ddlValidationType.DataValueField = "ValidationTypeId";
                            ddlValidationType.DataTextField = "ValidationType";
                            ddlValidationType.DataSource = dsRes.Tables[1];
                            ddlValidationType.DataBind();
                            if (dsRes.Tables[1].Rows.Count > 1)
                                ddlValidationType.Items.Insert(0, new ListItem("-- Select --", "0"));
                        }
                    }
                }
                catch (Exception ex)
                {
                    //ExceptionHelper.HandleException(ex);
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | BindFieldDataandValidationType()");  
                    //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | BindFieldDataandValidationType()");
                    Response.Clear();
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
                finally
                {
                    dsRes.Dispose();
                }
            }
        }

        protected void ddlFieldDataType_SelectedIndexChanged(object sender, EventArgs e)
        {
            Int32 fldDataTypeID = 0;
            try
            {
                if (ddlFieldDataType.SelectedIndex > 0)
                {
                    if (ddlFieldDataType.SelectedValue.ToString() == "1" || ddlFieldDataType.SelectedValue.ToString() == "2")
                    {
                        DataSet ds = new DataSet();
                        ddlValidationType.Items.Clear();
                        fldDataTypeID = Int32.Parse(ddlFieldDataType.SelectedValue.ToString());
                        ds = _presenter.USP_GetConfigureFieldsValidationType_Result(fldDataTypeID);
                        ddlValidationType.DataValueField = "ValidationTypeId";
                        ddlValidationType.DataTextField = "ValidationType";
                        ddlValidationType.DataSource = ds;
                        ddlValidationType.DataBind();
                        ddlValidationType.Items.Insert(0, new ListItem("-- Select --", "0"));
                    }
                    else
                    {
                        using (DataSet dsRes = _presenter.Getfieldname(Convert.ToInt32(ddlFieldType.SelectedValue.ToString())))
                        {
                            if (dsRes != null && dsRes.Tables.Count > 0 && dsRes.Tables[1].Rows.Count > 0)
                            {
                                ddlValidationType.DataValueField = "ValidationTypeId";
                                ddlValidationType.DataTextField = "ValidationType";
                                ddlValidationType.DataSource = dsRes.Tables[1];
                                ddlValidationType.DataBind();
                                if (dsRes.Tables[1].Rows.Count > 1)
                                    ddlValidationType.Items.Insert(0, new ListItem("-- Select --", "0"));
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | ddlFieldDataType_SelectedIndexChanged()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | ddlFieldDataType_SelectedIndexChanged()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        protected void ddlValidationType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlValidationType.SelectedIndex > 0)
                {
                    if (ddlValidationType.SelectedValue.ToString().Trim() == "2" || ddlValidationType.SelectedValue.ToString().Trim() == "7")
                        BindDateTimeFormat(Int32.Parse(ddlValidationType.SelectedValue.ToString().Trim()));
                }
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | ddlValidationType_SelectedIndexChanged()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | ddlValidationType_SelectedIndexChanged()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        private void BindDateTimeFormat(Int32 ValidationTypeID)
        {
            using (DataSet dsRes = _presenter.GetDatetimeFormat(ValidationTypeID))
            {
                try
                {
                    if (dsRes != null && dsRes.Tables.Count > 0 && dsRes.Tables[0].Rows.Count > 0)
                    {
                        trDtFormat.Visible = false;
                        ddlDateFormat.DataValueField = "DtFormatId";
                        ddlDateFormat.DataTextField = "DateTimeFormat";
                        ddlDateFormat.DataSource = dsRes.Tables[0];
                        ddlDateFormat.DataBind();
                        ddlDateFormat.Items.Insert(0, new ListItem("-- Select --", "0"));
                    }
                    else
                        trDtFormat.Visible = false;
                }
                catch (Exception ex)
                {
                    //ExceptionHelper.HandleException(ex);
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | BindDateTimeFormat()");  
                    //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | BindDateTimeFormat()");
                    Response.Clear();
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
                finally
                {
                    dsRes.Dispose();
                }
            }
        }
        #region Call to get add options Params method
        protected void BtnGetEditParams_Click(object sender, EventArgs e)
        {
            int index = 0;
            string ciphertext = string.Empty;
            string Pvalue = string.Empty;
            Label lblFieldMasterID = new Label();
            try
            {
                //  get the gridviewrow from the sender so we can get the datakey we need
                LinkButton btnDelete = sender as LinkButton;
                GridViewRow row = (GridViewRow)btnDelete.NamingContainer;
                index = Convert.ToInt32(row.RowIndex);
                lblFieldMasterID = (Label)row.FindControl("lblFieldMasterId");
                Label hdnFldTypeID = (Label)row.FindControl("lblFldTypeID");
               
 
                ciphertext = "PW";

                Pvalue = "AddOptionValuesForDynamicControls.aspx?FieldMasterID=" + lblFieldMasterID.Text.ToString() + "&FieldTypeID=" + hdnFldTypeID.Text;
                
                ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), "StartUpScript1", "javascript:window.showModalDialog('" + Pvalue + "',null,'left=30px; top=30px; dialogHeight=500px;dialogWidth=1000px; status=no; resizable= yes; scrollbars=yes; toolbar=no; location=no; menubar=no');", true);
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | BtnGetEditParams_Click()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | BtnGetEditParams_Click()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            finally
            {
                index = 0;
                ciphertext = string.Empty;
                Pvalue = string.Empty;
                lblFieldMasterID.Dispose();
            }

        }
        #endregion
        #region Grid Row Command , Paging , Sorting Code

        protected void gvConfigureFields_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            try
            {
                if (!(UserData == null))
                {
                    if (e.CommandName == "EditMailBoxMap")
                    {
                        int RowIndex = Convert.ToInt32(e.CommandArgument);
                        hddnMBMapId = ((Label)gvConfigureFields.Rows[RowIndex].FindControl("lblFieldMasterId")).Text.ToString().Trim();
                        string Country = ((Label)gvConfigureFields.Rows[RowIndex].FindControl("lblcountry")).Text.ToString().Trim();
                        string MBoxId = ((Label)gvConfigureFields.Rows[RowIndex].FindControl("lblMailBoxId")).Text.ToString().Trim();
                        string fieldname = ((Label)gvConfigureFields.Rows[RowIndex].FindControl("lblFieldName")).Text.ToString().Trim();
                        txtFieldName.Text = fieldname;
                        string lblTextLength = ((Label)gvConfigureFields.Rows[RowIndex].FindControl("lblTextLength")).Text.ToString().Trim();
                        string lblDefaultValue = ((Label)gvConfigureFields.Rows[RowIndex].FindControl("lblDefaultValue")).Text.ToString().Trim();

                        string lblFieldTypeId = ((Label)gvConfigureFields.Rows[RowIndex].FindControl("lblFieldType")).Text.ToString().Trim();
                        string lblValidationTypeId = ((Label)gvConfigureFields.Rows[RowIndex].FindControl("lblValidationType")).Text.ToString().Trim();
                        string lblFieldDataTypeId = ((Label)gvConfigureFields.Rows[RowIndex].FindControl("lblFieldDataType")).Text.ToString().Trim();
                        string IsActive = ((Label)gvConfigureFields.Rows[RowIndex].FindControl("lblActive")).Text.ToString().Trim();
                        string IsMandatory = ((Label)gvConfigureFields.Rows[RowIndex].FindControl("lblMandatory")).Text.ToString().Trim();
                        ddlCountry.SelectedIndex = ddlCountry.Items.IndexOf(ddlCountry.Items.FindByText(Country));
                        ddlCountry_SelectedIndexChanged(sender, e);
                        ddlMailBox.SelectedIndex = ddlMailBox.Items.IndexOf(ddlMailBox.Items.FindByValue(MBoxId));

                        ddlFieldType.SelectedIndex = ddlFieldType.Items.IndexOf(ddlFieldType.Items.FindByText(lblFieldTypeId));
                        ddlFieldType_SelectedIndexChanged(sender, e);
                        if (ddlFieldType.SelectedIndex == 1)
                        {
                            trMaxLength.Visible = true;
                            txtMaxLength.Text = lblTextLength;
                        }
                        else
                        {
                            trMaxLength.Visible = false;
                        }
                        ddlFieldDataType.SelectedIndex = ddlFieldDataType.Items.IndexOf(ddlFieldDataType.Items.FindByText(lblFieldDataTypeId));
                        ddlFieldDataType_SelectedIndexChanged(sender, e);
                        ddlValidationType.SelectedIndex = ddlValidationType.Items.IndexOf(ddlValidationType.Items.FindByText(lblValidationTypeId));
                        txtDefault.Text = lblDefaultValue;
                      

                        if (IsActive == "Yes")
                        {
                            chkActive.Checked = true;
                        }
                        else
                        {
                            chkActive.Checked = false;
                        }

                        if (IsMandatory == "Yes")
                        {
                            chkMandatory.Checked = true;
                        }
                        else
                        {
                            chkMandatory.Checked = false;
                        }

                        hddnMBoxMapID.Value = hddnMBMapId;
                        btnMap.Text = "Update";
                        ddlCountry.Enabled = false;

                    }
                    else if (e.CommandName == "DeleteMailBoxMap")
                    {
                        int RowIndex = Convert.ToInt32(e.CommandArgument);
                        hddnMBMapId = ((Label)gvConfigureFields.Rows[RowIndex].FindControl("lblMailBoxMapId")).Text.ToString().Trim();
                        //UserId = ((Label)grdMailBoxMapping.Rows[RowIndex].FindControl("lblUserID")).Text.ToString().Trim();
                        int returnvalue = _presenter.DeleteMailBoxMap(hddnMBMapId, UserId);
                        if (returnvalue == 0)//Delete Failed
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Record is not deleted!');", true);
                            BindMailBoxcateMapgrid();
                        }
                        if (returnvalue == 1)//Delete Success
                        {

                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Record has been deleted successfully!');", true);
                            Clearfields();
                            BindMailBoxcateMapgrid();
                        }
                        else if (returnvalue == 2)
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Record cannot be Deleted!!! Cases Pending under the selected User!');", true);
                            BindMailBoxcateMapgrid();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | gvConfigureFields_RowCommand()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | gvConfigureFields_RowCommand()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        protected void gvConfigureFields_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                gvConfigureFields.DataSource = SortDataTable(BindMailBoxcateMapgrid() as DataTable, true);
                gvConfigureFields.PageIndex = e.NewPageIndex;
                gvConfigureFields.DataBind();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | gvConfigureFields_PageIndexChanging()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | gvConfigureFields_PageIndexChanging()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        protected void gvConfigureFields_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                GridViewSortExpression = e.SortExpression;
                int pageIndex = gvConfigureFields.PageIndex;
                gvConfigureFields.DataSource = SortDataTable(BindMailBoxcateMapgrid() as DataTable, false);
                gvConfigureFields.DataBind();
                gvConfigureFields.PageIndex = pageIndex;
            }
            catch (Exception ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | gvConfigureFields_PageIndexChanging()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | gvConfigureFields_PageIndexChanging()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        protected DataView SortDataTable(DataTable dataTable, bool isPageIndexChanging)
        {
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (GridViewSortExpression != string.Empty)
                {
                    if (isPageIndexChanging)
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GridViewSortDirection);
                    }
                    else
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GetSortDirection());
                    }
                }
                return dataView;
            }
            else
            {
                return new DataView();
            }
        }

        private string GetSortDirection()
        {
            switch (GridViewSortDirection)
            {
                case "ASC":
                    GridViewSortDirection = "DESC";
                    break;
                case "DESC":
                    GridViewSortDirection = "ASC";
                    break;
            }
            return GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }

        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }



        protected void gvConfigureFields_RowEditing(object sender, GridViewEditEventArgs e)
        {
            try
            {
                Label lblSMEId = (Label)gvConfigureFields.Rows[e.NewEditIndex].FindControl("lblFieldMasterId");
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | gvConfigureFields_RowEditing()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | gvConfigureFields_RowEditing()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        protected void gvConfigureFields_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            Label lblFieldType = new Label();
            LinkButton lnlViewDetails = new LinkButton();
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    lblFieldType = (Label)e.Row.FindControl("lblFieldType");
                    if (lblFieldType != null && (lblFieldType.Text.Trim().ToLower() == "dropdownlist" || lblFieldType.Text.Trim().ToLower() == "checkboxlist" || lblFieldType.Text.Trim().ToLower() == "radiobuttonlist"))
                    {
                        lnlViewDetails = (LinkButton)e.Row.Cells[5].FindControl("lbAddOptions");
                        lnlViewDetails.Visible = true;
                    }
                    else
                    {
                        lnlViewDetails = (LinkButton)e.Row.Cells[5].FindControl("lbAddOptions");
                        lnlViewDetails.Visible = false;
                    }
                    //Varma - Timezone Feature On&OFF functionality 
                    if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                    {
                        //Pranay 11 January 2017--for changing modified date as per user TimeZone
                        Label ModifiedDate = (Label)(e.Row.FindControl("lblModifiedDate"));
                        string value = DataBinder.Eval(e.Row.DataItem, "ModifiedDate").ToString();
                        //if (DataBinder.Eval(e.Row.DataItem, "ModifiedDate").ToString() != null)
                        if (!String.IsNullOrEmpty(value))
                        {
                            DateTime modifiedDate = Convert.ToDateTime(DataBinder.Eval(e.Row.DataItem, "ModifiedDate"));
                            String zonedDateTime = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(modifiedDate.ToString("dd/MM/yyyy HH:mm:ss"), true, UserData.TimeZone, false);
                            //Label ModifiedDate = (Label)(e.Row.FindControl("lblModifiedDate"));
                            ModifiedDate.Text = zonedDateTime;
                        }
                        else
                        {
                            //Label ModifiedDate = (Label)(e.Row.FindControl("lblModifiedDate"));
                            ModifiedDate.Text = String.Empty;
                        }
                    }
                }
                if (e.Row.RowType == DataControlRowType.DataRow || e.Row.RowType == DataControlRowType.Header)
                    GridviewDateTimeFormat(e);
            }
            catch (Exception ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | gvConfigureFields_RowDataBound()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | gvConfigureFields_RowDataBound()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            finally
            {
                lblFieldType.Dispose();
                lnlViewDetails.Dispose();
            }
        }
        public void GridviewDateTimeFormat(GridViewRowEventArgs e)
        {
            try
            {
                for (int count = 0; count < e.Row.Cells.Count; count++)
                {
                    e.Row.Cells[count].Attributes.Add("style", "white-space: nowrap;");
                    if (e.Row.Cells[count].Text.Length > 40)
                    {
                        e.Row.Cells[count].Text = e.Row.Cells[count].Text.Replace(";", ";<br />");
                    }

                    System.DateTime cellDate = default(System.DateTime);
                    //if (System.DateTime.TryParse(e.Row.Cells[count].Text, out cellDate))
                    //{
                    //    e.Row.Cells[count].Text = string.Format("{0:dd/MM/yyyy HH:mm}", cellDate);
                    //}
                    string format = "dd/MM/yyyy HH:mm";
                    if (DateTime.TryParse(e.Row.Cells[count].Text, out cellDate))
                    {
                        e.Row.Cells[count].Text = Convert.ToDateTime(e.Row.Cells[count].Text).ToString(format, System.Globalization.CultureInfo.InvariantCulture);
                    }
                    else if (DateTime.TryParseExact(e.Row.Cells[count].Text, format, System.Globalization.CultureInfo.InvariantCulture,
                        System.Globalization.DateTimeStyles.None, out cellDate))
                    {
                        e.Row.Cells[count].Text = Convert.ToDateTime(e.Row.Cells[count].Text).ToString(format, System.Globalization.CultureInfo.InvariantCulture);
                    }
                }
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | FieldConfiguration.cs | GridviewDateTimeFormat()");  
                //errorlog.HandleError(ex, UserData.UserId, " | FieldConfiguration.cs | GridviewDateTimeFormat()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        

        #endregion
    }
}