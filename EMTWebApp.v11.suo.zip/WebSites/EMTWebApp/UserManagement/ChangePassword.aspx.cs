﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using EMTWebApp.Constants;
using System.Configuration;
using DigiOPS.TechFoundation.Security;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using DigiOPS.TechFoundation.Logging;
using System.Security;
using System.Runtime.InteropServices;
using System.Text;

namespace EMTWebApp.UserManagement.Views
{
    public partial class ChangePassword : Microsoft.Practices.CompositeWeb.Web.UI.Page, IChangePasswordView
    {
        #region DECLARATION
        private ChangePasswordPresenter _presenter;
        UserSession UserDetails = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();        
        string CheckWhichLoginType = ConfigurationManager.AppSettings["ADLogin"].ToString();
        string encryptionmode = ConfigurationManager.AppSettings["ENCRYPT/DECRYPT"].ToString();
        
        #endregion
        #region PROPERTIES
        [CreateNew]
        public ChangePasswordPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion
        /// <summary>
        /// Login Id of the user will be displayed in the Login Id field
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //int passwordexpired = Convert.ToInt16(Session["PasswordExpiration"]);
           // if (passwordexpired == 0)
                
                
                    if (CheckWhichLoginType == "Yes") // AD Login type
                    {

                        Response.Clear(); Response.Redirect("https://identity.cognizant.com/itim/self/Login/Logon.do", false);
                    }
                    else if (CheckWhichLoginType == "No")// Normal Login type
                    {
                         UserDetails = (UserSession)Session["UserDetails"];
                        IsValidRoleToAccessThisPage(UserDetails);
                        ValidateUserSession(UserDetails);
                        Session["CurrentPage"] = "User Management";                     
                        if (!this.IsPostBack)
                        {
                            this._presenter.OnViewInitialized();
                            Page.Form.DefaultButton = btnSubmit.UniqueID;
                            txtOldPKeyword.Focus();
                            txtOldPKeyword.Attributes.Add("onmousedown", "return noCopyMouse(event);");
                            txtNewPKeyword.Attributes.Add("onmousedown", "return noCopyMouse(event);");
                            txtConfirmPKeyword.Attributes.Add("onmousedown", "return noCopyMouse(event);");
                            txtOldPKeyword.Attributes.Add("onkeydown", "return noCopyKey(event);");
                            txtConfirmPKeyword.Attributes.Add("onkeydown", "return noCopyKey(event);");
                            txtNewPKeyword.Attributes.Add("onkeydown", "return noCopyKey(event);");
                            txtNewPKeyword.Attributes.Add("onkeypress", "return ValidateSpaces();");
                            txtConfirmPKeyword.Attributes.Add("onKeyPress", "return ValidateSpaces();");
                            //Pranay 28 March
                            txtOldPKeyword.Attributes.Add("onKeyPress", "return ValidateSpaces();");

                            if (Session["UserDetails"] != null)
                            {
                             txtLoginID.Text = UserDetails.UserId.ToString();
                            }
                            else
                            {
                                Response.Clear();
                                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                            }
                        }
                        this._presenter.OnViewLoaded();

                        ///
                        /// String passwordExpired Changed to Expired
                        /// modifiedBY : Natarajan (577343)
                        ///

                         string expired = Session["PasswordExpiration"].ToString();
                         if (expired == "yes" && Session["CurrentPage"] == "User Management")
                         {
                             Session["UserDetails"] = UserDetails;
                         }
                         
                         //else
                         //    Session["UserDetails"] = null;
                    }

                
                
            }

            catch (Exception ex)
            {
               // errorlog.HandleError(ex, UserDetails.UserId, " | ChangePassword.cs | Page_Load()");
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | ChangePassword.cs | Page_Load()");     
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        
        #region METHODS
        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserDetails)
        {
            try
            {
                if ((UserDetails.RoleId == (int)Constant.UserRole.SuperAdmin) || (UserDetails.RoleId == (int)Constant.UserRole.Admin) || (UserDetails.RoleId == (int)Constant.UserRole.TeamLead) || (UserDetails.RoleId == (int)Constant.UserRole.Processor) || (UserDetails.RoleId == (int)Constant.UserRole.ClientUser))
                {
                    return true;
                }
                else
                {
                    Response.Clear(); Response.Redirect(@"~\Errors\AccessDenied.aspx", false);
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
              //  errorlog.HandleError(Ex, UserDetails.UserId, " | ChangePassword.cs | IsValidRoleToAccessThisPage()");
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | ChangePassword.cs | IsValidRoleToAccessThisPage()");     
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
            return false;
        }

        /// <summary>
        /// Method to redirect to session expired page if userdetails are null
        /// </summary>
        private void ValidateUserSession(UserSession UserDetails)
        {
            try
            {
                if (UserDetails == null)
                {
                    Response.Clear(); Response.Redirect(@"~\Errors\SessionExpired.aspx", false);
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | ChangePassword.cs | ValidateUserSession()");     
                Response.Clear();
                //errorlog.HandleError(Ex, UserDetails.UserId, " | ChangePassword.cs | ValidateUserSession()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        #endregion
        public bool PasswordComplexityValidation(string password)
        {
            //Regex regex = new Regex(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,50}$");
            Regex regex = new Regex(@"^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,15}$");
            //Password must be 8-15 characters including 1 uppercase letter, 1 special character, alphanumeric characters
            Match match = regex.Match(password);
            return match.Success;

        }
        #region EVENTS
        /// <summary>
        /// Event to change the user's current password
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            SecureString sec_strPassword = new SecureString();
            SecureString sec_strPassword1 = new SecureString();
            try
            {
                ChangePassword miscObj = new ChangePassword();
                string expired = (Session["PasswordExpiration"]).ToString();
                string Fname=Session["fname"].ToString();
                string UserId = Session["UserID"].ToString();               
                string Rolename = Session["RoleName"].ToString();
                if (UserDetails.FirstName == Fname && UserDetails.UserId==UserId && UserDetails.RoleName==Rolename)
                {
                    string Pkeywordexpired = (Session["PasswordExpiration"]).ToString();

                    //Pranay 27 March--
                    //byte[] encodedLoginIdBytes = Convert.FromBase64String(txtLoginID.Text.Trim());
                  //string UserID = Encoding.UTF8.GetString(encodedLoginIdBytes);
                string UserID = txtLoginID.Text.Trim();

                //Encryption                
                //cryptInfo.CryptKey = cipherpassword;
                //cryptInfo.ValueToCrypt = txtOldPassword.Text.Trim();
                //string EncryptOldPassword = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
                //  string EncryptOldPassword = Constants.HelperMethods.EncryptString(txtOldPassword.Text.Trim());
                Regex regex = new Regex("\"|'");
                Match match = regex.Match(txtOldPKeyword.Text.Trim());
                Match match1 = regex.Match(txtConfirmPKeyword.Text.Trim());
                Match match2 = regex.Match(txtNewPKeyword.Text.Trim());
                if (match.Success || match1.Success || match2.Success)
                {
                    Response.Clear(); Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                }
                else
                {
                //Pranay 27 March 2017--making password encrypted for Request Body
                //sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.EncryptString(txtOldPKeyword.Text.Trim()));
                byte[] encodedOldPasswordBytes = Convert.FromBase64String(txtOldPKeyword.Text.Trim());
                string oldPassword = Encoding.UTF8.GetString(encodedOldPasswordBytes);
                //encrypt/encode
                if (encryptionmode == "ON")
                {
                    sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.EncryptString(oldPassword));
                }
                else
                {
                    sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.EncryptValue(oldPassword));
                }                

                //cryptInfo.ValueToCrypt = txtConfirmPassword.Text.Trim();
               //string EncryptConfirmPassword = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
               // string EncryptConfirmPassword = Constants.HelperMethods.EncryptString(txtConfirmPassword.Text.Trim());

                //string EncryptOldPassword = Constants.HelperMethods.EncryptValue(txtOldPassword.Text);
                //string EncryptConfirmPassword = Constants.HelperMethods.EncryptValue(txtConfirmPassword.Text);

                //Pranay 27 March 2017--making password encrypted for Request Body
                //sec_strPassword1 = miscObj.convertToSecureString(Constants.HelperMethods.EncryptValue(txtConfirmPKeyword.Text));
                byte[] encodedConfirmPasswordBytes = Convert.FromBase64String(txtConfirmPKeyword.Text.Trim());
                string confirmPassword = Encoding.UTF8.GetString(encodedConfirmPasswordBytes);
                //encrypt/encode
                if (encryptionmode == "ON")
                {
                    sec_strPassword1 = miscObj.convertToSecureString(Constants.HelperMethods.EncryptString(confirmPassword));
                }
                else
                {
                    sec_strPassword1 = miscObj.convertToSecureString(Constants.HelperMethods.EncryptValue(confirmPassword));
                }                

                int validate = _presenter.ValidatePassword(UserID, miscObj.convertToUNSecureString(sec_strPassword));
                //if (PasswordComplexityValidation(txtNewPKeyword.Text))
                if (PasswordComplexityValidation(Encoding.UTF8.GetString(Convert.FromBase64String(txtNewPKeyword.Text.Trim()))))
                {
                    if (validate == 1)//Checks whether the provided password matches the current password
                    {
                        if ((Encoding.UTF8.GetString(Convert.FromBase64String(txtNewPKeyword.Text.Trim()))) == (Encoding.UTF8.GetString(Convert.FromBase64String(txtConfirmPKeyword.Text.Trim()))))
                        {
                            if (miscObj.convertToUNSecureString(sec_strPassword) != miscObj.convertToUNSecureString(sec_strPassword1))//Checks whether the old password and the changed password are different
                            {
                                int returnValue = _presenter.ChangePassword(UserID, miscObj.convertToUNSecureString(sec_strPassword), miscObj.convertToUNSecureString(sec_strPassword1));
                                if (returnValue == 0) //Success Scenario
                                {
                                    if (expired == "yes" && Session["CurrentPage"] == "User Management")
                                    {
                                        String redirectURL = HttpContext.Current.Request.Url.ToString().Replace("ChangePassword", "Login");
                                        redirectURL = redirectURL.Replace("UserManagement", "AuthenticationandAuthorization");
                                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Success", "alert('Your Password has been Changed Successfully! You will be redirected to Login page.');window.location ='" + redirectURL + "';", true);
                                    }
                                    else
                                    {                                        
                                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Your Password has been Changed Successfully!');", true);
                                    }
                                }
                                else//Failure Scenario
                                {
                                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Please contact your administrator!');", true);
                                    txtOldPKeyword.Focus();
                                }
                            }
                            else
                            {
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Old & New password cannot be same!');", true);
                                txtOldPKeyword.Focus();
                            }
                        }
                        else
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('New & Confirm password cannot be different!');", true);
                            txtOldPKeyword.Focus();
                        }
                    }
                     else
                     {
                         ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Old password provided is not correct!');", true);
                         txtOldPKeyword.Focus();
                     }
                    }
                    else//Invalid LoginId
                    {
                        //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Provide your Current Password in the Old Password!');", true);
                        //txtOldPKeyword.Focus();
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Your Password length should be 8 digits with a Numeric, a Alphabet and a Special Character except single and double quotes!');", true);
                        txtNewPKeyword.Focus();
                    }
                }
            }
                else
                {
                   
                    Server.Transfer(@"~/Errors/BadRequest.aspx");
                
                }
            }
            catch (Exception ex)
            {
                // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | ChangePassword.cs | btnSubmit_Click()");     
                //errorlog.HandleError(ex, UserDetails.UserId, " | ChangePassword.cs | btnSubmit_Click()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        /// <summary>
        /// Event to Clear all the fields
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreset_Click(object sender, EventArgs e)
        {
            try
            {
                txtOldPKeyword.Text = "";
                txtNewPKeyword.Text = "";
                txtConfirmPKeyword.Text = "";
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | ChangePassword.cs | btnreset_Click()");     
               // errorlog.HandleError(ex, UserDetails.UserId, " | ChangePassword.cs | btnreset_Click()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        #endregion

        ///
        ///SecureString to retrieve the Sensitive Data
        ///ModifiedBy: Natarajan(577343)



        public SecureString convertToSecureString(string strPassword)
        {
            var secureStr = new SecureString();
            if (strPassword.Length > 0)
            {
                foreach (var c in strPassword.ToCharArray()) secureStr.AppendChar(c);
            }
            return secureStr;
        }

        public string convertToUNSecureString(SecureString secstrPassword)
        {
            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(secstrPassword);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

    }
}