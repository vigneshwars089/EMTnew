﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using DigiOPS.TechFoundation.Logging;
using EMTWebApp.Constants;

namespace EMTWebApp.UserManagement.Views
{
    public partial class UserManagement_CategoryConfiguration : Microsoft.Practices.CompositeWeb.Web.UI.Page, IUserMailBoxMappingView
    {

        #region DECLARATIONS
        private UserMailBoxMappingPresenter _presenter;
        private string LoginId = string.Empty;
        private string UserId = string.Empty;
        private string ddlCountryId = string.Empty;
        UserSession UserData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        public string hddnMBMapId;
        #endregion
        /// <summary>
        /// TO BIND THE USERS, COUNTRY NAMES TO THE DROPDOWN AND MAILBOX DETAILS TO THE GRID
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["UserDetails"] != null)
                {
                    Session["CurrentPage"] = "Configuration";
                    UserData = (UserSession)Session["UserDetails"];
                    RedirectToErrorPage(UserData);
                    IsValidRoleToAccessThisPage(UserData);
                    if (!this.IsPostBack)
                    {
                        this._presenter.OnViewInitialized();
                        BindMailBoxcateMapgrid();
                        Page.Form.DefaultButton = btnMap.UniqueID;
                        BindCountry();
                        ddlCountry_SelectedIndexChanged(null, null);
                        //chkescalation.Attributes.Add("onchange", "return Validation(" + txtnot.ClientID + ")");
                        //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                        string PKeyword = (Session["PasswordExpiration"]).ToString();
                        if (PKeyword == "yes")
                        {
                            Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                    }
                }
                }
                else
                {
                    Response.Clear();
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
                this._presenter.OnViewLoaded();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CategoryConfiguration.cs | Page_Load()");
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | CategoryConfiguration.cs | Page_Load()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        #region PROPERTIES
        [CreateNew]
        public UserMailBoxMappingPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion
        #region METHODS
        /// <summary>
        /// Method to redirect to login or session expired page
        /// </summary>
        private void RedirectToErrorPage(UserSession UserDetail)
        {
            try
            {
                if (UserDetail == null)
                {
                    Response.Clear(); Response.Redirect(@"~\Errors\Error.aspx", false); Response.End(); 
                }
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                Response.Clear();
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CategoryConfiguration.cs | RedirectToErrorPage()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | CategoryConfiguration.cs | RedirectToErrorPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserData)
        {
            try
            {
                if ((UserData.RoleId == (int)Constant.UserRole.Admin) || (UserData.RoleId == (int)Constant.UserRole.SuperAdmin))
                {
                    return true;
                }
                else
                {
                    Response.Clear(); Response.Redirect("~/Errors/AccessDenied.aspx", false); Response.End(); 
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CategoryConfiguration.cs | IsValidRoleToAccessThisPage()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserData.UserId, " | CategoryConfiguration.cs | IsValidRoleToAccessThisPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            return false;
        }

        /// <summary>
        /// FUNCTION TO BIND THE ACTIVE USERS TO THE DROPDOWN
        /// </summary>

        /// <summary>
        /// FUNCTION TO CLEAR THE FIELDS
        /// </summary>
        public void Clearfields()
        {
            try
            {
                //ddlMailBox.Items.Clear();
                // ddlMailBox.Items.Insert(0, "- Select -");
                //  ddlCountry.SelectedIndex = 0;
                ddlCountry.SelectedIndex = 0; ddlMailBox.SelectedIndex = 0;
                ddlMailBox.Items.Clear();
                txtCategory.Text = "";
                btnMap.Text = "Configure";
                //BindMailBoxcateMapgrid();
                lblmsg.Visible = false;
                lblmsg.Text = "";
                ddlCountry.Enabled = true;
                ListItem select = new ListItem();
                select.Text = "- Select -";
                select.Value = "0";
                ddlMailBox.Items.Insert(0, select);
                chkActive.Checked = true;
                ddlCountry_SelectedIndexChanged(null, null);
                if (ddlCountry.Items.Count == 1)
                {
                    ddlCountry.Enabled = false;
                }
                ddlMailBox.SelectedIndex = 0;
                BindMailBoxcateMapgrid();
            }
            catch(Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CategoryConfiguration.cs | Clearfields()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserData.UserId, " | CategoryConfiguration.cs | Clearfields()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        /// <summary>
        /// FUNCTION TO BIND THE COUNTRY NAMES TO THE DROPDOWN
        /// </summary>
        public void BindCountry()
        {
            try
            {
                DataSet dsCountryNames = _presenter.BindCountry();
                ddlCountry.DataSource = dsCountryNames;
                ddlCountry.DataValueField = "CountryID";
                ddlCountry.DataTextField = "Country";
                ddlCountry.DataBind();
                if (dsCountryNames.Tables[0].Rows.Count == 1)
                {
                    ddlCountry.SelectedIndex = -1;
                    ddlCountry.Enabled = false;
                }
                else
                {
                    ddlCountry.Items.Insert(0, new ListItem("-Select-", "0", true));
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CategoryConfiguration.cs | BindCountry()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserData.UserId, " | CategoryConfiguration.cs | BindCountry()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// FUNCTION TO BIND THE COUNTRY NAMES TO THE DROPDOWN
        /// </summary>

        /// <summary>
        /// FUNCTION TO BIND THE MAILOX MAP DETAILS TO THE GRID
        /// </summary>
        public DataTable BindMailBoxcateMapgrid()
        {
            DataTable dt = null;
            try
            {
                Hashtable htUserDatagrid = new Hashtable();
                htUserDatagrid.Add("@Country", (ddlCountry.SelectedValue != string.Empty && Convert.ToInt16(ddlCountry.SelectedValue) != 0) ? Convert.ToInt16(ddlCountry.SelectedValue) : 0);
                htUserDatagrid.Add("@Mailboxid", (ddlMailBox.SelectedValue != string.Empty && Convert.ToInt16(ddlMailBox.SelectedValue) != 0) ? Convert.ToInt16(ddlMailBox.SelectedValue) : 0);
                DataSet dsGridMailBoxMapBind = this._presenter.GridMailBoxcategoryBind(htUserDatagrid);
                grdCategoryConfiguration.DataSource = dsGridMailBoxMapBind;
                grdCategoryConfiguration.DataBind();
                ViewState["UserRoleMapGrid"] = grdCategoryConfiguration.DataSource;
                dt = dsGridMailBoxMapBind.Tables[0];
            }
            catch (Exception ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CategoryConfiguration.cs | BindMailBoxcateMapgrid()");
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | CategoryConfiguration.cs | BindMailBoxcateMapgrid()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            return dt;
        }

        #region Paging and Sorting
        /// <summary>
        /// To sort the Page
        /// </summary>
        protected DataView SortDataTable(DataTable dataTable, bool isPageIndexChanging)
        {
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (GridViewSortExpression != string.Empty)
                {
                    if (isPageIndexChanging)
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GridViewSortDirection);
                    }
                    else
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GetSortDirection());
                    }
                }
                return dataView;
            }
            else
            {
                return new DataView();
            }
        }

        private string GetSortDirection()
        {
            switch (GridViewSortDirection)
            {
                case "ASC":
                    GridViewSortDirection = "DESC";
                    break;
                case "DESC":
                    GridViewSortDirection = "ASC";
                    break;
            }
            return GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }

        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }


        #endregion

        /// <summary>
        /// Function to Bind the grid userwise
        /// </summary>
        public DataTable BindUserMailBoxgridUserWise()
        {
            DataTable dt = null;
            try
            {

                lblmsg.Text = "";
                lblmsg.Visible = false;
                DataSet dsUserWiseMailBoxMapGridBind = this._presenter.UserWiseMailBoxMapGridBind(UserId, ddlCountryId);
                grdCategoryConfiguration.DataSource = dsUserWiseMailBoxMapGridBind;
                grdCategoryConfiguration.Visible = true;
                grdCategoryConfiguration.DataBind();
                ViewState["UserRoleMapGrid"] = grdCategoryConfiguration.DataSource;
                dt = dsUserWiseMailBoxMapGridBind.Tables[0];
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CategoryConfiguration.cs | BindUserMailBoxgridUserWise()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserData.UserId, " | CategoryConfiguration.cs | BindUserMailBoxgridUserWise()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            return dt;
        }

        protected void sort(string strParam)
        {
            try
            {
                if (ViewState["SortDirection"] == null)
                {
                    ViewState["SortDirection"] = "asc";
                }
                else if (ViewState["SortDirection"].ToString() == "asc")
                {
                    ViewState["SortDirection"] = "desc";
                }
                else
                {
                    ViewState["SortDirection"] = "asc";
                }
                BindGrid(strParam);
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CategoryConfiguration.cs | sort()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserData.UserId, " | CategoryConfiguration.cs | sort()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        private void BindGrid(string strparameter)
        {
            try
            {
                string Sortexpression = "";
                string sortdirection = "";
                if (ViewState["Sort"] == null)
                {
                    Sortexpression = strparameter;
                }
                else
                {
                    Sortexpression = ViewState["Sort"].ToString();
                }
                if (ViewState["SortDirection"] == null)
                {
                    sortdirection = "asc";
                }
                else
                {
                    sortdirection = ViewState["SortDirection"].ToString();
                }
                DataTable dtWorkList = new DataTable();
                GetWorkList(Sortexpression, sortdirection);
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CategoryConfiguration.cs | BindGrid()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserData.UserId, " | CategoryConfiguration.cs | BindGrid()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        protected void GetWorkList(string SortExpression, string SortDirection)
        {
            try
            {
                DataSet ds = new DataSet();
                ds = (DataSet)ViewState["UserRoleMapGrid"];
                DataView dv = new DataView();
                dv = ds.Tables[0].DefaultView;
                dv.Sort = SortExpression + " " + SortDirection;
                grdCategoryConfiguration.DataSource = dv;
                grdCategoryConfiguration.DataBind();
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CategoryConfiguration.cs | GetWorkList()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserData.UserId, " | CategoryConfiguration.cs | GetWorkList()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        #endregion
        #region EVENTS
        /// <summary>
        /// EVENT TO MAP THE MAILBOX TO THE USERS BASED ON THE COUNTRY SELECTION
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnMap_Click(object sender, EventArgs e)
        {
            try
            {
                string UserID = Session["UserID"].ToString();
                string Fname = Session["fname"].ToString();
                string Rolename = Session["RoleName"].ToString();
                if(UserData.UserId==UserID && UserData.FirstName==Fname && UserData.RoleName==Rolename)
                {
                int chkactive;
                int MailBoxId = Convert.ToInt32(ddlMailBox.SelectedValue);
                LoginId = UserData.UserId;
                Hashtable hs = new Hashtable();
                hs.Add("@CountryId", ddlCountry.SelectedValue);
                hs.Add("@MailBoxId", MailBoxId);
                hs.Add("@Category", txtCategory.Text);
                if (chkActive.Checked == true)
                {
                    chkactive = 1;
                }
                else
                {
                    chkactive = 0;
                }
                hs.Add("@isActive", chkactive);
                hs.Add("@createdby", LoginId);

                if (btnMap.Text == "Configure")
                {

                    int returnvalue = _presenter.ConfigureCategorytoMailbox(hs);
                    if (returnvalue == 1)//MAPPING SUCCESS
                    {
                        Clearfields();
                        BindMailBoxcateMapgrid();
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Category configuration is successful');", true);
                    }
                    else//MAPPING FAILURE
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Category is already available to the Selected Mailbox');", true);
                        Clearfields();
                        BindMailBoxcateMapgrid();
                    }
                }
                else
                {

                    hs.Add("@raminsermailboxmapping", hddnMBoxMapID.Value);
                    int returnvalue = _presenter.UpdateConfigurecategorytoMailbox(hs);
                    if (returnvalue == 0)//UPDATE FAILS
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update Falied!');", true);
                        BindMailBoxcateMapgrid();
                        btnMap.Text = "Configure";
                    }
                    if (returnvalue == 1)//UPDATE SUCCESS
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update is successful!');", true);
                        Clearfields();
                        BindMailBoxcateMapgrid();
                        btnMap.Text = "Configure";
                    }
                    else if (returnvalue == 3)//Already Mapped
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Category is already available to the Selected Mailbox');", true);
                        btnMap.Text = "Update";
                        BindMailBoxcateMapgrid();
                        Clearfields();
                    }
                }
                }
                else
                {
                
                   Server.Transfer(@"~/Errors/BadRequest.aspx");
                
                }

            }

            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CategoryConfiguration.cs | btnMap_Click()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserData.UserId, " | CategoryConfiguration.cs | btnMap_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// EVENT TO CLEAR ALL THE FIELDS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClr_Click(object sender, EventArgs e)
        {
            Clearfields();
        }
        /// <summary>
        /// To change the page of the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdCategoryConfiguration_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdCategoryConfiguration.DataSource = SortDataTable(BindMailBoxcateMapgrid() as DataTable, true);
                grdCategoryConfiguration.PageIndex = e.NewPageIndex;
                grdCategoryConfiguration.EditIndex = -1;
                grdCategoryConfiguration.DataBind();
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CategoryConfiguration.cs | grdCategoryConfiguration_PageIndexChanging()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserData.UserId, " | CategoryConfiguration.cs | grdCategoryConfiguration_PageIndexChanging()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// To set the hover style over the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdCategoryConfiguration_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            try
            {
                //Varma - Timezone Feature On&OFF functionality 
                if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                {
                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        //    e.Row.Attributes.Add("onMouseOver", "SetNewColor(this);");
                        //    e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
                        //}

                        //Pranay 11 January 2017--for changing modified date as per user TimeZone
                        Label ModifiedDate = (Label)(e.Row.FindControl("lblModifiedDate"));
                        string value = DataBinder.Eval(e.Row.DataItem, "ModifiedDate").ToString();
                        //if (DataBinder.Eval(e.Row.DataItem, "ModifiedDate").ToString() != null)
                        if (!String.IsNullOrEmpty(value))
                        {
                            DateTime modifiedDate = Convert.ToDateTime(DataBinder.Eval(e.Row.DataItem, "ModifiedDate"));
                            String zonedDateTime = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(modifiedDate.ToString("dd/MM/yyyy HH:mm:ss"), true, UserData.TimeZone, false);
                            //Label ModifiedDate = (Label)(e.Row.FindControl("lblModifiedDate"));
                            ModifiedDate.Text = zonedDateTime;
                        }
                        else
                        {
                            //Label ModifiedDate = (Label)(e.Row.FindControl("lblModifiedDate"));
                            ModifiedDate.Text = String.Empty;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CategoryConfiguration.cs | grdCategoryConfiguration_RowDataBound()");
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | CategoryConfiguration.cs | grdCategoryConfiguration_RowDataBound()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// to sort the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdCategoryConfiguration_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                //ViewState["Sort"] = e.SortExpression;
                //sort("UserId");
                GridViewSortExpression = e.SortExpression;
                int pageIndex = grdCategoryConfiguration.PageIndex;
                grdCategoryConfiguration.DataSource = SortDataTable(BindMailBoxcateMapgrid() as DataTable, false);
                grdCategoryConfiguration.DataBind();
                grdCategoryConfiguration.PageIndex = pageIndex;
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CategoryConfiguration.cs | grdCategoryConfiguration_Sorting()");
                Response.Clear();
                //errorlog.HandleError(Ex, UserData.UserId, " | CategoryConfiguration.cs | grdCategoryConfiguration_Sorting()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        protected void grdCategoryConfiguration_Command(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.ToUpper() == "SORT")
                {
                }
                else if (e.CommandName.ToUpper() == "PAGE")
                {
                }
                else
                {
                    int index = Convert.ToInt32(e.CommandArgument);
                }
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CategoryConfiguration.cs | grdCategoryConfiguration_Command()");
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | CategoryConfiguration.cs | grdCategoryConfiguration_Command()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        /// <summary>
        /// Row command to edit the values from the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdCategoryConfiguration_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (!(UserData == null))
                {
                    if (e.CommandName == "EditMailBoxMap")
                    {
                        int RowIndex = Convert.ToInt32(e.CommandArgument);
                        hddnMBMapId = ((Label)grdCategoryConfiguration.Rows[RowIndex].FindControl("lblCatConfigMappingID")).Text.ToString().Trim();
                        string Country = ((Label)grdCategoryConfiguration.Rows[RowIndex].FindControl("lblcountry")).Text.ToString().Trim();
                        string MBoxId = ((Label)grdCategoryConfiguration.Rows[RowIndex].FindControl("lblMailBoxId")).Text.ToString().Trim();
                        string Category = ((Label)grdCategoryConfiguration.Rows[RowIndex].FindControl("lblCategory")).Text.ToString().Trim();
                        string IsActive = ((Label)grdCategoryConfiguration.Rows[RowIndex].FindControl("lblIsActive")).Text.ToString().Trim();

                        ddlCountry.SelectedIndex = ddlCountry.Items.IndexOf(ddlCountry.Items.FindByText(Country));
                        ddlCountry_SelectedIndexChanged(sender, e);
                        ddlMailBox.SelectedIndex = ddlMailBox.Items.IndexOf(ddlMailBox.Items.FindByValue(MBoxId));
                        txtCategory.Text = Category;
                        if (IsActive == "Yes")
                        {
                            chkActive.Checked = true;
                        }
                        else
                        {
                            chkActive.Checked = false;
                        }
                        hddnMBoxMapID.Value = hddnMBMapId;
                        btnMap.Text = "Update";
                        ddlCountry.Enabled = false;
                        
                    }
                    else if (e.CommandName == "DeleteMailBoxMap")
                    {
                        int RowIndex = Convert.ToInt32(e.CommandArgument);
                        hddnMBMapId = ((Label)grdCategoryConfiguration.Rows[RowIndex].FindControl("lblMailBoxMapId")).Text.ToString().Trim();
                        //UserId = ((Label)grdMailBoxMapping.Rows[RowIndex].FindControl("lblUserID")).Text.ToString().Trim();
                        int returnvalue = _presenter.DeleteMailBoxMap(hddnMBMapId, UserId);
                        if (returnvalue == 0)//Delete Failed
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Record is not deleted!');", true);
                            BindMailBoxcateMapgrid();
                        }
                        if (returnvalue == 1)//Delete Success
                        {

                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Record has been deleted successfully!');", true);
                            Clearfields();
                            BindMailBoxcateMapgrid();
                        }
                        else if (returnvalue == 2)
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Record cannot be Deleted!!! Cases Pending under the selected User!');", true);
                            BindMailBoxcateMapgrid();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CategoryConfiguration.cs | grdCategoryConfiguration_Command()");
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | CategoryConfiguration.cs | grdCategoryConfiguration_Command()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// TO BIND THE LIST OF MAILBOX TO THE MAILBOX DROPDOWN BASED ON THE COUNTRY SELECTTON
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (!(UserData == null))
                {
                    if (!ddlCountry.SelectedItem.Text.ToLower().Contains("select"))
                    {
                        int CountryId = Convert.ToInt32(ddlCountry.SelectedValue);
                        DataSet dsBindActiveMailBox = _presenter.BindActiveMailBox(CountryId, UserData.UserId, UserData.RoleId);
                        if (dsBindActiveMailBox.Tables[0].Rows.Count > 0)
                        {
                            ddlMailBox.DataSource = dsBindActiveMailBox;
                            ddlMailBox.DataValueField = "EMAILBOXID";
                            ddlMailBox.DataTextField = "EMAILBOXNAME";
                            ddlMailBox.DataBind();
                            ListItem select = new ListItem();
                            select.Text = "- Select -";
                            select.Value = "0";
                            ddlMailBox.Items.Insert(0, select);
                            ddlCountryId = ddlCountry.SelectedValue;
                            BindMailBoxcateMapgrid();
                            lblmsg.Text = "";
                        }
                        else
                        {
                            lblmsg.Visible = true;
                            ddlMailBox.Items.Clear();
                            ListItem select = new ListItem();
                            select.Text = "- Select -";
                            select.Value = "0";
                            ddlMailBox.Items.Insert(0, select);
                            lblmsg.Text = "No Category available for the selected country!!!";
                            BindMailBoxcateMapgrid();
                        }
                    }
                    else
                    {
                        ddlMailBox.Items.Clear();
                        ListItem select = new ListItem();
                        select.Text = "- Select -";
                        select.Value = "0";
                        ddlMailBox.Items.Insert(0, select);
                    }
                    ddlCountry.Focus();
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CategoryConfiguration.cs | ddlCountry_SelectedIndexChanged()");
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | CategoryConfiguration.cs | ddlCountry_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        #endregion




        protected void ddlMailBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                BindMailBoxcateMapgrid();
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CategoryConfiguration.cs | ddlMailBox_SelectedIndexChanged()");
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | CategoryConfiguration.cs | ddlMailBox_SelectedIndexChanged()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        
}
}