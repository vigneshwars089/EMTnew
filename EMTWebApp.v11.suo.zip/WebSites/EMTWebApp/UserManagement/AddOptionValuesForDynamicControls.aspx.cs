﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DigiOPS.TechFoundation.Logging;
using System.Web.UI.WebControls.WebParts;
using EMTWebApp.Constants;

namespace EMTWebApp.UserManagement.Views
{
    public partial class UserManagement_AddOptionValuesForDynamicControls : Microsoft.Practices.CompositeWeb.Web.UI.Page, IUserMailBoxMappingView
    {

        #region DECLARATIONS
        private UserMailBoxMappingPresenter _presenter;
        private string LoginId = string.Empty;
        private string UserId = string.Empty;
        private string ddlCountryId = string.Empty;
        UserSession UserData = new UserSession();
        public static string FieldMasterID = string.Empty;
        public string hddnMBMapId;
        UserErrorLog errorlog = new UserErrorLog();
        public static string FieldTypeID = string.Empty;


        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                if (Session["UserDetails"] != null)
                {
                    UserData = (UserSession)Session["UserDetails"];
                    ltError.Text = string.Empty;
                    if (!IsPostBack)
                    {
                        GetQueryString();
                        if (!string.IsNullOrEmpty(FieldMasterID))
                        {
                            BindFieldName(Int32.Parse(FieldMasterID));
                            BindDropDownValues(Int32.Parse(FieldMasterID));
                        }
                        //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                        string PKeyword = (Session["PasswordExpiration"]).ToString();
                        if (PKeyword == "yes")
                        {
                            Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                    }
                }
                }
                else
                {
                    Response.Clear();
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | Page_Load()");  
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | Page_Load()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();

            }
        }

        #region PROPERTIES
        [CreateNew]
        public UserMailBoxMappingPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion
        #region METHODS
        /// <summary>
        /// Method to redirect to login or session expired page
        /// </summary>
        private void RedirectToErrorPage(UserSession UserDetail)
        {
            try
            {
                if (UserDetail == null)
                {
                    Response.Clear();
                    Response.Redirect(@"~\Errors\Error.aspx?r=" + HelperMethods.GenerateSecureRandom());
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | RedirectToErrorPage()");  
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | RedirectToErrorPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();

            }
        }

        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserData)
        {
            try
            {
                if ((UserData.RoleId == (int)Constant.UserRole.Admin) || (UserData.RoleId == (int)Constant.UserRole.SuperAdmin))
                {
                    return true;
                }
                else
                {
                    Response.Clear();
                    Response.Redirect("~/Errors/AccessDenied.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | IsValidRoleToAccessThisPage()");  
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | IsValidRoleToAccessThisPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();

            }
            return false;
        }

        /// <summary>
        /// FUNCTION TO BIND THE ACTIVE USERS TO THE DROPDOWN
        /// </summary>

        /// <summary>
        /// FUNCTION TO CLEAR THE FIELDS
        /// </summary>
        public void Clearfields()
        {
            txtOptionText.Text = ""; chkActive.Checked = true;
        }

        private void GetQueryString()
        {
            //AddOptionValuesForDynamicControls.aspx?FieldMasterID
            //string strReq = string.Empty;
            //string[] arrMsgs, arrIndMsg;
            try
            {
//                strReq = Request.RawUrl;
//                // Here first check the string have query string or not
//                strReq = strReq.Substring(strReq.IndexOf('?') + 1);

//                if (!string.IsNullOrEmpty(strReq))
//                {
//                    // Decrypr the URL query string using web service
//                    strReq = Constants.HelperMethods.DecryptValue(strReq);
//                    //you can add loops or so to get the values out of the query string...
//                    arrMsgs = strReq.Split('&');
////                  arrIndMsg = arrMsgs[0].Split('='); //Get the FieldMasterID

//                    arrIndMsg = arrMsgs[0].Split('='); //Get the FieldMasterID
//                    FieldMasterID = arrIndMsg[1].ToString().Trim();
//                    hdnFieldMasterID.Value = FieldMasterID;
//                }

                if (Request.QueryString["FieldMasterID"] != null) 
                {
                    FieldMasterID = Request.QueryString["FieldMasterID"].ToString();
                    //hdnFieldMasterID.Value = FieldMasterID;
                    hdnFieldMasterID.Value =Server.HtmlEncode(Request.QueryString["FieldMasterID"].ToString());
                }

                if (Request.QueryString["FieldTypeID"] != null)
                {
                    FieldTypeID = Request.QueryString["FieldTypeID"].ToString();

                }
                
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | GetQueryString()");  
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | GetQueryString()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();

            }
            finally
            {
                //strReq = string.Empty; arrMsgs = null; arrIndMsg = null;
            }
        }
        private void BindFieldName(Int32 intFieldMasterID)
        {
            using (DataSet dtresult = _presenter.BindFieldName(intFieldMasterID))
            {
                try
                {
                    lblFieldName.Text = dtresult.Tables[0].Rows[0]["FieldName"].ToString();
                    string fldtypeID_text = dtresult.Tables[0].Rows[0]["FieldTypeID"].ToString();
                    if (fldtypeID_text == "3")
                    {
                        lbltext.Text = "[Only seven items can be allowed for Checkbox list]";
                    }
                    else if (fldtypeID_text == "5")
                    {
                        lbltext.Text = "[Only two items can be allowed for Radiobutton list]";
                    }
                }
                catch (Exception ex)
                {
                   // ExceptionHelper.HandleException(ex);
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | BindFieldName()");  
                    Response.Clear();
                    //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | BindFieldName()");
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
                finally
                {
                    dtresult.Dispose();
                }
            }
        }

        private void BindDropDownValues(Int32 intFieldMasterID)
        {
            using (DataTable dtVal = GetAddOptionValuesForDynamicControls(intFieldMasterID, 0))
            {
                try
                {
                    if (dtVal != null && dtVal.Rows.Count > 0)
                    {
                        gvDropDownValues.DataSource = dtVal;
                        gvDropDownValues.DataBind();
                    }
                    else
                    {
                        gvDropDownValues.DataSource = null;
                        gvDropDownValues.DataBind();
                    }
                }
                catch (Exception ex)
                {
                   // ExceptionHelper.HandleException(ex);
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | BindDropDownValues()");  
                    Response.Clear();
                    //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | BindDropDownValues()");
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
                finally
                {
                    dtVal.Dispose();
                }
            }
        }

        private DataTable GetAddOptionValuesForDynamicControls(Int32 intFieldTypeId, Int32 DynamicDropdownId)
        {
            DataTable dtVal = new DataTable();
            using (DataSet dsRes = _presenter.GetDefaultListValues(intFieldTypeId, DynamicDropdownId))
            {
                try
                {
                    if (dsRes != null && dsRes.Tables.Count > 0 && dsRes.Tables[0].Rows.Count > 0)
                    {
                        dtVal = dsRes.Tables[0];
                    }
                    return dtVal;
                }
                catch (Exception ex)
                {
                   // ExceptionHelper.HandleException(ex);
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | GetAddOptionValuesForDynamicControls()");  
                    Response.Clear();
                    //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | GetAddOptionValuesForDynamicControls()");
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
                finally
                {
                    dtVal.Dispose();
                }
            }
            return dtVal;
        }

        #endregion

        #region Call to get add options Params method


        protected void SaveItems() 
        {
            try
            {
                string strOptionText = string.Empty;
                int chkactive;
                if (!string.IsNullOrEmpty(txtOptionText.Text))
                {
                    LoginId = UserData.UserId;
                    Hashtable hs = new Hashtable();
                    hs.Add("@OptionText", txtOptionText.Text);

                    if (chkActive.Checked == true)
                    {
                        chkactive = 1;
                    }
                    else
                    {
                        chkactive = 0;
                    }
                    hs.Add("@Active", chkactive);
                    hs.Add("@CreatedBy", LoginId);
                    DataSet OptionValueforFieldmasterid = _presenter.GetOptionvalue(Convert.ToInt32(hdnFieldMasterID.Value));
                    int Optionvalue;
                    Int32 result = Convert.ToInt32(OptionValueforFieldmasterid.Tables[0].Rows[0]["result"]);
                    if (result == 0)
                    {
                        Optionvalue = 1;
                    }
                    else
                    {
                        Optionvalue = result + 1;
                    }


                    hs.Add("@OptionValue", Optionvalue);
                    hs.Add("@fieldmasterid", Convert.ToInt32(hdnFieldMasterID.Value));
                    if (btnInsert.Text == "Configure")
                    {
                        int returnvalue = _presenter.ConfigureOptiontoField(hs);
                        if (returnvalue == 1)//MAPPING SUCCESS
                        {

                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Option is added successfully');", true);
                        }
                        else if (returnvalue == 2)//MAPPING FAILURE
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('List item  already exists to the Field name');", true);
                        }
                        Clearfields();
                        BindDropDownValues(Int32.Parse(FieldMasterID));
                    }
                    else // update section
                    {
                        hs.Add("@hdnddlid", Convert.ToInt32(hdnddlid.Value));
                        int returnvalue = _presenter.UpdateOptionstoFields(hs);
                        if (returnvalue == 0)//UPDATE FAILS
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update Falied!');", true);
                            BindDropDownValues(Int32.Parse(FieldMasterID));
                            btnInsert.Text = "Configure";
                        }
                        if (returnvalue == 1)//UPDATE SUCCESS
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update is successful!');", true);
                            Clearfields();
                            BindDropDownValues(Int32.Parse(FieldMasterID));
                            btnInsert.Text = "Configure";
                        }
                        else if (returnvalue == 2)//Already Mapped
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('List item is already available with the Same Field name! Please use different Field name');", true);
                            BindDropDownValues(Int32.Parse(FieldMasterID));
                            btnInsert.Text = "Configure";
                            Clearfields();
                        }
                    }

                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Enter Field name');", true);
                }
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | SaveItems()");  
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | SaveItems()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }


        protected void btnInsert_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
            try
            {
                // Checking items Count For Checkbox and Radio Button

                if ((FieldTypeID == "3" || FieldTypeID == "5") && btnInsert.Text == "Configure")
                {
                    if (gvDropDownValues.Rows.Count < Constant.ChkItmCnt && Request.QueryString["FieldTypeID"].ToString() == "3")
                    {
                        SaveItems();
                    }
                    else if (gvDropDownValues.Rows.Count < Constant.RadItmCnt && Request.QueryString["FieldTypeID"].ToString() == "5")
                    {
                        SaveItems();
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('List items exceeded the max limit, Please update the existing Items.');", true);
                        Clearfields();
                    }
                }
                else
                {
                    SaveItems();
                }
            }


            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | btnInsert_Click()");
                    Response.Clear();
                    //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | btnInsert_Click()");
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                fnClearValue();
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | btnReset_Click()");
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | btnReset_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }


        private void fnClearValue()
        {
            try
            {
                txtOptionText.Text = string.Empty;
                btnInsert.Text = "Configure";
                chkActive.Checked = true;
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | fnClearValue()");
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | fnClearValue()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        #endregion

        #region Grid Row Command , Paging , Sorting Code

        protected void gvDropDownValues_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            try
            {
                if (!(UserData == null))
                {
                    if (e.CommandName == "EditField")
                    {
                        int RowIndex = Convert.ToInt32(e.CommandArgument);
                      string  lblDynamicDropdownId = ((Label)gvDropDownValues.Rows[RowIndex].FindControl("lblDynamicDropdownId")).Text.ToString().Trim();
                      string lblFieldType = ((Label)gvDropDownValues.Rows[RowIndex].FindControl("lblFieldType")).Text.ToString().Trim();
                      txtOptionText.Text = lblFieldType;
                      string IsActive = ((Label)gvDropDownValues.Rows[RowIndex].FindControl("lblActive")).Text.ToString().Trim();

                        if (IsActive == "Yes")
                        {
                            chkActive.Checked = true;
                        }
                        else
                        {
                            chkActive.Checked = false;
                        }
                        hdnddlid.Value = lblDynamicDropdownId;
                        btnInsert.Text = "Update";
                    }
                }
            }
            catch (Exception ex )
            {

               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | gvDropDownValues_RowCommand()");
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | gvDropDownValues_RowCommand()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }

        }
        protected void gvDropDownValues_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                gvDropDownValues.DataSource = SortDataTable(GetAddOptionValuesForDynamicControls(Int32.Parse(FieldMasterID), 0) as DataTable, true);
                gvDropDownValues.PageIndex = e.NewPageIndex;
                gvDropDownValues.DataBind();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | gvDropDownValues_PageIndexChanging()");
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | gvDropDownValues_PageIndexChanging()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        protected void gvDropDownValues_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                GridViewSortExpression = e.SortExpression;
                int pageIndex = gvDropDownValues.PageIndex;
                gvDropDownValues.DataSource = SortDataTable(GetAddOptionValuesForDynamicControls(Int32.Parse(FieldMasterID), 0) as DataTable, false);
                gvDropDownValues.DataBind();
                gvDropDownValues.PageIndex = pageIndex;
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | gvDropDownValues_Sorting()");
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | gvDropDownValues_Sorting()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        protected DataView SortDataTable(DataTable dataTable, bool isPageIndexChanging)
        {
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (GridViewSortExpression != string.Empty)
                {
                    if (isPageIndexChanging)
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GridViewSortDirection);
                    }
                    else
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GetSortDirection());
                    }
                }
                return dataView;
            }
            else
            {
                return new DataView();
            }
        }

        private string GetSortDirection()
        {
            switch (GridViewSortDirection)
            {
                case "ASC":
                    GridViewSortDirection = "DESC";
                    break;
                case "DESC":
                    GridViewSortDirection = "ASC";
                    break;
            }
            return GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }

        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }



        protected void gvDropDownValues_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            Label lblFieldType = new Label();
            ImageButton imgShowStatus = new ImageButton();
            ImageButton imgEditStatus = new ImageButton();
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    lblFieldType = (Label)e.Row.FindControl("lblActive");

                    if (lblFieldType != null && lblFieldType.Text.Trim().ToLower() == "false")
                    {
                        // Delte Button
                       

                        // Edit Button
                        imgEditStatus = (ImageButton)e.Row.FindControl("lkbEdit");
                        imgEditStatus.Visible = false;

                    }
                    else
                    {
                        // Delte Button
                      
                        //Edit Button
                        imgEditStatus = (ImageButton)e.Row.FindControl("lkbEdit");
                        imgEditStatus.ImageUrl = "~/Images/Edit.png";
                    }

                    //Varma - Timezone Feature On&OFF functionality 
                    if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                    {
                        //Pranay 24 January 2017--for changing modified date as per user TimeZone
                        Label ModifiedDate = (Label)(e.Row.FindControl("lblModifiedDate"));
                        string value = DataBinder.Eval(e.Row.DataItem, "ModifiedDate").ToString();
                        //if (DataBinder.Eval(e.Row.DataItem, "ModifiedDate").ToString() != null)
                        if (!String.IsNullOrEmpty(value))
                        {
                            DateTime modifiedDate = Convert.ToDateTime(DataBinder.Eval(e.Row.DataItem, "ModifiedDate"));
                            String zonedDateTime = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(modifiedDate.ToString("dd/MM/yyyy HH:mm:ss"), true, UserData.TimeZone, false);
                            //Label ModifiedDate = (Label)(e.Row.FindControl("lblModifiedDate"));
                            ModifiedDate.Text = zonedDateTime;
                        }
                        else
                        {
                            //Label ModifiedDate = (Label)(e.Row.FindControl("lblModifiedDate"));
                            ModifiedDate.Text = String.Empty;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | gvDropDownValues_RowDataBound()");
                Response.Clear();
                //errorlog.HandleError(ex, UserData.UserId, " | AddOptionValuesForDynamicControls.cs | gvDropDownValues_RowDataBound()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            finally
            {
                lblFieldType.Dispose();
                imgShowStatus.Dispose();
                imgEditStatus.Dispose();
            }

        }

        #endregion
    }


}