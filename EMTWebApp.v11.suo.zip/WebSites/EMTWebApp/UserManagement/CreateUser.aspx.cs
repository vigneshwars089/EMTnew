﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using EMTWebApp.Constants;
using System.Configuration;
using DigiOPS.TechFoundation.Security;
using System.Text.RegularExpressions;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.ExceptionHandling;
using System.Security;
using System.Runtime.InteropServices;

namespace EMTWebApp.UserManagement.Views
{
    public partial class CreateUser : Microsoft.Practices.CompositeWeb.Web.UI.Page, ICreateUserView
    {
        #region DECLARATION
        private CreateUserPresenter _presenter;
        private string LoginId = string.Empty;
        private int UserRoleId;
        UserErrorLog errorlog = new UserErrorLog();
        UserSession UserData = new UserSession();
        string CheckWhichLoginType = ConfigurationManager.AppSettings["ADLogin"].ToString();
        SecurityFactory securityFactory = new SecurityFactory();
        //UserSession Constants;
        //Product License key
        string ToolPurchased = ConfigurationManager.AppSettings["ToolPurchased"].ToString();
        string cipher = ConfigurationManager.AppSettings["ENCRYPT/DECRYPT"].ToString();
        string DateOfPurchase = ConfigurationManager.AppSettings["DateOfPurchase"].ToString();
        string Version = ConfigurationManager.AppSettings["Version"].ToString();
        string InstanceID = ConfigurationManager.AppSettings["InstanceID"].ToString();
        int MaxNoOfUser = Convert.ToInt16(ConfigurationManager.AppSettings["MaxNoOfUser"].ToString());
        string ClientName = ConfigurationManager.AppSettings["ClientName"].ToString();
        int usercount;
        int GetLicenseKey;
        string Errormessage;
        string LicenseStatus;
        string LicenseKey;
        string ErrorMessage;
        #endregion

        /// <summary>
        /// To INITIALIZE THE FIELDS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                txtUserID.Focus();
                Session["CurrentPage"] = "User Management";

                UserData = (UserSession)Session["UserDetails"];
                LoginId = UserData.UserId;
                UserRoleId = Convert.ToInt32(UserData.RoleId);
                RedirectToErrorPage(UserData);
                IsValidRoleToAccessThisPage(UserData);
                if (!this.IsPostBack)
                {
                    Page.Form.DefaultButton = btnSubmit.UniqueID;
                    BindUserGrid();
                    BindTimeZone();
                    
                    grdCreateUser.Visible = true;
                    txtPKeyword.Attributes.Add("onKeyPress", "return ValidateSpaces();");
                    this._presenter.OnViewInitialized();
                    BindSkillSet();
                    //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                    string PKeyword = (Session["PasswordExpiration"]).ToString();
                    if (PKeyword == "yes")
                    {
                        Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                    }
                }
                if (CheckWhichLoginType == "Yes") // AD Login Type
                {
                    txtPKeyword.Visible = false;
                    txtCnfrmPKeyword.Visible = false;
                    lblCnfrmPKeyword.Visible = false;
                    lblPKeyword.Visible = false;
                }
                else if (CheckWhichLoginType == "No") // Normal Login Type
                {
                    RFVtxtPKeyword.Enabled = true;
                    RFVtxtCnfrmPKeyword.Enabled = true;

                }
                ValidateLicensekey();
                if (LicenseStatus == "False")
                {
                    btnSubmit.Attributes.Add("onClick", "return false");
                    btnClear.Attributes.Add("onClick", "return false");
                    txtUserID.Enabled = false;
                    txtFirstName.Enabled = false;
                    txtLastName.Enabled = false;
                    txtemailid.Enabled = false;
                    txtPKeyword.Enabled = false;
                    txtCnfrmPKeyword.Enabled = false;
                    //Varma - Timezone Feature On&OFF functionality 
                    if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                    {
                        ddlTimeZone.Enabled = false;
                    }
                    chkActive.Enabled = false;
                    if (ErrorMessage.CompareTo("Expired Product License Key") == 0)
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Product License Key Expired , Please contact EMT team for Reneual of License key...');", true);
                    }
                    else
                    {
                        if (Errormessage.CompareTo("User Count exceeds the maximum value") == 0)
                        {

                            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('User Count exceeds the maximum value. Please Contact EMT Team for Higher version of User Count');", true);
                        }
                        else
                        {
                            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + Errormessage + "');", true);
                        }

                    }
                    grdCreateUser.Enabled = false;

                }
                if (ErrorMessage.CompareTo("Product License Key will expire in a week") == 0)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert(' Product License Key will expire in a week Please contact EMT team for Reneual of License key... ');", true);
                }

                this._presenter.OnViewLoaded();

            }
            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CreateUser.cs |  Page_Load()");
                //errorlog.HandleError(ex, UserData.UserId, " | CreateUser.cs |  Page_Load()");
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CreateUser.cs | Page_Load()");
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.cs | Page_Load()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        #region PROPERTIES
        [CreateNew]
        public CreateUserPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion

        #region METHODS
        /// <summary>
        /// Method to redirect to login or session expired page
        /// </summary>
        private void RedirectToErrorPage(UserSession UserDetail)
        {
            try
            {
                if (UserDetail == null)
                {
                    Response.Redirect(@"~\Errors\Error.aspx", false);
                }
            }
            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CreateUser.cs | RedirectToErrorPage()");
                //errorlog.HandleError(ex, UserData.UserId, " | CreateUser.cs | RedirectToErrorPage()");
            }
            catch (Exception Ex)
            {
                // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CreateUser.cs | RedirectToErrorPage()");
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.cs | RedirectToErrorPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserData)
        {
            try
            {
                if ((UserData.RoleId == (int)Constant.UserRole.TeamLead) || (UserData.RoleId == (int)Constant.UserRole.Admin) || (UserData.RoleId == (int)Constant.UserRole.SuperAdmin))
                {
                    return true;
                }
                else
                {
                    securityFactory.GetUserSecurityHandler("AD").IsLogEnabled(UserData + "CreateUser.aspx.cs|IsValidRoleToAccessThisPage", true);
                    Response.Redirect(@"~\Errors\AccessDenied.aspx", false);
                }
            }
            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CreateUser.cs | IsValidRoleToAccessThisPage()");
                //errorlog.HandleError(ex, UserData.UserId, " | CreateUser.cs | IsValidRoleToAccessThisPage()");
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CreateUser.cs | IsValidRoleToAccessThisPage()");
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.cs | IsValidRoleToAccessThisPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
            return false;
        }

        /// <summary>
        /// TO BIND THE EXISTING USER DETAILS TO THE GRID
        /// </summary>
        public DataTable BindUserGrid()
        {
            DataTable dt = null;
            try
            {
                DataSet dsCreateUser = this._presenter.GridBind();
                ViewState["UserGrid"] = dsCreateUser.Tables[0];
                grdCreateUser.DataSource = dsCreateUser;
                grdCreateUser.DataBind();
                dt = dsCreateUser.Tables[0];
            }
            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CreateUser.cs | BindUserGrid()");
                //errorlog.HandleError(ex, UserData.UserId, " | CreateUser.cs | BindUserGrid()");
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CreateUser.cs | BindUserGrid()");
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.cs | BindUserGrid()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
            return dt;
        }

        //Pranay 3rd January 2017 
        // Get all timezone from local system and bind it in dropdownlist
        private void BindTimeZone()
        {
            try
            {
                //Varma - Timezone Feature On&OFF functionality 
                if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                {
                    foreach (TimeZoneInfo z in TimeZoneInfo.GetSystemTimeZones())
                    {
                        //ddlTimeZone.Items.Add(new ListItem(z.DisplayName, z.Id));
                        ddlTimeZone.Items.Add(new ListItem(z.StandardName, z.Id));
                    }
                    ListItem select = new ListItem();
                    select.Text = "--Select--";
                    select.Value = "0";
                    ddlTimeZone.Items.Insert(0, select);
                }
                else
                {
                    //trowTimezone.Visible = false;
                    ddlTimeZone.Visible = false;
                    RFddlTimeZone.Enabled = false;
                }
            }
            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CreateUser.cs | BindTimeZone()");
                //errorlog.HandleError(ex, UserData.UserId, " | CreateUser.cs | BindTimeZone()");
            }
            catch (Exception Ex)
            {
                ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserDetails.UserId + " | MailBoxCreation.cs | BindTimeZone()");
                //Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }


        private void BindSkillSet()
        {
            try
            {
                DataSet dsSkillSet = _presenter.GetSkillSet();
                foreach (DataRow dr in dsSkillSet.Tables[0].Rows)
                {

                    listBoxSkillSet.Items.Add(new ListItem(dr["SkillDescription"].ToString(), dr["SkillId"].ToString()));
                }
                ListItem select = new ListItem();
                select.Text = "--Select--";
                select.Value = "0";
                listBoxSkillSet.Items.Insert(0, select);

            }
            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CreateUser.cs | BindTimeZone()");
                //errorlog.HandleError(ex, UserData.UserId, " | CreateUser.cs | BindTimeZone()");
            }
            catch (Exception Ex)
            {
                ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserDetails.UserId + " | MailBoxCreation.cs | BindTimeZone()");
                //Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        /// <summary>
        /// to sort the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdCreateUser_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                //ViewState["Sort"] = e.SortExpression;
                //sort("UserId");
                try
                {
                    GridViewSortExpression = e.SortExpression;
                    int pageIndex = grdCreateUser.PageIndex;
                    grdCreateUser.DataSource = SortDataTable(BindUserGrid() as DataTable, false);
                    grdCreateUser.DataBind();
                    grdCreateUser.PageIndex = pageIndex;
                }
                catch (Exception ex)
                {
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | Ageing.aspx.cs | GVBaseData_Sorting()");
                    //errorlog.HandleError(ex, UserData.UserId, " | Ageing.aspx.cs | GVBaseData_Sorting()");
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                }
            }
            catch (Exception Ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_Sorting()");
                // ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_Sorting()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

        }

        #region Paging and Sorting
        /// <summary>
        /// To sort the Page
        /// </summary>
        protected DataView SortDataTable(DataTable dataTable, bool isPageIndexChanging)
        {
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (GridViewSortExpression != string.Empty)
                {
                    if (isPageIndexChanging)
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GridViewSortDirection);
                    }
                    else
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GetSortDirection());
                    }
                }
                return dataView;
            }
            else
            {
                return new DataView();
            }
        }

        private string GetSortDirection()
        {
            switch (GridViewSortDirection)
            {
                case "ASC":
                    GridViewSortDirection = "DESC";
                    break;
                case "DESC":
                    GridViewSortDirection = "ASC";
                    break;
            }
            return GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }

        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }


        #endregion
        /// <summary>
        /// METHOD TO CLEAR THE FIELDS
        /// </summary>
        public void Clearfields()
        {
            // string CheckLoginType = Session["CheckLoginType"].ToString();
            if (CheckWhichLoginType == "Yes")//AD Login Type
            {
                txtUserID.Text = "";
                txtUserID.Focus();
                txtFirstName.Text = "";
                txtLastName.Text = "";
                txtemailid.Text = "";
                txtPKeyword.Visible = false;
                txtCnfrmPKeyword.Visible = false;
                lblCnfrmPKeyword.Visible = false;
                lblPKeyword.Visible = false;
                btnSubmit.Text = "Submit";
                chkActive.Checked = true;
                foreach(ListItem li in listBoxSkillSet.Items)
                {
                    li.Selected = false;
                }
            }
            else if (CheckWhichLoginType == "No")//Forms  Login Type
            {
                txtUserID.Text = "";
                txtUserID.Focus();
                txtFirstName.Text = "";
                txtLastName.Text = "";
                txtemailid.Text = "";
                txtPKeyword.Text = "";
                txtUserID.Enabled = true;
                txtPKeyword.Visible = true;
                txtCnfrmPKeyword.Visible = true;
                lblCnfrmPKeyword.Visible = true;
                lblPKeyword.Visible = true;
                btnSubmit.Text = "Submit";
                chkActive.Checked = true;
                foreach (ListItem li in listBoxSkillSet.Items)
                {
                    li.Selected = false;
                }
            }

            //Varma - Timezone Feature On&OFF functionality 
            if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
            {
                ddlTimeZone.SelectedIndex = 0;
            }
        }
        #endregion

        public bool PasswordComplexityValidation(string password)
        {
            Regex regex = new Regex(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,50}$");
            //Password must be 8-15 characters including 1 uppercase letter, 1 special character, alphanumeric characters
            Match match = regex.Match(password);
            return match.Success;

        }
        #region EVENTS
        /// <summary>
        /// CLICK EVENT TO ADD THE USER DETAILS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            SecureString sec_strPassword = new SecureString();
            SecureString sec_strPassword1 = new SecureString();
            try
            {
                string UserID = txtUserID.Text.Trim();
                string FirstName = txtFirstName.Text.Trim();
                string LastName = txtLastName.Text.Trim();
                string EmailID = txtemailid.Text.Trim();
                string SkillSet = "";
                string SkillDescription = "";
                string TimeZone = "", OffSet = "";
                TimeZoneInfo cst;
                TimeSpan offset;
                //Varma - Timezone Feature On&OFF functionality 
                if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                {
                    //Pranay 3rd January 2017 --adding string for retrieving value of TimeZone selected
                    TimeZone = ddlTimeZone.SelectedItem.ToString();
                    cst = TimeZoneInfo.FindSystemTimeZoneById(TimeZone);
                    offset = cst.GetUtcOffset(DateTime.Now);
                    //if((offset < TimeSpan.Zero) ? "-" : "")
                    OffSet = ((offset < TimeSpan.Zero) ? "-" : "+") + offset.ToString(@"hh\:mm");
                    //string EncryptPassword = Constants.HelperMethods.EncryptString(txtpwd.Text.Trim());
                    // string EncryptConfirmPassword = Constants.HelperMethods.EncryptString(txtCnfrmpwd.Text.Trim());
                }
                CreateUser miscObj = new CreateUser();


                int Active;
                if (chkActive.Checked == true)
                {
                    Active = 1;
                }
                else
                {
                    Active = 0;
                }
              //  SkillSet = ddlSkillSet.SelectedValue;
                foreach (ListItem listItem in listBoxSkillSet.Items)
                {
                    if (listItem.Selected == true)
                    {
                        SkillSet += listItem.Value + ';';
                        SkillDescription += listItem.Text + ';';
                    }
                }

                #region submit
                if (btnSubmit.Text == "Submit")//Add
                {


                    if (CheckWhichLoginType == "Yes")//AD Login Type
                    {
                        //Varma - Timezone Feature On&OFF functionality 
                        int returnvalue = 0;
                        if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                        {
                            returnvalue = _presenter.AddUser(UserID, FirstName, LastName, EmailID, "", Active, LoginId, TimeZone, OffSet,SkillSet,SkillDescription, true);
                        }
                        else
                        {
                            returnvalue = _presenter.AddUser(UserID, FirstName, LastName, EmailID, "", Active, LoginId, TimeZone, OffSet,SkillSet,SkillDescription, false);
                        }
                        if (returnvalue == 0)//If the user already exists
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('UserID already Exists!');", true);
                            Clearfields();
                            BindUserGrid();
                        }
                        if (returnvalue == 1)//user added successful
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('User added successfully!');", true);
                            txtUserID.Focus();
                            RFVtxtPKeyword.Enabled = false;
                            RFVtxtCnfrmPKeyword.Enabled = false;
                            Clearfields();
                            BindUserGrid();
                        }
                    }//AD
                    else if (CheckWhichLoginType == "No")// Forms Login Type
                    {
                        Regex regex = new Regex("\"|'");
                        Match match = regex.Match(txtPKeyword.Text.Trim());
                        Match match1 = regex.Match(txtCnfrmPKeyword.Text.Trim());
                        if (match.Success || match1.Success)
                        {
                            Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                        }
                        else
                        {
                            bool Passwordcheck = PasswordComplexityValidation(txtPKeyword.Text.Trim());
                            if (Passwordcheck)
                            {
                                if (cipher == "ON")
                                {
                                    sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.EncryptString(txtPKeyword.Text.Trim()));
                                    sec_strPassword1 = miscObj.convertToSecureString(Constants.HelperMethods.EncryptString(txtCnfrmPKeyword.Text.Trim()));
                                }
                                else
                                {
                                    sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.EncryptValue(txtPKeyword.Text.Trim()));
                                    sec_strPassword1 = miscObj.convertToSecureString(Constants.HelperMethods.EncryptValue(txtCnfrmPKeyword.Text.Trim()));
                                }

                                if (miscObj.convertToUNSecureString(sec_strPassword) == miscObj.convertToUNSecureString(sec_strPassword1))
                                {
                                    //Varma - Timezone Feature On&OFF functionality 
                                    int returnvalue = 0;
                                    if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                                    {
                                        returnvalue = _presenter.AddUser(UserID, FirstName, LastName, EmailID, miscObj.convertToUNSecureString(sec_strPassword1), Active, LoginId, TimeZone, OffSet,SkillSet,SkillDescription, true);
                                    }
                                    else
                                    {
                                        returnvalue = _presenter.AddUser(UserID, FirstName, LastName, EmailID, miscObj.convertToUNSecureString(sec_strPassword1), Active, LoginId, TimeZone, OffSet,SkillSet,SkillDescription, false);
                                    }
                                    if (returnvalue == 0)//If the user already exists
                                    {
                                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('UserID already Exists!');", true);
                                        Clearfields();
                                        BindUserGrid();
                                    }
                                    if (returnvalue == 1)//user added successful
                                    {
                                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('User added successfully!');", true);
                                        Clearfields();
                                        BindUserGrid();
                                    }
                                }
                                else//If Provided Passwords do not match
                                {
                                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Passwords Mismatch!');", true);
                                    txtPKeyword.Text = "";
                                    txtCnfrmPKeyword.Text = "";
                                    txtPKeyword.Focus();
                                    BindUserGrid();
                                }
                            }
                            else
                            {
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Password must be 8-15 characters including 1 uppercase letter, 1 special character, alphanumeric characters');", true);

                            }
                        }//forms                      


                    }//submit
                }
                #endregion
                #region update
                else//Update
                {
                    if (cipher == "ON")
                    {
                        sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.EncryptString(txtPKeyword.Text.Trim()));
                        sec_strPassword1 = miscObj.convertToSecureString(Constants.HelperMethods.EncryptString(txtCnfrmPKeyword.Text.Trim()));
                    }
                    else
                    {
                        sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.EncryptValue(txtPKeyword.Text.Trim()));
                        sec_strPassword1 = miscObj.convertToSecureString(Constants.HelperMethods.EncryptValue(txtCnfrmPKeyword.Text.Trim()));
                    }
                    //Varma - Timezone Feature On&OFF functionality 
                    int returnvalue = 0;
                    if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                    {
                        returnvalue = _presenter.UpdateUser(UserID, FirstName, LastName, EmailID, miscObj.convertToUNSecureString(sec_strPassword1), Active, LoginId, TimeZone, OffSet,SkillSet,SkillDescription, true);
                    }
                    else
                    {
                        returnvalue = _presenter.UpdateUser(UserID, FirstName, LastName, EmailID, miscObj.convertToUNSecureString(sec_strPassword1), Active, LoginId, TimeZone, OffSet,SkillSet,SkillDescription, false);
                    }
                    if (returnvalue == 0)//Update Fails
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('User Details are not updated!');", true);
                        Clearfields();
                        BindUserGrid();
                        btnSubmit.Text = "Submit";
                    }
                    if (returnvalue == 1)//Update Success
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('User Updated successfully!');", true);
                        txtUserID.Focus();
                        RFVtxtPKeyword.Enabled = false;
                        RFVtxtCnfrmPKeyword.Enabled = false;
                        Clearfields();
                        BindUserGrid();
                        btnSubmit.Text = "Submit";
                    }
                }
                #endregion

            }


            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //errorlog.HandleError(ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }
        /// <summary>
        /// CLICK EVENT TO ADD THE USER DETAILS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void ValidateLicensekey()
        {

            LicenseInfo LicenseInfo = new LicenseInfo();
            LicenseInfo.ToolPurchased = ToolPurchased;
            LicenseInfo.DateOfPurchase = DateOfPurchase;
            LicenseInfo.Version = Version;
            LicenseInfo.InstanceID = InstanceID;
            DataSet ds = (_presenter.GetUsercount());
            if (ds.Tables[0].Rows.Count > 0)
            {
                usercount = Convert.ToInt16(ds.Tables[0].Rows[0]["TotalNoOfUsers"]);
            }
            LicenseInfo.MaxNoOfUser = MaxNoOfUser;
            LicenseInfo.UserCount = usercount;
            ProductLicenseKey ProductLicenseKey = new ProductLicenseKey();
            LicenseInfo objlicense = new LicenseInfo();
            objlicense = ProductLicenseKey.GenerateProductKey(LicenseInfo);
            if (string.IsNullOrEmpty(objlicense.EncryptedProductKey) || objlicense.EncryptedProductKey == "null")
            {
                Errormessage = objlicense.ErrorMessage.ToString();
            }
            LicenseKey = objlicense.EncryptedProductKey;
            objlicense = ProductLicenseKey.ValidateProductLicenseKey(LicenseKey);
            //objlicense = ProductLicenseKey.ValidateProductLicenseKey(GetLicenseKey);
            // Errormessage = objlicense.ErrorMessage.ToString();
            Errormessage = objlicense.ErrorMessage.ToString();
            string str = null;
            string[] productKeyInformation = null;
            productKeyInformation = Errormessage.Split('!');
            ErrorMessage = productKeyInformation[0];
            //string n2 = productKeyInformation[1];
            // string n3 = productKeyInformation[2];
            LicenseStatus = objlicense.ResultStatus.ToString();


        }

        /// <summary>
        /// CLICK EVENT TO CLEAR THE FIELDS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        protected void btnClear_Click(object sender, EventArgs e)
        {
            Clearfields();
        }



        /// <summary>
        /// GRID EVENT TO EDIT THE GRID DETAILS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdCreateUser_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "EditUsers")
                {
                    int RowIndex = Convert.ToInt32(e.CommandArgument);
                    string UserId = ((Label)grdCreateUser.Rows[RowIndex].FindControl("lblUserID")).Text.ToString().Trim();
                    string FirstName = ((Label)grdCreateUser.Rows[RowIndex].FindControl("lblFirstName")).Text.ToString().Trim();
                    string LastName = ((Label)grdCreateUser.Rows[RowIndex].FindControl("lblLastName")).Text.ToString().Trim();
                    string EmailId = ((Label)grdCreateUser.Rows[RowIndex].FindControl("lblEMAIL")).Text.ToString().Trim();
                    string IsActive = ((Label)grdCreateUser.Rows[RowIndex].FindControl("lblIsActive")).Text.ToString().Trim();
                    string SkillSet = ((Label)grdCreateUser.Rows[RowIndex].FindControl("labelSkillId")).Text.ToString().Trim();
                    String[] arrSkillSet = null;
                    txtUserID.Text = UserId;
                    txtUserID.Enabled = false;
                    txtFirstName.Text = FirstName;
                    txtLastName.Text = LastName;
                    txtemailid.Text = EmailId;
                    foreach (ListItem li in listBoxSkillSet.Items)
                    {                        
                            li.Selected = false;
                    }
                    if (!String.IsNullOrEmpty(SkillSet))
                        arrSkillSet = SkillSet.TrimEnd(';').Split(';');
                    if (arrSkillSet != null)
                        foreach (String s in arrSkillSet)
                        {
                            foreach (ListItem li in listBoxSkillSet.Items)
                            {
                                if (li.Value == s)
                                    li.Selected = true;
                            }
                        }
                    //Varma - Timezone Feature On&OFF functionality 
                    if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                    {
                        //Pranay 16 January 2017  getting timeZone mapped to user
                        string TimeZone = ((Label)grdCreateUser.Rows[RowIndex].FindControl("labelTimeZone")).Text.ToString().Trim();

                        if (!string.IsNullOrEmpty(TimeZone))
                        {
                            ddlTimeZone.SelectedValue = TimeZone;
                        }
                        else
                        {
                            ddlTimeZone.SelectedIndex = 0;
                        }
                    }

                    if (IsActive == "Yes")
                    {
                        chkActive.Checked = true;
                    }
                    else
                    {
                        chkActive.Checked = false;
                    }
                    grdCreateUser.EditIndex = -1;
                    btnSubmit.Text = "Update";
                    btnSubmit.ValidationGroup = "Update";
                    lblPKeyword.Visible = false;
                    lblCnfrmPKeyword.Visible = false;
                    txtPKeyword.Visible = false;
                    txtCnfrmPKeyword.Visible = false;
                    btnSubmit.ValidationGroup = "Submit";
                }
            }
            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_RowCommand()");
                //errorlog.HandleError(ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_RowCommand()");
            }
            catch (Exception Ex)
            {
                // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_RowCommand()");
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_RowCommand()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// GRID EVENT TO CHANGE THE PAGE INDEX 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdCreateUser_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdCreateUser.DataSource = SortDataTable(BindUserGrid() as DataTable, true);
                grdCreateUser.PageIndex = e.NewPageIndex;
                grdCreateUser.EditIndex = -1;
                grdCreateUser.DataBind();
            }
            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_PageIndexChanging()");
                //errorlog.HandleError(ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_PageIndexChanging()");
            }
            catch (Exception ex)
            {
                // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_PageIndexChanging()");
                //errorlog.HandleError(ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_PageIndexChanging()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        protected void grdCreateUser_onRowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                //Varma - Timezone Feature On&OFF functionality 
                if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                {
                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        Label ModifiedDate = (Label)(e.Row.FindControl("lblModifiedDate"));
                        string value = DataBinder.Eval(e.Row.DataItem, "ModifiedDate").ToString();

                        if (!String.IsNullOrEmpty(value))
                        {
                            DateTime modifiedDate = Convert.ToDateTime(DataBinder.Eval(e.Row.DataItem, "ModifiedDate"));
                            string zonedDateTime = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(modifiedDate.ToString("dd/MM/yyyy HH:mm:ss"), true, UserData.TimeZone, false);
                            //Label ModifiedDate = (Label)(e.Row.FindControl("lblModifiedDate"));
                            ModifiedDate.Text = zonedDateTime;
                        }

                        else
                        {
                            ModifiedDate.Text = String.Empty;
                        }

                        DataTable dt = (DataTable)ViewState["UserGrid"];

                        if (dt != null)
                        {
                            if (dt.Columns["TimeZone"] != null)
                            {
                                grdCreateUser.Columns[4].Visible = true;
                                Label labelTimeZone = (Label)e.Row.FindControl("labelTimeZone");

                                if (labelTimeZone != null)
                                {
                                    labelTimeZone.Text = dt.Rows[e.Row.RowIndex]["TimeZone"].ToString();
                                }
                            }
                        }
                    }
                }
                else
                {
                    grdCreateUser.Columns[4].Visible = false;
                }
            }
            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_onRowDataBound()");
                //errorlog.HandleError(ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_onRowDataBound()");
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_onRowDataBound()");
                //errorlog.HandleError(ex, UserData.UserId, " | CreateUser.aspx.cs | grdCreateUser_onRowDataBound()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }

        }
        #endregion


        public SecureString convertToSecureString(string strPassword)
        {
            var secureStr = new SecureString();
            if (strPassword.Length > 0)
            {
                foreach (var c in strPassword.ToCharArray()) secureStr.AppendChar(c);
            }
            return secureStr;
        }

        public string convertToUNSecureString(SecureString secstrPassword)
        {
            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(secstrPassword);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

    }
}

