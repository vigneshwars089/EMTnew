﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using DigiOPS.TechFoundation.Logging;
using System.Web.UI.WebControls.WebParts;
using EMTWebApp.Constants;
using System.Text.RegularExpressions;

namespace EMTWebApp.UserManagement.Views
{
    public partial class UserMapping : Microsoft.Practices.CompositeWeb.Web.UI.Page, IUserMappingView
    {
        #region DECLARATIONS
        private UserMappingPresenter _presenter;
        private string LoginId = string.Empty;
        private string UserId = string.Empty;
        private int LoggedInUserRoleId;
        UserSession UserData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        #endregion
        #region PROPERTIES
        [CreateNew]
        public UserMappingPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion
        /// <summary>
        /// Loads the Active Users and Roles to the respective dropdowns and initialize other controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["UserDetails"] != null)
                {
                    Session["CurrentPage"] = "User Management";
                    ddlUserName.Focus();
                    UserData = (UserSession)Session["UserDetails"];
                    RedirectToErrorPage(UserData);
                    IsValidRoleToAccessThisPage(UserData);

                    if (!this.IsPostBack)
                    {
                        this._presenter.OnViewInitialized();
                        LoginId = UserData.UserId;
                        Bindroles();
                        BindActiveUsers();
                        BindCountryChekBoxList();
                        BindUserrolemapgrid();
                        Page.Form.DefaultButton = btnMap.UniqueID;
                        //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                        string PKeyword = (Session["PasswordExpiration"]).ToString();
                        if (PKeyword == "yes")
                        {
                            Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                    }
                }
                }
                else
                {
                    Response.Clear();
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
                this._presenter.OnViewLoaded();
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMapping.cs | Page_Load()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMapping.cs | Page_Load()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        #region METHODS

        /// <summary>
        /// Method to redirect to login or session expired page
        /// </summary>
        private void RedirectToErrorPage(UserSession UserData)
        {
            try
            {
                if (UserData == null)
                {
                    Response.Clear(); Response.Redirect(@"~\Errors\Error.aspx", false); Response.End();
                }
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMapping.cs | RedirectToErrorPage()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMapping.cs | RedirectToErrorPage()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserData)
        {
            try
            {
                if ((UserData.RoleId == (int)Constant.UserRole.TeamLead) || (UserData.RoleId == (int)Constant.UserRole.Admin) || (UserData.RoleId == (int)Constant.UserRole.SuperAdmin))
                {
                    return true;
                }
                else
                {
                    Response.Clear(); Response.Redirect("~/Errors/AccessDenied.aspx", false); Response.End();
                }
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMapping.cs | IsValidRoleToAccessThisPage()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMapping.cs | IsValidRoleToAccessThisPage()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            return false;
        }

        /// <summary>
        /// Function to Bind the users mapped to the roles to the grid
        /// </summary>
        private DataTable BindUserrolemapgrid()
        {
            DataTable dt = null;
            try
            {
                DataSet dsUserRoleMapBind = this._presenter.GridUserRoleMapBind();
                grdUserRoleMapping.DataSource = dsUserRoleMapBind;
                grdUserRoleMapping.DataBind();
                ViewState["UserRoleMapGrid"] = dsUserRoleMapBind.Tables[0];
                dt = dsUserRoleMapBind.Tables[0];
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMapping.cs | BindUserrolemapgrid()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMapping.cs | BindUserrolemapgrid()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            return dt;
        }
        /// <summary>
        /// Function to Bind the grid userwise
        /// </summary>
        public DataTable BindUserrolemapgridUserWise()
        {
            DataTable dt = null;
            try
            {
                Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
                Match matchUserName = regex.Match(ddlUserName.SelectedValue.ToString());
                if (matchUserName.Success)
                {
                UserId = ddlUserName.SelectedValue.ToString();
                DataSet dsUserWiseMailBoxMapGridBind = this._presenter.UserWiseRoleMapGridBind(UserId);
                grdUserRoleMapping.DataSource = dsUserWiseMailBoxMapGridBind;
                grdUserRoleMapping.DataBind();
                ViewState["UserRoleMapGrid"] = grdUserRoleMapping.DataSource;
                dt = dsUserWiseMailBoxMapGridBind.Tables[0];
                ddlrole.Enabled = true;
            }
                else
                {
                    Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMapping.cs | BindUserrolemapgridUserWise()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMapping.cs | BindUserrolemapgridUserWise()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }return dt;
        }
        /// <summary>
        /// Function to Clear all the fields
        /// </summary>
        public void Clearfields()
        {
            ddlrole.SelectedIndex = 0;
            ddlUserName.SelectedIndex = 0;
            ddlUserName.Enabled = true;
            ddlrole.Enabled = true;
            btnMap.Text = "Map";
            ddlUserName.Focus();
            BindUserrolemapgrid();
            cbLCountry.ClearSelection(); 
            cbLCountry.Visible = false;
            lblCountry.Visible = false;
        }
        /// <summary>
        /// Function to bind the roles to the dropdown
        /// </summary>
        public void Bindroles()
        {
            try
            {
                DataSet dsRoleNames = _presenter.BindRole();
                ddlrole.DataSource = dsRoleNames;
                ddlrole.DataValueField = "UserRoleID";
                ddlrole.DataTextField = "RoleDescription";
                ddlrole.DataBind();
                ListItem select = new ListItem();
                select.Text = "- Select -";
                select.Value = "0";
                ddlrole.Items.Insert(0, select);
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMapping.cs | Bindroles()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMapping.cs | Bindroles()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// Function to bind the Users to the dropdown
        /// </summary>
        public void BindActiveUsers()
        {
            try
            {
                DataSet dsActiveUsers = _presenter.BindActiveUsers();
                ddlUserName.DataSource = dsActiveUsers;
                ddlUserName.DataValueField = "UserID";
                ddlUserName.DataTextField = "UserName";
                ddlUserName.DataBind();
                ListItem select = new ListItem();
                select.Text = "- Select -";
                select.Value = "0";
                ddlUserName.Items.Insert(0, select);
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMapping.cs | BindActiveUsers()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMapping.cs | BindActiveUsers()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// Function to bind the Country to the ChekBoxList
        /// </summary>
        public void BindCountryChekBoxList()
        {
            try
            {
                DataSet dscountry = _presenter.BindCountryChekBoxList();
                cbLCountry.DataSource = dscountry;
                cbLCountry.DataValueField = "CountryId";
                cbLCountry.DataTextField = "Country";
                cbLCountry.DataBind();
                cbLCountry.SelectedIndex = 0;
                //ListItem select = new ListItem();
                //select.Text = "All";
                //select.Value = "0";
                //cbLCountry.Items.Insert(0, select);
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMapping.cs | BindCountryChekBoxList()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMapping.cs | BindCountryChekBoxList()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// Method to sort the grid Column values
        /// </summary>
        /// <param name="strParam"></param>
        #region Paging and Sorting
        /// <summary>
        /// To sort the Page
        /// </summary>
        protected DataView SortDataTable(DataTable dataTable, bool isPageIndexChanging)
        {
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (GridViewSortExpression != string.Empty)
                {
                    if (isPageIndexChanging)
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GridViewSortDirection);
                    }
                    else
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GetSortDirection());
                    }
                }
                return dataView;
            }
            else
            {
                return new DataView();
            }
        }

        private string GetSortDirection()
        {
            switch (GridViewSortDirection)
            {
                case "ASC":
                    GridViewSortDirection = "DESC";
                    break;
                case "DESC":
                    GridViewSortDirection = "ASC";
                    break;
            }
            return GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }

        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }


        #endregion
        #endregion
        #region EVENTS
        /// <summary>
        /// Button event to map the users to the particular roles
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnMap_Click(object sender, EventArgs e)
        {
            try
            {
                if (UserData != null)
                {
                    UserId = ddlUserName.SelectedValue.ToString();
                    int RoleId = Convert.ToInt32(ddlrole.SelectedValue);
                    LoginId = UserData.UserId;
                    LoggedInUserRoleId = UserData.RoleId;
                    string strCountryIdsToMap = "";
                    if (RoleId == 5)
                        strCountryIdsToMap = getMappedCountries();

                    if (!(LoginId == UserId))
                    {
                        if (!((LoggedInUserRoleId == (int)Constant.UserRole.TeamLead) && (RoleId == (int)Constant.UserRole.Admin)))
                        {
                            if (btnMap.Text == "Map")
                            {
                                if (ddlUserName.SelectedIndex > 0 && ddlrole.SelectedIndex > 0)
                                {
                                    int returnvalue = _presenter.MapUserRole(UserId, RoleId, LoginId, strCountryIdsToMap);
                                    if (returnvalue == 1)//Success Scenario
                                    {
                                        Clearfields();
                                        BindUserrolemapgrid();
                                        cbLCountry.ClearSelection();
                                        lblCountry.Visible = cbLCountry.Visible = false;
                                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('The user has been mapped successfully');", true);
                                    }
                                    else//Failure Scenario
                                    {
                                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('User is already mapped to the Selected Role');", true);
                                        BindUserrolemapgridUserWise();
                                    } 
                                }
                                else
                                {
                                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Select Login ID and role for mapping');", true);
                                }
                                
                            }
                            else
                            {
                                string UserRoleMapId = hddnRoleMapId.Value;
                                int returnvalue = _presenter.UpdateRoleMap(UserRoleMapId, UserId, RoleId, LoginId, strCountryIdsToMap);
                                if (returnvalue == 0)//Update Failed
                                {
                                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update Falied!');", true);
                                    Clearfields();
                                    BindUserrolemapgrid();
                                    btnMap.Text = "Map";
                                }
                                if (returnvalue == 1)//Update Success
                                {
                                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Role Map Updated successfully!');", true);
                                    Clearfields();
                                    BindUserrolemapgrid();
                                    btnMap.Text = "Map";
                                }
                                else if (returnvalue == 2)//User Role Already Mapped
                                {
                                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('User is already mapped to the Selected Role!');", true);
                                    BindUserrolemapgrid();
                                    btnMap.Text = "Update";
                                }
                            }
                        }
                        else
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('You dont have permission to map the Selected Role');", true);
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('You dont have permission to map the Role to Yourself');", true);
                    }
                }
                else
                {
                    Response.Clear(); Response.Redirect(@"~\Errors\SessionExpired.aspx", false); Response.End();
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMapping.cs | btnMap_Click()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMapping.cs | btnMap_Click()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        private string getMappedCountries()
        {
            string str = "";

            for (int i = 0; i < cbLCountry.Items.Count; i++)
            {
                if (cbLCountry.Items[i].Selected)
                if (str == "")
                    str = cbLCountry.Items[i].Value;
                else
                    str += ", " + cbLCountry.Items[i].Value;
            }
            return str;
        }
        /// <summary>
        /// Event to change the index of the grid page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdUserRoleMapping_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdUserRoleMapping.DataSource = SortDataTable(BindUserrolemapgrid() as DataTable, true);
                grdUserRoleMapping.PageIndex = e.NewPageIndex;
                grdUserRoleMapping.DataBind(); 
                //grdUserRoleMapping.EditIndex = -1;
                //BindUserrolemapgrid();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | UserMapping.cs | grdUserRoleMapping_PageIndexChanging()");  
                //errorlog.HandleError(ex, UserData.UserId, " | UserMapping.cs | grdUserRoleMapping_PageIndexChanging()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// Event to set the Hover style to the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdUserRoleMapping_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    Label lblRoleId = (Label)e.Row.FindControl("lblRoleId");
                    ImageButton imgBtn = (ImageButton)e.Row.FindControl("imgEdit");

                    if (lblRoleId != null && imgBtn != null)
                    {
                        if (lblRoleId.Text.Trim() == "5")
                            imgBtn.Enabled = true;
                        else
                        {
                            imgBtn.Enabled = false; imgBtn.ToolTip = "You can't edit this record!";
                        }
                    }
                    //Varma - Timezone Feature On&OFF functionality 
                    if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                    {

                        //Pranay 10 January 2017--for changing modified date as per user TimeZone
                        //DateTime modifiedDate = Convert.ToDateTime(DataBinder.Eval(e.Row.DataItem, "CreatedDate"));
                        //String zonedDateTime = ISSWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(modifiedDate.ToString("dd/MM/yyyy HH:mm:ss"), true, UserData.TimeZone, false);
                        Label ModifiedDate = (Label)(e.Row.FindControl("lblCreatedDate"));

                        string value = DataBinder.Eval(e.Row.DataItem, "CreatedDate").ToString();

                        if (!String.IsNullOrEmpty(value))
                        {
                            DateTime modifiedDate = Convert.ToDateTime(DataBinder.Eval(e.Row.DataItem, "CreatedDate"));
                            String zonedDateTime = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(modifiedDate.ToString("dd/MM/yyyy HH:mm:ss"), true, UserData.TimeZone, false);
                            ModifiedDate.Text = zonedDateTime;
                        }
                        else
                        {
                            ModifiedDate.Text = String.Empty;
                        }
                    }

                    //e.Row.Attributes.Add("onMouseOver", "SetNewColor(this);");
                    //e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMapping.cs | grdUserRoleMapping_RowDataBound()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMapping.cs | grdUserRoleMapping_RowDataBound()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// Event to sort the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdUserRoleMapping_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                if (ddlUserName.SelectedIndex == 0)
                {
                    //ViewState["Sort"] = e.SortExpression;
                    //sort("UserId");
                    GridViewSortExpression = e.SortExpression;
                    int pageIndex = grdUserRoleMapping.PageIndex;
                    grdUserRoleMapping.DataSource = SortDataTable(BindUserrolemapgrid() as DataTable, false);
                    grdUserRoleMapping.DataBind();
                    grdUserRoleMapping.PageIndex = pageIndex;
                }
                else
                {
                    //ViewState["Sort"] = e.SortExpression;
                    //sort("UserId");
                    GridViewSortExpression = e.SortExpression;
                    int pageIndex = grdUserRoleMapping.PageIndex;
                    grdUserRoleMapping.DataSource = SortDataTable(BindUserrolemapgridUserWise() as DataTable, false);
                    grdUserRoleMapping.DataBind();
                    grdUserRoleMapping.PageIndex = pageIndex;
                }
                
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMapping.cs | grdUserRoleMapping_Sorting()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMapping.cs | grdUserRoleMapping_Sorting()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        protected void grdUserRoleMapping_Command(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.ToUpper() == "SORT")
                {
                }
                else if (e.CommandName.ToUpper() == "PAGE")
                {
                }
                else
                {
                    int index = Convert.ToInt32(e.CommandArgument);
                }
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | UserMapping.cs | grdUserRoleMapping_Command()");  
                //errorlog.HandleError(ex, UserData.UserId, " | UserMapping.cs | grdUserRoleMapping_Command()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        /// <summary>
        /// Command event to edit and delete the grid rows
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdUserRoleMapping_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                string hddnRMapId;

                if (e.CommandName == "DeleteRoleMap")
                {
                    int rowindex = Convert.ToInt32(e.CommandArgument);
                    Label lblUserId = (Label)grdUserRoleMapping.Rows[rowindex].FindControl("lblUserID");
                    Label lblRoleId = (Label)grdUserRoleMapping.Rows[rowindex].FindControl("lblRoleId");

                    if (!(lblUserId == null && lblRoleId == null))
                    {
                        if (!(UserData.UserId == lblUserId.Text.Trim()))
                        {
                            if (!((UserData.RoleId == (int)Constant.UserRole.TeamLead) && (Convert.ToInt32(lblRoleId.Text.Trim()) == (int)Constant.UserRole.Admin)))
                            {
                                hddnRMapId = ((Label)grdUserRoleMapping.Rows[rowindex].FindControl("lblRoleMapId")).Text.ToString().Trim();
                                int returnvalue = _presenter.DeleteRoleMap(hddnRMapId);
                                if (returnvalue == 0)//Delete Failed
                                {
                                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Record is not deleted!');", true);
                                    BindUserrolemapgrid();
                                }
                                if (returnvalue == 1)//Delete Success
                                {
                                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Record has been deleted successfully!');", true);
                                    BindUserrolemapgrid();
                                    Clearfields();
                                }
                            }
                            else
                            {
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('You dont have permission to delete this record!');", true);
                            }
                        }
                        else
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('You dont have permission to delete this record!');", true);
                        }
                    }
                }

                if (e.CommandName == "EditRoleMap")
                {
                    cbLCountry.ClearSelection();
                    int RowIndex = Convert.ToInt32(e.CommandArgument);
                    hddnRMapId = ((Label)grdUserRoleMapping.Rows[RowIndex].FindControl("lblRoleMapId")).Text.ToString().Trim();
                    string AssId = ((Label)grdUserRoleMapping.Rows[RowIndex].FindControl("lblUserID")).Text.ToString().Trim();
                    string UserName = ((Label)grdUserRoleMapping.Rows[RowIndex].FindControl("lblUserName")).Text.ToString().Trim();
                    string Role = ((Label)grdUserRoleMapping.Rows[RowIndex].FindControl("lblRole")).Text.ToString().Trim();
                    string CountriesMapped = ((Label)grdUserRoleMapping.Rows[RowIndex].FindControl("lblMappedCountryIds")).Text.ToString().Trim();

                    ddlUserName.SelectedIndex = ddlUserName.Items.IndexOf(ddlUserName.Items.FindByValue(AssId));

                    ddlrole.SelectedIndex = ddlrole.Items.IndexOf(ddlrole.Items.FindByText(Role));
                    hddnRoleMapId.Value = hddnRMapId;
                    btnMap.Text = "Update";
                    ddlUserName.Enabled = false;
                    ddlrole.Enabled = false;
                    if (Role == "Client User")
                    {
                        if (CountriesMapped.Split(',').Length > 0)
                        {
                            string[] val = CountriesMapped.Split(',');

                            for (int i = 0; i < val.Length; i++)
                            {
                                if (cbLCountry.Items.FindByValue(val[i].Trim()) != null)
                                    cbLCountry.Items.FindByValue(val[i].Trim()).Selected = true;
                            }
                        }
                        cbLCountry.Visible = true;
                    }
                }
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMapping.cs | grdUserRoleMapping_RowCommand()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMapping.cs | grdUserRoleMapping_RowCommand()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        /// <summary>
        /// Click Event to clear the fields
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClr_Click(object sender, EventArgs e)
        {
            Clearfields();
        }

        protected void ddlUserName_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindUserrolemapgridUserWise();
        }

        protected void ddlrole_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlrole.SelectedItem.Value == "5")
                {
                    BindCountryChekBoxList();
                    cbLCountry.Visible = lblCountry.Visible = true;
                }
                else
                {
                    cbLCountry.Visible = lblCountry.Visible = false;
                }
                ddlrole.Focus();
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | UserMapping.cs | ddlrole_SelectedIndexChanged()");  
                //errorlog.HandleError(ex, UserData.UserId, " | UserMapping.cs | ddlrole_SelectedIndexChanged()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        #endregion
    }
}