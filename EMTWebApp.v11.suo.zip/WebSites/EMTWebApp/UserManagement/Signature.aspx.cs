﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using EMTWebApp.Constants;
using DigiOPS.TechFoundation.Logging;
using EMTWebApp.ExceptionHandler;

namespace EMTWebApp.UserManagement.Views
{
    public partial class UserManagement_Signature : Microsoft.Practices.CompositeWeb.Web.UI.Page, ISignatureView
    {
        #region DECLARATION
        private SignaturePresenter  _presenter;
        private string LoginId;
        UserSession UserDetail = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Session["CurrentPage"] = "User Management";
                UserDetail = (UserSession)Session["UserDetails"];
                IsValidRoleToAccessThisPage(UserDetail);
                RedirectToErrorPage(UserDetail);

                if (!this.IsPostBack)
                {
                    txtSignature.Focus();
                    Page.Form.DefaultButton = btnSubmit.UniqueID;
                    if (Session["UserDetails"] != null)
                    {
                        LoginId = UserDetail.UserId.ToString();
                    }
                    else
                    {
                        Response.Clear();
                        Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                        Response.End();
                    }
                    BindSignatureDetails(LoginId);
                    this._presenter.OnViewInitialized();

                    //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                    string PKeyword = (Session["PasswordExpiration"]).ToString();
                    if (PKeyword == "yes")
                    {
                        Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                }
                }
                this._presenter.OnViewLoaded();
            }
            catch (Exception ex)
            {
                // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | Signature.aspx.cs | Page_Load()");  
                //errorlog.HandleError(ex, UserDetail.UserId , " | Signature.aspx.cs | Page_Load()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx",false);
                Response.End();

            }
        }
        #region PROPERTIES
        [CreateNew]
        public SignaturePresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion
        private bool IsValidRoleToAccessThisPage(UserSession UserDetail)
        {
            try
            {
                if ((UserDetail.RoleId == (int)Constant.UserRole.Processor) || (UserDetail.RoleId == (int)Constant.UserRole.TeamLead))
                {
                    return true;
                }
                else
                {
                    Response.Clear();
                    Response.Redirect("~/Errors/AccessDenied.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
            catch (Exception Ex)
            {
                // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | Signature.aspx.cs | IsValidRoleToAccessThisPage()");  
                //errorlog.HandleError(Ex, UserDetail.UserId , " | Signature.aspx.cs | IsValidRoleToAccessThisPage()");
                Response.Clear();
                Response.Redirect(@"~\Errors\Error.aspx",false);
                Response.End();
            }
            return false;
        }

        /// <summary>
        /// Method to redirect to Error page if userdetails are null
        /// </summary>
        private void RedirectToErrorPage(UserSession UserDetail)
        {
            try
            {
                if (UserDetail == null)
                {
                    Response.Clear();
                    Response.Redirect(@"~\Errors\Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | Signature.aspx.cs | RedirectToErrorPage()");  
                //errorlog.HandleError(Ex, UserDetail.UserId , " | Signature.aspx.cs | RedirectToErrorPage()");
                Response.Clear();
                Response.Redirect(@"~\Errors\Error.aspx",false);
                Response.End();
            }
        }
       
        protected void grdConfigureSignature_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "EditSignature")
                {
                    int RowIndex = Convert.ToInt32(e.CommandArgument);
                    string SignId = ((Label)grdConfigureSignature.Rows[RowIndex].FindControl("lblSignatureID")).Text.ToString().Trim();
                    string Signature = ((Label)grdConfigureSignature.Rows[RowIndex].FindControl("lblSignature")).Text.ToString().Trim();

                    HddnsignId.Value = SignId;
                    Signature = Signature.Replace("<br/>", "\n");
                    txtSignature.Text = Signature;
                    btnSubmit.Text = "Update";
                    btnSubmit.ValidationGroup = "Submit";
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | Signature.aspx.cs | grdConfigureSignature_RowCommand()");  
                //errorlog.HandleError(ex, UserDetail.UserId , " | Signature.aspx.cs | grdConfigureSignature_RowCommand()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx",false);
                Response.End();
            }
        }
        /// <summary>
        /// TO BIND THE DETAILS OF THE Signature TO THE GRID
        /// </summary>
        public void BindSignatureDetails(string LoginId)
        {
            try
            {
                DataSet dsresult = new DataSet();
                dsresult= this._presenter.GetSignature(LoginId);
                if (dsresult.Tables[0].Rows[0]["SignID"].ToString() != "0")
                {
                    grdConfigureSignature.DataSource = dsresult;
                    grdConfigureSignature.DataBind();
                    ViewState["Signature"] = grdConfigureSignature.DataSource;
                }
                else
                {
                    grdConfigureSignature.EmptyDataText = "No Records found";
                    
                }
                
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | Signature.aspx.cs | BindSignatureDetails()");  
                //errorlog.HandleError(ex, UserDetail.UserId , " | Signature.aspx.cs | BindSignatureDetails()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx",false);
                Response.End();
            }
        }
        /// <summary>
        /// TO ADD THE COUNTRY DETAILS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
            try
            {
                string Signature = txtSignature.Text.Trim();
                Signature = Signature.Replace("\n", "<br/>");
                UserDetail = (UserSession)Session["UserDetails"];
                LoginId = UserDetail.UserId.ToString();

                if (btnSubmit.Text == "Configure")
                {
                    int returnvalue = _presenter.ConfigureSignature(Signature, LoginId);
                    if (returnvalue == 0)//TO SHOW COUNTRY ALREADY EXISTS
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Signature already exists for the current user!');", true);
                        Clearfields();
                        BindSignatureDetails(LoginId);
                    }
                    if (returnvalue == 1)//TO SHOW COUNTRY HAS BEEN ADDED
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Signature added  successfully!');", true);
                        Clearfields();
                        BindSignatureDetails(LoginId);
                    }
                }
                else
                {
                    string SignId = HddnsignId.Value;
                    int returnvalue = _presenter.UpdateSignature(SignId, Signature, LoginId);
                    if (returnvalue == 0)//UPDATE FAILURE ALERT
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update Falied!');", true);
                        Clearfields();
                        BindSignatureDetails(LoginId);
                        btnSubmit.Text = "Configure";
                        btnSubmit.ValidationGroup = "Submit";
                    }
                    if (returnvalue == 1)//UPDATE SUCCESS
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update is successful!');", true);
                        Clearfields();
                        BindSignatureDetails(LoginId);
                        btnSubmit.Text = "Configure";
                        BindSignatureDetails(LoginId);
                        btnSubmit.ValidationGroup = "Submit";
                    }
                }
            }

            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                    new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetail.UserId, " | Signature.aspx.cs | btnSubmit_Click()");
                    //errorlog.HandleError(Ex, UserDetail.UserId , " | Signature.aspx.cs | btnSubmit_Click()");
                    Response.Clear();
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
            }
        }
        /// <summary>
        /// BUTTON EVENT TO CLEAR THE FIELDS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                Clearfields();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | Signature.aspx.cs | btnClear_Click()");  
                //errorlog.HandleError(ex, UserDetail.UserId , " | Signature.aspx.cs | btnClear_Click()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx",false);
                Response.End();
            }
        }
        /// <summary>
        /// TO CLEAR THE FIELDS
        /// </summary>
        public void Clearfields()
        {
            try
            {
                txtSignature.Text = "";
                btnSubmit.Text = "Configure";
                txtSignature.Focus();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetail.UserId, " | Signature.aspx.cs | Clearfields()");  
                //errorlog.HandleError(ex, UserDetail.UserId , " | Signature.aspx.cs | Clearfields()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx",false);
                Response.End();
            }
        }
}
}