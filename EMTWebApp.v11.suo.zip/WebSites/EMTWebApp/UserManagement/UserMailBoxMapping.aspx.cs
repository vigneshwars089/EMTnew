﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using DigiOPS.TechFoundation.Logging;
using EMTWebApp.Constants;
using System.Text.RegularExpressions;

namespace EMTWebApp.UserManagement.Views
{
    public partial class UserMailBoxMapping : Microsoft.Practices.CompositeWeb.Web.UI.Page, IUserMailBoxMappingView
    {
        #region DECLARATIONS
        private UserMailBoxMappingPresenter _presenter;
        private string LoginId = string.Empty;
        private string UserId = string.Empty;
        private string ddlCountryId = string.Empty;
        UserSession UserData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        public string hddnMBMapId;
        #endregion
        /// <summary>
        /// TO BIND THE USERS, COUNTRY NAMES TO THE DROPDOWN AND MAILBOX DETAILS TO THE GRID
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["UserDetails"] != null)
                {
                    Session["CurrentPage"] = "User Management";
                    ddlUserName.Focus();
                    UserData = (UserSession)Session["UserDetails"];                  
                        RedirectToErrorPage(UserData);
                        IsValidRoleToAccessThisPage(UserData);
                        if (!this.IsPostBack)
                        {
                            this._presenter.OnViewInitialized();

                            BindActiveUsers();

                            Page.Form.DefaultButton = btnMap.UniqueID;
                            BindCountry();
                            ddlCountry_SelectedIndexChanged(null, null);

                            BindMailBoxMapgrid();
                            //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                            string PKeyword = (Session["PasswordExpiration"]).ToString();
                            if (PKeyword == "yes")
                            {
                                Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                        }
                   
                }
                   
                }
                else
                {
                    Response.Clear();
                    Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                    Response.End();
                }
                this._presenter.OnViewLoaded();
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | UserMailBoxMapping.cs | Page_Load()");  
                //errorlog.HandleError(ex, UserData.UserId, " | UserMailBoxMapping.cs | Page_Load()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        #region PROPERTIES
        [CreateNew]
        public UserMailBoxMappingPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion
        #region METHODS
        /// <summary>
        /// Method to redirect to login or session expired page
        /// </summary>
        private void RedirectToErrorPage(UserSession UserDetail)
        {
            try
            {
                if (UserDetail == null)
                {
                    Response.Clear(); Response.Redirect(@"~\Errors\Error.aspx", false); Response.End();
                }
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMailBoxMapping.cs | RedirectToErrorPage()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMailBoxMapping.cs | RedirectToErrorPage()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserData)
        {
            try
            {
                if ((UserData.RoleId == (int)Constant.UserRole.TeamLead) || (UserData.RoleId == (int)Constant.UserRole.Admin) || (UserData.RoleId == (int)Constant.UserRole.SuperAdmin))
                {
                    return true;
                }
                else
                {
                    Response.Clear(); Response.Redirect("~/Errors/AccessDenied.aspx", false); Response.End();
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMailBoxMapping.cs | IsValidRoleToAccessThisPage()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMailBoxMapping.cs | IsValidRoleToAccessThisPage()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();

            }
            return false;
        }

        /// <summary>
        /// FUNCTION TO BIND THE ACTIVE USERS TO THE DROPDOWN
        /// </summary>
        public void BindActiveUsers()
        {
            try
            {
               
                DataSet dsActiveUsers = _presenter.BindActiveUsers();
                ddlUserName.DataSource = dsActiveUsers;
                ddlUserName.DataValueField = "UserID";
                ddlUserName.DataTextField = "UserName";
                ddlUserName.DataBind();
                ListItem select = new ListItem();
                select.Text = "- Select -";
                select.Value = "0";
                ddlUserName.Items.Insert(0, select);          
                
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMailBoxMapping.cs | BindActiveUsers()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMailBoxMapping.cs | BindActiveUsers()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// FUNCTION TO CLEAR THE FIELDS
        /// </summary>
        public void Clearfields()
        {
            try
            {

                ddlMailBox.Items.Clear();
                ddlMailBox.Items.Insert(0, "- Select -");
                ddlCountry.SelectedIndex = 0;
                ddlUserName.SelectedIndex = 0;
                ddlUserName.Enabled = true;
                btnMap.Text = "Map";

                lblmsg.Visible = false;
                lblmsg.Text = "";
                ddlCountry_SelectedIndexChanged(null, null);
                BindMailBoxMapgrid();
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | UserMailBoxMapping.cs | Clearfields()");  
                //errorlog.HandleError(ex, UserData.UserId, " | UserMailBoxMapping.cs | Clearfields()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// FUNCTION TO BIND THE COUNTRY NAMES TO THE DROPDOWN
        /// </summary>
        public void BindCountry()
        {
            try
            {              
                if (UserData.RoleId == (int)Constant.UserRole.TeamLead)
                {
                    DataSet dsCountry = new DataSet();
                    Hashtable htUserData = new Hashtable();
                    htUserData.Add("@ASSOCIATEID", (UserData.UserId != null && UserData.UserId != "") ? UserData.UserId : "");
                    htUserData.Add("@Roleid", (UserData.RoleId != null) ? Convert.ToString(UserData.RoleId) : "");

                    dsCountry = _presenter.GetCountryByUserIdForDashboard(htUserData);

                    if (dsCountry.Tables[0].Rows.Count > 0)
                    {
                        ddlCountry.DataSource = dsCountry;
                        ddlCountry.DataTextField = "Country";
                        ddlCountry.DataValueField = "CountryId";
                        ddlCountry.DataBind();
                        //ddlCountry.Enabled = true;
                        if (dsCountry.Tables[0].Rows.Count == 1)
                        {
                            ddlCountry.SelectedIndex = -1;
                            ddlCountry.Enabled = false;
                        }
                        else
                        {
                            ddlCountry.Items.Insert(0, new ListItem("-Select-", "0", true));
                        }
                    }
                    dsCountry.Dispose();
                }
                else
                {
                    DataSet dsCountryNames = _presenter.BindCountry();
                    ddlCountry.DataSource = dsCountryNames;
                    ddlCountry.DataValueField = "CountryID";
                    ddlCountry.DataTextField = "Country";
                    ddlCountry.DataBind();
                    if (dsCountryNames.Tables[0].Rows.Count == 1)
                    {
                        ddlCountry.SelectedIndex = -1;
                        ddlCountry.Enabled = false;
                    }
                    else
                    {
                        ddlCountry.Items.Insert(0, new ListItem("-Select-", "0", true));
                    }
                   
                  }
              

            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMailBoxMapping.cs | BindCountry()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMailBoxMapping.cs | BindCountry()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// FUNCTION TO BIND THE MAILOX MAP DETAILS TO THE GRID
        /// </summary>
        public DataTable BindMailBoxMapgrid()
        {
            DataTable dt = null;
            try
            {
                    Hashtable htUserDatagrid = new Hashtable();
                    htUserDatagrid.Add("@ASSOCIATEID", (UserData.UserId != null && UserData.UserId != "") ? UserData.UserId : "");
                    htUserDatagrid.Add("@Roleid", (UserData.RoleId != null) ? Convert.ToString(UserData.RoleId) : "");
                    DataSet dsGridMailBoxMapBind = this._presenter.GridMailBoxMapBind(htUserDatagrid);
                    grdMailBoxMapping.DataSource = dsGridMailBoxMapBind;
                    grdMailBoxMapping.DataBind();
                    ViewState["UserRoleMapGrid"] = grdMailBoxMapping.DataSource;
                    dt = dsGridMailBoxMapBind.Tables[0];
               
            }
            catch (Exception ex)
            {
              //  ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | UserMailBoxMapping.cs | BindMailBoxMapgrid()");  
                //errorlog.HandleError(ex, UserData.UserId, " | UserMailBoxMapping.cs | BindMailBoxMapgrid()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            return dt;
        }

        #region Paging and Sorting
        /// <summary>
        /// To sort the Page
        /// </summary>
        protected DataView SortDataTable(DataTable dataTable, bool isPageIndexChanging)
        {
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (GridViewSortExpression != string.Empty)
                {
                    if (isPageIndexChanging)
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GridViewSortDirection);
                    }
                    else
                    {
                        dataView.Sort = string.Format("{0} {1}", GridViewSortExpression, GetSortDirection());
                    }
                }
                return dataView;
            }
            else
            {
                return new DataView();
            }
        }

        private string GetSortDirection()
        {
            switch (GridViewSortDirection)
            {
                case "ASC":
                    GridViewSortDirection = "DESC";
                    break;
                case "DESC":
                    GridViewSortDirection = "ASC";
                    break;
            }
            return GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }

        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }


        #endregion

        /// <summary>
        /// Function to Bind the grid userwise
        /// </summary>
        public DataTable BindUserMailBoxgridUserWise()
        {
            DataTable dt = null;
            try
            {
                Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
                Match matchUserName = regex.Match(ddlUserName.SelectedValue.ToString());
                Match matchCountryId = regex.Match(ddlCountryId);
                if (matchUserName.Success && matchCountryId.Success)
                {
                UserId = ddlUserName.SelectedValue.ToString();
                lblmsg.Text = "";
                lblmsg.Visible = false;
                DataSet dsUserWiseMailBoxMapGridBind = this._presenter.UserWiseMailBoxMapGridBind(UserId, ddlCountryId);
                grdMailBoxMapping.DataSource = dsUserWiseMailBoxMapGridBind;
                grdMailBoxMapping.Visible = true;
                grdMailBoxMapping.DataBind();
                ViewState["UserRoleMapGrid"] = grdMailBoxMapping.DataSource;
                dt = dsUserWiseMailBoxMapGridBind.Tables[0];
                }
                else
                {
                    Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                }
             
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMailBoxMapping.cs | BindUserMailBoxgridUserWise()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMailBoxMapping.cs | BindUserMailBoxgridUserWise()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
            return dt;
        }

        protected void sort(string strParam)
        {
            try
            {
                if (ViewState["SortDirection"] == null)
                {
                    ViewState["SortDirection"] = "asc";
                }
                else if (ViewState["SortDirection"].ToString() == "asc")
                {
                    ViewState["SortDirection"] = "desc";
                }
                else
                {
                    ViewState["SortDirection"] = "asc";
                }
                BindGrid(strParam);
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMailBoxMapping.cs | sort()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMailBoxMapping.cs | sort()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        private void BindGrid(string strparameter)
        {
            try
            {
                string Sortexpression = "";
                string sortdirection = "";
                if (ViewState["Sort"] == null)
                {
                    Sortexpression = strparameter;
                }
                else
                {
                    Sortexpression = ViewState["Sort"].ToString();
                }
                if (ViewState["SortDirection"] == null)
                {
                    sortdirection = "asc";
                }
                else
                {
                    sortdirection = ViewState["SortDirection"].ToString();
                }
                DataTable dtWorkList = new DataTable();
                GetWorkList(Sortexpression, sortdirection);
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMailBoxMapping.cs | BindGrid()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMailBoxMapping.cs | BindGrid()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        protected void GetWorkList(string SortExpression, string SortDirection)
        {
            try
            {
                DataSet ds = new DataSet();
                ds = (DataSet)ViewState["UserRoleMapGrid"];
                DataView dv = new DataView();
                dv = ds.Tables[0].DefaultView;
                dv.Sort = SortExpression + " " + SortDirection;
                grdMailBoxMapping.DataSource = dv;
                grdMailBoxMapping.DataBind();
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMailBoxMapping.cs | BindGrid()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMailBoxMapping.cs | BindGrid()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        #endregion
        #region EVENTS
        /// <summary>
        /// EVENT TO MAP THE MAILBOX TO THE USERS BASED ON THE COUNTRY SELECTION
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnMap_Click(object sender, EventArgs e)
        {
            try
            {
               string Rolename= Session["RoleName"].ToString();
               if (UserData.RoleName == Rolename)
                {
                UserId = ddlUserName.SelectedValue.ToString();
                int MailBoxId = Convert.ToInt32(ddlMailBox.SelectedValue);
                LoginId = UserData.UserId;

                if (!(LoginId == UserId))
                {
                    if (btnMap.Text == "Map")
                    {
                        int returnvalue = _presenter.MapUserMailBox(UserId, MailBoxId, LoginId);
                        if (returnvalue == 1)//MAPPING SUCCESS
                        {
                            Clearfields();
                            BindMailBoxMapgrid();
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('The user has been mapped successfully to the selected MailBox');", true);
                        }
                        else//MAPPING FAILURE
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('User is already mapped to the Selected MailBox');", true);
                            BindUserMailBoxgridUserWise();
                        }
                    }
                    else
                    {
                        string UserMailBoxMapId = hddnMBoxMapID.Value;
                        int returnvalue = _presenter.UpdateUserMailBoxMap(UserMailBoxMapId, UserId, MailBoxId, LoginId);
                        if (returnvalue == 0)//UPDATE FAILS
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update Falied!');", true);
                            BindMailBoxMapgrid();
                            btnMap.Text = "Map";
                        }
                        if (returnvalue == 1)//UPDATE SUCCESS
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update is successful!');", true);
                            Clearfields();
                            BindMailBoxMapgrid();
                            btnMap.Text = "Map";
                        }
                        else if (returnvalue == 2)//Already Mapped
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('User is already mapped to the Selected MailBox');", true);
                            btnMap.Text = "Update";
                            BindMailBoxMapgrid();
                            Clearfields();
                        }
                    }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('You dont have permission to map the MailBox to Yourself');", true);
                }
                }
                else
                {
                    Server.Transfer(@"~/Errors/BadRequest.aspx");
                }
            }
            catch (Exception ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | UserMailBoxMapping.cs | btnMap_Click()");  
                //errorlog.HandleError(ex, UserData.UserId, " | UserMailBoxMapping.cs | btnMap_Click()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// EVENT TO CLEAR ALL THE FIELDS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClr_Click(object sender, EventArgs e)
        {
            Clearfields();
        }
        /// <summary>
        /// To change the page of the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdMailBoxMapping_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdMailBoxMapping.DataSource = SortDataTable(BindMailBoxMapgrid() as DataTable, true);
                grdMailBoxMapping.PageIndex = e.NewPageIndex;
                grdMailBoxMapping.EditIndex = -1;
                grdMailBoxMapping.DataBind();
            }
            catch (Exception ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | UserMailBoxMapping.cs | grdMailBoxMapping_PageIndexChanging()");  
                //errorlog.HandleError(ex, UserData.UserId, " | UserMailBoxMapping.cs | grdMailBoxMapping_PageIndexChanging()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// To set the hover style over the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdMailBoxMapping_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            try
            {
                //if (e.Row.RowType == DataControlRowType.DataRow)
                //{
                //    e.Row.Attributes.Add("onMouseOver", "SetNewColor(this);");
                //    e.Row.Attributes.Add("onMouseOut", "SetOldColor(this);");
                //}

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    Label lblMapId = (Label)e.Row.FindControl("lblMailBoxId");
                    Label lbluId = (Label)e.Row.FindControl("lblUserID");

                    ImageButton imgBtn = (ImageButton)e.Row.FindControl("imgDelete");
                    ImageButton imgBtnEdit = (ImageButton)e.Row.FindControl("imgEdit");
                    if (lblMapId != null && ddlMailBox.Items.Count > 0)
                    {
                        if (ddlMailBox.Items.FindByValue(lblMapId.Text) != null)
                        {
                            if (lbluId.Text != UserData.UserId)
                            {
                                imgBtn.Enabled = true; imgBtn.ToolTip = "Delete";
                                imgBtnEdit.Enabled = true; imgBtnEdit.ToolTip = "Edit";
                            }
                            else
                            {
                                imgBtn.Enabled = false; imgBtn.ToolTip = "You can't delete this record!";
                                imgBtnEdit.Enabled = false; imgBtnEdit.ToolTip = "You can't edit this record!";
                            }
                        }
                        else if (ddlMailBox.Items.FindByValue(lblMapId.Text) == null)
                        {
                            imgBtn.Enabled = false; imgBtn.ToolTip = "You can't delete this record!";
                            imgBtnEdit.Enabled = false; imgBtnEdit.ToolTip = "You can't edit this record!";
                        }
                    }
                    //Varma - Timezone Feature On&OFF functionality 
                    if (Convert.ToString(System.Configuration.ConfigurationManager.AppSettings.Get("TimeZoneRequired")) == "ON")
                    {
                        //Pranay 10 January 2017--for changing modified date as per user TimeZone
                        // DateTime modifiedDate = Convert.ToDateTime(DataBinder.Eval(e.Row.DataItem, "ModifiedDate"));
                        //String zonedDateTime = ISSWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(modifiedDate.ToString("dd/MM/yyyy HH:mm:ss"), true, UserData.TimeZone, false);
                        Label ModifiedDate = (Label)(e.Row.FindControl("lblModifiedDate"));
                        string value = DataBinder.Eval(e.Row.DataItem, "ModifiedDate").ToString();

                        if (!String.IsNullOrEmpty(value))
                        {
                            DateTime modifiedDate = Convert.ToDateTime(DataBinder.Eval(e.Row.DataItem, "ModifiedDate"));
                            String zonedDateTime = EMTWebApp.Constants.TransformDateTime.GetZonedDateTimeToDisplay(modifiedDate.ToString("dd/MM/yyyy HH:mm:ss"), true, UserData.TimeZone, false);
                            ModifiedDate.Text = zonedDateTime;
                        }
                        else
                        {
                            ModifiedDate.Text = String.Empty;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | UserMailBoxMapping.cs | grdMailBoxMapping_RowDataBound()");  
                //errorlog.HandleError(ex, UserData.UserId, " | UserMailBoxMapping.cs | grdMailBoxMapping_RowDataBound()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// to sort the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdMailBoxMapping_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                if (ddlUserName.SelectedIndex == 0)
                {
                    GridViewSortExpression = e.SortExpression;
                    int pageIndex = grdMailBoxMapping.PageIndex;
                    grdMailBoxMapping.DataSource = SortDataTable(BindMailBoxMapgrid() as DataTable, false);
                    grdMailBoxMapping.DataBind();
                    grdMailBoxMapping.PageIndex = pageIndex;
                }
                else
                {
                    //ViewState["Sort"] = e.SortExpression;
                    //sort("UserId");
                    GridViewSortExpression = e.SortExpression;
                    int pageIndex = grdMailBoxMapping.PageIndex;
                    grdMailBoxMapping.DataSource = SortDataTable(BindUserMailBoxgridUserWise() as DataTable, false);
                    grdMailBoxMapping.DataBind();
                    grdMailBoxMapping.PageIndex = pageIndex;
                }
                
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserData.UserId, " | UserMailBoxMapping.cs | grdMailBoxMapping_Sorting()");  
                //errorlog.HandleError(Ex, UserData.UserId, " | UserMailBoxMapping.cs | grdMailBoxMapping_Sorting()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        protected void grdMailBoxMapping_Command(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.ToUpper() == "SORT")
                {
                }
                else if (e.CommandName.ToUpper() == "PAGE")
                {
                }
                else
                {
                    int index = Convert.ToInt32(e.CommandArgument);
                }
            }
            catch(Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | UserMailBoxMapping.cs | grdMailBoxMapping_Command()");  
                //errorlog.HandleError(ex, UserData.UserId, " | UserMailBoxMapping.cs | grdMailBoxMapping_Command()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            
            }
        }

        /// <summary>
        /// Row command to edit the values from the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdMailBoxMapping_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                if (!(UserData == null))
                {
                    if (e.CommandName == "EditMailBoxMap")
                    {
                        int RowIndex = Convert.ToInt32(e.CommandArgument);
                        UserId = ((Label)grdMailBoxMapping.Rows[RowIndex].FindControl("lblUserID")).Text.ToString().Trim();
                        hddnMBMapId = ((Label)grdMailBoxMapping.Rows[RowIndex].FindControl("lblMailBoxMapId")).Text.ToString().Trim();
                        if (!(UserData.UserId == UserId.Trim()))
                        {
                            string UserName = ((Label)grdMailBoxMapping.Rows[RowIndex].FindControl("lblUserName")).Text.ToString().Trim();
                            string Country = ((Label)grdMailBoxMapping.Rows[RowIndex].FindControl("lblCountry")).Text.ToString().Trim();
                            string MBoxId = ((Label)grdMailBoxMapping.Rows[RowIndex].FindControl("lblMailBoxId")).Text.ToString().Trim();
                            string MBoxName = ((Label)grdMailBoxMapping.Rows[RowIndex].FindControl("lblMailBoxName")).Text.ToString().Trim();
                            ddlUserName.SelectedIndex = ddlUserName.Items.IndexOf(ddlUserName.Items.FindByValue(UserId));
                            ddlCountry.SelectedIndex = ddlCountry.Items.IndexOf(ddlCountry.Items.FindByText(Country));
                            ddlCountry_SelectedIndexChanged(sender, e);
                            ddlMailBox.SelectedIndex = ddlMailBox.Items.IndexOf(ddlMailBox.Items.FindByValue(MBoxId));
                            hddnMBoxMapID.Value = hddnMBMapId;
                            btnMap.Text = "Update";
                            ddlUserName.Enabled = false;
                        }
                        else
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('You dont have permission to edit the Mailbox Mapping to Yourself');", true);
                        }
                    }
                    else if (e.CommandName == "DeleteMailBoxMap")
                    {
                        
                        if (!(UserData.UserId == UserId.Trim()))
                        {

                            int RowIndex = Convert.ToInt32(e.CommandArgument);
                            hddnMBMapId = ((Label)grdMailBoxMapping.Rows[RowIndex].FindControl("lblMailBoxMapId")).Text.ToString().Trim();
                            //UserId = ((Label)grdMailBoxMapping.Rows[RowIndex].FindControl("lblUserID")).Text.ToString().Trim();
                           
                            int returnvalue = _presenter.DeleteMailBoxMap(hddnMBMapId, UserId);
                            if (returnvalue == 0)//Delete Failed
                            {
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Record is not deleted!');", true);
                                BindMailBoxMapgrid();
                            }
                            if (returnvalue == 1)//Delete Success
                            {

                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Record has been deleted successfully!');", true);
                                Clearfields();
                                BindMailBoxMapgrid();
                            }
                            else if (returnvalue == 2)
                            {
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Record cannot be Deleted!!! Cases Pending under the selected User!');", true);
                                BindMailBoxMapgrid();
                            }
                        }
                        else
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('You dont have permission to delete the Mailbox Mapping to Youerself');", true);
                        }
                   
                    }
                }
            }
            catch (Exception ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | UserMailBoxMapping.cs | grdMailBoxMapping_RowCommand()");  
                //errorlog.HandleError(ex, UserData.UserId, " | UserMailBoxMapping.cs | grdMailBoxMapping_RowCommand()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }
        /// <summary>
        /// TO BIND THE LIST OF MAILBOX TO THE MAILBOX DROPDOWN BASED ON THE COUNTRY SELECTTON
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
             
                    if (!(UserData == null))
                    {
                        if (!ddlCountry.SelectedItem.Text.ToLower().Contains("select"))
                        {
                            int CountryId = Convert.ToInt32(ddlCountry.SelectedValue);
                            DataSet dsBindActiveMailBox = _presenter.BindActiveMailBox(CountryId, UserData.UserId, UserData.RoleId);
                            if (dsBindActiveMailBox.Tables[0].Rows.Count > 0)
                            {
                                ddlMailBox.DataSource = dsBindActiveMailBox;
                                ddlMailBox.DataValueField = "EMAILBOXID";
                                ddlMailBox.DataTextField = "EMAILBOXNAME";
                                ddlMailBox.DataBind();
                                ListItem select = new ListItem();
                                select.Text = "- Select -";
                                select.Value = "0";
                                ddlMailBox.Items.Insert(0, select);
                                ddlCountryId = ddlCountry.SelectedValue;
                                BindUserMailBoxgridUserWise();
                            }
                            else
                            {
                                lblmsg.Visible = true;
                                ddlMailBox.Items.Clear();
                                ListItem select = new ListItem();
                                select.Text = "- Select -";
                                select.Value = "0";
                                ddlMailBox.Items.Insert(0, select);
                                lblmsg.Text = "No Records Found";
                                grdMailBoxMapping.Visible = false;
                            }
                        }
                        else
                        {
                            ddlMailBox.Items.Clear();
                            ListItem select = new ListItem();
                            select.Text = "- Select -";
                            select.Value = "0";
                            ddlMailBox.Items.Insert(0, select);
                        }
                        ddlCountry.Focus();
                    }

                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('You dont have permission to delete the Mailbox Mapping to Youerself');", true);

                    }
              
            }
            catch (Exception ex)
            {
               // ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserData.UserId, " | UserMailBoxMapping.cs | ddlCountry_SelectedIndexChanged()");  
                //errorlog.HandleError(ex, UserData.UserId, " | UserMailBoxMapping.cs | ddlCountry_SelectedIndexChanged()");
                Response.Clear();
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
                Response.End();
            }
        }

        protected void ddlUserName_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindUserMailBoxgridUserWise();
        }
        #endregion
    }
}