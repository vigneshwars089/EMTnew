﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net.Mail;
using System.Configuration;
using EMTWebApp.Constants;
using DigiOPS.TechFoundation.Security;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.ExceptionHandling;
using System.Security;
using System.Runtime.InteropServices;
using System.Web.Security;
using System.Text.RegularExpressions;

namespace EMTWebApp.UserManagement.Views
{
    public partial class ForgotPassword : Microsoft.Practices.CompositeWeb.Web.UI.Page, IForgotPasswordView
    {
        #region DECLARATIONS
        private ForgotPasswordPresenter _presenter;
        public string LoginID;
        UserErrorLog errorlog = new UserErrorLog();
        string CheckWhichLoginType = ConfigurationManager.AppSettings["ADLogin"].ToString();
        string encryptionmode = ConfigurationManager.AppSettings["ENCRYPT/DECRYPT"].ToString();
        SecurityFactory securityFactory = new SecurityFactory();
        private const string AntiXsrfTokenKey = "__AntiXsrfToken";
        private const string AntiXsrfUserNameKey = "__AntiXsrfUserName";
        private string _antiXsrfTokenValue;
        #endregion


        protected void Page_Init(object sender, EventArgs e)
        {
            //if (Session.IsNewSession)
            //{
            //    Session["UserDetails"] = DateTime.Now;
            //}
            Page.ViewStateUserKey = Session.SessionID;
            if (Page.EnableViewState)
            {

                if (!string.IsNullOrEmpty(Request.Params["__VIEWSTATE"]) && string.IsNullOrEmpty(Request.Form["__VIEWSTATE"]))
                {
                    throw new Exception("Cross Site History Manipulation happened...");
                }
            }

            // The code below helps to protect against XSRF attacks
            var requestCookie = Request.Cookies[AntiXsrfTokenKey];
            Guid requestCookieGuidValue;
            if (requestCookie != null && Guid.TryParse(requestCookie.Value, out requestCookieGuidValue))
            {
                // Use the Anti-XSRF token from the cookie
                _antiXsrfTokenValue = requestCookie.Value;
                Page.ViewStateUserKey = _antiXsrfTokenValue;
            }
            else
            {
                // Generate a new Anti-XSRF token and save to the cookie
                _antiXsrfTokenValue = Guid.NewGuid().ToString("N");
                Page.ViewStateUserKey = _antiXsrfTokenValue;

                var responseCookie = new HttpCookie(AntiXsrfTokenKey)
                {
                    HttpOnly = true,
                    Value = _antiXsrfTokenValue
                };
                if (FormsAuthentication.RequireSSL && Request.IsSecureConnection)
                {
                    responseCookie.Secure = true;
                }
                Response.Cookies.Set(responseCookie);
            }

            Page.PreLoad += Page_PreLoad;
        }

        protected void Page_PreLoad(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Set Anti-XSRF token
                ViewState[AntiXsrfTokenKey] = Page.ViewStateUserKey;
                ViewState[AntiXsrfUserNameKey] = Context.User.Identity.Name ?? String.Empty;
            }
            else
            {
                // Validate the Anti-XSRF token
                if ((string)ViewState[AntiXsrfTokenKey] != _antiXsrfTokenValue
                    || (string)ViewState[AntiXsrfUserNameKey] != (Context.User.Identity.Name ?? String.Empty))
                {
                    throw new InvalidOperationException("Validation of Anti-XSRF token failed.");
                }
            }
        }        /// <summary>
        /// Allows the user to enter his/her Login Id
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //iterate through all the params and check for sql injection - saranya
            Regex regex = new Regex(System.Configuration.ConfigurationManager.AppSettings["SQLInjectionRegex"]);
                      
            foreach (string key in HttpContext.Current.Request.Form.Keys)
            {                
                if (!String.IsNullOrEmpty(Request.Form[key]) && regex.Match(Request.Form[key]).Success)
                {
                    Server.Transfer(@"~/Errors/BadRequest.aspx");
                }
            }
            try
            {
                if (!this.IsPostBack)
                {
                    this._presenter.OnViewInitialized();
                    Regex regex1 = new Regex(@"^[a-zA-Z0-9 ]*$");
                    if (txtLoginId.Value.Trim() != "")
                    {
                    Match matchtxtLoginId = regex.Match(txtLoginId.Value.Trim());
                    if (string.IsNullOrEmpty(txtLoginId.Value.Trim()) || matchtxtLoginId.Success)
                    {
                        LoginID = txtLoginId.Value.Trim();
                        txtLoginId.Focus();
                        txtLoginId.Visible = true;
                        submit.Visible = true;
                    }
                    else
                    {
                        Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                    }
                }
                    //Pranay 3rd May 2017 --DastIssue Fix---User able to access application without resetting password
                    string PKeyword = (Session["PasswordExpiration"]).ToString();
                    if (PKeyword == "yes")
                    {
                        Server.Transfer(@"~/Errors/BadRequest.aspx?r=(new Random()).nextInt()");
                    }
                }
                    this._presenter.OnViewLoaded();
              
            }

            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex,System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(LoginID,true), " | ForgotPassword.aspx.cs | Page_Load()");  
                //errorlog.HandleError(ex, LoginID, " | ForgotPassword.aspx.cs | Page_Load()");
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex,System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(LoginID,true), "ForgotPassword.aspx.cs | Page_Load()");  
                //errorlog.HandleError(Ex,LoginID, "ForgotPassword.aspx.cs | Page_Load()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }

        //void Page_Init(object sender, EventArgs e)
        //{
        //    if (Session.IsNewSession)
        //    {
        //        Session["UserDetails"] = DateTime.Now;
        //    }
        //    this.ViewStateUserKey = Session.SessionID;
        //    if (Page.EnableViewState)
        //    {
        //        if (!string.IsNullOrEmpty(Request.Params["__VIEWSTATE"]) && string.IsNullOrEmpty(Request.Form["__VIEWSTATE"]))
        //        {
        //            throw new Exception("Cross Site History Manipulation happened...");
        //        }
        //    }
        //}
        #region PROPERTIES
        [CreateNew]
        public ForgotPasswordPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion

        #region EVENTS
        /// <summary>
        /// Event to allow the user to navigate to the login page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lnkLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AuthenticationandAuthorization/Login.aspx", false);
        }
        /// <summary>
        /// Event to send the User's Password in the mail
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            SecureString sec_strPassword = new SecureString();
            SecureString sec_strPassword1 = new SecureString();
            try
            {
                submit.Visible = false;
                string Subject = "Email Management Tool - Your Password ";
                Regex regex = new Regex(@"^[a-zA-Z0-9 ]*$");
                Match matchtxtLoginId = regex.Match(txtLoginId.Value.Trim());
                if (matchtxtLoginId.Success)
                {
                    LoginID = txtLoginId.Value.Trim();
                    int returnvalue = _presenter.ValidateLogin(LoginID);
                    if (returnvalue == 0)
                    {
                        securityFactory.GetUserSecurityHandler("AD").IsLogEnabled(LoginID + "Given UserId does not exists!!!" + "ForgotPassword.aspx.cs|btnSubmit_Click", true);
                        //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Given UserId does not exists!!');", true);
                        lblErrorMsg.Text = "Given UserId does not exists!!!";
                        submit.Visible = true;
                        txtLoginId.Focus();
                    }
                    else
                    {
                        DataSet ds = _presenter.ForgotPassword(LoginID);
                        if (ds.Tables.Count > 0 && (ds.Tables[0].Rows.Count > 0 && ds.Tables[1].Rows.Count > 0))
                        {
                            string FirstName, LastName, To, MailBoxLoginId, EmailBoxId;
                            FirstName = ds.Tables[0].Rows[0]["FirstName"].ToString();
                            LastName = ds.Tables[0].Rows[0]["LastName"].ToString();
                            //Password = Constants.HelperMethods.DecryptValue(ds.Tables[0].Rows[0]["Password"].ToString());
                            //Decryption                
                            //cryptInfo.CryptKey = cipherpassword;
                            //cryptInfo.ValueToCrypt = ds.Tables[0].Rows[0]["Password"].ToString();
                            //Password = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);                        
                            //  Password = Constants.HelperMethods.DecryptString(ds.Tables[0].Rows[0]["Password"].ToString());
                            ForgotPassword miscObj = new ForgotPassword();
                            if (encryptionmode == "ON")
                            {
                                //UserCredentials
                            sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.DecryptString(ds.Tables[0].Rows[0]["Password"].ToString()));
                                //MailboxCredentials
                                sec_strPassword1 = miscObj.convertToSecureString(Constants.HelperMethods.DecryptString(ds.Tables[1].Rows[0]["Password"].ToString()));
                            }
                            else
                            {
                                //UserCredentials
                                sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.DecryptValue(ds.Tables[0].Rows[0]["Password"].ToString()));
                                //MailboxCredentials
                                sec_strPassword1 = miscObj.convertToSecureString(Constants.HelperMethods.DecryptValue(ds.Tables[1].Rows[0]["Password"].ToString()));
                            }

                            To = ds.Tables[0].Rows[0]["Email"].ToString();
                            EmailBoxId = ds.Tables[0].Rows[0]["EMailBoxAddress"].ToString();
                            MailBoxLoginId = ds.Tables[1].Rows[0]["EMailId"].ToString();
                            //MailBoxPassword = Constants.HelperMethods.DecryptValue(ds.Tables[1].Rows[0]["Password"].ToString());
                            //Decryption                
                            //cryptInfo.CryptKey = cipherpassword;
                            //cryptInfo.ValueToCrypt = ds.Tables[1].Rows[0]["Password"].ToString();
                            //MailBoxPassword = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
                            //MailBoxPassword = Constants.HelperMethods.DecryptString(ds.Tables[1].Rows[0]["Password"].ToString());

                            


                            if (To != string.Empty)
                            {
                                //Decrypt password
                                //string Body = "Hi " + FirstName + " " + LastName + ",\r\n\r\n";
                                //Body += "Please find your details below for EMT Login.\r\n";
                                //Body += "\r\n Login Id :" + txtLoginId.Text + "\r\n Password  :" + DecryptPassword;
                                //Body += "\r\n PASSWORDS ARE CASE SENSITIVE. \r\n\r\n URL : " + ConfigurationManager.AppSettings["EMTURL"].ToString();
                                //Body += "\r\n\n*Note : THIS IS A SYSTEM GENERATED MAIL. PLEASE DO NOT REPLY!.\r\n\r\n";
                                //string MailBoxEmailId = ConfigurationManager.AppSettings.Get("MailBoxEmailId");
                                //string LoginEmailId = ConfigurationManager.AppSettings.Get("LoginEmailId");
                                string ServiceURL = ConfigurationManager.AppSettings.Get("ClientServiceURL");
                                //MailBoxPassword = ConfigurationManager.AppSettings.Get("MailBoxPassword");

                                string strHeader = string.Empty;
                                string strBody = string.Empty;
                                string strFooter = string.Empty;

                                strHeader += "<table width='60%' border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse; border-color: #333333;'>";
                                strHeader += "<tr><td style='height:200px;' valign='top'><table width='100%' border='0' cellpadding='0' cellspacing='0'>";
                                strHeader += "<tr><td style='height: 3px; background-color: #05A4B7;'></td></tr>";
                                strBody += "<tr><td style='font-family:Verdana; font-size:12px; color:#333333; height:200px; padding-left:10px; padding-Right:10px;' valign='middle'>";
                                strBody += "Hi " + FirstName + " " + LastName + ",<br/><br/>" + "Please find your details below for Patheon EMT Login. <br/><br/> Login Id: " + txtLoginId.Value +
                                    "<br/> Password: " + miscObj.convertToUNSecureString(sec_strPassword) + "<br><br><b>Note: This is a System Generated Mail. We request you not to reply to this message.</b><br><br><br><br>";
                                strBody += "Regards<br>Patheon EMT Helpdesk<br></td>";
                                strFooter += "<tr><td style='height: 3px; background-color: #05A4B7;'></td></tr></table></table>";

                                strBody = strHeader + strBody + strFooter;

                                if (HelperMethods.ForgotPasswordSendMail(MailBoxLoginId, EmailBoxId, miscObj.convertToUNSecureString(sec_strPassword1), ServiceURL, To, Subject, strBody))
                                {
                                    //emailClient.Send(message);
                                    lblErrorMsg.Text = "Your password has been sent to your MailID (" + To + "). Please check your mail.";
                                    txtLoginId.Visible = false;
                                }
                                else
                                {
                                    submit.Visible = true;
                                    lblErrorMsg.Text = "Your password can't be sent. Please try later.";
                                }
                            }
                            else
                            {
                                //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Hi, Email Id has not been configured to your Login Id.<br/> Please contact Admin);", true);
                                lblErrorMsg.Text = "Hi, Email Id has not been configured to your Login Id.<br/> Please contact Admin.";
                            }
                        }
                        else
                        {
                            //ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Hi, Your account had been locked or Loginid may be invalid.<br/> Please contact Admin);", true);
                            lblErrorMsg.Text = "Hi, Your account had been locked or Loginid may be invalid.<br/> Please contact Admin";
                        }
                    }
                }
                else
                {
                    Response.Redirect(@"~/Errors/BadRequest.aspx", false);
                }
            }
            catch (EMTException ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(LoginID, true), " | ForgotPassword.aspx.cs | btnSubmit_Click()");
                //errorlog.HandleError(ex, LoginID, " | ForgotPassword.aspx.cs | btnSubmit_Click()");
            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, System.Web.Security.AntiXss.AntiXssEncoder.HtmlEncode(LoginID, true), " | ForgotPassword.aspx.cs | btnSubmit_Click()");
                //errorlog.HandleError(ex, LoginID , " | ForgotPassword.aspx.cs | btnSubmit_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + HelperMethods.GenerateSecureRandom(), false);
            }
        }
        #endregion

        public SecureString convertToSecureString(string strPassword)
        {
            var secureStr = new SecureString();
            if (strPassword.Length > 0)
            {
                foreach (var c in strPassword.ToCharArray()) secureStr.AppendChar(c);
            }
            return secureStr;
        }

        /// <summary>
        /// SecureString method to retrive the data
        /// </summary>
        /// <param name="secstrPassword"></param>
        /// <returns></returns>


        public string convertToUNSecureString(SecureString secstrPassword)
        {
            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(secstrPassword);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }
    }
}