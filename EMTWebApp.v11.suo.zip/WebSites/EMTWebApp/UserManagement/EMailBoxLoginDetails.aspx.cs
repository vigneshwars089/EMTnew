﻿using System;
using Microsoft.Practices.ObjectBuilder;
using EMTWebApp.UserManagement.Common;
using System.Collections;
using System.Data;
using EMTWebApp.ExceptionHandler;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using EMTWebApp.Constants;
using DigiOPS.TechFoundation.Security;
using System.Security;
using System.Runtime.InteropServices;
using DigiOPS.TechFoundation.Logging;
using System.Configuration;

namespace EMTWebApp.UserManagement.Views
{
    public partial class EMailBoxLoginDetails : Microsoft.Practices.CompositeWeb.Web.UI.Page, IEMailBoxLoginDetailsView
    {
        #region DECLARATION
        private EMailBoxLoginDetailsPresenter _presenter;
        UserSession UserDetails = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();        
        string cipher = ConfigurationManager.AppSettings["ENCRYPT/DECRYPT"].ToString();
        #endregion
        /// <summary>
        /// To bind the MailBox Login Details grid and to initialize other controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Session["CurrentPage"] = "Client Configuration";
                UserDetails = (UserSession)Session["UserDetails"];
                IsValidRoleToAccessThisPage(UserDetails);
                RedirectToErrorPage(UserDetails);
                if (!this.IsPostBack)
                {
                    this._presenter.OnViewInitialized();
                    if (Session["UserDetails"] != null)
                    {
                        Page.Form.DefaultButton = btnSubmit.UniqueID;
                        txtMBoxloginid.Focus();
                        BindMailBoxLoginDetails();
                    }
                    else
                    {
                        Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
                    }
                }
                this._presenter.OnViewLoaded();
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | Page_Load()");     
               // errorlog.HandleError(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | Page_Load()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }
        #region PROPERTIES
        [CreateNew]
        public EMailBoxLoginDetailsPresenter Presenter
        {
            get
            {
                return this._presenter;
            }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");

                this._presenter = value;
                this._presenter.View = this;
            }
        }
        #endregion
        #region METHODS

        /// <summary>
        /// Method to Check if roleId logged in can access this page or not.
        /// </summary>
        private bool IsValidRoleToAccessThisPage(UserSession UserDetails)
        {
            try
            {
                if ((UserDetails.RoleId == (int)Constant.UserRole.SuperAdmin))
                {
                    return true;
                }
                else
                {
                    Response.Redirect("~/Errors/AccessDenied.aspx", false);
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | IsValidRoleToAccessThisPage()");     
               // errorlog.HandleError(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | IsValidRoleToAccessThisPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
            return false;
        }

        /// <summary>
        /// Method to redirect to Error page if userdetails are null
        /// </summary>
        private void RedirectToErrorPage(UserSession UserDetails)
        {
            try
            {
                if (UserDetails == null)
                {
                    Response.Redirect(@"~\Errors\Error.aspx",false);
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | RedirectToErrorPage()");     
               // errorlog.HandleError(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | RedirectToErrorPage()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }

        /// <summary>
        /// Function to clear the fields 
        /// </summary>
        public void ClearFields()
        {
            txtMBoxloginid.Text = "";
            txtPKeyword.Text = "";
            txtConfirmPKeyword.Text = "";
            txtConfirmPKeyword.Visible = true;
            txtPKeyword.Visible = true;
            lblPKeyword.Visible = true;
            lblConfirmPKeyword.Visible = true;
            chkActive.Checked = true;
            chkLocked.Checked = false;
            btnSubmit.Text = "Submit";
            txtMBoxloginid.Focus();
        }
        /// <summary>
        /// TO BIND THE EMAILBOX LOGIN DETAILS TO THE GRID
        /// </summary>
        public void BindMailBoxLoginDetails()
        {
            try
            {
                grdMailboxLogin.DataSource = this._presenter.GridEmailBoxLoginDetailsBind();
                grdMailboxLogin.DataBind();
                ViewState["MailboxLoginDetails"] = grdMailboxLogin.DataSource;
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | BindMailBoxLoginDetails()");     
               // errorlog.HandleError(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | BindMailBoxLoginDetails()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }
        protected void sort(string StrParam)
        {
            try
            {
                if (ViewState["SortDirection"] == null)
                {
                    ViewState["SortDirection"] = "asc";
                }
                else if (ViewState["SortDirection"].ToString() == "asc")
                {
                    ViewState["SortDirection"] = "desc";
                }
                else
                {
                    ViewState["SortDirection"] = "asc";
                }
                BindGrid(StrParam);
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | sort()");     
                //errorlog.HandleError(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | sort()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }
        private void BindGrid(string StrParameter)
        {
            try
            {
                string Sortexpression = "";
                string sortdirection = "";
                if (ViewState["Sort"] == null)
                {
                    Sortexpression = StrParameter;
                }
                else
                {
                    Sortexpression = ViewState["Sort"].ToString();
                }
                if (ViewState["SortDirection"] == null)
                {
                    sortdirection = "asc";
                }
                else
                {
                    sortdirection = ViewState["SortDirection"].ToString();
                }
                DataTable dtWorkList = new DataTable();
                GetWorkList(Sortexpression, sortdirection);
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | BindGrid()");     
               // errorlog.HandleError(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | BindGrid()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }
        protected void GetWorkList(string SortExpression, string SortDirection)
        {
            try
            {
                DataSet ds = new DataSet();
                ds = (DataSet)ViewState["MailboxLoginDetails"];
                DataView dv = new DataView();
                dv = ds.Tables[0].DefaultView;
                dv.Sort = SortExpression + " " + SortDirection;
                grdMailboxLogin.DataSource = dv;
                grdMailboxLogin.DataBind();
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | GetWorkList()");     
                //errorlog.HandleError(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | GetWorkList()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }
        #endregion
        #region EVENTS
        /// <summary>
        /// to sort the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdMailboxLogin_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                ViewState["Sort"] = e.SortExpression;
                sort("EmailBoxLoginDetailID");
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | grdMailboxLogin_Sorting()");     
               // errorlog.HandleError(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | grdMailboxLogin_Sorting()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }
        /// <summary>
        /// BUTTON SUBMIT EVENT TO ADD THE EMAILBOX LOGIN DETAILS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            SecureString sec_strPassword = new SecureString();
            SecureString sec_strPassword1 = new SecureString();
            try
            {
                EMailBoxLoginDetails miscObj = new EMailBoxLoginDetails();
                string MailId = txtMBoxloginid.Text.Trim();
                //Encryption                
                ////cryptInfo.CryptKey = cipherpassword;
                ////cryptInfo.ValueToCrypt = txtPassword.Text.Trim();
                ////string EncryptPassword = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
                ////cryptInfo.ValueToCrypt = EncryptPassword;
              //  string EncryptPassword = Constants.HelperMethods.EncryptString(txtPassword.Text.Trim());


                //-modified to secureString---//
                if(cipher=="ON")
                {
                sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.EncryptString(txtPKeyword.Text.Trim()));
                    sec_strPassword1 = miscObj.convertToSecureString(Constants.HelperMethods.EncryptString(txtConfirmPKeyword.Text.Trim()));
                }
                else
                {
                    sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.EncryptValue(txtPKeyword.Text.Trim()));
                    sec_strPassword1 = miscObj.convertToSecureString(Constants.HelperMethods.EncryptValue(txtConfirmPKeyword.Text.Trim()));
                }


                //cryptInfo.ValueToCrypt = txtConfirmPassword.Text.Trim();
                //string EncryptConfirmPassword = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
                //cryptInfo.ValueToCrypt = EncryptConfirmPassword;                       
               
                // string EncryptConfirmPassword = Constants.HelperMethods.EncryptString(txtConfirmPassword.Text.Trim());

                //-modified to secureString---//
                

                //string EncryptPassword = Constants.HelperMethods.EncryptValue(txtPassword.Text);
                //string EncryptConfirmPassword = Constants.HelperMethods.EncryptValue(txtConfirmPassword.Text);
                int Locked, Active;
                if (chkLocked.Checked == true)
                {
                    Locked = 1;
                }
                else
                {
                    Locked = 0;
                }

                if (chkActive.Checked == true)
                {
                    Active = 1;
                }
                else
                {
                    Active = 0;
                }

                if (miscObj.convertToUNSecureString(sec_strPassword) ==miscObj.convertToUNSecureString(sec_strPassword1))
                {
                    if (btnSubmit.Text == "Submit")
                    {
                        {
                            int returnValue = _presenter.InsertMailLoginDetails(MailId, miscObj.convertToUNSecureString(sec_strPassword1), Locked, Active);
                            if (returnValue == 0)//FAILURE ALERT
                            {
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Details already exists!');", true);
                                BindMailBoxLoginDetails();
                            }
                            else//SUCCESS ALERT
                            {
                                ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Details Added Successfully!');", true);
                                ClearFields();
                                txtMBoxloginid.Focus();
                                BindMailBoxLoginDetails();
                            }
                        }
                    }
                    else//UPDATING THE FIELDS
                    {
                        string EmailBoxLoginDetailID = HddnLogDetID.Value;
                        int returnvalue = _presenter.UpdateMailBoxLoginDetails(EmailBoxLoginDetailID, MailId, miscObj.convertToUNSecureString(sec_strPassword1), Locked, Active);
                        if (returnvalue == 0)//FAILURE ALERT
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update Falied!');", true);
                            ClearFields();
                            BindMailBoxLoginDetails();
                            btnSubmit.Text = "Submit";
                        }
                        if (returnvalue == 1)//SUCCESS ALERT
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Update Successful!');", true);
                            ClearFields();
                            BindMailBoxLoginDetails();
                            btnSubmit.Text = "Submit";
                        }
                    }
                }
                else//ALERT WHEN THE PROVIDED PASSWORDS ARE NOT SAME
                {
                    ScriptManager.RegisterClientScriptBlock(Page, this.GetType(), "Success", "alert('Passwords Mismatch!');", true);
                    txtPKeyword.Focus();
                    BindMailBoxLoginDetails();
                }

            }
            catch (Exception ex)
            {
                //ExceptionHelper.HandleException(ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | btnSubmit_Click()");     
              //  errorlog.HandleError(ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | btnSubmit_Click()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }
        /// <summary>
        /// BUTTON RESET EVENT TO CLEAR ALL THE FIELDS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnreset_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        /// <summary>
        /// ROW COMMAND EVENT TO EDIT THE VALUES FROM THE GRID
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdMailboxLogin_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            SecureString sec_strPassword = new SecureString();
            try
            {
                if (e.CommandName == "EditLoginDetails")
                {
                    int RowIndex = Convert.ToInt32(e.CommandArgument);
                    string LogDetId = ((Label)grdMailboxLogin.Rows[RowIndex].FindControl("lblEmailBoxLoginDetailID")).Text.ToString().Trim();
                    string EmailId = ((Label)grdMailboxLogin.Rows[RowIndex].FindControl("lbleMailId")).Text.ToString().Trim();
                    string Pkeyword = ((Label)grdMailboxLogin.Rows[RowIndex].FindControl("lblPKeyword")).Text.ToString().Trim();
                    string IsLocked = ((Label)grdMailboxLogin.Rows[RowIndex].FindControl("lblIsLocked")).Text.ToString().Trim();
                    string IsActive = ((Label)grdMailboxLogin.Rows[RowIndex].FindControl("lblIsActive")).Text.ToString().Trim();

                  //  string EncryptPassword = Constants.HelperMethods.DecryptValue(Pwd);
                  //  Pwd = EncryptPassword;

                    EMailBoxLoginDetails miscObj = new EMailBoxLoginDetails();
                    if(cipher=="ON")
                    {
                        sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.DecryptString(Pkeyword));
                    }
                    else
                    {
                        sec_strPassword = miscObj.convertToSecureString(Constants.HelperMethods.DecryptValue(Pkeyword));
                    }
                    



                    txtMBoxloginid.Text = EmailId;
                    HddnLogDetID.Value = LogDetId;
                    if (IsLocked == "No")
                    {
                        chkLocked.Checked = false;
                    }
                    else
                    {
                        chkLocked.Checked = true;
                    }
                    if (IsActive == "Yes")
                    {
                        chkActive.Checked = true;
                    }
                    else
                    {
                        chkActive.Checked = false;
                    }
                    btnSubmit.Text = "Update";
                    btnSubmit.ValidationGroup = "Submit";
                    //txtConfirmPassword.Visible = false;
                    //txtPassword.Visible = false;
                    //lblPassword.Visible = false;
                    //lblConfirmPassword.Visible = false;
                }
            }
            catch (Exception Ex)
            {
               // ExceptionHelper.HandleException(Ex);
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | grdMailboxLogin_RowCommand()");     
                //errorlog.HandleError(Ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | grdMailboxLogin_RowCommand()");
                Response.Redirect("~/Errors/Error.aspx?r=" + (new Random()).Next(), false);
            }
        }
        /// <summary>
        /// TO CHANGE THE PAGE OF THE GRID
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdMailboxLogin_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdMailboxLogin.PageIndex = e.NewPageIndex;
                grdMailboxLogin.EditIndex = -1;
                BindMailBoxLoginDetails();
            }
            catch (Exception ex)
            {
                new LoggingFactory().GetLoggingHandler("Log4net").LogException(ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | grdMailboxLogin_PageIndexChanging()");     
               // errorlog.HandleError(ex, UserDetails.UserId, " | EMailBoxLoginDetails.cs | grdMailboxLogin_PageIndexChanging()");
                Response.Redirect(@"~\Errors\Error.aspx",false);
            }
        }
        #endregion

        /// <summary>
        /// SecureString method to retrieve the sensitive Data
        /// ModifiedBy : Natarajan(577343)
        /// </summary>
        /// <param name="strPassword"></param>
        /// <returns></returns>
        public SecureString convertToSecureString(string strPassword)
        {
            var secureStr = new SecureString();
            if (strPassword.Length > 0)
            {
                foreach (var c in strPassword.ToCharArray()) secureStr.AppendChar(c);
            }
            return secureStr;
        }


        public string convertToUNSecureString(SecureString secstrPassword)
        {
            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(secstrPassword);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

    }
}