using System;

namespace EMTWebApp.UserManagement
{
    public interface IUserManagementController
    {
        
    }
}
