﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EMTWebApp.UserManagement.Common
{
    [Serializable]
    public class UserSession
    {
        private string userId;

        public string UserId
        {
            get { return userId; }
            set { userId = value; }

        }

        private string firstName;

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }

        }

        private string lastName;

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }

        }

        private int roleId;

        public int RoleId
        {
            get { return roleId; }
            set { roleId = value; }
        }

        private string roleName;

        public string RoleName
        {
            get { return roleName; }
            set { roleName = value; }
        }

        //Pranay 5 January 2017 --adding TimeZone for User Session

        private string timeZone;

        public string TimeZone
        {
            get { return timeZone; }
            set { timeZone = value; }
        }

        //Pranay 18 janauary 2017 -- adding offset for User Session fo Report purpose
        private string offset;

        public string OffSet
        {
            get { return offset; }
            set { offset = value; }
        }

        public object PKeywordExpiration { get; set; }
    }
    [Serializable]
    public class EMailBoxCredentials
    {
        private string mailboxemailid;

        public string MailBoxEmailId
        {
            get { return mailboxemailid; }
            set { mailboxemailid = value; }
        }

        private string mailboxemailidoptional;
        public string MailBoxEmailIdOptional
        {
            get { return mailboxemailidoptional; }
            set { mailboxemailidoptional = value; }
        }

        private string loginemailid;

        public string LoginEmailId
        {
            get { return loginemailid; }
            set { loginemailid = value; }

        }

        private string pkeyword;

        public string PKeyword
        {
            get { return pkeyword; }
            set { pkeyword = value; }

        }

        private string serviceurl;

        public string ServiceURL
        {
            get { return serviceurl; }
            set { serviceurl = value; }
        }
        private bool isreplynotrequired;

        public bool isReplyNotRequired
        {
            get { return isreplynotrequired; }
            set { isreplynotrequired = value; }
        }

        private bool islocked;

        public bool isLocked
        {
            get { return islocked; }
            set { islocked = value; }
        }
    }
}
