using System;
using System.Data;
using EMTWebApp.DataService.UserManagement;
using System.Collections;
namespace EMTWebApp.UserManagement
{
    public class UserManagementController : IUserManagementController
    {
        IUserManagementDataService _UserManagementDataService = new UserManagementDataService();
        public UserManagementController()
        {

        }
        public int AddUser(string UserID, string FirstName, string LastName, string EmailID, string Password, int Active, string LoginId, string TimeZone, string OffSet,string SkillSet,string SkillDescription, bool isTimezone)
        {
            return _UserManagementDataService.AddUser(UserID, FirstName, LastName, EmailID, Password, Active, LoginId, TimeZone, OffSet,SkillSet,SkillDescription, isTimezone);
        }

        public DataSet GridBind()
        {
            return _UserManagementDataService.GridBind();
        }

        public DataSet GetSkillSet()
        {
            return _UserManagementDataService.GetSkillSet();
        }

        public DataSet GetUsercount()
        {
            return _UserManagementDataService.GetUsercount();
        }


        public int UpdateUser(string UserID, string FirstName, string LastName, string EmailID, string Password, int Active, string LoginId, string TimeZone, string OffSet,string SkillSet,string SkillDescription, bool isTimezone)
        {
            return _UserManagementDataService.UpdateUser(UserID, FirstName, LastName, EmailID, Password, Active, LoginId, TimeZone, OffSet,SkillSet,SkillDescription, isTimezone);
        }

        public int ValidatePassword(string UserID, string encryptOldPassword)
        {
            return _UserManagementDataService.ValidatePassword(UserID, encryptOldPassword);
        }

        public int ChangePassword(string txtLoginID, string encryptOldPassword, string encryptConfirmPassword)
        {
            return _UserManagementDataService.ChangePassword(txtLoginID, encryptOldPassword, encryptConfirmPassword);
        }

        public int ValidateLogin(string LoginId)
        {
            return _UserManagementDataService.ValidateLogin(LoginId);
        }

        public DataSet ForgotPassword(string loginId)
        {
            return _UserManagementDataService.ForgotPassword(loginId);
        }
        public DataSet GetSignature(string loginId)
        {
            return _UserManagementDataService.GetSignature(loginId);
        }
        public int ConfigureSignature(string Signature, string LoginId)
        {
            return _UserManagementDataService.ConfigureSignature(Signature, LoginId);
        }

        public int UpdateSignature(string SignId, string Signature,  string LoginId)
        {
            return _UserManagementDataService.UpdateSignature(SignId, Signature, LoginId);
        }
        public DataSet BindRole()
        {
            return _UserManagementDataService.BindRole();
        }

        public DataSet BindActiveUsers()
        {
            return this._UserManagementDataService.BindActiveUsers();
        }
        public DataSet GetCountryByUserIdForDashboard(Hashtable hs)
        {
            return this._UserManagementDataService.GetCountryByUserIdForDashboard(hs);
        }
        public DataSet BindCountryChekBoxList()
        {
            return this._UserManagementDataService.BindCountryChekBoxList();
        }
        public int MapUserRole(string UserId, int RoleId, string LoginId, string strCountryIdsToMap)
        {
            return this._UserManagementDataService.MapUserRole(UserId, RoleId, LoginId, strCountryIdsToMap);
        }

        public DataSet BindCountry()
        {
            return this._UserManagementDataService.BindCountry();
        }

        public int UpdateRoleMap(string UserRoleMapId, string UserId, int RoleId, string LoginId, string CountryIdsToMap)
        {
            return this._UserManagementDataService.UpdateRoleMap(UserRoleMapId, UserId, RoleId, LoginId, CountryIdsToMap);
        }

        public int DeleteRoleMap(string hddnRMapId)
        {
            return this._UserManagementDataService.DeleteRoleMap(hddnRMapId);
        }

        public DataSet GridUserRoleMapBind()
        {
            return this._UserManagementDataService.GridUserRoleMapBind();
        }

        public DataSet UserWiseRoleMapGridBind(string UserId)
        {
            return this._UserManagementDataService.UserWiseRoleMapGridBind(UserId);
        }

        public DataSet BindActiveMailBox(int CountryId, string LoggedInUserId, int LoggedInUserRoleId)
        {
            return this._UserManagementDataService.BindActiveMailBox(CountryId, LoggedInUserId, LoggedInUserRoleId);
        }

        public int MapUserMailBox(string UserId, int MailBoxId, string LoginId)
        {
            return this._UserManagementDataService.MapUserMailBox(UserId, MailBoxId, LoginId);
        }

        public int ConfigureRemaindertoMailbox(Hashtable htUserData)
        {
            return this._UserManagementDataService.ConfigureRemaindertoMailbox(htUserData);
        }
        public int ConfigureCategorytoMailbox(Hashtable htUserData)
        {
            return this._UserManagementDataService.ConfigureCategorytoMailbox(htUserData);
        }
        public DataSet GridMailBoxMapBind(Hashtable hs)
        {
            return this._UserManagementDataService.GridMailBoxMapBind(hs);
        }
        public DataSet GridMailBoxRemainderBind(Hashtable hs)
        {
            return this._UserManagementDataService.GridMailBoxRemainderBind(hs);
        }
        public DataSet GridMailBoxcategoryBind(Hashtable hs)
        {
            return this._UserManagementDataService.GridMailBoxcategoryBind(hs);
        }

        public DataSet UserWiseMailBoxMapGridBind(string UserId, string ddlCountryId)
        {
            return this._UserManagementDataService.UserWiseMailBoxMapGridBind(UserId, ddlCountryId);
        }

        public int UpdateUserMailBoxMap(string UserMailBoxMapId, string UserId, int MailBoxId, string LoginId)
        {
            return this._UserManagementDataService.UpdateUserMailBoxMap(UserMailBoxMapId, UserId, MailBoxId, LoginId);
        }

        public int UpdateConfigureRemaindertoMailbox(Hashtable hs )
        {
            return this._UserManagementDataService.UpdateConfigureRemaindertoMailbox(hs);
        }
        public int UpdateConfigurecategorytoMailbox(Hashtable hs)
        {
            return this._UserManagementDataService.UpdateConfigurecategorytoMailbox(hs);
        }

        public int DeleteMailBoxMap(string hddnMBMapId, string UserId)
        {
            return this._UserManagementDataService.DeleteMailBoxMap(hddnMBMapId, UserId);
        }

        public int InsertMailLoginDetails(string MailId, string encryptConfirmPassword, int Locked, int Active)
        {
            return this._UserManagementDataService.InsertMailLoginDetails(MailId, encryptConfirmPassword, Locked, Active);
        }

        public DataSet GridEmailBoxLoginDetailsBind()
        {
            return this._UserManagementDataService.GridEmailBoxLoginDetailsBind();
        }

        public int UpdateMailBoxLoginDetails(string EmailBoxLoginDetailID, string MailId, string EncryptConfirmPassword, int Locked, int Active)
        {
            return this._UserManagementDataService.UpdateMailBoxLoginDetails(EmailBoxLoginDetailID, MailId, EncryptConfirmPassword, Locked, Active);
        }


        public int ConfigureEscalationMatrix(Hashtable htUserData)
        {
            return this._UserManagementDataService.ConfigureEscalationMatrix(htUserData);
        }
        public int UpdateConfigureEscalationMatrix(Hashtable htUserData)
        {
            return this._UserManagementDataService.UpdateConfigureEscalationMatrix(htUserData);
        }
        public DataSet GridEscalationMatrixBind(Hashtable hs)
        {
            return this._UserManagementDataService.GridEscalationMatrixBind(hs);
        }

        public int DeleteEscalationMatrixMap(string hddnMBMapId, string UserId)
        {
            return this._UserManagementDataService.DeleteEscalationMatrixMap(hddnMBMapId, UserId);
        }

        public DataSet BindFieldType()
        {
            return this._UserManagementDataService.BindFieldType();
        }
        public DataSet GetFieldDataandValidationType(Int32 FieldTypeID)
        {
            return this._UserManagementDataService.GetFieldDataandValidationType(FieldTypeID);
        }

        public DataSet Getfieldname(Int32 intFieldMasterID)
        {
            return this._UserManagementDataService.Getfieldname(intFieldMasterID);
        }
        public DataSet BindFieldName(Int32 intFieldMasterID)
        {
            return _UserManagementDataService.BindFieldName(intFieldMasterID);
        }
        public DataSet GetDefaultListValues(Int32 intFieldTypeId, Int32 DynamicDropdownId)
        {
            return _UserManagementDataService.GetDefaultListValues(intFieldTypeId, DynamicDropdownId);
        }
        public DataSet USP_GetConfigureFieldsValidationType_Result(Int32 fldDataTypeID)
        {
            return this._UserManagementDataService.USP_GetConfigureFieldsValidationType_Result(fldDataTypeID);
        }
        public DataSet GetDatetimeFormat(Int32 ValidationTypeID)
        {
            return this._UserManagementDataService.GetDatetimeFormat(ValidationTypeID);
        }
        public DataSet GridMailBoxFieldBind(Hashtable hs)
        {
            return this._UserManagementDataService.GridMailBoxFieldBind(hs);
        }

        public int UpdateConfigureFieldstoMailbox(Hashtable hs)
        {
            return this._UserManagementDataService.UpdateConfigureFieldstoMailbox(hs);
        }

        public int ConfigureFieldtoMailbox(Hashtable htUserData)
        {
            return this._UserManagementDataService.ConfigureFieldtoMailbox(htUserData);
        }

        public int ConfigureOptiontoField(Hashtable htUserData)
        {
            return this._UserManagementDataService.ConfigureOptiontoField(htUserData);
        }
        public int UpdateOptionstoFields(Hashtable htUserData)
        {
            return this._UserManagementDataService.UpdateOptionstoFields(htUserData);
        }
        public DataSet GetOptionvalue(Int32 FieldmasterID)
        {
            return this._UserManagementDataService.GetOptionvalue(FieldmasterID);
        }

        //Pranay 11 August 2016 ---Adding method for adding acknowledgeMail Template
        public int configureacknowledgetomailbox(Hashtable htUserData)
        {
            //return this._UserManagementDataService.configureacknowledgetomailbox(htUserData);
            return this._UserManagementDataService.ConfigureAcknowledgetoMailbox(htUserData);
        }

        //Pranay 16 August 2016--Adding method for binding acknowlegded mailbox in gridview 
        public DataSet GridMailBoxAcknowledgeBind(Hashtable hs)
        {
            return this._UserManagementDataService.GridMailBoxAcknowledgeBind(hs);
        }

        public DataSet getfromStatus(Hashtable hs)
        {
            return this._UserManagementDataService.getfromStatus(hs);
        }

        ////Pranay 16 August 2016--Adding method for updating acknowlegded mailbox
        public int UpdateConfigureAcknowledgetoMailbox(Hashtable htUserData)
        {
            return this._UserManagementDataService.UpdateConfigureAcknowledgetoMailbox(htUserData);
        }

        //Pranay 20 October 2016 -- Method for adding Reference for future user
        public int ConfigureReferencetoMailbox(Hashtable htUserData)
        {
            return this._UserManagementDataService.ConfigureReferencetoMailbox(htUserData);
        }

        //Pranay 21 October 2016 -- Method for adding Reference for future user
        public int UpdateConfigureReferencetoMailbox(Hashtable hs)
        {
            return this._UserManagementDataService.UpdateConfigureReferencetoMailbox(hs);
        }

        //Pranay 21 October 2016 -- method for binding GridView
        public DataSet GridMailBoxReferenceBind(Hashtable hs)
        {
            return this._UserManagementDataService.GridMailBoxReferenceBind(hs);
        }
        
    }
}
