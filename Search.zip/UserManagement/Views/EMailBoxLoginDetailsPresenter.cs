﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;

namespace EMTWebApp.UserManagement.Views
{
    public class EMailBoxLoginDetailsPresenter : Presenter<IEMailBoxLoginDetailsView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        private UserManagementController _controller;
        public EMailBoxLoginDetailsPresenter([CreateNew] UserManagementController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        // TODO: Handle other view events and set state in the view

        public int InsertMailLoginDetails(string MailId, string encryptConfirmPassword, int Locked, int Active)
        {
            return _controller.InsertMailLoginDetails(MailId, encryptConfirmPassword, Locked, Active);
        }

        public DataSet GridEmailBoxLoginDetailsBind()
        {
            return _controller.GridEmailBoxLoginDetailsBind();
        }

        public int UpdateMailBoxLoginDetails(string EmailBoxLoginDetailID, string MailId, string EncryptConfirmPassword, int Locked, int Active)
        {
            return _controller.UpdateMailBoxLoginDetails(EmailBoxLoginDetailID, MailId, EncryptConfirmPassword, Locked, Active);
        }
    }
}




