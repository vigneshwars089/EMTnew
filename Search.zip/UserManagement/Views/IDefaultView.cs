using System;
using System.Collections.Generic;
using System.Text;

namespace EMTWebApp.UserManagement.Views
{
    public interface IDefaultView
    {
    }
}
