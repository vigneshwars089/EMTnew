﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;

namespace EMTWebApp.UserManagement.Views
{
    public class UserMappingPresenter : Presenter<IUserMappingView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        private UserManagementController _controller;
        public UserMappingPresenter([CreateNew] UserManagementController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }
        // TODO: Handle other view events and set state in the view
        public DataSet BindRole()
        {
            return this._controller.BindRole();
        }

        public DataSet BindActiveUsers()
        {
            return this._controller.BindActiveUsers();
        }
        public DataSet BindCountryChekBoxList()
        {
            return this._controller.BindCountryChekBoxList();
        }
        public int MapUserRole(string UserId, int RoleId, string LoginId, string strCountryIdsToMap)
        {
            return this._controller.MapUserRole(UserId, RoleId, LoginId, strCountryIdsToMap);
        }

        public int UpdateRoleMap(string UserRoleMapId, string UserId, int RoleId, string LoginId, string CountryIdsToMap)
        {
            return this._controller.UpdateRoleMap(UserRoleMapId, UserId, RoleId, LoginId, CountryIdsToMap);
        }

        public int DeleteRoleMap(string hddnRMapId)
        {
            return this._controller.DeleteRoleMap(hddnRMapId);
        }

        public DataSet GridUserRoleMapBind()
        {
            return this._controller.GridUserRoleMapBind();
        }
        public DataSet UserWiseRoleMapGridBind(string UserId)
        {
            return this._controller.UserWiseRoleMapGridBind(UserId);
        }
        
    }
}




