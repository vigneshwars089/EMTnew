using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;

namespace EMTWebApp.UserManagement.Views
{
    public class DefaultViewPresenter : Presenter<IDefaultView>
    {
        private IUserManagementController _controller;

        public DefaultViewPresenter([CreateNew] IUserManagementController controller)
        {
            this._controller = controller;
        }
    }
}
