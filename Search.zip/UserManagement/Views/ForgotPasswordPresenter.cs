﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;

namespace EMTWebApp.UserManagement.Views
{
    public class ForgotPasswordPresenter : Presenter<IForgotPasswordView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        private UserManagementController _controller;
        public ForgotPasswordPresenter([CreateNew] UserManagementController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        public int ValidateLogin(string LoginId)
        {
            return _controller.ValidateLogin(LoginId);
        }

        public DataSet ForgotPassword(string loginId)
        {
            return _controller.ForgotPassword(loginId);
        }
        // TODO: Handle other view events and set state in the view
    }
}




