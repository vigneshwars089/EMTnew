﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using System.Collections;

namespace EMTWebApp.UserManagement.Views
{
    public class UserMailBoxMappingPresenter : Presenter<IUserMailBoxMappingView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        private UserManagementController _controller;
        public UserMailBoxMappingPresenter([CreateNew] UserManagementController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        // TODO: Handle other view events and set state in the view

        public DataSet BindActiveUsers()
        {
            return this._controller.BindActiveUsers();
        }
        public DataSet GetCountryByUserIdForDashboard(Hashtable htUserData)
        {
            return this._controller.GetCountryByUserIdForDashboard(htUserData);
        }

        public DataSet BindActiveMailBox(int CountryId, string LoggedInUserId, int LoggedInUserRoleId)
        {
            return this._controller.BindActiveMailBox(CountryId, LoggedInUserId, LoggedInUserRoleId);
        }

        public int MapUserMailBox(string UserId, int MailBoxId, string LoginId)
        {
            return this._controller.MapUserMailBox(UserId, MailBoxId, LoginId);
        }

        public int ConfigureRemaindertoMailbox(Hashtable htUserData)
        {
            return this._controller.ConfigureRemaindertoMailbox(htUserData);
        }
        public int ConfigureCategorytoMailbox(Hashtable htUserData)
        {
            return this._controller.ConfigureCategorytoMailbox(htUserData);
        }

        public DataSet BindCountry()
        {
            return _controller.BindCountry();
        }

        public DataSet GridMailBoxMapBind( Hashtable hs)
        {
            return this._controller.GridMailBoxMapBind(hs);
        }

        public DataSet GridMailBoxRemainderBind(Hashtable hs)
        {
            return this._controller.GridMailBoxRemainderBind(hs);
        }
        public DataSet GridMailBoxcategoryBind(Hashtable hs)
        {
            return this._controller.GridMailBoxcategoryBind(hs);
        }

        public DataSet UserWiseMailBoxMapGridBind(string UserId, string ddlCountryId)
        {
            return this._controller.UserWiseMailBoxMapGridBind(UserId, ddlCountryId);
        }

        public int UpdateUserMailBoxMap(string UserMailBoxMapId, string UserId, int MailBoxId, string LoginId)
        {
            return this._controller.UpdateUserMailBoxMap(UserMailBoxMapId, UserId, MailBoxId, LoginId);
        }
        public int UpdateConfigureRemaindertoMailbox(Hashtable hs)
        {
            return this._controller.UpdateConfigureRemaindertoMailbox(hs);
        }
        public int UpdateConfigurecategorytoMailbox(Hashtable hs)
        {
            return this._controller.UpdateConfigurecategorytoMailbox(hs);
        }

        public int DeleteMailBoxMap(string hddnMBMapId, string UserId)
        {
            return this._controller.DeleteMailBoxMap(hddnMBMapId, UserId);
        }



        public int ConfigureEscalationMatrix(Hashtable htUserData)
        {
            return this._controller.ConfigureEscalationMatrix(htUserData);
        }
        public int UpdateConfigureEscalationMatrix(Hashtable htUserData)
        {
            return this._controller.UpdateConfigureEscalationMatrix(htUserData);
        }
        public DataSet GridEscalationMatrixBind(Hashtable hs)
        {
            return this._controller.GridEscalationMatrixBind(hs);
        }
        public int DeleteEscalationMatrixMap(string hddnMBMapId, string UserId)
        {
            return this._controller.DeleteEscalationMatrixMap(hddnMBMapId, UserId);
        }

        public DataSet BindFieldType()
        {
            return _controller.BindFieldType();
        }

        public DataSet GetFieldDataandValidationType(Int32 FieldTypeID)
        {
            return _controller.GetFieldDataandValidationType(FieldTypeID);
        }

        public DataSet Getfieldname(Int32 intFieldMasterID)
        {
            return _controller.Getfieldname(intFieldMasterID);
        }
        public DataSet BindFieldName(Int32 intFieldMasterID)
        {
            return _controller.BindFieldName(intFieldMasterID);
        }

        public DataSet GetDefaultListValues(Int32 intFieldTypeId, Int32 DynamicDropdownId)
        {
            return _controller.GetDefaultListValues(intFieldTypeId, DynamicDropdownId);
        }
        public DataSet USP_GetConfigureFieldsValidationType_Result(Int32 fldDataTypeID)
        {
            return _controller.USP_GetConfigureFieldsValidationType_Result(fldDataTypeID);
        }
        public DataSet GetDatetimeFormat(Int32 ValidationTypeID)
        {
            return _controller.GetDatetimeFormat(ValidationTypeID);
        }
        public DataSet GridMailBoxFieldBind(Hashtable hs)
        {
            return this._controller.GridMailBoxFieldBind(hs);
        }
        public int UpdateConfigureFieldstoMailbox(Hashtable hs)
        {
            return this._controller.UpdateConfigureFieldstoMailbox(hs);
        }
        public int ConfigureFieldtoMailbox(Hashtable htUserData)
        {
            return this._controller.ConfigureFieldtoMailbox(htUserData);
        }
        public int ConfigureOptiontoField(Hashtable htUserData)
        {
            return this._controller.ConfigureOptiontoField(htUserData);
        }

        public int UpdateOptionstoFields(Hashtable htUserData)
        {
            return this._controller.UpdateOptionstoFields(htUserData);
        }

        public DataSet GetOptionvalue(Int32 FieldmasterID)
        {
            return this._controller.GetOptionvalue(FieldmasterID);
        }
        //pranay 11 august 2016 ---adding method for adding acknowledgemail template
        public int configureacknowledgetomailbox(Hashtable htuserdata)
        {
            return this._controller.configureacknowledgetomailbox(htuserdata);
        }

        //Pranay 16 August 2016--Adding method for binding acknowlegded mailbox in gridview 
        public DataSet GridMailBoxAcknowledgeBind(Hashtable hs)
        {
            return this._controller.GridMailBoxAcknowledgeBind(hs);
        }

        public DataSet getfromStatus(Hashtable hs)
        {
            return _controller.getfromStatus(hs);
        }

        //Pranay 16 August 2016--Method for updating configuration
        public int UpdateConfigureAcknowledgetoMailbox(Hashtable hs)
        {
            return this._controller.UpdateConfigureAcknowledgetoMailbox(hs);
        }

        //Pranay 20 October 2016 -- Method for adding Reference for future user
        public int ConfigureReferencetoMailbox(Hashtable htUserData)
        {
            return this._controller.ConfigureReferencetoMailbox(htUserData);
        }

        //Pranay 21 October 2016 -- method for updating Reference 
        public int UpdateConfigureReferencetoMailbox(Hashtable hs)
        {
            return this._controller.UpdateConfigureReferencetoMailbox(hs);
        }

        //Pranay 21 October 2016 -- method for binding GridView
        public DataSet GridMailBoxReferenceBind(Hashtable hs)
        {
            return this._controller.GridMailBoxReferenceBind(hs);
        }
    }
}




