﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;

namespace EMTWebApp.UserManagement.Views
{
    public class SignaturePresenter : Presenter<ISignatureView>
    {
         private UserManagementController _controller;
         public SignaturePresenter([CreateNew] UserManagementController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }
        public DataSet GetSignature(string UserID)
        {
            return _controller.GetSignature(UserID);
        }
        public int ConfigureSignature(string Signature, string LoginId)
        {
            return _controller.ConfigureSignature(Signature, LoginId);
        }

        public int UpdateSignature(string SignId, string Signature, string LoginId)
        {
            return _controller.UpdateSignature(SignId, Signature, LoginId);
        }

    }
}
