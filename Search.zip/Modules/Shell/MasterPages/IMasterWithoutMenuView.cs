﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EMTWebApp.Shell.MasterPages
{
    public interface IMasterWithoutMenuView
    {
    }
}




