using System;
using EMTWebApp.DataService.Search;
using System.Data;
using System.Collections;

namespace EMTWebApp.Search
{
    public class SearchController : ISearchController
    {
        SearchDataService _SearchDataService = new SearchDataService();

        public SearchController()
        {
        }

        public DataSet GetCountryByUserId(Hashtable ht)
        {
            return this._SearchDataService.GetCountryByUserId(ht);
        }

        public DataSet GetCountryByUserIdForDashboard(Hashtable ht)
        {
            return this._SearchDataService.GetCountryByUserIdForDashboard(ht);
        }
        public DataSet GetMailboxByCountryId(Hashtable ht)
        {
            return this._SearchDataService.GetMailboxByCountryId(ht);
        }
        public DataSet GetMailboxByCountryIdandUserId(Hashtable ht)
        {
            return this._SearchDataService.GetMailboxByCountryIdandUserId(ht);
        }
        public DataSet GetSearchCaseList(Hashtable ht)
        {
            return this._SearchDataService.GetSearchCaseList(ht);
        }
        public DataSet GetSearchExportList(Hashtable ht)
        {
            return this._SearchDataService.GetSearchExportList(ht);
        }
        public DataSet GetAllStatus(Hashtable ht)
        {
            return this._SearchDataService.GetAllStatus(ht);
        }
        public DataSet GetUserIdsByCountryEmailboxRole(Hashtable ht)
        {
            return this._SearchDataService.GetUserIdsByCountryEmailboxRole(ht);
        }
        public DataSet GetSkillSet()
        {
            return this._SearchDataService.GetSkillSet();
        }
        public int UpdateOnReassign(Hashtable ht)
        {
            return this._SearchDataService.UpdateOnReassign(ht);
        }
        public int UpdateCaseFromClarifNeededToClarifReceived(Hashtable ht)
        {
            return this._SearchDataService.UpdateCaseFromClarifNeededToClarifReceived(ht);
        }


        public DataSet IsSkillBasedAllocation(Hashtable ht)
        {
            return this._SearchDataService.IsSkillBasedAllocation(ht);
        }

        //Pranay -3 October 2016
        /// <summary>
        /// Function for Inserting values to StoredProcedure for Reopen Cases
        /// </summary>
        /// <param name="ht"></param>
        /// <returns></returns>
        public int InsertMailForReopenCases(Hashtable ht)
        {
            return Convert.ToInt32(this._SearchDataService.InsertMailForReopenCases(ht));
        }

        //Pranay   -- 3 October 2016
        /// <summary>
        /// Function for Inserting Attachments of Previous caseid to Reopened Cases
        /// </summary>
        /// <param name="ht"></param>
        /// <returns></returns>

        public int InsertAttachmentForReopenCases(Hashtable htcaseid)
        {
            return this._SearchDataService.InsertAttachmentForReopenCases(htcaseid);
        }


        public DataSet LoadCaseDetails(Hashtable hs)
        {
            return this._SearchDataService.LoadCaseDetails(hs);
        }

        //Pranay 24 October 2016 Function to Bind the Flag Criteria based on Mailbox selected
        public DataSet GetFlagCriteriaByEmailboxSelected(Hashtable ht)
        {
            return this._SearchDataService.GetFlagCriteriaByEmailboxSelected(ht);
        }

        ////Pranay -24 October 2016
        ///// <summary>
        ///// Function for Inserting values to StoredProcedure for Flagged Cases
        ///// </summary>
        ///// <param name="ht"></param>
        ///// <returns></returns>
        //public int InsertDetailsForFlaggedCases(Hashtable ht)
        //{
        //    return Convert.ToInt32(this._SearchDataService.InsertDetailsForFlaggedCases(ht));
        //}


        //Pranay -26 October 2016
        /// <summary>
        /// Function for Unflagging cases
        /// </summary>
        /// <param name="ht"></param>
        /// <returns></returns>
        public int UpdateDetailsForUnFlaggedCases(Hashtable ht)
        {
            return Convert.ToInt32(this._SearchDataService.UpdateDetailsForUnFlaggedCases(ht));
        }
    }

}
