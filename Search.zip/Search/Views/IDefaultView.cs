using System;
using System.Collections.Generic;
using System.Text;

namespace EMTWebApp.Search.Views
{
    public interface IDefaultView
    {
    }
}
