using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;

namespace EMTWebApp.Search.Views
{
    public class DefaultViewPresenter : Presenter<IDefaultView>
    {
        private ISearchController _controller;

        public DefaultViewPresenter([CreateNew] ISearchController controller)
        {
            this._controller = controller;
        }
    }
}
