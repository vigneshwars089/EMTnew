﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using System.Collections;
using System.Data;

namespace EMTWebApp.Search.Views
{
    public class SearchPresenter : Presenter<ISearchView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        private SearchController _controller;
        //public void GetCountryByUserId(string userId)
        //{
        //    Hashtable htUserData = new Hashtable();
        //    htUserData.Add("@ASSOCIATEID", userId);
        //    View.BindCountry = this._controller.GetCountryByUserId(htUserData);
        //}
        public SearchPresenter([CreateNew] SearchController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        // TODO: Handle other view events and set state in the view

        public DataSet GetCountryByUserId(Hashtable ht)
        {
            return this._controller.GetCountryByUserId(ht);
        }
        public DataSet GetCountryByUserIdForDashboard(Hashtable ht)
        {
            return this._controller.GetCountryByUserIdForDashboard(ht);
        }
        public DataSet GetMailboxByCountryId(Hashtable ht)
        {
            return this._controller.GetMailboxByCountryId(ht);
        }
        public DataSet GetMailboxByCountryIdandUserId(Hashtable ht)
        {
            return this._controller.GetMailboxByCountryIdandUserId(ht);
        }
        public DataSet GetSearchCaseList(Hashtable ht)
        {
            return this._controller.GetSearchCaseList(ht);
        }
        public DataSet GetSearchExportList(Hashtable ht)
        {
            return this._controller.GetSearchExportList(ht);
        }
        public DataSet GetAllStatus(Hashtable ht)
        {
            return this._controller.GetAllStatus(ht);
        }
        public DataSet GetUserIdsByCountryEmailboxRole(Hashtable ht)
        {
            return this._controller.GetUserIdsByCountryEmailboxRole(ht);
        }
        public DataSet GetSkillSet()
        {
            return _controller.GetSkillSet();
        }
        public int UpdateOnReassign(Hashtable ht)
        {
            return this._controller.UpdateOnReassign(ht);
        }

        public int UpdateCaseFromClarifNeededToClarifReceived(Hashtable ht)
        {
            return this._controller.UpdateCaseFromClarifNeededToClarifReceived(ht);
        }

        public DataSet IsSkillBasedAllocation(Hashtable ht)
        {
            return this._controller.IsSkillBasedAllocation(ht);
        }

        //Pranay -3 October 2016
        /// <summary>
        /// Function for Inserting values to StoredProcedure for Reopen Cases
        /// </summary>
        /// <param name="ht"></param>
        /// <returns></returns>
        public int InsertMailForReopenCases(Hashtable ht)
        {
            return Convert.ToInt32(this._controller.InsertMailForReopenCases(ht));
        }

       //Pranay   -- 3 October 2016
        /// <summary>
        /// Function for Inserting Attachments of Previous caseid to Reopened Cases
        /// </summary>
        /// <param name="ht"></param>
        /// <returns></returns>

        public int InsertAttachmentForReopenCases(Hashtable htcaseid)
        {
            return this._controller.InsertAttachmentForReopenCases(htcaseid);
        }


        public DataSet LoadCaseDetails(long CaseId, int EMailBoxId, string UserId, int StatusId, int RoleId)
        {
            Hashtable hsCaseDetails = new Hashtable();
            if (CaseId == 0)
            {
                hsCaseDetails.Add("@CaseID", DBNull.Value);
            }
            else
            {
                hsCaseDetails.Add("@CaseID", CaseId);
            }
            hsCaseDetails.Add("@EMAILBOXID", EMailBoxId);
            hsCaseDetails.Add("@USERID", UserId);
            hsCaseDetails.Add("@STATUSID", StatusId);
            hsCaseDetails.Add("@ROLEID", RoleId);
            return this._controller.LoadCaseDetails(hsCaseDetails);
        }

        //Pranay 24 October 2016 Function to Bind the Flag Criteria based on Mailbox selected
        public DataSet GetFlagCriteriaByEmailboxSelected(Hashtable ht)
        {
            return this._controller.GetFlagCriteriaByEmailboxSelected(ht);
        }

        ////Pranay -24 October 2016
        ///// <summary>
        ///// Function for Inserting values to StoredProcedure for Flagged Cases
        ///// </summary>
        ///// <param name="ht"></param>
        ///// <returns></returns>
        //public int InsertDetailsForFlaggedCases(Hashtable ht)
        //{
        //    return Convert.ToInt32(this._controller.InsertDetailsForFlaggedCases(ht));
        //}



        //Pranay -26 October 2016
        /// <summary>
        /// Function for Unflagging cases
        /// </summary>
        /// <param name="ht"></param>
        /// <returns></returns>
        public int UpdateDetailsForUnFlaggedCases(Hashtable ht)
        {
            return Convert.ToInt32(this._controller.UpdateDetailsForUnFlaggedCases(ht));
        }
    }
}




