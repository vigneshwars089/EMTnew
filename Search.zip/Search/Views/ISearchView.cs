﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace EMTWebApp.Search.Views
{
    public interface ISearchView
    {
        
    }
}




