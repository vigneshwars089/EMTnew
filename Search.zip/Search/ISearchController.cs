using System;

namespace EMTWebApp.Search
{
    public interface ISearchController
    {
    }
}
