﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Collections.ObjectModel;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.ProvisioningManagement;
using DigiOPS.TechFoundation.Configuration;
using DigiOPS.TechFoundation.Security;
using System.Security;
using System.Runtime.InteropServices;



namespace TenantConfiguration
{
    public class tenantConfig 
    {
        public void CreateTenant(string tenantName, string userId, string effectivefromdate, string effectiveTodate, string InstanceName, string DBServerName, string DBUserName, string DBPassword, string Vertical, string Account, bool SameURL, string customUrl, string OperationName, string UserCount, string MaxNoOfUser)
        {
            //ProxyLogger.Log.Info("TenantController - CreateTenant - Called.");
            string message = string.Empty;
            DigiOPS.TechFoundation.Entities.TenantInfo objmtoup = new DigiOPS.TechFoundation.Entities.TenantInfo();
            // MultiTenantOutput objmtoup = new MultiTenantOutput();
            // MultiTenant objMultiTenancy = new MultiTenant();
            // MultiTenancyInfo objinfo = new MultiTenancyInfo();
            try
            {
                Tenant objMultiTenancy = new Tenant();
                DigiOPS.TechFoundation.Entities.TenantInfo objinfo = new DigiOPS.TechFoundation.Entities.TenantInfo();

                //objinfo.AppID = "1";

                objinfo.DatabaseDetails.ServerName = DBServerName;
                objinfo.DatabaseDetails.DataBaseName = InstanceName;
                objinfo.DatabaseDetails.UserName = DBUserName;
                objinfo.DatabaseDetails.Password = DBPassword;

                objinfo.AppID = ConfigurationManager.AppSettings["AppID"].ToString();
                objinfo.TenantName = tenantName;
                //objinfo.TenantID = Convert.ToInt32(userId);
                objinfo.TenantDetails = new List<DigiOPS.TechFoundation.Entities.TenantInstanceInfo>();
                DigiOPS.TechFoundation.Entities.TenantInstanceInfo objtenat = new DigiOPS.TechFoundation.Entities.TenantInstanceInfo();

                objtenat.TenantUserID = Convert.ToInt32(userId);
                objtenat.InstanceName = InstanceName;// "INST1";
                objtenat.URL = customUrl;
                objtenat.SameURL = SameURL;
                ProductLicenseKey objProductLicenseKey = new ProductLicenseKey();
                LicenseInfo objlinfo = new LicenseInfo();
                LicenseInfo objoutlicinfo = new LicenseInfo();
                objlinfo.MaxNoOfUser = Convert.ToInt32(MaxNoOfUser);
                objlinfo.ToolPurchased = "Quart";
                objlinfo.DateOfPurchase = Convert.ToString(DateTime.Now);
                objlinfo.Version = "1.0";
                objlinfo.InstanceID = InstanceName;
                objlinfo.UserCount = Convert.ToInt32(UserCount);
                //ProxyLogger.Log.Info("TenantController - CreateTenant - Called.");
                objoutlicinfo = objProductLicenseKey.GenerateProductKey(objlinfo);
                if (Convert.ToString(objoutlicinfo.ErrorMessage) != null)
                    objtenat.LicenseKey = objoutlicinfo.EncryptedProductKey;
                else
                    objtenat.LicenseKey = null;

                // objtenat.LicenseKey = objProductLicenseKey.GenerateProductKey(objlinfo);
                // objtenat.LicenseKey = "ABC";
                objtenat.EffectiveFrom = Convert.ToDateTime(effectivefromdate);
                objtenat.EffectiveTo = Convert.ToDateTime(effectiveTodate);
                objtenat.Vertical = Convert.ToInt32(Vertical);
                objtenat.AccountId = Convert.ToInt32(Account);
                objinfo.TenantDetails.Add(objtenat);
                objinfo.OperationName = OperationName;


                //objinfo.AppID = "Quart";
                //objinfo.ServerName = DBServerName;
                //objinfo.DataBaseName = InstanceName;
                //objinfo.UserName = DBUserName;
                //objinfo.Password = DBPassword;

                //objinfo.InstanceName = InstanceName;// "INST1";
                //objinfo.TenantName = tenantName;
                //objinfo.TenantUserID = Convert.ToInt32(userId);
                //objinfo.URL = customUrl;
                //objinfo.SameURL = SameURL;
                //ProductLicenseKey objProductLicenseKey = new ProductLicenseKey();
                //LicenseInfo objlinfo = new LicenseInfo();
                //objlinfo.MaxNoOfUser = Convert.ToInt32(MaxNoOfUser);
                //objlinfo.ToolPurchased = "Quart";
                //objlinfo.DateOfPurchase = Convert.ToString(DateTime.Now);
                //objlinfo.Version = "1.0";
                //objlinfo.InstanceID = InstanceName;
                //objlinfo.UserCount = Convert.ToInt32(UserCount);
                //objinfo.LicenseKey = objProductLicenseKey.GenerateProductKey(objlinfo);
                //objinfo.EffectiveFrom = Convert.ToDateTime(effectivefromdate);
                //objinfo.EffectiveTo = Convert.ToDateTime(effectiveTodate);
                //objinfo.Vertical = Convert.ToInt32(Vertical);
                //objinfo.AccountId = Convert.ToInt32(Account);
                //objinfo.OperationName = OperationName;

                ////objmtoup = objMultiTenancy.SaveTenantDetails(objinfo);

                //if (OperationName == "INSERT")
                //{

                //    string PSScriptPath = ConfigurationManager.AppSettings["PSScript"].ToString();
                //    string SQLScriptPath = ConfigurationManager.AppSettings["SQLScript"].ToString();
                //    objinfo.PSScriptPath = PSScriptPath;
                //    //objMultiTenancyInfo.PSScriptPath = PSScriptPath;
                //    objinfo.SQLScriptPath = SQLScriptPath;
                //    //objMultiTenancyInfo.SQLScriptPath = SQLScriptPath;
                //    objmtoup = objMultiTenancy.GenerateDataBase(objinfo);
                //    if (objmtoup.ResultStatus == false)
                //    {
                //        // message = objmtoup.Output.ToString();
                //    }
                //}
                //else
                //{
                //    objinfo.TenantDBID = Convert.ToInt32(tenantName);
                //}

                //objmtoup = objMultiTenancy.SaveTenantDetails(objinfo);
                //if (objmtoup.ResultStatus == false)
                //{
                //    message = objmtoup.Output.ToString();
                //}
                //else
                //{
                //    message = "Tenant created successfully!";
                //}


                if (OperationName == "INSERT")
                {
                    string PSScriptPath = ConfigurationManager.AppSettings["PSScript"].ToString();
                    string SQLScriptPath = ConfigurationManager.AppSettings["SQLScript"].ToString();
                    objinfo.DatabaseDetails.PSScriptPath = PSScriptPath;
                    //objMultiTenancyInfo.PSScriptPath = PSScriptPath;
                    objinfo.DatabaseDetails.SQLScriptPath = SQLScriptPath;
                    //objMultiTenancyInfo.SQLScriptPath = SQLScriptPath;
                    objmtoup = objMultiTenancy.GenerateDataBase(objinfo); //to generatedb
                    if (objmtoup.ResultStatus == true)
                    {
                        message = objmtoup.Output;
                        objmtoup = objMultiTenancy.SaveTenantDetails(objinfo);//to save tenant info in tool tenant db

                    }
                    else
                    {
                        message = objmtoup.Output.ToString();
                    }
                }
                else
                {
                    objinfo.TenantID = Convert.ToInt32(tenantName);
                    objmtoup = objMultiTenancy.SaveTenantDetails(objinfo);

                    message = objmtoup.Output.ToString();

                }
                //if (string.IsNullOrEmpty(message) || message == "Incorrect syntax near '?'.")
                //{

                //}

            }
            catch (ApplicationException ex)
            {
                //ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
                //objmtoup.Output = Quart.Utility.Constants.mSG_Tnt_InsertionFailed;
            }
            catch (Exception ex)
            {
                //ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);
                //objmtoup.Output = Quart.Utility.Constants.mSG_Tnt_InsertionFailed;
            }

            //return Json(new { message }, JsonRequestBehavior.AllowGet);
        }

    }
}

