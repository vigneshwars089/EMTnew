using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.CompositeWeb;
using Microsoft.Practices.CompositeWeb.Interfaces;
using Microsoft.Practices.CompositeWeb.Services;
using Microsoft.Practices.CompositeWeb.Configuration;
using Microsoft.Practices.CompositeWeb.EnterpriseLibrary.Services;
using EMTWebApp.UserManagement.Common;

namespace EMTWebApp.Utilities
{
    public class UtilitiesModuleInitializer : ModuleInitializer
    {
        private const string AuthorizationSection = "compositeWeb/authorization";
        UserSession UserData = new UserSession();
        UserErrorLog errorlog = new UserErrorLog();
        public override void Load(CompositionContainer container)
        {
            try
            {
                base.Load(container);

                AddGlobalServices(container.Parent.Services);
                AddModuleServices(container.Services);
                RegisterSiteMapInformation(container.Services.Get<ISiteMapBuilderService>(true));

                container.RegisterTypeMapping<IUtilitiesController, UtilitiesController>();
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UtilitiesModuleInitializer.cs | Load()");
            }
        }

        protected virtual void AddGlobalServices(IServiceCollection globalServices)
        {
            // TODO: add a service that will be visible to any module
        }

        protected virtual void AddModuleServices(IServiceCollection moduleServices)
        {
            // TODO: add a service that will be visible to this module
        }

        protected virtual void RegisterSiteMapInformation(ISiteMapBuilderService siteMapBuilderService)
        {
            try
            {
                SiteMapNodeInfo moduleNode = new SiteMapNodeInfo("Utilities", "~/Utilities/Default.aspx", "Utilities");
                siteMapBuilderService.AddNode(moduleNode);
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UtilitiesModuleInitializer.cs | RegisterSiteMapInformation()");
            }

            // TODO: register other site map nodes that Utilities module might provide            
        }

        public override void Configure(IServiceCollection services, System.Configuration.Configuration moduleConfiguration)
        {
            try
            {
                IAuthorizationRulesService authorizationRuleService = services.Get<IAuthorizationRulesService>();
                if (authorizationRuleService != null)
                {
                    AuthorizationConfigurationSection authorizationSection = moduleConfiguration.GetSection(AuthorizationSection) as AuthorizationConfigurationSection;
                    if (authorizationSection != null)
                    {
                        foreach (AuthorizationRuleElement ruleElement in authorizationSection.ModuleRules)
                        {
                            authorizationRuleService.RegisterAuthorizationRule(ruleElement.AbsolutePath, ruleElement.RuleName);
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                errorlog.HandleError(ex, UserData.UserId, " | UtilitiesModuleInitializer.cs | Configure()");
            }
        }
    }
}
