using System;
using EMTWebApp.DataService.Utilities;
using System.Data;
using System.Collections;

namespace EMTWebApp.Utilities
{
    public class UtilitiesController : IUtilitiesController
    {
        IUtilitiesDataService _UtilitiesDataService = new UtilitiesDataService();

        public UtilitiesController()
        {

        }

        internal DataSet BindComments(Hashtable hsParams)
        {
            return this._UtilitiesDataService.BindComments(hsParams);
        }

        internal DataSet BindAuditLog(Hashtable hsParams)
        {
            return this._UtilitiesDataService.BindAuditLog(hsParams);
        }
    }
}
