﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using System.Collections;
using System.Data;

namespace EMTWebApp.Utilities.Views
{
    public class CommentsPresenter : Presenter<ICommentsView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        // private IUtilitiesController _controller;
        // public CommentsPresenter([CreateNew] IUtilitiesController controller)
        // {
        // 		_controller = controller;
        // }
        private UtilitiesController _UtilitiesController;

        public  CommentsPresenter([CreateNew] UtilitiesController controller)
        {
            _UtilitiesController = controller;
        }
         
        public void BindComments(int caseid)
        {
            Hashtable hsParams = new Hashtable();
            hsParams.Add("@CASEID", caseid);
            View.BindComments = _UtilitiesController.BindComments(hsParams);
            
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        // TODO: Handle other view events and set state in the view
    }
}




