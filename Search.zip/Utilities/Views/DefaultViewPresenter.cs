using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;

namespace EMTWebApp.Utilities.Views
{
    public class DefaultViewPresenter : Presenter<IDefaultView>
    {
        private IUtilitiesController _controller;

        public DefaultViewPresenter([CreateNew] IUtilitiesController controller)
        {
            this._controller = controller;
        }
    }
}
