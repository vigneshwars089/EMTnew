﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using System.Collections;
using System.Data;

namespace EMTWebApp.Utilities.Views
{
    public class AuditLogPresenter : Presenter<IAuditLogView>
    {

        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        // private IUtilitiesController _controller;
        // public AuditLogPresenter([CreateNew] IUtilitiesController controller)
        // {
        // 		_controller = controller;
        // }
          private UtilitiesController _UtilitiesController;

          public AuditLogPresenter([CreateNew] UtilitiesController controller)
        {
            _UtilitiesController = controller;
        }


        public void BindAuditLog(int caseid)
        {
            Hashtable hsParams = new Hashtable();
            hsParams.Add("@CASEID", caseid);
            View.BindAuditLog = _UtilitiesController.BindAuditLog(hsParams);

        }
        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        // TODO: Handle other view events and set state in the view
    }
}




