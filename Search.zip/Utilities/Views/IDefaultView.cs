using System;
using System.Collections.Generic;
using System.Text;

namespace EMTWebApp.Utilities.Views
{
    public interface IDefaultView
    {
    }
}
