using System;

namespace EMTWebApp.Utilities
{
    public interface IUtilitiesController
    {
    }
}
