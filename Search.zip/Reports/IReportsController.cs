using System;

namespace EMTWebApp.Reports
{
    public interface IReportsController
    {
    }
}
