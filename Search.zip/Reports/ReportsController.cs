using System;
using System.Data;
using System.Data.SqlClient;
using EMTWebApp.DataService.Reports;
using System.Collections;

namespace EMTWebApp.Reports
{
    public class ReportsController : IReportsController
    {
        //IReportsDataService _ReportsDataService = new ReportsDataService();

        ReportsDataService _ReportsDataService = new ReportsDataService();
        public ReportsController()
        {
        }
        public DataSet BindCountry(Hashtable ht)
        {
            return _ReportsDataService.BindCountry(ht);
        }

        public DataSet BindSubProcessNames(Hashtable ht)
        {
            return _ReportsDataService.BindSubProcessNames(ht);
        }

        public DataSet BindEmailboxNames(int CountryId, int SubProcessId)
        {
            return _ReportsDataService.BindEmailboxNames(CountryId, SubProcessId);
        }

        public DataSet GridAgeingDetBind(string CountryId, string SubProcessId, string EmailBoxId, int Range1, int Range2, int Range3, int Range4,string offset)
        {
            return _ReportsDataService.GridAgeingDetBind(CountryId, SubProcessId, EmailBoxId, Range1, Range2, Range3, Range4,offset);
        }

       
        public DataSet GetCountryByUserIdForDashboard(Hashtable ht)
        {
            return this._ReportsDataService.GetCountryByUserIdForDashboard(ht);
        }

        public DataSet GetSearchCaseList(Hashtable ht, int Report)
        {
            return this._ReportsDataService.GetSearchCaseList(ht, Report);
            
        }

        public DataSet GetMailboxByCountryId(Hashtable ht)
        {
            return this._ReportsDataService.GetMailboxByCountryId(ht);
        }
        public DataSet GetMailboxByCountryIdandUserId(Hashtable ht)
        {
            return this._ReportsDataService.GetMailboxByCountryIdandUserId(ht);
        }
        public DataSet GetSubProcessGroup(Hashtable ht)
        {
            return this._ReportsDataService.GetSubProcessGroup(ht);
        }
        public DataSet BindBaseData(Hashtable ht)
        {
            return this._ReportsDataService.BindBaseData(ht);
        }
        public DataSet GetCategory(Hashtable ht)
        {
            return this._ReportsDataService.GetCategory(ht);
        }
    }
}
