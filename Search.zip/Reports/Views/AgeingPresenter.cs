﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using System.Collections;

namespace EMTWebApp.Reports.Views
{
    public class AgeingPresenter : Presenter<IAgeingView>
    {

        private ReportsController _controller;
        public AgeingPresenter([CreateNew] ReportsController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        public DataSet BindCountry(Hashtable ht)
        {
            return _controller.BindCountry(ht);
        }

        public DataSet BindSubProcessNames(Hashtable ht)
        {
            return _controller.BindSubProcessNames(ht);
        }

        public DataSet BindEmailboxNames(int CountryId, int SubProcessId)
        {
            return _controller.BindEmailboxNames(CountryId, SubProcessId);
        }

        public DataSet GridAgeingDetBind(string CountryId, string SubProcessId, string EmailBoxId, int Range1, int Range2, int Range3, int Range4,string offset)
        {
            return _controller.GridAgeingDetBind(CountryId, SubProcessId, EmailBoxId, Range1, Range2, Range3, Range4,offset);
        }

        public DataSet BindBaseData(Hashtable ht)
        {
            return _controller.BindBaseData(ht);
        }
    }
}
