﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using System.Collections;
using System.Data;

namespace EMTWebApp.Reports.Views
{
    public class TATSplitupPresenter : Presenter<ITATSplitupView>
    {
        // NOTE: Uncomment the following code if you want ObjectBuilder to inject the module controller
        //       The code will not work in the Shell module, as a module controller is not created by default
        //
        private ReportsController _controller;
        public TATSplitupPresenter([CreateNew] ReportsController controller)
         {
             _controller = controller;
         }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }

        //public DataSet GetCountryByUserIdForDashboard(Hashtable ht)
        //{
        //    return this._controller.GetCountryByUserIdForDashboard(ht);
        //}

        public DataSet GetCountryByUserIdForDashboard(Hashtable ht)
        {
            return this._controller.GetCountryByUserIdForDashboard(ht);
        }

        public DataSet GetSearchCaseList(Hashtable ht, int Report)
        {
            return this._controller.GetSearchCaseList(ht, Report);
        }
        public DataSet GetMailboxByCountryId(Hashtable ht)
        {
            return this._controller.GetMailboxByCountryId(ht);
        }
        public DataSet GetMailboxByCountryIdandUserId(Hashtable ht)
        {
            return this._controller.GetMailboxByCountryIdandUserId(ht);
        }
        public DataSet GetSubProcessGroup(Hashtable ht)
        {
            return this._controller.GetSubProcessGroup(ht);
        }
        public DataSet GetCategory(Hashtable ht)
        {
            return this._controller.GetCategory(ht);
        }
        // TODO: Handle other view events and set state in the view
    }
}
