﻿using System;
using EMTWebApp.DataService.Survey;
using System.Data;
using System.Collections;

namespace EMTWebApp.Survey
{
    public class SurveyController:ISurveyController
    {
        ISurveyDataService _surveyDataService = new SurveyDataService();

        public int InsertVOCSurveyDetails(Hashtable htUserData)
        {
            return this._surveyDataService.InsertVOCSurveyDetails(htUserData);
        }
        
    }
}
