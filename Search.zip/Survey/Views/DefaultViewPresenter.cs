﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;

namespace EMTWebApp.Survey.Views
{
    public class DefaultViewPresenter : Presenter<IDefaultView>
    {
        private ISurveyController _controller;

        public DefaultViewPresenter([CreateNew] ISurveyController controller)
        {
            this._controller = controller;
        }
    }
}
