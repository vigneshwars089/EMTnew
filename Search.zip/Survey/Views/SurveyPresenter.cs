﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using System.Collections;
using System.Data;

namespace EMTWebApp.Survey.Views
{
    public class SurveyPresenter : Presenter<ISurveyView>
    {
        private SurveyController _controller;
        public SurveyPresenter([CreateNew] SurveyController controller)
        {
            _controller = controller;
        }

        public override void OnViewLoaded()
        {
            // TODO: Implement code that will be executed every time the view loads
        }

        public override void OnViewInitialized()
        {
            // TODO: Implement code that will be executed the first time the view loads
        }


        public int InsertVOCSurveyDetails(Hashtable htUserData)
        {
            return this._controller.InsertVOCSurveyDetails(htUserData);
        }
    }
}
