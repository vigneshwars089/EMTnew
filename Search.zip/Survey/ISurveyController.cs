﻿using System;

namespace EMTWebApp.Survey
{
    public interface ISurveyController
    {
    }
}
